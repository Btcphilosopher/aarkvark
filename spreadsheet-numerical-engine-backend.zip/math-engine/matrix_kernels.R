#' Matrix Kernels and Safe Mathematics
#'
#' @description This module provides low-level mathematical checks,
#' dimensions validations, and helper routines for matrix safety.

#' Verify if a matrix is symmetric
#' @param A A square numeric matrix
#' @param tol Tolerance for symmetry check
#' @return Logical indicating symmetry
is_symmetric <- function(A, tol = 1e-8) {
  if (!is.matrix(A) || nrow(A) != ncol(A)) return(FALSE)
  return(all(abs(A - t(A)) < tol))
}

#' Safe pseudoinverse (Moore-Penrose Inverse via SVD)
#' @param A Any numeric matrix
#' @param tol Singular value truncation threshold
#' @return Moore-Penrose pseudo-inverse matrix
safe_pseudo_inverse <- function(A, tol = 1e-12) {
  if (!is.matrix(A)) A <- as.matrix(A)
  
  # Compute SVD
  s <- svd(A)
  
  # Invert non-zero singular values
  di_val <- s$d
  di_val_inv <- ifelse(di_val > tol, 1 / di_val, 0)
  
  # Reconstruct
  # A_pinv = V * S_inv * U_T
  s_inv <- diag(di_val_inv, nrow = length(s$v), ncol = length(s$u))
  pinv <- s$v %*% s_inv %*% t(s$u)
  
  return(pinv)
}

#' Safe division to prevent division by zero or NaN
#' @param numerator Numeric vector or matrix
#' @param denominator Numeric vector or matrix
#' @param fallback Fallback value for divisions by zero
#' @return Safe element-wise quotient
safe_divide <- function(numerator, denominator, fallback = 0) {
  res <- numerator / denominator
  res[is.nan(res) | is.infinite(res)] <- fallback
  return(res)
}

#' Verify matrix compliance for operations
#' @param A Target object
#' @return Explicit matrix representation
ensure_matrix <- function(A) {
  if (is.matrix(A)) {
    return(A)
  } else if (is.data.frame(A)) {
    return(as.matrix(A))
  } else if (is.vector(A)) {
    return(matrix(A, ncol = 1))
  } else {
    stop("Input cannot be converted to a matrix.")
  }
}
