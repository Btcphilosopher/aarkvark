#' Statistical Kernel
#'
#' @description Computes comprehensive statistical properties, rolling structures, 
#' and distribution fittings on spreadsheet vector or tabular data.

source("matrix_kernels.R")

#' Compute column-wise statistics
#' @param data Matrix or dataframe representation
#' @return Dataframe with mean, var, sd, min, max, median
compute_summary_stats <- function(data) {
  M <- ensure_matrix(data)
  n_cols <- ncol(M)
  
  col_names <- colnames(M)
  if (is.null(col_names)) {
    col_names <- paste0("V", 1:n_cols)
  }
  
  summary_list <- lapply(1:n_cols, function(j) {
    x <- M[, j, drop = TRUE]
    x_clean <- x[!is.na(x)]
    
    if (length(x_clean) == 0) {
      return(data.frame(
        column = col_names[j], mean = NA, variance = NA, sd = NA,
        min = NA, max = NA, median = NA, count = 0
      ))
    }
    
    return(data.frame(
      column = col_names[j],
      mean = mean(x_clean),
      variance = var(x_clean),
      sd = sd(x_clean),
      min = min(x_clean),
      max = max(x_clean),
      median = median(x_clean),
      count = length(x_clean)
    ))
  })
  
  return(do.call(rbind, summary_list))
}

#' Computes covariance matrix safely
#' @param data Matrix of variables (observations in rows)
#' @return Covariance matrix
compute_covariance <- function(data) {
  M <- ensure_matrix(data)
  return(cov(M, use = "pairwise.complete.obs"))
}

#' Computes Pearson correlation matrix safely
#' @param data Matrix of variables (observations in rows)
#' @return Correlation matrix
compute_correlation <- function(data) {
  M <- ensure_matrix(data)
  return(cor(M, use = "pairwise.complete.obs"))
}

#' Rolling statistics (mean, sd) on vectors
#' @param x Numeric vector
#' @param window Lookback period integer
#' @return List with rolling_mean and rolling_sd
compute_rolling_stats <- function(x, window) {
  if (window <= 0) stop("Window must be positive")
  n <- length(x)
  
  r_mean <- rep(NA, n)
  r_sd <- rep(NA, n)
  
  for (i in window:n) {
    subset <- x[(i - window + 1):i]
    r_mean[i] <- mean(subset, na.rm = TRUE)
    r_sd[i] <- sd(subset, na.rm = TRUE)
  }
  
  return(list(
    rolling_mean = r_mean,
    rolling_sd = r_sd
  ))
}

#' Compute arbitrary quantiles vectorised
#' @param x Numeric vector
#' @param probs Numeric vector of probabilities (0 to 1)
#' @return Quantile values
compute_quantiles <- function(x, probs = c(0.25, 0.5, 0.75)) {
  x_clean <- x[!is.na(x)]
  return(quantile(x_clean, probs = probs))
}

#' Fit normal or lognormal distribution empirically
#' @param x Numeric vector
#' @param dist Character string "normal" or "lognormal"
#' @return Parameter estimations
fit_distribution <- function(x, dist = "normal") {
  x_clean <- x[!is.na(x)]
  
  if (dist == "normal") {
    mu <- mean(x_clean)
    sigma <- sd(x_clean)
    return(list(distribution = "normal", mean = mu, sd = sigma))
  } else if (dist == "lognormal") {
    if (any(x_clean <= 0)) {
      stop("Lognormal distribution requires positive values")
    }
    log_x <- log(x_clean)
    mu_log <- mean(log_x)
    sigma_log <- sd(log_x)
    return(list(distribution = "lognormal", meanlog = mu_log, sdlog = sigma_log))
  } else {
    stop("Unsupported distribution type")
  }
}
