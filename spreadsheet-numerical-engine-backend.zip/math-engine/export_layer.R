#' Spreadsheet Integration Export Layer
#'
#' @description Handles output conversions to CSV buffers or clean representations to be
#' directly ingested by external spreadsheet engines or downstream API pipelines.

source("matrix_kernels.R")

#' Convert a numeric matrix to a clean CSV string representation
#' @param A Matrix to convert
#' @param col_names Optional column header descriptors
#' @param row_names Optional boolean to output row numbers
#' @return A single character string containing the formatted CSV document
export_matrix_to_csv <- function(A, col_names = NULL, row_names = FALSE) {
  A <- ensure_matrix(A)
  
  # Format column headers
  if (!is.null(col_names)) {
    colnames(A) <- col_names
  } else if (is.null(colnames(A))) {
    colnames(A) <- paste0("Column_", 1:ncol(A))
  }
  
  # Write matrix to character connection
  chart_conn <- textConnection("csv_out", "w", local = TRUE)
  write.csv(A, row.names = row_names, file = chart_conn)
  close(chart_conn)
  
  return(paste(csv_out, collapse = "\n"))
}

#' Convert a statistical aggregate results list to a clean key-value dataframe
#' @param stats_list Structured results lists from calculations
#' @return Formatted dataframe for easy spreadsheet reading
format_for_spreadsheet <- function(stats_list) {
  # Standardize list outputs to flattened data frames
  tidy_df <- as.data.frame(stats_list)
  return(tidy_df)
}
