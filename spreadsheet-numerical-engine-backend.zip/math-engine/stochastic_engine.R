#' Stochastic Simulation Engine
#'
#' @description Generates numerical trajectories using stochastic differences,
#' Monte Carlo simulation frameworks, and generic Markov transition state matrices.

source("matrix_kernels.R")

#' Standard Gaussian (normal) noise generator
#' @param n Number of samples to generate
#' @param mean Center bias parameter (default 0)
#' @param sd Dispersion scale parameter (default 1)
#' @return Vector of normal random values
generate_gaussian_noise <- function(n, mean = 0, sd = 1) {
  return(rnorm(n, mean = mean, sd = sd))
}

#' Random Walk process: X_t = X_{t-1} + e_t
#' @param n Time duration steps
#' @param x0 Starting coordinate (default 0)
#' @param drift Constant deterministic step offset (default 0)
#' @param noise_sd Noise standard deviation (default 1)
#' @return Simulated path vector
simulate_random_walk <- function(n, x0 = 0, drift = 0, noise_sd = 1) {
  epsilon <- rnorm(n - 1, mean = drift, sd = noise_sd)
  path <- cumsum(c(x0, epsilon))
  return(path)
}

#' Monte Carlo simulation of Autoregressive process: X_t = phi * X_{t-1} + e_t + drift
#' @param n Time steps per path
#' @param paths Number of sample paths to create
#' @param x0 Initial state
#' @param phi Autoregressive coefficient (usually |phi| < 1 for stationary)
#' @param drift System shift bias constant
#' @param noise_sd Noise standard deviation
#' @return Matrix of size (n x paths) with simulated paths
simulate_monte_carlo <- function(n, paths = 100, x0 = 0, phi = 0.9, drift = 0, noise_sd = 1) {
  sim_results <- matrix(NA, nrow = n, ncol = paths)
  
  for (p in 1:paths) {
    path <- rep(NA, n)
    path[1] <- x0
    epsilon <- rnorm(n - 1, mean = 0, sd = noise_sd)
    
    for (t in 2:n) {
      path[t] <- phi * path[t-1] + drift + epsilon[t-1]
    }
    sim_results[, p] <- path
  }
  
  return(sim_results)
}

#' Simulate state transitions in a generic discrete Markov chain
#' @param n_steps Number of timeline steps to simulated
#' @param transition_matrix Probability transition matrix (K x K)
#' @param initial_state Starting index (1 to K)
#' @return Integer state sequence vector of length n_steps
simulate_markov_chain <- function(n_steps, transition_matrix, initial_state = 1) {
  P <- ensure_matrix(transition_matrix)
  
  # Validation checks
  K <- nrow(P)
  if (ncol(P) != K) stop("Markov transition matrix must be square")
  if (any(abs(rowSums(P) - 1.0) > 1e-6)) {
    # Normalize row sums to ensure stochastic consistency
    P <- P / rowSums(P)
  }
  
  states <- rep(NA, n_steps)
  states[1] <- initial_state
  
  for (t in 2:n_steps) {
    curr <- states[t-1]
    probs <- P[curr, ]
    states[t] <- sample(1:K, size = 1, prob = probs)
  }
  
  return(states)
}
