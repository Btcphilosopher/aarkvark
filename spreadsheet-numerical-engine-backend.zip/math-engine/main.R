#' R Numerical Computation Workspace Setup
#'
#' @description Master workspace initializer which loads all individual mathematical kernels 
#' (linear algebra, stats, timeseries, stochastic simulation, optimizations, exports)
#' and displays a test sequence validating system capabilities.

# Imports
source("matrix_kernels.R")
source("linear_algebra.R")
source("statistics_engine.R")
source("time_series_engine.R")
source("stochastic_engine.R")
source("optimisation_engine.R")
source("transformation_engine.R")
source("export_layer.R")

#' Master API Dispatcher
#' @param operation Character identifier of requested module step
#' @param ... Arguments directed to respective engine functions
#' @return Calculation results object
dispatch_computation <- function(operation, ...) {
  switch(operation,
    "matrix_multiply"     = matrix_multiply(...),
    "eigen"               = eigen_decomposition(...),
    "svd"                 = svd_decomposition(...),
    "rank"                = estimate_rank(...),
    "invert"              = invert_matrix(...),
    "summary"             = compute_summary_stats(...),
    "covariance"         = compute_covariance(...),
    "correlation"        = compute_correlation(...),
    "rolling_stats"       = compute_rolling_stats(...),
    "quantile"            = compute_quantiles(...),
    "lag"                 = compute_lag(...),
    "difference"          = compute_difference(...),
    "ema"                 = compute_ema(...),
    "trend"               = extract_trend(...),
    "random_walk"         = simulate_random_walk(...),
    "monte_carlo"         = simulate_monte_carlo(...),
    "markov_chain"        = simulate_markov_chain(...),
    "least_squares"       = solve_least_squares(...),
    "minimise"            = numerical_minimise(...),
    "normalize"           = normalize_matrix(...),
    "aggregate"           = aggregate_columns(...),
    "to_csv"              = export_matrix_to_csv(...),
    stop("Unknown numerical calculation request")
  )
}

# Self-Verification Test Routine
run_system_diagonsis <- function() {
  cat("========================================================================\n")
  cat("R NUMERICAL CORE COMPILATION DIAGNOSTICS: SUCCESSFUL\n")
  cat("========================================================================\n")
  
  # 1. Linear Algebra
  A <- matrix(c(4, 12, -16, 12, 37, -43, -16, -43, 98), nrow = 3, byrow = TRUE)
  cat("- Matrix validation and symmetry: ", is_symmetric(A), "\n")
  
  # 2. Eigen values
  evs <- eigen_decomposition(A)
  cat("- Eigenvalues: ", paste(round(evs$values, 4), collapse = ", "), "\n")
  
  # 3. Statistics summary
  stats_summary <- compute_summary_stats(A)
  cat("- Summary dimensions: ", nrow(stats_summary), "x", ncol(stats_summary), "\n")
  
  # 4. Stochastic simulations
  walk_path <- simulate_random_walk(10, x0 = 100)
  cat("- Simulated Stochastic Walk length: ", length(walk_path), "\n")
  
  # 5. Optimisation fit
  X_fit <- matrix(c(1, 1, 1, 2, 1, 3, 1, 4), nrow = 4, byrow = TRUE)
  Y_fit <- c(2.1, 4.0, 6.1, 8.0)
  ols_fit <- solve_least_squares(X_fit, Y_fit)
  cat("- OLS R-Squared: ", round(ols_fit$r_squared, 5), "\n")
  cat("========================================================================\n")
}

# Run diagnosis on source execution
if (!interactive()) {
  run_system_diagonsis()
}
