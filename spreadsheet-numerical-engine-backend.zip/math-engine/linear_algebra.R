#' Linear Algebra Kernel
#'
#' @description Implements fundamental linear algebra computations
#' on structured data, including decomposition, inverses, and rank.

source("matrix_kernels.R")

#' Perform fast vectorised matrix multiplication
#' @param A Left hand matrix
#' @param B Right hand matrix
#' @return Numeric matrix product
matrix_multiply <- function(A, B) {
  A <- ensure_matrix(A)
  B <- ensure_matrix(B)
  
  if (ncol(A) != nrow(B)) {
    stop("Dimension mismatch: Columns of A must equal rows of B")
  }
  
  return(A %*% B)
}

#' SVD decomposition
#' @param A Target numeric matrix
#' @return List with u, d, v matrices/vectors
eigen_decomposition <- function(A) {
  A <- ensure_matrix(A)
  if (nrow(A) != ncol(A)) {
    stop("Eigen decomposition requires a square matrix")
  }
  
  # For numerical stability, guarantee matrix is numeric
  storage.mode(A) <- "double"
  
  ev <- eigen(A)
  return(list(
    values = ev$values,
    vectors = ev$vectors
  ))
}

#' Singular Value Decomposition (SVD)
#' @param A Matrix (m x n)
#' @return List containing standard U, D, V matrices
svd_decomposition <- function(A) {
  A <- ensure_matrix(A)
  s <- svd(A)
  return(list(
    u = s$u,
    d = s$d,
    v = s$v
  ))
}

#' Estimate numerical rank using singular values
#' @param A Numeric matrix
#' @param tol Tolerance below which singular values are ignored
#' @return Integer representing the mathematical rank of matrix A
estimate_rank <- function(A, tol = 1e-12) {
  A <- ensure_matrix(A)
  s <- svd(A)
  rank <- sum(s$d > (max(dim(A)) * s$d[1] * tol))
  return(rank)
}

#' Safe inversion using QR decomposition or pseudoinverse
#' @param A Square matrix
#' @return Inverse of A
invert_matrix <- function(A) {
  A <- ensure_matrix(A)
  if (nrow(A) != ncol(A)) {
    stop("Matrix inverse requires a square matrix")
  }
  
  # Try routine inversion first
  inv_matrix <- tryCatch({
    solve(A)
  }, error = function(e) {
    # Fallback to pseudoinverse if matrix is singlar
    safe_pseudo_inverse(A)
  })
  
  return(inv_matrix)
}
