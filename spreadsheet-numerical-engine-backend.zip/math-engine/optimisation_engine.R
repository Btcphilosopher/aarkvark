#' Numerical Optimisation Engine
#'
#' @description Solves systems via ordinary least squares (OLS), objective min/max,
#' and simple gradient-descent / coordinate search steps under optional constraints.

source("matrix_kernels.R")
source("linear_algebra.R")

#' Solve Ordinary Least Squares: beta = (X^T * X)^-1 * X^T * Y
#' @param X Design matrix containing feature observations (m x k)
#' @param Y Response outcome vector (m x 1)
#' @return List with beta coefficients, residuals, and fitted values
solve_least_squares <- function(X, Y) {
  X_mat <- ensure_matrix(X)
  Y_vec <- as.vector(Y)
  
  if (nrow(X_mat) != length(Y_vec)) {
    stop("Dimensions mismatch between feature space and target response vector")
  }
  
  # Compute transpose
  Xt <- t(X_mat)
  # (X^T * X)
  XtX <- Xt %*% X_mat
  # Inverse
  inv_XtX <- invert_matrix(XtX)
  # coefficient beta
  beta <- inv_XtX %*% Xt %*% Y_vec
  
  fitted <- X_mat %*% beta
  residuals <- Y_vec - as.vector(fitted)
  
  return(list(
    coefficients = as.vector(beta),
    fitted_values = as.vector(fitted),
    residuals = residuals,
    r_squared = 1 - (sum(residuals^2) / sum((Y_vec - mean(Y_vec))^2))
  ))
}

#' Simple Coordinate-Descent Numerical Optimizer for multidimensional functions
#' @param objective_func A mathematical function mapping numeric parameters to scale scalar
#' @param start_params Starting initial values vector
#' @param tol Tolerance of optimization progress
#' @param max_iter Iteration count boundary
#' @param lower Optional lower boundary limits
#' @param upper Optional upper boundary limits
#' @return List of optimized par coordinates and minimized objective value
numerical_minimise <- function(objective_func, start_params, tol = 1e-6, max_iter = 500, lower = NULL, upper = NULL) {
  params <- start_params
  n_par <- length(params)
  
  h <- 1e-5 # finite difference step size
  learning_rate <- 0.05
  prev_val <- objective_func(params)
  
  for (iter in 1:max_iter) {
    grad <- rep(0, n_par)
    
    # Estimate gradient using finite differences
    for (i in 1:n_par) {
      temp_params_p <- params
      temp_params_p[i] <- temp_params_p[i] + h
      val_p <- objective_func(temp_params_p)
      
      temp_params_m <- params
      temp_params_m[i] <- temp_params_m[i] - h
      val_m <- objective_func(temp_params_m)
      
      grad[i] <- (val_p - val_m) / (2 * h)
    }
    
    # Gradient descent update step
    new_params <- params - learning_rate * grad
    
    # Clip parameters according to box boundary-constraints (lower/upper bound constraints)
    if (!is.null(lower)) {
      new_params <- pmax(new_params, lower)
    }
    if (!is.null(upper)) {
      new_params <- pmin(new_params, upper)
    }
    
    new_val <- objective_func(new_params)
    
    # If objective value improved, accept step and potentially scale LR
    if (new_val < prev_val) {
      params <- new_params
      if (abs(prev_val - new_val) < tol) {
        break
      }
      prev_val <- new_val
    } else {
      # Reduce step rate if gradient overshot
      learning_rate <- learning_rate * 0.5
      if (learning_rate < 1e-8) {
        break
      }
    }
  }
  
  return(list(
    par = params,
    value = prev_val,
    iterations = iter
  ))
}
