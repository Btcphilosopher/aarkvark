#' Dynamic Transformation Layer
#'
#' @description Operates like spreadsheet row/col vectorized functions:
#' row/col-wise transformations, matrix centering, and grouped segmentations.

source("matrix_kernels.R")

#' Row-wise or col-wise normalization (Z-score scaling)
#' @param A Target numeric matrix
#' @param margin Dimension to scale: 1 for rows, 2 for columns
#' @return Z-score scaled matrix of identical dimension
normalize_matrix <- function(A, margin = 2) {
  A <- ensure_matrix(A)
  
  if (margin == 2) {
    # Column centering and scaling
    means <- colMeans(A, na.rm = TRUE)
    sds <- apply(A, 2, sd, na.rm = TRUE)
    sds[sds == 0] <- 1.0 # prevent nan
    
    scaled <- scale(A, center = means, scale = sds)
    return(scaled)
  } else {
    # Row scaling (transform, standard scale, transform back)
    t_A <- t(A)
    means <- colMeans(t_A, na.rm = TRUE)
    sds <- apply(t_A, 2, sd, na.rm = TRUE)
    sds[sds == 0] <- 1.0
    
    scaled_t <- scale(t_A, center = means, scale = sds)
    return(t(scaled_t))
  }
}

#' Col-wise aggregation sums, averages, counts, mins, maxes
#' @param A Matrix base
#' @return Dataframe summarizing columns
aggregate_columns <- function(A) {
  A <- ensure_matrix(A)
  sums <- colSums(A, na.rm = TRUE)
  means <- colMeans(A, na.rm = TRUE)
  mins <- apply(A, 2, min, na.rm = TRUE)
  maxs <- apply(A, 2, max, na.rm = TRUE)
  counts <- apply(A, 2, function(x) sum(!is.na(x)))
  
  return(data.frame(
    sum = sums,
    mean = means,
    min = mins,
    max = maxs,
    count = counts
  ))
}

#' Reshape matrix from wide to long format (useful for chart ingestion)
#' @param A Numeric matrix with optional headers/row indices
#' @return Long dataframe format containing row, col, and value coordinates
melt_matrix <- function(A) {
  A <- ensure_matrix(A)
  nr <- nrow(A)
  nc <- ncol(A)
  
  col_names <- colnames(A)
  if (is.null(col_names)) {
    col_names <- paste0("Col", 1:nc)
  }
  
  long_df <- data.frame(
    row_idx = rep(1:nr, each = nc),
    col_name = rep(col_names, times = nr),
    value = as.vector(t(A))
  )
  
  return(long_df)
}

#' Simple segmented aggregation (grouped summaries)
#' @param data DataFrame or converted Matrix
#' @param group_vector Categorical variable vector matching height of data
#' @return DataFrame of column mean values segmented by category groups
group_by_means <- function(data, group_vector) {
  M <- as.data.frame(data)
  if (length(group_vector) != nrow(M)) {
    stop("Group vector length must match row count of target table")
  }
  
  res <- aggregate(M, by = list(group = group_vector), FUN = mean, na.rm = TRUE)
  return(res)
}
