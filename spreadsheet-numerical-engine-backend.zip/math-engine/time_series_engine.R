#' Time Series Engine
#'
#' @description Implements shift (lag) operators, difference filters, simple and
#' exponential smoothing, and trend estimation primitives for sequences.

source("matrix_kernels.R")

#' Lag operator shifting a sequence backwards
#' @param x Numeric vector
#' @param k Integer shift count (positive = shift future to past)
#' @param pad Value used for padding shifted areas (default NA)
#' @return Lagged numeric vector
compute_lag <- function(x, k = 1, pad = NA) {
  n <- length(x)
  if (k == 0) return(x)
  if (abs(k) >= n) return(rep(pad, n))
  
  if (k > 0) {
    return(c(rep(pad, k), x[1:(n - k)]))
  } else {
    abs_k <- abs(k)
    return(c(x[(abs_k + 1):n], rep(pad, abs_k)))
  }
}

#' Simple and higher-order differencing
#' @param x Numeric vector
#' @param d Positive integer order of differencing (default = 1)
#' @return Differenced vector
compute_difference <- function(x, d = 1) {
  if (d == 0) return(x)
  if (d < 0) stop("Order of differencing must be non-negative")
  
  res <- x
  for (i in 1:d) {
    res <- res - compute_lag(res, 1)
  }
  return(res)
}

#' Exponential moving average (EMA)
#' @param x Numeric vector
#' @param alpha Smoothing scale parameter between 0 and 1
#' @return Smoothed series
compute_ema <- function(x, alpha = 0.2) {
  if (alpha <= 0 || alpha > 1) stop("Alpha weight must be in (0, 1]")
  n <- length(x)
  ema <- rep(NA, n)
  
  # Base initialization
  for (i in 1:n) {
    if (!is.na(x[i])) {
      ema[i] <- x[i]
      start_idx <- i
      break
    }
  }
  
  if (start_idx < n) {
    for (i in (start_idx + 1):n) {
      if (is.na(x[i])) {
        ema[i] <- ema[i-1] # carry forward
      } else {
        ema[i] <- alpha * x[i] + (1 - alpha) * ema[i-1]
      }
    }
  }
  
  return(ema)
}

#' Trend-Cycle extraction using OLS local regression
#' @param x Numeric vector representing time series
#' @return List with extracted trend, residual, cycle
extract_trend <- function(x) {
  n <- length(x)
  t <- 1:n
  
  # Fit linear trend ignoring NA values
  fit <- lm(x ~ t, na.action = na.exclude)
  trend <- predict(fit, newdata = data.frame(t = t))
  
  # Convert possible residuals to matching lengths
  residuals <- x - trend
  
  return(list(
    trend = as.vector(trend),
    residuals = as.vector(residuals)
  ))
}
