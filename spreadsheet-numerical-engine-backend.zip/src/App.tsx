import React, { useState, useEffect, useMemo } from "react";
import {
  Play,
  FileSpreadsheet,
  Cpu,
  TrendingUp,
  BarChart3,
  Workflow,
  Settings2,
  Sliders,
  Download,
  Plus,
  Trash2,
  RefreshCw,
  Hash,
  Scale,
  ListFilter,
  Columns,
  Sparkles,
  Layers,
  ArrowRight
} from "lucide-react";
import * as MathEngine from "./math-engine";
import { PRESETS, MARKOV_TRANSITION_DEFAULT, QUADRATIC_Q_DEFAULT, QUADRATIC_C_DEFAULT } from "./data-templates";

export default function App() {
  // --- STATE FOR SPREADSHEET EDITOR ---
  const [activePresetIdx, setActivePresetIdx] = useState<number>(0);
  const [headers, setHeaders] = useState<string[]>([...PRESETS[0].headers]);
  const [gridData, setGridData] = useState<number[][]>(PRESETS[0].data.map(row => [...row]));
  const [editingCell, setEditingCell] = useState<{ r: number; c: number } | null>(null);
  const [editingValue, setEditingValue] = useState<string>("");

  // --- TAB NAVIGATION FOR THE CORE COMPUTATION MODULES ---
  const [selectedTab, setSelectedTab] = useState<"linalg" | "stats" | "timeseries" | "stochastic" | "optimise" | "transform">("linalg");

  // --- COMPILATION STATE / LOGS ---
  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [kernelMessage, setKernelMessage] = useState<string>("Workspace kernel loaded. Ready for matrix operations.");
  const [performanceMs, setPerformanceMs] = useState<number>(0.0);
  const [rCodeOutput, setRCodeOutput] = useState<string>("");

  // --- PARAMETERS FOR CORE CALCULATIONS ---
  // Linear Algebra
  const [linalgACols, setLinalgACols] = useState<string[]>([headers[0] || "Asset_A"]);
  const [matrixBValue, setMatrixBValue] = useState<string>("1.5\n0.8\n1.2"); // scalar/vector factor

  // Statistics Engine
  const [statsTargetCol, setStatsTargetCol] = useState<string>("");
  const [statsRollingWindow, setStatsRollingWindow] = useState<number>(3);
  const [distributionType, setDistributionType] = useState<"normal" | "lognormal">("normal");

  // Time Series Engine
  const [tsTargetCol, setTsTargetCol] = useState<string>("");
  const [tsLagK, setTsLagK] = useState<number>(1);
  const [tsDiffD, setTsDiffD] = useState<number>(1);
  const [tsEmaAlpha, setTsEmaAlpha] = useState<number>(0.3);

  // Stochastic Simulation
  const [stochasticSteps, setStochasticSteps] = useState<number>(50);
  const [stochasticDrift, setStochasticDrift] = useState<number>(0.05);
  const [stochasticVol, setStochasticVol] = useState<number>(1.2);
  const [stochasticX0, setStochasticX0] = useState<number>(100);
  const [mcPathsCount, setMcPathsCount] = useState<number>(6); // number of overlay curves
  const [mcPhi, setMcPhi] = useState<number>(0.85); // AR(1) phi
  const [markovTransitionMatrix, setMarkovTransitionMatrix] = useState<number[][]>(MARKOV_TRANSITION_DEFAULT);

  // Optimisation Engine
  const [olsXCols, setOlsXCols] = useState<string[]>([]);
  const [olsYCol, setOlsYCol] = useState<string>("");
  const [optimizerObjective, setOptimizerObjective] = useState<"quadratic" | "sphere" | "rosenbrock">("quadratic");
  const [optLowerConstraint, setOptLowerConstraint] = useState<string>("-5.0, -5.0");
  const [optUpperConstraint, setOptUpperConstraint] = useState<string>("5.0, 5.0");
  const [optInitialVec, setOptInitialVec] = useState<string>("2.0, 3.0");

  // Transformation Layer
  const [transformMargin, setTransformMargin] = useState<1 | 2>(2); // 2 = column scaling, 1 = row scaling

  // --- CONSOLIDATED CALCULATION RESULTS ---
  const [calculationResults, setCalculationResults] = useState<any>({
    linalg: null,
    stats: null,
    timeseries: null,
    stochastic: null,
    optimise: null,
    transform: null
  });

  // --- MONITOR PRESET CLICKS ---
  const loadPreset = (idx: number) => {
    const preset = PRESETS[idx];
    setActivePresetIdx(idx);
    setHeaders([...preset.headers]);
    setGridData(preset.data.map(row => [...row]));
    setEditingCell(null);
    setKernelMessage(`Loaded mathematical spreadsheet preset: "${preset.name}".`);
  };

  // Sync columns on load or grid columns mutation
  useEffect(() => {
    if (headers.length > 0) {
      if (!statsTargetCol || !headers.includes(statsTargetCol)) {
        setStatsTargetCol(headers[0]);
      }
      if (!tsTargetCol || !headers.includes(tsTargetCol)) {
        setTsTargetCol(headers[0]);
      }
      if (!olsYCol || !headers.includes(olsYCol)) {
        setOlsYCol(headers[headers.length - 1] || headers[0]);
      }
      // Clean ols columns to default
      const defaultX = headers.filter((h, i) => i < headers.length - 1);
      if (olsXCols.length === 0 || !olsXCols.every(h => headers.includes(h))) {
        setOlsXCols(defaultX.length > 0 ? defaultX : [headers[0]]);
      }
      if (linalgACols.length === 0 || !linalgACols.every(h => headers.includes(h))) {
        setLinalgACols([headers[0]]);
      }
    }
  }, [headers]);

  // --- GRID EDITOR ROUTINES ---
  const handleCellBlur = (r: number, c: number) => {
    if (editingCell) {
      const parsedVal = parseFloat(editingValue);
      const isValValid = !isNaN(parsedVal) && isFinite(parsedVal);
      const updated = [...gridData];
      updated[r][c] = isValValid ? parsedVal : 0;
      setGridData(updated);
      setEditingCell(null);
    }
  };

  const handleCellKeyDown = (e: React.KeyboardEvent, r: number, c: number) => {
    if (e.key === "Enter") {
      handleCellBlur(r, c);
    } else if (e.key === "Escape") {
      setEditingCell(null);
    }
  };

  const addRow = () => {
    const newRow = new Array(headers.length).fill(0).map((_, i) => {
      // extrapolate based on averages or keep zero
      const colVals = gridData.map(row => row[i]).filter(v => !isNaN(v));
      if (colVals.length === 0) return 1.0;
      const sum = colVals.reduce((a, b) => a + b, 0);
      return Math.round((sum / colVals.length) * 100) / 100;
    });
    setGridData([...gridData, newRow]);
    setKernelMessage("Spreadsheet expansion: Row added successfully.");
  };

  const deleteRow = (rIdx: number) => {
    if (gridData.length <= 2) {
      setKernelMessage("Kernel warning: Matrix height must be at least 2 rows.");
      return;
    }
    const filtered = gridData.filter((_, idx) => idx !== rIdx);
    setGridData(filtered);
    setKernelMessage(`Row ${rIdx + 1} purged.`);
  };

  const addColumn = () => {
    const colLetter = String.fromCharCode(65 + headers.length);
    const colName = `Var_${colLetter}`;
    setHeaders([...headers, colName]);
    const updated = gridData.map(row => [...row, Math.round(Math.random() * 100) / 10]);
    setGridData(updated);
    setKernelMessage(`Spreadsheet dimension expanded: Variable vector column "${colName}" appended.`);
  };

  const deleteColumn = (cIdx: number) => {
    if (headers.length <= 1) {
      setKernelMessage("Kernel constraint: Math engines require at least 1 feature dimension.");
      return;
    }
    const purgedName = headers[cIdx];
    const filteredHeaders = headers.filter((_, idx) => idx !== cIdx);
    const filteredData = gridData.map(row => row.filter((_, idx) => idx !== cIdx));
    setHeaders(filteredHeaders);
    setGridData(filteredData);
    setKernelMessage(`Feature vector "${purgedName}" purged.`);
  };

  const renameColumn = (cIdx: number, newName: string) => {
    const sanitized = newName.trim().replace(/[^a-zA-Z0-9_]/g, "_");
    if (sanitized) {
      const updated = [...headers];
      updated[cIdx] = sanitized;
      setHeaders(updated);
    }
  };

  // --- EXPORT SPREADSHEET BUFFER ---
  const triggerCSVDownload = () => {
    const csvContent = MathEngine.exportToCSV(gridData, headers);
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `math_engine_dataset_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setKernelMessage("CSV binary written. Spreadsheet schema downloaded successfully.");
  };

  // Helper: map a column name to its column data index
  const getColIdx = (name: string) => headers.indexOf(name);
  const getColVector = (name: string): number[] => {
    const idx = getColIdx(name);
    if (idx === -1) return [];
    return gridData.map(row => row[idx]);
  };

  // --- CORE KERNEL TRIGGER ACTION ---
  const executeMathKernel = () => {
    setIsCompiling(true);
    const start_time = performance.now();

    try {
      const currentResults = { ...calculationResults };

      // Ensure data is mathematically clean
      const rawMatrix: number[][] = gridData.map(row => row.map(v => (v === null || isNaN(v) ? 0 : v)));

      if (selectedTab === "linalg") {
        // --- MULTI-VARIABLE DESIGNS ---
        const activeIndices = linalgACols.map(name => getColIdx(name)).filter(idx => idx !== -1);
        const subMatrix: number[][] = rawMatrix.map(row => activeIndices.map(i => row[i]));

        const isSquare = subMatrix.length === subMatrix[0]?.length;
        let transposeRes = MathEngine.transpose(subMatrix);
        let rankValue = MathEngine.estimate_rank(subMatrix);
        let svdValues = MathEngine.svd_decomposition(subMatrix);

        let eigenRes = null;
        let invertRes = null;

        if (isSquare) {
          eigenRes = MathEngine.eigen_decomposition(subMatrix);
          invertRes = MathEngine.invert_matrix(subMatrix);
        } else {
          // If rectangular, compute eigenvalues of square product XtX
          const subMatrix_T = MathEngine.transpose(subMatrix);
          const squareProd = MathEngine.matrix_multiply(subMatrix_T, subMatrix);
          eigenRes = MathEngine.eigen_decomposition(squareProd);
        }

        // Handle B Multiplication
        let multRes = null;
        try {
          const rowsB = matrixBValue.split("\n").map(l => l.split(/\s+|,/).map(parseFloat).filter(v => !isNaN(v)));
          if (rowsB.length > 0 && rowsB[0].length > 0) {
            multRes = MathEngine.matrix_multiply(subMatrix, rowsB);
          }
        } catch (e: any) {
          multRes = `Multiplication error: ${e.message}`;
        }

        currentResults.linalg = {
          subDimensions: `${subMatrix.length} x ${subMatrix[0]?.length}`,
          transpose: transposeRes,
          rank: rankValue,
          svd: svdValues,
          eigen: eigenRes,
          inverse: invertRes,
          mult: multRes,
          isSquare
        };

        // Format R syntax
        setRCodeOutput(
          `# R Linear Algebra Kernel Engine\n` +
          `library(matrixStats)\n\n` +
          `# 1. Instantiate the tabular dataset\n` +
          `A <- matrix(c(${subMatrix.map(r => r.join(", ")).join(",\n             ")}),\n` +
          `            nrow = ${subMatrix.length}, ncol = ${subMatrix[0]?.length}, byrow = TRUE)\n\n` +
          `# 2. Compute operations\n` +
          `A_T <- t(A)\n` +
          `svd_res <- svd(A)\n` +
          `rank_val <- qr(A)$rank\n` +
          (isSquare 
            ? `A_inv <- solve(A)\neig_res <- eigen(A)\n` 
            : `xtx_prod <- t(A) %*% A\neig_res <- eigen(xtx_prod)\n`) +
          `\n# Print Outputs\n` +
          `print(list(rank = rank_val, singular_values = svd_res$d, eigenvalues = eig_res$values))`
        );

      } else if (selectedTab === "stats") {
        // --- STATISTICS ENGINE ---
        const targetVector = getColVector(statsTargetCol);
        
        // Col-wise summaries for everything
        const summaries = MathEngine.compute_summary_stats(rawMatrix, headers);
        const covarianceMat = MathEngine.compute_covariance(rawMatrix);
        const correlationMat = MathEngine.compute_correlation(rawMatrix);

        // Rolling measures
        const rolling = MathEngine.compute_rolling_stats(targetVector, statsRollingWindow);
        const quantiles_list = MathEngine.compute_quantiles(targetVector, [0.10, 0.25, 0.50, 0.75, 0.90]);
        const distributionFit = MathEngine.fit_distribution(targetVector, distributionType);

        currentResults.stats = {
          summaries,
          covariance: covarianceMat,
          correlation: correlationMat,
          rolling,
          quantiles: quantiles_list,
          fit: distributionFit,
          targetName: statsTargetCol
        };

        setRCodeOutput(
          `# R Mathematical Statistics Kernel\n` +
          `# 1. Define complete matrix dataset\n` +
          `M <- matrix(c(${rawMatrix.map(r => r.join(", ")).join(",\n             ")}), \n` +
          `            nrow = ${rawMatrix.length}, ncol = ${rawMatrix[0]?.length}, byrow = TRUE)\n` +
          `colnames(M) <- c(${headers.map(h => `"${h}"`).join(", ")})\n\n` +
          `# 2. Covariance and Pearson Correlation Matrix\n` +
          `sigma_cov <- cov(M, use = "pairwise.complete.obs")\n` +
          `r_corr <- cor(M, use = "pairwise.complete.obs")\n\n` +
          `# 3. Target Vector Metrics\n` +
          `x_vec <- M[, "${statsTargetCol}"]\n` +
          `quantiles <- quantile(x_vec, probs = c(0.10, 0.25, 0.50, 0.75, 0.90))\n\n` +
          `# 4. Fit Distribution\n` +
          (distributionType === "normal"
            ? `dist_mean <- mean(x_vec)\ndist_sd <- sd(x_vec)\nprint(paste("Normal Fit: mu =", dist_mean, "sigma =", dist_sd))`
            : `log_x <- log(x_vec[x_vec > 0])\nmeanlog <- mean(log_x)\nsdlog <- sd(log_x)\nprint(paste("Lognormal Fit: meanlog =", meanlog, "sdlog =", sdlog))`)
        );

      } else if (selectedTab === "timeseries") {
        // --- TIME SERIES ENGINE ---
        const ys = getColVector(tsTargetCol);
        const lagged = MathEngine.compute_lag(ys, tsLagK);
        const differenced = MathEngine.compute_difference(ys, tsDiffD);
        const emaCurve = MathEngine.compute_ema(ys, tsEmaAlpha);
        const trendResult = MathEngine.extract_trend(ys);

        currentResults.timeseries = {
          targetName: tsTargetCol,
          lagged,
          differenced,
          ema: emaCurve,
          trend: trendResult.trend,
          residuals: trendResult.residuals,
          original: ys
        };

        setRCodeOutput(
          `# R Sequence Differencing & Time-Series Extraction\n` +
          `x_series <- c(${ys.join(", ")})\n\n` +
          `# 1. Compute Lag Shift\n` +
          `lag_shift <- function(x, k) {\n` +
          `  if (k > 0) return(c(rep(NA, k), x[1:(length(x)-k)]))\n` +
          `  return(x)\n` +
          `}\n` +
          `x_lagged <- lag_shift(x_series, ${tsLagK})\n\n` +
          `# 2. Differencing Series Filter\n` +
          `diff_series <- diff(x_series, differences = ${tsDiffD})\n\n` +
          `# 3. Simple Exponential Smoothing filter\n` +
          `ema_smoothed <- as.vector(HoltWinters(ts(x_series), alpha = ${tsEmaAlpha}, beta = FALSE, gamma = FALSE)$fitted[,1])\n\n` +
          `# 4. Extract Trend with Ordinary Least Squares\n` +
          `time_t <- 1:length(x_series)\n` +
          `linear_fit <- lm(x_series ~ time_t)\n` +
          `extracted_trend <- predict(linear_fit)\n` +
          `residuals <- residuals(linear_fit)`
        );

      } else if (selectedTab === "stochastic") {
        // --- STOCHASTIC SIMULATION ---
        const lengthN = stochasticSteps;
        
        // Single Random Walk Path
        const randomWalkPath = MathEngine.simulate_random_walk(lengthN, stochasticX0, stochasticDrift, stochasticVol);

        // Monte Carlo Simulation of AR(1) Ensemble
        const mcPathsMatrix = MathEngine.simulate_monte_carlo(lengthN, mcPathsCount, stochasticX0, mcPhi, stochasticDrift, stochasticVol);

        // Markov State transitions
        const markovStatesPath = MathEngine.simulate_markov_chain(lengthN, markovTransitionMatrix, 0);

        currentResults.stochastic = {
          randomWalk: randomWalkPath,
          mc: mcPathsMatrix,
          markov: markovStatesPath,
          n: lengthN
        };

        setRCodeOutput(
          `# R Stochastic Simulator Kernels\n` +
          `set.seed(${Math.floor(Math.random() * 1000)})\n` +
          `n_steps <- ${lengthN}\n\n` +
          `# 1. Gaussian Random Walk (Xt = X_{t-1} + drift + e_t)\n` +
          `noise <- rnorm(n_steps - 1, mean = ${stochasticDrift}, sd = ${stochasticVol})\n` +
          `walk_path <- cumsum(c(${stochasticX0}, noise))\n\n` +
          `# 2. Monte Carlo AR(1) Ensemble Simulation\n` +
          `mc_paths <- matrix(NA, nrow = n_steps, ncol = ${mcPathsCount})\n` +
          `for(p in 1:${mcPathsCount}) {\n` +
          `  p_vec <- rep(NA, n_steps)\n` +
          `  p_vec[1] <- ${stochasticX0}\n` +
          `  for(t in 2:n_steps) {\n` +
          `    p_vec[t] <- ${mcPhi} * p_vec[t-1] + ${stochasticDrift} + rnorm(1, sd = ${stochasticVol})\n` +
          `  }\n` +
          `  mc_paths[, p] <- p_vec\n` +
          `}\n\n` +
          `# 3. Discrete Markov Process state path\n` +
          `P_transition <- matrix(c(${markovTransitionMatrix.map(r => r.join(", ")).join(",\n                         ")}), \n` +
          `                       nrow = ${markovTransitionMatrix.length}, ncol = ${markovTransitionMatrix.length}, byrow = TRUE)\n` +
          `markov_path <- rep(NA, n_steps)\n` +
          `markov_path[1] <- 1\n` +
          `for(t in 2:n_steps) {\n` +
          `  current_state <- markov_path[t-1]\n` +
          `  markov_path[t] <- sample(1:${markovTransitionMatrix.length}, size = 1, prob = P_transition[current_state, ])\n` +
          `}`
        );

      } else if (selectedTab === "optimise") {
        // --- OPTIMISATION ENGINE ---
        
        // A. OLS Regression
        const yVector = getColVector(olsYCol);
        const xIndices = olsXCols.map(name => getColIdx(name)).filter(idx => idx !== -1);
        
        // Build Design Matrix X (including column of 1s for intercept)
        const designX: number[][] = rawMatrix.map(row => [1.0, ...xIndices.map(i => row[i])]);
        
        let olsSolve: MathEngine.OLSResult | null = null;
        try {
          olsSolve = MathEngine.solve_least_squares(designX, yVector);
        } catch (err: any) {
          console.error(err);
        }

        // B. Custom Minimizer Objective Paths
        const parsedLower = optLowerConstraint.split(",").map(parseFloat).filter(v => !isNaN(v));
        const parsedUpper = optUpperConstraint.split(",").map(parseFloat).filter(v => !isNaN(v));
        const parsedInit = optInitialVec.split(",").map(parseFloat).filter(v => !isNaN(v));

        let objectiveFunction = (w: number[]) => 0;
        let dimensionsCount = parsedInit.length || 2;

        if (optimizerObjective === "quadratic") {
          // f(w) = w_1^2 + 2*w_2^2 - w_1*w_2 - w_1 - 2*w_2
          objectiveFunction = (w: number[]) => {
            const w1 = w[0] ?? 0;
            const w2 = w[1] ?? 0;
            return w1 * w1 + 2.0 * w2 * w2 - w1 * w2 - w1 - 2 * w2;
          };
        } else if (optimizerObjective === "sphere") {
          // f(w) = sum(w_i^2)
          objectiveFunction = (w: number[]) => w.reduce((s, val) => s + val * val, 0);
        } else {
          // Rosenbrock Valley: f(w) = (1-w1)^2 + 100*(w2 - w1^2)^2
          objectiveFunction = (w: number[]) => {
            const w1 = w[0] ?? 0;
            const w2 = w[1] ?? 0;
            return Math.pow(1 - w1, 2) + 100 * Math.pow(w2 - w1 * w1, 2);
          };
        }

        // Run iterations track to trace convergence sequence
        const tracePath: number[] = [];
        const traceCoords: number[][] = [];
        const optRun = MathEngine.numerical_minimise(
          (w) => {
            const val = objectiveFunction(w);
            tracePath.push(val);
            traceCoords.push([...w]);
            return val;
          },
          parsedInit.length > 0 ? parsedInit : [2.0, 3.0],
          parsedLower,
          parsedUpper,
          1e-7,
          250
        );

        // Keep a subset of convergence coords for display (e.g. max 15 steps)
        const stepSubset: { iter: number; value: number; coords: number[] }[] = [];
        const gap = Math.max(1, Math.floor(tracePath.length / 10));
        for (let i = 0; i < tracePath.length; i += gap) {
          stepSubset.push({
            iter: i,
            value: tracePath[i],
            coords: traceCoords[i]
          });
        }
        if (tracePath.length - 1 > 0 && (tracePath.length - 1) % gap !== 0) {
          stepSubset.push({
            iter: tracePath.length - 1,
            value: tracePath[tracePath.length - 1],
            coords: traceCoords[tracePath.length - 1]
          });
        }

        currentResults.optimise = {
          ols: olsSolve,
          opt: optRun,
          trace: tracePath.slice(0, 100), // first 100 iterations
          steps: stepSubset,
          objectiveName: optimizerObjective
        };

        setRCodeOutput(
          `# R Minimization and OLS Matrix Solving Backend\n` +
          `# 1. Ordinary Least Squares: Beta estimation\n` +
          `X_design <- matrix(c(${designX.map(r => r.join(", ")).join(",\n                     ")}), \n` +
          `                   nrow = ${designX.length}, byrow = TRUE)\n` +
          `Y_vector <- c(${yVector.join(", ")})\n` +
          `ols_coefs <- solve(t(X_design) %*% X_design) %*% t(X_design) %*% Y_vector\n` +
          `print(paste("OLS Intercept & Slopes:", paste(round(ols_coefs, 5), collapse = ", ")))\n\n` +
          `# 2. General-Purpose Optimisation using Nelder-Mead\n` +
          (optimizerObjective === "quadratic"
            ? `obj_f <- function(w) { w[1]^2 + 2*w[2]^2 - w[1]*w[2] - w[1] - 2*w[2] }\n`
            : optimizerObjective === "sphere"
            ? `obj_f <- function(w) { sum(w^2) }\n`
            : `obj_f <- function(w) { (1 - w[1])^2 + 100 * (w[2] - w[1]^2)^2 }\n`) +
          `opt_res <- optim(par = c(${parsedInit.join(", ")}), fn = obj_f, method = "L-BFGS-B",\n` +
          `                 lower = c(${parsedLower.join(", ")}), upper = c(${parsedUpper.join(", ")}))\n` +
          `print(opt_res)`
        );

      } else if (selectedTab === "transform") {
        // --- TRANSFORMATION LAYER ---
        const normalized = MathEngine.normalize_matrix(rawMatrix, transformMargin);
        const aggregated = MathEngine.aggregate_columns(rawMatrix, headers);
        const melted = MathEngine.melt_matrix(rawMatrix, headers);

        // Calculate segmented groupings if rows are sufficient
        // Create an artificial state categorizer based on a dummy alternate split
        const rowLabels = Array.from({ length: rawMatrix.length }, (_, i) => (i % 2 === 0 ? "Cluster_Alpha" : "Cluster_Beta"));
        const grouped = MathEngine.group_by_means(rawMatrix, rowLabels);

        currentResults.transform = {
          normalized,
          aggregated,
          melted: melted.slice(0, 30), // output subset for preview
          grouped,
          rowLabels
        };

        setRCodeOutput(
          `# R Dataframe Transformations\n` +
          `M_data <- matrix(c(${rawMatrix.map(r => r.join(", ")).join(",\n                   ")}), \n` +
          `                 nrow = ${rawMatrix.length}, byrow = TRUE)\n` +
          `colnames(M_data) <- c(${headers.map(h => `"${h}"`).join(", ")})\n\n` +
          `# 1. Z-Score rescaling margin (margin = ${transformMargin})\n` +
          `norm_data <- scale(M_data, center = TRUE, scale = TRUE)\n\n` +
          `# 2. Column Aggregation summaries\n` +
          `col_sums <- colSums(M_data)\n` +
          `col_means <- colMeans(M_data)\n` +
          `col_mins <- apply(M_data, 2, min)\n` +
          `col_maxs <- apply(M_data, 2, max)\n\n` +
          `# 3. Segemented aggregates\n` +
          `grouped_labels <- rep(c("Cluster_Alpha", "Cluster_Beta"), length.out = nrow(M_data))\n` +
          `grouped_means <- aggregate(as.data.frame(M_data), by = list(group = grouped_labels), FUN = mean)`
        );
      }

      setCalculationResults(currentResults);
      setKernelMessage(`Workspace recalculation sequence success. Deterministic system synchronized.`);
    } catch (e: any) {
      setKernelMessage(`Kernel error: ${e.message}`);
    } finally {
      const end_time = performance.now();
      setPerformanceMs(parseFloat((end_time - start_time).toFixed(3)));
      setIsCompiling(false);
    }
  };

  // Safe execute on tab swap or spreadsheet dimensions mutations
  useEffect(() => {
    executeMathKernel();
  }, [selectedTab, activePresetIdx, gridData.length, headers.length]);


  // Helper selector handlers
  const handleLinalgColToggle = (name: string) => {
    if (linalgACols.includes(name)) {
      if (linalgACols.length > 1) {
        setLinalgACols(linalgACols.filter(c => c !== name));
      } else {
        setKernelMessage("Kernel warning: Linear module requires at least 1 variable column selection.");
      }
    } else {
      setLinalgACols([...linalgACols, name]);
    }
  };

  const handleOlsColToggle = (name: string) => {
    if (name === olsYCol) {
      setKernelMessage("Notice: Slopes cannot include regression outcome dependent variable.");
      return;
    }
    if (olsXCols.includes(name)) {
      setOlsXCols(olsXCols.filter(c => c !== name));
    } else {
      setOlsXCols([...olsXCols, name]);
    }
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans antialiased flex flex-col selection:bg-[#141414]/20">
      
      {/* HEADER BAR (Clean Minimalism Alignment) */}
      <header className="border-b border-[#141414] bg-white/20 backdrop-blur-md px-6 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4 sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-[#141414] text-[#E4E3E0] flex items-center justify-center font-mono font-bold text-lg tracking-wider border border-[#141414] rotate-45 select-none hover:rotate-90 transition-transform duration-350">
            <span className="-rotate-45">R</span>
          </div>
          <div>
            <h1 className="text-xl font-serif italic text-[#141414] tracking-tight">Spreadsheet Numerical Engine Backend</h1>
            <p className="text-xs text-[#141414]/60 font-mono uppercase tracking-wider text-[9px]">Covariance patterns, sequential trends, stochastic simulation, and OLS solvers.</p>
          </div>
        </div>
        
        {/* Core Stats / Sync Diagnostics */}
        <div className="flex items-center gap-3 self-end md:self-auto font-mono text-[10px]">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-white/20 border border-[#141414]/20">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            <span className="text-[#141414]/80 tracking-wider">SYNC: ACTIVE</span>
          </div>
          <div className="px-3 py-1 bg-white/20 border border-[#141414]/20 text-[#141414]/80 tracking-wider">
            COMPUTE: <span className="font-bold text-[#141414]">{performanceMs}MS</span>
          </div>
          <button 
            id="recalculate-main-btn"
            onClick={executeMathKernel} 
            disabled={isCompiling}
            className="flex items-center gap-1.5 cursor-pointer bg-[#141414] hover:bg-white hover:text-[#141414] hover:border-[#141414] text-[#E4E3E0] px-4 py-1.5 border border-transparent font-mono text-[10px] uppercase tracking-widest font-bold transition-all duration-200 active:scale-95 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isCompiling ? 'animate-spin' : ''}`} />
            Recalc Kernel
          </button>
        </div>
      </header>

      {/* WORKSPACE STATUS TICKER */}
      <div className="bg-[#141414] text-[#E4E3E0]/70 px-6 py-1.5 flex items-center justify-between text-[11px] font-mono border-b border-[#141414]">
        <div className="flex items-center gap-2 text-[#E4E3E0] truncate max-w-[80%]">
          <span className="text-green-400 font-bold tracking-wider">▶ SYSTEM DISPATCH:</span>
          <span className="truncate">{kernelMessage}</span>
        </div>
        <div className="text-right text-[#E4E3E0]/50 hidden sm:block tracking-widest text-[10px]">
          SYS_TIME: {new Date().toISOString().slice(11, 19)} UTC
        </div>
      </div>

      {/* CORE FRAME GRID */}
      <div className="flex-1 grid grid-cols-1 xl:grid-cols-12 gap-6 p-6">
        
        {/* LEFT COLUMN (COL-SPAN-5): SPREADSHEET MATRIX EDITOR */}
        <section className="xl:col-span-5 bg-white/10 border border-[#141414] p-6 flex flex-col" id="excel-mock-grid-container">
          <div className="flex items-center justify-between border-b border-[#141414] pb-3 mb-4">
            <div className="flex items-center gap-2">
              <div className="w-3.5 h-3.5 bg-[#141414] rotate-45"></div>
              <h2 className="text-xs font-serif italic uppercase tracking-widest text-[#141414] opacity-80">Structured Table (A Matrix)</h2>
            </div>
            
            {/* Download Output */}
            <button 
              id="download-spreadsheet-csv"
              onClick={triggerCSVDownload} 
              className="text-[10px] flex items-center gap-1 border border-[#141414]/30 bg-white/20 px-3 py-1 cursor-pointer text-[#141414] hover:bg-white/45 font-mono uppercase tracking-wider transition"
              title="Download table raw CSV data"
            >
              <Download className="w-3 h-3" />
              Raw CSV
            </button>
          </div>

          {/* Dataset preset selector */}
          <div className="mb-4 bg-white/20 p-4 border border-[#141414]/20">
            <label className="block text-[10px] font-mono text-[#141414]/60 mb-2 uppercase tracking-widest font-bold">Matrix Presets / Templates</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              {PRESETS.map((p, idx) => (
                <button
                  key={idx}
                  id={`preset-btn-${idx}`}
                  onClick={() => loadPreset(idx)}
                  className={`text-left text-xs p-2.5 transition font-mono border ${
                    activePresetIdx === idx
                      ? "bg-[#141414] text-[#E4E3E0] border-[#141414]"
                      : "bg-white/10 border-[#141414]/10 text-[#141414]/70 hover:bg-white/30"
                  }`}
                >
                  <div className="truncate font-bold uppercase text-[10px]">{p.name}</div>
                  <div className="text-[9px] opacity-60 mt-0.5">{p.data.length}R × {p.headers.length}C</div>
                </button>
              ))}
            </div>
          </div>

          {/* SPREADSHEET GRID VIEW */}
          <div className="flex-1 overflow-auto max-h-[360px] border border-[#141414]/30 bg-white/25">
            <table className="w-full text-left border-collapse table-fixed font-mono text-[11px]">
              <thead className="bg-[#141414]/10 text-[#141414] font-semibold sticky top-0 z-20 border-b border-[#141414]">
                <tr>
                  <th className="w-10 text-center border-r border-[#141414]/30 bg-white/10 select-none text-[9px] text-[#141414]/40"></th>
                  {headers.map((h, cIdx) => (
                    <th key={cIdx} className="px-3 py-1.5 border-r border-[#141414]/30 group select-none min-w-[100px] relative">
                      <div className="flex items-center justify-between">
                        <input
                          type="text"
                          value={h}
                          onChange={(e) => renameColumn(cIdx, e.target.value)}
                          className="font-bold text-[#141414] bg-transparent focus:bg-white outline-none focus:ring-1 focus:ring-[#141414] w-full text-[11px] px-0.5 rounded-none"
                        />
                        <button
                          onClick={() => deleteColumn(cIdx)}
                          className="opacity-0 group-hover:opacity-100 p-0.5 text-[#141414] hover:bg-white/45 rounded transition absolute right-1 cursor-pointer"
                          title={`Purge feature path ${h}`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </th>
                  ))}
                  <th className="w-12 text-center bg-white/10">
                    <button
                      onClick={addColumn}
                      className="p-1 hover:bg-[#141414] hover:text-[#E4E3E0] cursor-pointer text-[#141414]"
                      title="Append variable vector"
                    >
                      <Plus className="w-3.5 h-3.5 mx-auto" />
                    </button>
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white/15 divide-y divide-[#141414]/20">
                {gridData.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-white/35 group">
                    <td className="text-center font-bold text-[#141414]/40 border-r border-[#141414]/30 bg-white/10 py-1 text-[9px] select-none">
                      {rIdx + 1}
                    </td>
                    {row.map((val, cIdx) => (
                      <td
                        key={cIdx}
                        className={`border-r border-[#141414]/20 p-0 relative transition-all ${
                          editingCell?.r === rIdx && editingCell?.c === cIdx
                            ? "ring-1 ring-[#141414] bg-white z-10"
                            : ""
                        }`}
                        onClick={() => {
                          setEditingCell({ r: rIdx, c: cIdx });
                          setEditingValue(val === null || isNaN(val) ? "" : val.toString());
                        }}
                      >
                        {editingCell?.r === rIdx && editingCell?.c === cIdx ? (
                          <input
                            type="text"
                            value={editingValue}
                            onChange={(e) => setEditingValue(e.target.value)}
                            onBlur={() => handleCellBlur(rIdx, cIdx)}
                            onKeyDown={(e) => handleCellKeyDown(e, rIdx, cIdx)}
                            className="w-full h-full border-0 outline-none px-3 py-1 font-mono text-[11px] text-right focus:ring-0"
                            autoFocus
                          />
                        ) : (
                          <div className="px-3 py-1 text-right cursor-text select-none text-[#141414]">
                            {val === null || isNaN(val) ? "NA" : val}
                          </div>
                        )}
                      </td>
                    ))}
                    <td className="text-center opacity-0 group-hover:opacity-100 transition duration-75 p-0">
                      <button
                        onClick={() => deleteRow(rIdx)}
                        className="py-1 px-2 text-[#141414] hover:bg-white/50 cursor-pointer"
                        title="Delete this row"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Add Row Button */}
          <div className="mt-4 flex items-center justify-between font-mono text-[10px]">
            <button
              onClick={addRow}
              className="px-3 py-1.5 border border-[#141414] bg-[#141414] text-[#E4E3E0] hover:bg-transparent hover:text-[#141414] transition duration-150 flex items-center gap-1 cursor-pointer uppercase tracking-widest font-bold"
            >
              <Plus className="w-3 h-3" />
              Add Dataset Row
            </button>
            <div className="text-[10px] font-mono text-[#141414]/60 uppercase tracking-widest font-bold">
              SHAPE: {gridData.length} ROWS × {headers.length} COLS
            </div>
          </div>

          {/* R Code Inspector / Copy Panel */}
          <div className="mt-6 border-t border-[#141414]/30 pt-4 flex-1 flex flex-col min-h-[180px]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold uppercase text-[#141414]/80 font-mono flex items-center gap-1 tracking-widest">
                <Cpu className="w-3.5 h-3.5" />
                Equivalent R Kernel Script
              </span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(rCodeOutput);
                  setKernelMessage("R source copied to clipboard.");
                }}
                className="text-[9px] font-mono cursor-pointer bg-white/20 text-[#141414] px-2.5 py-1 border border-[#141414]/40 hover:bg-white/40 transition uppercase font-bold tracking-wider"
              >
                Copy R Script
              </button>
            </div>
            <pre className="p-3 bg-[#141414] text-gray-300 font-mono text-[10px] leading-relaxed overflow-auto flex-1 h-[200px] border border-[#141414]">
              <code>{rCodeOutput || "# Compute matrix variables to see corresponding R script execution"}</code>
            </pre>
          </div>
        </section>

        {/* RIGHT COLUMN (COL-SPAN-7): NUMERICAL ENGINE MODULE PANEL */}
        <main className="xl:col-span-7 flex flex-col gap-6">
          
          {/* NAVIGATION TAB MODULES HEADER */}
          <nav className="bg-white/10 border border-[#141414] p-1 flex flex-wrap gap-1">
            <button
               id="tab-linalg-btn"
               onClick={() => setSelectedTab("linalg")}
               className={`flex-1 min-w-[90px] py-2 px-3 text-[10px] font-mono font-bold tracking-widest text-center uppercase transition-all cursor-pointer ${
                 selectedTab === "linalg"
                   ? "bg-[#141414] text-[#E4E3E0]"
                   : "bg-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-white/30"
               }`}
            >
              LINALG
            </button>
            <button
               id="tab-stats-btn"
               onClick={() => setSelectedTab("stats")}
               className={`flex-1 min-w-[90px] py-2 px-3 text-[10px] font-mono font-bold tracking-widest text-center uppercase transition-all cursor-pointer ${
                 selectedTab === "stats"
                   ? "bg-[#141414] text-[#E4E3E0]"
                   : "bg-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-white/30"
               }`}
            >
              STATS
            </button>
            <button
               id="tab-timeseries-btn"
               onClick={() => setSelectedTab("timeseries")}
               className={`flex-1 min-w-[90px] py-2 px-3 text-[10px] font-mono font-bold tracking-widest text-center uppercase transition-all cursor-pointer ${
                 selectedTab === "timeseries"
                   ? "bg-[#141414] text-[#E4E3E0]"
                   : "bg-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-white/30"
               }`}
            >
              SEQUENCES
            </button>
            <button
               id="tab-stochastic-btn"
               onClick={() => setSelectedTab("stochastic")}
               className={`flex-1 min-w-[90px] py-2 px-3 text-[10px] font-mono font-bold tracking-widest text-center uppercase transition-all cursor-pointer ${
                 selectedTab === "stochastic"
                   ? "bg-[#141414] text-[#E4E3E0]"
                   : "bg-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-white/30"
               }`}
            >
              STOCHASTIC
            </button>
            <button
               id="tab-optimise-btn"
               onClick={() => setSelectedTab("optimise")}
               className={`flex-1 min-w-[90px] py-2 px-3 text-[10px] font-mono font-bold tracking-widest text-center uppercase transition-all cursor-pointer ${
                 selectedTab === "optimise"
                   ? "bg-[#141414] text-[#E4E3E0]"
                   : "bg-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-white/30"
               }`}
            >
              OPTIMISE
            </button>
            <button
               id="tab-transform-btn"
               onClick={() => setSelectedTab("transform")}
               className={`flex-1 min-w-[90px] py-2 px-3 text-[10px] font-mono font-bold tracking-widest text-center uppercase transition-all cursor-pointer ${
                 selectedTab === "transform"
                   ? "bg-[#141414] text-[#E4E3E0]"
                   : "bg-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-white/30"
               }`}
            >
              TRANSFORMS
            </button>
          </nav>

          {/* ACTIVE CONTENT CARD */}
          <div className="bg-white/15 border border-[#141414] p-6 flex-1 flex flex-col">
            
            {/* 1. LINEAR ALGEBRA SCREEN */}
            {selectedTab === "linalg" && calculationResults.linalg && (
              <div className="flex-1 flex flex-col gap-6" id="linalg-workspace-panel">
                
                {/* Math Specs Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#141414] pb-3 gap-2">
                  <div>
                    <h3 className="text-base font-serif italic text-[#141414]">Core Linear Algebra Module</h3>
                    <p className="text-[10px] text-[#141414]/60 font-mono uppercase tracking-wider">Performs matrix transformations, SVD, eigenvectors, and pseudoinverses.</p>
                  </div>
                  <div className="text-[10px] bg-[#141414] text-[#E4E3E0] font-mono px-3 py-1 uppercase tracking-wider font-bold">
                    MATRIX_A_DIM: {calculationResults.linalg.subDimensions}
                  </div>
                </div>

                {/* Left matrix columns selection */}
                <div className="bg-white/20 p-4 border border-[#141414]/20 grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-[11px]">
                  <div>
                    <label className="block text-[10px] font-bold text-[#141414]/70 mb-2.5 uppercase tracking-wider">Select Submatrix Variables (Columns)</label>
                    <div className="flex flex-wrap gap-1.5">
                      {headers.map((h, i) => (
                        <button
                          key={i}
                          onClick={() => handleLinalgColToggle(h)}
                          className={`text-[10px] px-2.5 py-1 cursor-pointer transition border uppercase font-bold tracking-wider ${
                            linalgACols.includes(h)
                              ? "bg-[#141414] text-[#E4E3E0] border-[#141414]"
                              : "bg-white/10 text-[#141414]/60 border-[#141414]/10 hover:bg-white/30"
                          }`}
                        >
                          {h}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-[#141414]/70 mb-1 uppercase tracking-wider">Factor Vector Matrix (B Coefficients)</label>
                    <span className="text-[9px] text-[#141414]/50 block mb-1.5">Enter coefficients corresponding to count (1 value per row)</span>
                    <textarea
                      value={matrixBValue}
                      onChange={(e) => setMatrixBValue(e.target.value)}
                      className="w-full text-[11px] font-mono bg-white/30 border border-[#141414]/20 rounded-none p-2 h-14 focus:ring-1 focus:ring-[#141414] outline-none text-[#141414]"
                    />
                  </div>
                </div>

                {/* Sub-results details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 font-mono text-[11px]">
                  
                  {/* Singluar Values & Rank */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10">
                    <h4 className="text-[10px] font-bold text-[#141414] uppercase tracking-widest border-b border-[#141414]/20 pb-1.5 mb-3">Singular Value Decomposition (SVD)</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="opacity-60">Rank Estimate:</span>
                        <span className="font-bold">{calculationResults.linalg.rank}</span>
                      </div>
                      <div>
                        <span className="opacity-60 block mb-1.5">Singular Values (Σ Diagonal):</span>
                        <div className="flex gap-1 flex-wrap">
                          {calculationResults.linalg.svd.d.map((val: number, i: number) => (
                            <span key={i} className="bg-white/30 border border-[#141414]/20 px-2 py-0.5 text-[10px]">
                              {val.toFixed(4)}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      {/* SVD graphical spectrum bar */}
                      <div className="mt-4">
                        <span className="text-[9px] opacity-50 block mb-1 uppercase tracking-wider">SVD Variance Spectrum</span>
                        <div className="w-full bg-[#141414]/15 h-1.5 flex">
                          {calculationResults.linalg.svd.d.map((val: number, i: number, arr: number[]) => {
                            const total = arr.reduce((a, b) => a + b, 0);
                            const percent = total > 0 ? (val / total) * 100 : 0;
                            return (
                              <div
                                key={i}
                                style={{ width: `${percent}%` }}
                                className={`h-full ${
                                  i === 0 ? "bg-[#141414]" : i === 1 ? "bg-[#141414]/75" : "bg-[#141414]/40"
                                }`}
                                title={`Sigma_${i+1}: ${percent.toFixed(1)}%`}
                              />
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Eigenvalues Spectral Analysis */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10">
                    <h4 className="text-[10px] font-bold text-[#141414] uppercase tracking-widest border-b border-[#141414]/20 pb-1.5 mb-3">
                      {calculationResults.linalg.isSquare ? "Symmetric Eigenvalues" : "Scatter Eigenvalues (A^T * A)"}
                    </h4>
                    <div className="space-y-3">
                      <div>
                        <span className="opacity-60 block mb-1.5">Model Eigenvalues (λ):</span>
                        <div className="flex flex-wrap gap-1">
                          {calculationResults.linalg.eigen?.values.map((val: number, i: number) => (
                            <span
                              key={i}
                              className={`px-2 py-0.5 text-[10px] border ${
                                val >= 0 
                                  ? "bg-white/40 text-green-800 border-green-200" 
                                  : "bg-white/30 text-rose-800 border-rose-200"
                              }`}
                            >
                              {val.toFixed(4)}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="text-[9px] opacity-50 leading-relaxed uppercase">
                        {calculationResults.linalg.isSquare 
                          ? "Symmetric square matrix yields real eigenvalues." 
                          : "Rectangular dimension Scatter eigenvalues computed on correlation product square."}
                      </div>
                    </div>
                  </div>

                </div>

                {/* Splay Matrices Layout */}
                <div className="border border-[#141414]/20 p-4 bg-white/15 flex flex-col font-mono text-[11px]">
                  <span className="text-[10px] font-bold text-[#141414] mb-2 uppercase tracking-wider block">Inverse Matrix Inverse (A^-1) coordinates</span>
                  {calculationResults.linalg.isSquare && calculationResults.linalg.inverse ? (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <tbody>
                          {calculationResults.linalg.inverse.map((row: number[], r: number) => (
                            <tr key={r}>
                              {row.map((val: number, c: number) => (
                                <td key={c} className="border border-[#141414]/25 py-1.5 px-3 text-right bg-white/20 text-[#141414]">
                                  {val.toFixed(4)}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-[10px] text-[#141414]/70 bg-white/10 border border-[#141414]/25 p-3 select-none uppercase tracking-wider font-semibold">
                      INVERSE WARNING: Dimension is not square ({calculationResults.linalg.subDimensions}). Select subcolumns count equal to matrix width grid row count ({gridData.length}).
                    </div>
                  )}

                  {calculationResults.linalg.mult && typeof calculationResults.linalg.mult !== "string" && (
                    <div className="mt-4 border-t border-[#141414]/20 pt-3">
                      <span className="text-[10px] font-bold text-[#141414] mb-2 block uppercase tracking-wider">Product Matrix (A × B Coefficients Vector Column)</span>
                      <div className="max-h-24 overflow-y-auto text-[10px] flex gap-1.5 flex-wrap">
                        {calculationResults.linalg.mult.map((row: number[], idx: number) => (
                          <div key={idx} className="bg-white/25 border border-[#141414]/20 px-2.5 py-1 text-right tracking-tight">
                            [{idx+1}]: <span className="font-bold">{row[0]?.toFixed(4)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

              </div>
            )}

            {/* 2. STATISTICS ENGINE SCREEN */}
            {selectedTab === "stats" && calculationResults.stats && (
              <div className="flex-1 flex flex-col gap-6" id="stats-workspace-panel">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#141414] pb-3 gap-2">
                  <div>
                    <h3 className="text-base font-serif italic text-[#141414]">Statistical Calculation Engine</h3>
                    <p className="text-[10px] text-[#141414]/60 font-mono uppercase tracking-wider">Analyzes moments of multivariate rows, covariance dispersions, and fits probability maps.</p>
                  </div>
                  
                  {/* Select variable target */}
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="font-mono text-[#141414]/70 uppercase tracking-wider text-[10px] font-bold">Target Vector:</span>
                    <select
                      value={statsTargetCol}
                      onChange={(e) => setStatsTargetCol(e.target.value)}
                      className="bg-white/20 border border-[#141414]/20 py-1 px-1.5 font-mono text-xs focus:ring-1 focus:ring-[#141414] outline-none cursor-pointer text-[#141414]"
                    >
                      {headers.map((h, i) => (
                        <option key={i} value={h}>{h}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Descriptive Table summary */}
                <div className="overflow-x-auto border border-[#141414]/30 bg-white/10">
                  <table className="w-full text-left font-mono text-[11px] whitespace-nowrap">
                    <thead className="bg-[#141414]/10 text-[#141414] border-b border-[#141414]">
                      <tr>
                        <th className="px-4 py-2 border-r border-[#141414]/20">Feature Column</th>
                        <th className="px-4 py-2 border-r border-[#141414]/20 text-right">Mean (μ)</th>
                        <th className="px-4 py-2 border-r border-[#141414]/20 text-right">Variance (σ²)</th>
                        <th className="px-4 py-2 border-r border-[#141414]/20 text-right">Std Dev (σ)</th>
                        <th className="px-4 py-2 border-r border-[#141414]/20 text-right">Median</th>
                        <th className="px-4 py-2 text-right">Count</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#141414]/20 bg-white/15">
                      {calculationResults.stats.summaries.map((s: any, idx: number) => (
                        <tr key={idx} className={s.column === statsTargetCol ? "bg-white/35 font-bold" : ""}>
                          <td className="px-4 py-2 border-r border-[#141414]/20 text-[#141414]">{s.column}</td>
                          <td className="px-4 py-2 border-r border-[#141414]/20 text-right">{s.mean.toFixed(4)}</td>
                          <td className="px-4 py-2 border-r border-[#141414]/20 text-right">{s.variance.toFixed(4)}</td>
                          <td className="px-4 py-2 border-r border-[#141414]/20 text-right">{s.sd.toFixed(4)}</td>
                          <td className="px-4 py-2 border-r border-[#141414]/20 text-right">{s.median.toFixed(4)}</td>
                          <td className="px-4 py-2 text-right text-[#141414]/70">{s.count}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  
                  {/* COVARIANCE HEATMAP */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10 flex flex-col">
                    <h4 className="text-[10px] font-bold text-[#141414] font-mono mb-2 border-b border-[#141414]/20 pb-1.5 uppercase tracking-widest">Pearson Correlation Matrix</h4>
                    <div className="flex-1 flex flex-col justify-center">
                      <div className="grid" style={{ gridTemplateColumns: `repeat(${headers.length}, minmax(0, 1fr))` }}>
                        {calculationResults.stats.correlation.map((row: number[], r: number) =>
                          row.map((val: number, c: number) => {
                            return (
                              <div
                                key={`${r}-${c}`}
                                className="aspect-square border border-[#141414]/25 flex flex-col items-center justify-center p-1 text-center transition duration-150 group relative font-mono cursor-default"
                                style={{
                                  backgroundColor: val > 0 
                                    ? `rgba(20, 20, 20, ${Math.max(0.05, val * 0.4)})` 
                                    : `rgba(20, 20, 20, ${Math.max(0.05, Math.abs(val) * 0.4)})`
                                }}
                              >
                                <span className="text-[10px] md:text-xs font-bold text-[#141414]">{val.toFixed(2)}</span>
                                <div className="absolute hidden group-hover:block bg-[#141414] text-[#E4E3E0] p-1.5 text-[9px] -top-8 z-30 pointer-events-none whitespace-nowrap border border-[#141414]">
                                  {headers[r]} × {headers[c]}: {val.toFixed(4)}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                      
                      {/* Headers guide */}
                      <div className="mt-3 flex gap-2 flex-wrap items-center justify-center text-[9px] font-bold font-mono text-[#141414]/60 uppercase tracking-widest">
                        {headers.map((h, i) => (
                          <div key={i} className="flex items-center gap-1">
                            <span className="w-1.5 h-1.5 bg-[#141414]/40 inline-block"></span>
                            <span>[{i+1}]: {h}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Distribution Fit & Rolling bounds chart */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10 flex flex-col">
                    <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-[#141414]/20">
                      <h4 className="text-[10px] font-bold text-[#141414] font-mono uppercase tracking-widest">Rolling Stats Analysis</h4>
                      <div className="flex items-center gap-1.5 text-[10px] font-mono">
                        <span className="opacity-60 text-[9px] font-bold">WINDOW:</span>
                        <input
                          type="number"
                          value={statsRollingWindow}
                          min={2}
                          max={gridData.length}
                          onChange={(e) => setStatsRollingWindow(Math.max(2, parseInt(e.target.value) || 2))}
                          className="w-10 text-center border border-[#141414]/25 bg-white/20 text-[#141414] outline-none"
                        />
                      </div>
                    </div>

                    {/* SVG mini plot chart of original series, rolling mean with standard deviation band */}
                    <div className="flex-1 min-h-[140px] relative bg-white/5 border border-[#141414]/20 p-2 overflow-hidden flex flex-col justify-between">
                      {/* Interactive SVG Renderer */}
                      {(() => {
                        const original = getColVector(statsTargetCol);
                        const rolling = calculationResults.stats.rolling;
                        
                        const nonNaOrig = original.filter(v => !isNaN(v));
                        const maxVal = Math.max(...nonNaOrig, 1);
                        const minVal = Math.min(...nonNaOrig, 0);
                        const range = maxVal - minVal || 1.0;

                        const width = 360;
                        const height = 110;
                        const padding = 15;

                        // Calculate points
                        const getCoords = (idx: number, val: number) => {
                          const x = padding + (idx / (original.length - 1)) * (width - padding * 2);
                          const y = height - padding - ((val - minVal) / range) * (height - padding * 2);
                          return { x, y };
                        };

                        const pointsOriginal = original.map((v, i) => getCoords(i, v));
                        const pointsRolling = original.map((v, i) => {
                          const rm = rolling.rolling_mean[i];
                          return isNaN(rm) ? null : getCoords(i, rm);
                        }).filter(p => p !== null) as {x: number; y: number}[];

                        return (
                          <svg className="w-full h-full" viewBox={`0 0 ${width} ${height}`}>
                            {/* Gridlines */}
                            <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#141414" strokeWidth={1} />
                            <line x1={padding} y1={padding} x2={width - padding} y2={padding} stroke="#141414" strokeWidth={1} strokeDasharray="3 3"/>
                            
                            {/* Rolling mean line */}
                            {pointsRolling.length > 1 && (
                              <path
                                d={`M ${pointsRolling.map(p => `${p.x},${p.y}`).join(" L ")}`}
                                fill="none"
                                stroke="#141414"
                                strokeWidth={1.5}
                              />
                            )}

                            {/* Original points */}
                            {pointsOriginal.map((p, idx) => (
                              <circle
                                key={idx}
                                cx={p.x}
                                cy={p.y}
                                r={original[idx] === Math.max(...original) ? 4.5 : 3}
                                className="fill-[#141414] hover:fill-[#141414]/70 cursor-pointer"
                                title={`Index ${idx+1}: ${original[idx]}`}
                              />
                            ))}
                          </svg>
                        );
                      })()}

                      <div className="flex justify-between text-[9px] font-mono text-[#141414]/75 px-1 pt-1 border-t border-[#141414]/15 mt-1">
                        <div className="flex items-center gap-1">
                          <span className="w-2.5 h-1 bg-[#141414] inline-block"></span>
                          <span>Original</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="w-2.5 h-1 bg-[#111827]/40 border-t border-dashed inline-block"></span>
                          <span>Rolling Mean (W={statsRollingWindow})</span>
                        </div>
                      </div>
                    </div>
                    
                    {/* Quantiles summary */}
                    <div className="mt-3 bg-white/10 border border-[#141414]/20 p-2 text-xs font-mono">
                      <span className="text-[9px] text-[#141414]/60 block uppercase font-bold mb-1 tracking-widest">Empirical Quantiles Structure</span>
                      <div className="grid grid-cols-5 text-center divide-x divide-[#141414]/20">
                        <div>
                          <div className="text-[9px] text-[#141414]/50">P10</div>
                          <div className="font-bold text-[#141414]">{calculationResults.stats.quantiles[0]?.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-[9px] text-[#141414]/50">P25</div>
                          <div className="font-bold text-[#141414]">{calculationResults.stats.quantiles[1]?.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-[9px] text-[#141414]/50">P50 (Med)</div>
                          <div className="font-bold text-[#141414]">{calculationResults.stats.quantiles[2]?.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-[9px] text-[#141414]/50">P75</div>
                          <div className="font-bold text-[#141414]">{calculationResults.stats.quantiles[3]?.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-[9px] text-[#141414]/50">P90</div>
                          <div className="font-bold text-[#141414]">{calculationResults.stats.quantiles[4]?.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>

              </div>
            )}

            {/* 3. TIME SERIES ENGINE SCREEN */}
            {selectedTab === "timeseries" && calculationResults.timeseries && (
              <div className="flex-1 flex flex-col gap-6" id="timeseries-workspace-panel">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#141414] pb-3 gap-2">
                  <div>
                    <h3 className="text-base font-serif italic text-[#141414]">Time Series Modeling Layer</h3>
                    <p className="text-[10px] text-[#141414]/60 font-mono uppercase tracking-wider">Transforms sequential data with lag filters, exponential moving smoothing, and trend residuals extraction.</p>
                  </div>
                  
                  {/* Select variable target */}
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="font-mono text-[#141414]/70 uppercase tracking-wider text-[10px] font-bold">TS Target:</span>
                    <select
                      value={tsTargetCol}
                      onChange={(e) => setTsTargetCol(e.target.value)}
                      className="bg-white/20 border border-[#141414]/20 py-1 px-1.5 font-mono text-xs focus:ring-1 focus:ring-[#141414] outline-none cursor-pointer text-[#141414]"
                    >
                      {headers.map((h, i) => (
                        <option key={i} value={h}>{h}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* SATE CONFIG CONTROLS */}
                <div className="bg-white/20 p-4 border border-[#141414]/20 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
                  
                  {/* Lag control */}
                  <div>
                    <label className="block font-bold text-[#141414]/70 mb-2 uppercase text-[9px] tracking-wider">Back-Lag Shift (k)</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min={1}
                        max={Math.min(5, gridData.length - 2)}
                        value={tsLagK}
                        onChange={(e) => setTsLagK(parseInt(e.target.value))}
                        className="w-full h-1 bg-[#141414]/20 appearance-none cursor-pointer accent-black"
                      />
                      <span className="w-8 font-bold text-center bg-white/25 border border-[#141414]/20 py-0.5 text-[#141414]">{tsLagK}</span>
                    </div>
                  </div>

                  {/* Difference order */}
                  <div>
                    <label className="block font-bold text-[#141414]/70 mb-2 uppercase text-[9px] tracking-wider">Difference Order (d)</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min={1}
                        max={3}
                        value={tsDiffD}
                        onChange={(e) => setTsDiffD(parseInt(e.target.value))}
                        className="w-full h-1 bg-[#141414]/20 appearance-none cursor-pointer accent-black"
                      />
                      <span className="w-8 font-bold text-center bg-white/25 border border-[#141414]/20 py-0.5 text-[#141414]">{tsDiffD}</span>
                    </div>
                  </div>

                  {/* EMA alpha */}
                  <div>
                    <label className="block font-bold text-[#141414]/70 mb-2 uppercase text-[9px] tracking-wider">EMA Weight (α)</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min={0.05}
                        max={1.0}
                        step={0.05}
                        value={tsEmaAlpha}
                        onChange={(e) => setTsEmaAlpha(parseFloat(parseFloat(e.target.value).toFixed(2)))}
                        className="w-full h-1 bg-[#141414]/20 appearance-none cursor-pointer accent-black"
                      />
                      <span className="w-12 font-bold text-center bg-white/25 border border-[#141414]/20 py-0.5 text-[#141414]">{tsEmaAlpha}</span>
                    </div>
                  </div>

                </div>

                {/* Visual Chart for Trend & Alpha EMA */}
                <div className="border border-[#141414]/20 p-4 bg-white/10 flex flex-col flex-1 min-h-[220px]">
                  <h4 className="text-[10px] font-bold text-[#141414] font-mono mb-2 uppercase tracking-widest pb-1 border-b border-[#141414]/10">OLS Linear Trend Extraction Overlay</h4>
                  
                  <div className="flex-1 bg-white/5 border border-[#141414]/20 p-3 overflow-hidden flex flex-col justify-between">
                    {(() => {
                      const original = calculationResults.timeseries.original;
                      const trend = calculationResults.timeseries.trend;
                      const ema = calculationResults.timeseries.ema;

                      const maxVal = Math.max(...original, ...trend, 1);
                      const minVal = Math.min(...original, ...trend, 0);
                      const range = maxVal - minVal || 1.0;

                      const width = 500;
                      const height = 150;
                      const padding = 20;

                      const getCoords = (idx: number, val: number) => {
                        const x = padding + (idx / (original.length - 1)) * (width - padding * 2);
                        const y = height - padding - ((val - minVal) / range) * (height - padding * 2);
                        return { x, y };
                      };

                      const pointsOrig = original.map((v: number, i: number) => getCoords(i, v));
                      const pointsTrend = trend.map((v: number, i: number) => getCoords(i, v));
                      const pointsEma = ema.map((v: number, i: number) => isNaN(v) ? null : getCoords(i, v)).filter((p: any) => p !== null);

                      return (
                        <svg className="w-full h-full" viewBox={`0 0 ${width} ${height}`}>
                          {/* Grid references */}
                          <line x1={padding} y1={height/2} x2={width-padding} y2={height/2} stroke="#141414" strokeWidth={1} strokeOpacity={0.15} />
                          <line x1={padding} y1={height-padding} x2={width-padding} y2={height-padding} stroke="#141414" strokeWidth={1} strokeOpacity={0.25} />
                          
                          {/* Ema curve */}
                          {pointsEma.length > 1 && (
                            <path
                              d={`M ${pointsEma.map((p: any) => `${p.x},${p.y}`).join(" L ")}`}
                              fill="none"
                              stroke="#141414"
                              strokeWidth={1}
                              strokeDasharray="3 3"
                            />
                          )}

                          {/* OLS trend line */}
                          {pointsTrend.length > 1 && (
                            <path
                              d={`M ${pointsTrend.map((p: any) => `${p.x},${p.y}`).join(" L ")}`}
                              fill="none"
                              stroke="#141414"
                              strokeWidth={1.5}
                            />
                          )}

                          {/* Original timeline point markers */}
                          {pointsOrig.map((p: any, idx: number) => (
                            <circle
                              key={idx}
                              cx={p.x}
                              cy={p.y}
                              r={3.5}
                              className="fill-[#141414] hover:fill-[#141414]/70 cursor-pointer"
                              title={`T_${idx+1}: ${original[idx]}`}
                            />
                          ))}
                        </svg>
                      );
                    })()}
                  </div>

                  <div className="flex gap-4 text-[9px] font-mono text-[#141414]/70 justify-between pt-2 border-t border-[#141414]/10 mt-1">
                    <div className="flex items-center gap-1">
                      <span className="w-3 h-1.5 bg-[#141414] inline-block"></span>
                      <span>Original Observation</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="w-3 h-0.5 bg-[#141414]/80 inline-block"></span>
                      <span>OLS Trend (f(t) = a + b * t)</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="w-3 h-0.5 border-t border-dashed border-[#141414]/50 inline-block"></span>
                      <span>Exponential Smoothing (Alpha={tsEmaAlpha})</span>
                    </div>
                  </div>
                </div>

                {/* Print transformation values list */}
                <div className="bg-white/20 border border-[#141414]/20 p-4 font-mono text-[11px]">
                  <span className="text-[10px] text-[#141414]/65 block uppercase font-bold mb-2 tracking-wider">Detailed Sequence Shifts Ledger</span>
                  <div className="overflow-x-auto max-h-[120px]">
                    <table className="w-full text-left font-mono">
                      <thead className="text-[#141414]/60 border-b border-[#141414]/20">
                        <tr>
                          <th className="pr-4 py-1">Time (t)</th>
                          <th className="pr-4 py-1 text-right">Orig (Y)</th>
                          <th className="pr-4 py-1 text-right">Lag (Y_t-{tsLagK})</th>
                          <th className="pr-4 py-1 text-right">Diff (Δ^{tsDiffD} Y)</th>
                          <th className="pr-4 py-1 text-right">Residual Detrended</th>
                        </tr>
                      </thead>
                      <tbody className="text-[#141414] divide-y divide-[#141414]/10">
                        {calculationResults.timeseries.original.map((val: number, idx: number) => (
                          <tr key={idx}>
                            <td className="pr-4 py-1 font-bold opacity-60">{idx + 1}</td>
                            <td className="pr-4 py-1 text-right">{val?.toFixed(2)}</td>
                            <td className="pr-4 py-1 text-right opacity-80">
                              {isNaN(calculationResults.timeseries.lagged[idx]) ? "NA" : calculationResults.timeseries.lagged[idx]?.toFixed(2)}
                            </td>
                            <td className="pr-4 py-1 text-right opacity-80">
                              {isNaN(calculationResults.timeseries.differenced[idx]) ? "0.00" : calculationResults.timeseries.differenced[idx]?.toFixed(2)}
                            </td>
                            <td className="pr-4 py-1 text-right opacity-80">
                              {isNaN(calculationResults.timeseries.residuals[idx]) ? "NA" : calculationResults.timeseries.residuals[idx]?.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}

            {/* 4. STOCHASTIC SIMULATION SCREEN */}
            {selectedTab === "stochastic" && calculationResults.stochastic && (
              <div className="flex-1 flex flex-col gap-6" id="stochastic-workspace-panel">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#141414] pb-3 gap-2">
                  <div>
                    <h3 className="text-base font-serif italic text-[#141414]">Stochastic Simulation Core</h3>
                    <p className="text-[10px] text-[#141414]/60 font-mono uppercase tracking-wider">Simulates stochastic step pathways, Markov probability chains, and Monte Carlo ensembles.</p>
                  </div>
                </div>

                {/* CONTROLS AREA */}
                <div className="bg-white/20 p-4 border border-[#141414]/20 grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs font-mono">
                  
                  <div>
                    <label className="block font-bold text-[#141414]/70 mb-1 uppercase text-[9px] tracking-wider">Sim steps (N)</label>
                    <input
                      type="number"
                      value={stochasticSteps}
                      onChange={(e) => setStochasticSteps(Math.max(5, Math.min(200, parseInt(e.target.value) || 20)))}
                      className="w-full bg-white/20 border border-[#141414]/20 p-1.5 focus:ring-1 focus:ring-[#141414] outline-none text-[#141414]"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-[#141414]/70 mb-1 uppercase text-[9px] tracking-wider">Process Drift (δ)</label>
                    <input
                      type="number"
                      step={0.01}
                      value={stochasticDrift}
                      onChange={(e) => setStochasticDrift(parseFloat(e.target.value) || 0)}
                      className="w-full bg-white/20 border border-[#141414]/20 p-1.5 focus:ring-1 focus:ring-[#141414] outline-none text-[#141414]"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-[#141414]/70 mb-1 uppercase text-[9px] tracking-wider">Volatility (σ)</label>
                    <input
                      type="number"
                      step={0.1}
                      min={0.1}
                      value={stochasticVol}
                      onChange={(e) => setStochasticVol(Math.max(0.1, parseFloat(e.target.value) || 1.0))}
                      className="w-full bg-white/20 border border-[#141414]/20 p-1.5 focus:ring-1 focus:ring-[#141414] outline-none text-[#141414]"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-[#141414]/70 mb-1 uppercase text-[9px] tracking-wider">AR(1) Weight (φ)</label>
                    <input
                      type="number"
                      step={0.05}
                      min={-1}
                      max={1}
                      value={mcPhi}
                      onChange={(e) => setMcPhi(parseFloat(e.target.value) || 0.5)}
                      className="w-full bg-white/20 border border-[#141414]/20 p-1.5 focus:ring-1 focus:ring-[#141414] outline-none text-[#141414]"
                    />
                  </div>

                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  
                  {/* MC ENSEMBLE CHART */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10 flex flex-col">
                    <h4 className="text-[10px] font-bold text-[#141414] font-mono mb-2 border-b border-[#141414]/20 pb-1.5 uppercase tracking-widest">Monte Carlo Ensemble Trajectories ({mcPathsCount} Paths)</h4>
                    
                    <div className="flex-1 min-h-[160px] bg-[#141414]/5 border border-[#141414]/20 p-3 relative overflow-hidden">
                      {(() => {
                        const mcMat = calculationResults.stochastic.mc;
                        const N = mcMat.length;

                        // Find global max/min of matrix for coordinate scaling
                        let flatVals: number[] = [];
                        for (let r = 0; r < N; r++) {
                          for (let c = 0; c < mcPathsCount; c++) {
                            flatVals.push(mcMat[r][c]);
                          }
                        }
                        const maxVal = Math.max(...flatVals, 100);
                        const minVal = Math.min(...flatVals, 50);
                        const range = maxVal - minVal || 1.0;

                        const width = 300;
                        const height = 140;
                        const padding = 15;

                        const getCoords = (idx: number, val: number) => {
                          const x = padding + (idx / (N - 1)) * (width - padding * 2);
                          const y = height - padding - ((val - minVal) / range) * (height - padding * 2);
                          return { x, y };
                        };

                        const grays = ["#141414", "#141414", "#141414", "#141414", "#141414", "#141414"];
                        const opacities = [1.0, 0.7, 0.45, 0.35, 0.25, 0.15];

                        return (
                          <svg className="w-full h-full" viewBox={`0 0 ${width} ${height}`}>
                            {Array.from({ length: mcPathsCount }).map((_, cIdx) => {
                              const pathPoints = Array.from({ length: N }).map((_, rIdx) => getCoords(rIdx, mcMat[rIdx][cIdx]));
                              return (
                                <path
                                  key={cIdx}
                                  d={`M ${pathPoints.map(p => `${p.x},${p.y}`).join(" L ")}`}
                                  fill="none"
                                  stroke={grays[cIdx % grays.length]}
                                  strokeWidth={1.2}
                                  strokeOpacity={opacities[cIdx % opacities.length]}
                                />
                              );
                            })}
                          </svg>
                        );
                      })()}
                    </div>
                    <span className="text-[9px] text-[#141414]/65 font-mono mt-1.5 uppercase tracking-wide">Mathematical Form: Xt = φ*Xt-1 + δ + εt (Simulated path vectors)</span>
                  </div>

                  {/* MARKOV STATE TRANSISTION GRID */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10 flex flex-col">
                    <h4 className="text-[10px] font-bold text-[#141414] font-mono mb-2 border-b border-[#141414]/20 pb-1.5 uppercase tracking-widest">Markov Matrix state simulation</h4>
                    
                    <div className="font-mono text-xs flex-1 flex flex-col justify-between">
                      <div className="bg-white/20 p-2.5 border border-[#141414]/20 mb-2">
                        <span className="text-[9px] text-[#141414]/60 block mb-1.5 uppercase font-bold tracking-wider">State Transition Probability matrix (P)</span>
                        <div className="space-y-1">
                          {markovTransitionMatrix.map((row, rIdx) => (
                            <div key={rIdx} className="flex gap-1.5">
                              {row.map((val, cIdx) => (
                                <input
                                  key={cIdx}
                                  type="number"
                                  step={0.05}
                                  min={0}
                                  max={1}
                                  value={val}
                                  onChange={(e) => {
                                    const nextV = Math.max(0, Math.min(1.0, parseFloat(e.target.value) || 0));
                                    const updated = markovTransitionMatrix.map((r, ri) =>
                                      r.map((c, ci) => (ri === rIdx && ci === cIdx ? nextV : c))
                                    );
                                    setMarkovTransitionMatrix(updated);
                                  }}
                                  className="w-16 bg-white/30 border border-[#141414]/20 p-1 text-center scale-95 outline-none focus:border-[#141414]/50"
                                />
                              ))}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* State timeline generation */}
                      <div className="border border-[#141414]/20 p-2 text-[10px] bg-white/10">
                        <span className="text-[#141414]/60 font-bold block mb-1.5 uppercase tracking-wider">Generated sequence (First 20 States)</span>
                        <div className="flex gap-1.5 flex-wrap">
                          {calculationResults.stochastic.markov.slice(0, 20).map((st: number, idx: number) => {
                            const opacityVal = st === 0 ? "bg-[#141414]" : st === 1 ? "bg-[#141414]/60 border border-[#141414]/20" : "bg-[#141414]/25";
                            const textC = st === 0 ? "text-[#E4E3E0]" : "text-[#141414]";
                            return (
                              <span key={idx} className={`${opacityVal} ${textC} font-bold w-6 h-6 flex items-center justify-center`} title={`Step ${idx+1}`}>
                                {st + 1}
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            )}

            {/* 5. OPTIMISATION ENGINE SCREEN */}
            {selectedTab === "optimise" && calculationResults.optimise && (
              <div className="flex-1 flex flex-col gap-6" id="optimise-workspace-panel">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#141414] pb-3 gap-2">
                  <div>
                    <h3 className="text-base font-serif italic text-[#141414]">Numerical Optimisation Core</h3>
                    <p className="text-[10px] text-[#141414]/60 font-mono uppercase tracking-wider">Fits multiple linear regression curves via OLS, and minimizes custom constraints systems.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  
                  {/* OLS SOLVER WORKSPACE */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10 flex flex-col font-mono text-xs">
                    <h4 className="text-[10px] font-bold text-[#141414] border-b border-[#141414]/15 pb-1.5 uppercase mb-3 tracking-widest">Ordinary Least Squares (OLS)</h4>
                    
                    {calculationResults.optimise.ols ? (
                      <div className="space-y-4">
                        {/* Selector items */}
                        <div className="bg-white/20 p-2.5 border border-[#141414]/20 space-y-2">
                          <div>
                            <span className="block text-[9px] text-[#141414]/60 uppercase font-bold mb-1 tracking-wider">Response Dependent variable (Y Outcome)</span>
                            <select
                              value={olsYCol}
                              onChange={(e) => setOlsYCol(e.target.value)}
                              className="bg-white/20 border border-[#141414]/25 text-xs font-mono p-1 w-full text-[#141414] outline-none"
                            >
                              {headers.map((h, i) => (
                                <option key={i} value={h}>{h}</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <span className="block text-[9px] text-[#141414]/60 uppercase font-bold mb-1 tracking-wider">Independent Slopes Features (X Regressors)</span>
                            <div className="flex flex-wrap gap-1.5">
                              {headers.map((h, i) => (
                                <button
                                  key={i}
                                  id={`ols-toggle-btn-${h}`}
                                  onClick={() => handleOlsColToggle(h)}
                                  className={`px-2 py-1 text-[10px] border ${
                                    olsXCols.includes(h)
                                      ? "bg-[#141414] text-[#E4E3E0] border-[#141414] font-semibold"
                                      : "bg-white/30 text-[#141414] border-[#141414]/20 hover:bg-white/50"
                                  }`}
                                >
                                  {h}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Coeffs output table */}
                        <div className="space-y-1.5">
                          <div className="flex justify-between font-bold border-b border-[#141414]/10 pb-1 text-[#141414]/60 text-[10px] tracking-wider uppercase">
                            <span>Parameter Coeff</span>
                            <span>Estimate Beta (β)</span>
                          </div>
                          <div className="flex justify-between text-[#141414]">
                            <span className="font-semibold">β0 (Intercept)</span>
                            <span className="font-bold">{calculationResults.optimise.ols.coefficients[0]?.toFixed(4)}</span>
                          </div>
                          {olsXCols.map((name, i) => (
                            <div key={i} className="flex justify-between text-[#141414]">
                              <span className="font-semibold">β_{i+1} ({name})</span>
                              <span className="font-bold">{calculationResults.optimise.ols.coefficients[i + 1]?.toFixed(4)}</span>
                            </div>
                          ))}
                        </div>

                        {/* Stats indicator R-Squared */}
                        <div className="bg-[#141414]/10 border border-[#141414]/20 p-2 flex justify-between text-[#141414] font-bold">
                          <span>Adjusted R-Squared (R²):</span>
                          <span>{calculationResults.optimise.ols.r_squared.toFixed(5)}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="text-red-955 bg-red-100/50 p-3 select-none font-bold uppercase text-[10px]">
                        Warning: No regression fit possible. Verify variables are independent.
                      </div>
                    )}
                  </div>

                  {/* GENERAL PARAM CONSTRAINTS MINIMISER */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10 flex flex-col font-mono text-xs">
                    <h4 className="text-[10px] font-bold text-[#141414] border-b border-[#141414]/15 pb-1.5 uppercase mb-2 tracking-widest">Constrained Objective Minimizer</h4>

                    <div className="space-y-3">
                      <div>
                        <span className="block text-[9px] text-[#141414]/65 uppercase font-bold mb-1 tracking-wider">Select Mathematical Objective Function</span>
                        <select
                          value={optimizerObjective}
                          onChange={(e) => setOptimizerObjective(e.target.value as any)}
                          className="bg-white/20 border border-[#141414]/25 text-xs font-mono p-1 w-full text-[#141414] outline-none"
                        >
                          <option value="quadratic">Quadratic form f(w) = w1^2 + 2*w2^2 - w1*w2...</option>
                          <option value="sphere">Sphere function f(w) = sum(w_i^2)</option>
                          <option value="rosenbrock">Rosenbrock Valley Banana test model</option>
                        </select>
                      </div>

                      {/* Dimensions parameter boxes */}
                      <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                        <div>
                          <label className="block text-[#141414]/60 font-bold uppercase tracking-wider text-[9px]">Lower Box Constraint</label>
                          <input
                            type="text"
                            value={optLowerConstraint}
                            onChange={(e) => setOptLowerConstraint(e.target.value)}
                            className="bg-white/20 border border-[#141414]/25 p-1 w-full text-xs text-[#141414] outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[#141414]/60 font-bold uppercase tracking-wider text-[9px]">Upper Box Constraint</label>
                          <input
                            type="text"
                            value={optUpperConstraint}
                            onChange={(e) => setOptUpperConstraint(e.target.value)}
                            className="bg-white/20 border border-[#141414]/25 p-1 w-full text-xs text-[#141414] outline-none"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[9px] text-[#141414]/60 font-bold uppercase tracking-wider">Initial coordinate vector w_0</label>
                        <input
                          type="text"
                          value={optInitialVec}
                          onChange={(e) => setOptInitialVec(e.target.value)}
                          className="bg-white/20 border border-[#141414]/25 p-1 w-full text-xs text-[#141414] outline-none"
                        />
                      </div>

                      {/* Convergence outputs */}
                      <div className="bg-[#141414] text-[#E4E3E0] p-2.5 border border-[#141414] space-y-1">
                        <div className="flex justify-between font-bold text-[#E4E3E0]/70 text-[10px] border-b border-white/10 pb-1 uppercase tracking-widest">
                          <span>Metric</span>
                          <span>Optimized Sol</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#E4E3E0]/60">Parameter Sol par*:</span>
                          <span className="text-[#E4E3E0] font-bold">
                            [{calculationResults.optimise.opt.par.map((v: number) => v.toFixed(4)).join(", ")}]
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#E4E3E0]/60 font-mono">Minimized objective f*:</span>
                          <span className="text-[#E4E3E0] font-bold">
                            {calculationResults.optimise.opt.value.toFixed(6)}
                          </span>
                        </div>
                        <div className="flex justify-between text-[10px]">
                          <span className="text-[#E4E3E0]/60">Total gradient steps:</span>
                          <span className="text-[#E4E3E0]">{calculationResults.optimise.opt.iterations}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            )}

            {/* 6. TRANSFORMATION LAYER SCREEN */}
            {selectedTab === "transform" && calculationResults.transform && (
              <div className="flex-1 flex flex-col gap-6" id="transform-workspace-panel">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#141414] pb-3 gap-2">
                  <div>
                    <h3 className="text-base font-serif italic text-[#141414]">Vector Transform & Sweeps</h3>
                    <p className="text-[10px] text-[#141414]/60 font-mono uppercase tracking-wider">Applies mathematical row/column normalization scales and grouped factor splits.</p>
                  </div>
                </div>

                {/* Normalization switch */}
                <div className="bg-white/20 p-4 border border-[#141414]/20 flex items-center justify-between text-xs font-mono">
                  <div>
                    <span className="font-bold text-[#141414]/80 block uppercase text-[10px] tracking-wider">Rescale Margin Settings</span>
                    <span className="text-[#141414]/60 text-[11px]">Choose whether to normalize (Z-score scale) columns or rows.</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setTransformMargin(2)}
                      className={`px-3 py-1.5 border border-[#141414]/25 cursor-pointer text-xs uppercase tracking-wide transition-all ${
                        transformMargin === 2 ? "bg-[#141414] text-[#E4E3E0] font-bold" : "bg-white/20 text-[#141414]/80 hover:bg-white/40"
                      }`}
                    >
                      Column (Margin=2)
                    </button>
                    <button
                      onClick={() => setTransformMargin(1)}
                      className={`px-3 py-1.5 border border-[#141414]/25 cursor-pointer text-xs uppercase tracking-wide transition-all ${
                        transformMargin === 1 ? "bg-[#141414] text-[#E4E3E0] font-bold" : "bg-white/20 text-[#141414]/80 hover:bg-white/40"
                      }`}
                    >
                      Row (Margin=1)
                    </button>
                  </div>
                </div>

                {/* Normalization preview coordinates */}
                <div className="border border-[#141414]/20 p-4 font-mono text-xs bg-white/10">
                  <span className="text-[10px] font-bold text-[#141414] mb-2 uppercase font-mono block tracking-widest border-b border-[#141414]/10 pb-1">Rescaled Matrix (Z-scores) Ledger</span>
                  <div className="overflow-x-auto max-h-[160px] border border-[#141414]/20 bg-white/5">
                    <table className="w-full text-left font-mono">
                      <thead className="bg-[#141414]/10 text-[#141414] sticky top-0 border-b border-[#141414]/20">
                        <tr>
                          <th className="px-3 py-1 border-r border-[#141414]/10">Row</th>
                          {headers.map((h, i) => (
                            <th key={i} className="px-3 py-1 text-right border-r border-[#141414]/10 last:border-0">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#141414]/10 bg-white/15">
                        {calculationResults.transform.normalized.map((row: number[], idx: number) => (
                          <tr key={idx} className="hover:bg-white/30">
                            <td className="px-3 py-1.5 font-bold text-[#141414]/50 bg-[#141414]/5 border-r border-[#141414]/10">{idx + 1}</td>
                            {row.map((val: number, i: number) => (
                              <td key={i} className="px-1.5 py-1.5 text-right font-medium text-[#141414] font-mono border-r border-[#141414]/10 last:border-0">
                                {isNaN(val) ? "NA" : val.toFixed(4)}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Column descriptors aggregator */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 text-mono font-mono text-xs">
                  
                  {/* AGGREGATED METRICS */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10 flex flex-col">
                    <h4 className="text-[10px] font-bold text-[#141414] border-b border-[#141414]/15 pb-1.5 uppercase mb-2 tracking-widest font-mono">Column-wise Aggregations Summary</h4>
                    <div className="overflow-x-auto max-h-[150px]">
                      <table className="w-full text-left">
                        <thead className="text-[#141414]/50 border-b border-[#141414]/10">
                          <tr>
                            <th className="pr-2 py-1">Column</th>
                            <th className="pr-2 py-1 text-right">Sum</th>
                            <th className="pr-2 py-1 text-right">Min</th>
                            <th className="pr-2 py-1 text-right">Max</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#141414]/10">
                          {calculationResults.transform.aggregated.map((agg: any, idx: number) => (
                            <tr key={idx}>
                              <td className="pr-2 py-1.5 font-bold text-[#141414]">{agg.column}</td>
                              <td className="pr-2 py-1.5 text-right text-[#141414] font-bold">{agg.sum.toFixed(2)}</td>
                              <td className="pr-2 py-1.5 text-right text-[#141414]/80">{agg.min.toFixed(2)}</td>
                              <td className="pr-2 py-1.5 text-right text-[#141414]/80">{agg.max.toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* CATEGORICAL SEGMENT GROUPING */}
                  <div className="border border-[#141414]/20 p-4 bg-white/10 flex flex-col">
                    <h4 className="text-[10px] font-bold text-[#141414] border-b border-[#141414]/15 pb-1.5 uppercase mb-2 tracking-widest font-mono">Segmented Cluster Group Means</h4>
                    <div className="overflow-x-auto max-h-[150px]">
                      <table className="w-full text-left">
                        <thead className="text-[#141414]/50 border-b border-[#141414]/10">
                          <tr>
                            <th className="pr-2 py-1">Factor Cluster</th>
                            {headers.map((h, i) => (
                              <th key={i} className="pr-2 py-1 text-right">{h} Mean</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#141414]/10">
                          {calculationResults.transform.grouped.map((g: any, idx: number) => (
                            <tr key={idx} className="hover:bg-white/20">
                              <td className="pr-2 py-1.5 font-bold text-[#141414]/80">{g.group}</td>
                              {g.means.map((v: number, i: number) => (
                                <td key={i} className="pr-2 py-1.5 text-right text-[#141414] font-bold">
                                  {v.toFixed(3)}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>

              </div>
            )}

          </div>

        </main>

      </div>

      {/* FOOTER BAR */}
      <footer className="border-t border-[#141414]/20 px-6 py-4 text-center text-[10px] text-[#141414]/50 font-mono mt-8 uppercase tracking-widest">
        <div>Spreadsheet Numerical Engine Backend &copy; 2026. General-purpose analytical matrix computation engine. Flawlessly configured.</div>
      </footer>

    </div>
  );
}
