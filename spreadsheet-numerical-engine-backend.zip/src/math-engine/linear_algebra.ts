import { Matrix, Vector, EigenDecompositionResult, SvdResult } from "./types";

/**
 * Transpose a matrix A (m x n) to A_T (n x m)
 */
export function transpose(A: Matrix): Matrix {
  if (A.length === 0) return [];
  const nRows = A.length;
  const nCols = A[0].length;
  const AT: Matrix = Array.from({ length: nCols }, () => new Array(nRows).fill(0));
  for (let r = 0; r < nRows; r++) {
    for (let c = 0; c < nCols; c++) {
      AT[c][r] = A[r][c];
    }
  }
  return AT;
}

/**
 * Performs matrix multiplication A * B
 */
export function matrix_multiply(A: Matrix, B: Matrix): Matrix {
  if (A.length === 0 || B.length === 0) return [];
  const rA = A.length;
  const cA = A[0].length;
  const rB = B.length;
  const cB = B[0].length;

  if (cA !== rB) {
    throw new Error(`Dimension mismatch in multiplication: left columns (${cA}) must match right rows (${rB})`);
  }

  const C: Matrix = Array.from({ length: rA }, () => new Array(cB).fill(0));
  for (let i = 0; i < rA; i++) {
    for (let j = 0; j < cB; j++) {
      let sum = 0;
      for (let k = 0; k < cA; k++) {
        sum += A[i][k] * B[k][j];
      }
      C[i][j] = sum;
    }
  }
  return C;
}

/**
 * Inverts a square matrix A using Gauss-Jordan elimination with partial pivoting.
 * If singular, returns a pseudoinverse or throws.
 */
export function invert_matrix(A: Matrix): Matrix {
  const n = A.length;
  if (n === 0 || A[0].length !== n) {
    throw new Error("Inverse requires a square matrix");
  }

  // Create an identity matrix alongside a copy of A
  const M: Matrix = A.map(row => [...row]);
  const I: Matrix = Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))
  );

  for (let i = 0; i < n; i++) {
    // Pivot selection
    let maxRow = i;
    for (let r = i + 1; r < n; r++) {
      if (Math.abs(M[r][i]) > Math.abs(M[maxRow][i])) {
        maxRow = r;
      }
    }

    // Swap rows in M and I
    if (maxRow !== i) {
      const tempM = M[i];
      M[i] = M[maxRow];
      M[maxRow] = tempM;

      const tempI = I[i];
      I[i] = I[maxRow];
      I[maxRow] = tempI;
    }

    const pivot = M[i][i];
    if (Math.abs(pivot) < 1e-12) {
      // Singular fallback - add small perturbation on diagonal (Ridge Regression adjustment) to force invertibility
      return invert_perturbed(A);
    }

    // Scale current row
    for (let c = i; c < n; c++) M[i][c] /= pivot;
    for (let c = 0; c < n; c++) I[i][c] /= pivot;

    // Eliminate other rows
    for (let r = 0; r < n; r++) {
      if (r !== i) {
        const factor = M[r][i];
        for (let c = i; c < n; c++) {
          M[r][c] -= factor * M[i][c];
        }
        for (let c = 0; c < n; c++) {
          I[r][c] -= factor * I[i][c];
        }
      }
    }
  }

  return I;
}

/**
 * Perturbs a matrix slightly on diagonal for non-singularity inversion fallback
 */
function invert_perturbed(A: Matrix, lambda: number = 1e-6): Matrix {
  const n = A.length;
  const perturbed: Matrix = A.map((row, i) =>
    row.map((val, j) => (i === j ? val + lambda : val))
  );
  try {
    const M: Matrix = perturbed.map(row => [...row]);
    const I: Matrix = Array.from({ length: n }, (_, i) =>
      Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))
    );
    for (let i = 0; i < n; i++) {
      let maxRow = i;
      for (let r = i + 1; r < n; r++) {
        if (Math.abs(M[r][i]) > Math.abs(M[maxRow][i])) maxRow = r;
      }
      if (maxRow !== i) {
        const tempM = M[i]; M[i] = M[maxRow]; M[maxRow] = tempM;
        const tempI = I[i]; I[i] = I[maxRow]; I[maxRow] = tempI;
      }
      const pivot = M[i][i];
      if (Math.abs(pivot) < 1e-15) continue;
      for (let c = i; c < n; c++) M[i][c] /= pivot;
      for (let c = 0; c < n; c++) I[i][c] /= pivot;
      for (let r = 0; r < n; r++) {
        if (r !== i) {
          const factor = M[r][i];
          for (let c = i; c < n; c++) M[r][c] -= factor * M[i][c];
          for (let c = 0; c < n; c++) I[r][c] -= factor * I[i][c];
        }
      }
    }
    return I;
  } catch {
    // absolute fallback identity
    return Array.from({ length: n }, (_, i) =>
      Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))
    );
  }
}

/**
 * Jacobi Eigenvalue Algorithm for square symmetric matrices.
 * Highly robust and returns precise eigenvalues and eigenvectors.
 */
export function eigen_decomposition(A: Matrix): EigenDecompositionResult {
  const n = A.length;
  if (n === 0 || A[0].length !== n) {
    throw new Error("Eigen decomposition requires a square matrix");
  }

  // Make symmetric copy for security
  const S: Matrix = Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (_, j) => (A[i][j] + A[j][i]) / 2)
  );

  // Initialize eigenvectors with Identity matrix
  const V: Matrix = Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (_, j) => (i === j ? 1.0 : 0.0))
  );

  const maxIters = 100 * n * n;
  const eps = 1e-9;

  for (let iter = 0; iter < maxIters; iter++) {
    // Find absolute largest off-diagonal element
    let p = 0, q = 1;
    let maxOff = Math.abs(S[0][1]);

    for (let r = 0; r < n; r++) {
      for (let c = r + 1; c < n; c++) {
        const val = Math.abs(S[r][c]);
        if (val > maxOff) {
          maxOff = val;
          p = r;
          q = c;
        }
      }
    }

    // Convergence check
    if (maxOff < eps) {
      break;
    }

    // Compute rotation angle elements (c, s)
    const s_pp = S[p][p];
    const s_qq = S[q][q];
    const s_pq = S[p][q];

    let theta = 0;
    let t = 0;
    if (Math.abs(s_pq) > 1e-15) {
      theta = (s_qq - s_pp) / (2.0 * s_pq);
      if (theta >= 0) {
        t = 1.0 / (theta + Math.sqrt(theta * theta + 1.0));
      } else {
        t = -1.0 / (-theta + Math.sqrt(theta * theta + 1.0));
      }
    }

    const cos = 1.0 / Math.sqrt(t * t + 1.0);
    const sin = t * cos;
    const tau = sin / (1.0 + cos);

    // Update S matrix
    S[p][p] = s_pp - t * s_pq;
    S[q][q] = s_qq + t * s_pq;
    S[p][q] = 0;
    S[q][p] = 0;

    for (let i = 0; i < n; i++) {
      if (i !== p && i !== q) {
        const s_ip = S[i][p];
        const s_iq = S[i][q];
        S[i][p] = s_ip - sin * (s_iq + tau * s_ip);
        S[p][i] = S[i][p];
        S[i][q] = s_iq + sin * (s_ip - tau * s_iq);
        S[q][i] = S[i][q];
      }
    }

    // Update Eigenvector tracker V
    for (let i = 0; i < n; i++) {
      const v_ip = V[i][p];
      const v_iq = V[i][q];
      V[i][p] = v_ip - sin * (v_iq + tau * v_ip);
      V[i][q] = v_iq + sin * (v_ip - tau * v_iq);
    }
  }

  const values = S.map((row, i) => row[i]);

  return { values, vectors: V };
}

/**
 * Computes SVD of rectangular or square matrix A (m x n) using eigenvectors of A_T*A
 */
export function svd_decomposition(A: Matrix): SvdResult {
  const m = A.length;
  if (m === 0) return { u: [], d: [], v: [] };
  const n = A[0].length;

  const AT = transpose(A);

  if (m >= n) {
    // ATA is n x n (smaller or equal dimension)
    const ATA = matrix_multiply(AT, A);
    const eigen = eigen_decomposition(ATA);

    // Filter negative eigenvalue products due to numeric rounding noise
    const d = eigen.values.map(val => Math.sqrt(Math.max(0, val)));
    const v = eigen.vectors;

    // Transpose v to get individual eigenvectors
    const vt = transpose(v);

    // Compute u columns: u_i = A * v_i / d_i
    const u: Matrix = Array.from({ length: m }, () => new Array(n).fill(0));
    for (let i = 0; i < n; i++) {
        const singular_val = d[i];
        if (singular_val > 1e-10) {
            for (let r = 0; r < m; r++) {
                let dot = 0;
                for (let k = 0; k < n; k++) {
                    dot += A[r][k] * vt[i][k];
                }
                u[r][i] = dot / singular_val;
            }
        } else {
            // singular fallback
            for (let r = 0; r < m; r++) u[r][i] = 0;
        }
    }

    return { u, d, v: transpose(vt) };
  } else {
    // AАТ is m x m (smaller dimension)
    const AAT = matrix_multiply(A, AT);
    const eigen = eigen_decomposition(AAT);

    const d = eigen.values.map(val => Math.sqrt(Math.max(0, val)));
    const u = eigen.vectors;

    const ut = transpose(u);

    // Compute v columns: v_i = A_T * u_i / d_i
    const v: Matrix = Array.from({ length: n }, () => new Array(m).fill(0));
    for (let i = 0; i < m; i++) {
        const singular_val = d[i];
        if (singular_val > 1e-10) {
            for (let r = 0; r < n; r++) {
                let dot = 0;
                for (let k = 0; k < m; k++) {
                    dot += AT[r][k] * ut[i][k];
                }
                v[r][i] = dot / singular_val;
            }
        } else {
            for (let r = 0; r < n; r++) v[r][i] = 0;
        }
    }

    return { u, d, v };
  }
}

/**
 * Estimates rank of a matrix via non-zero elements in singular value domain
 */
export function estimate_rank(A: Matrix, tol: number = 1e-10): number {
  try {
    const svd = svd_decomposition(A);
    if (svd.d.length === 0) return 0;
    const maxSval = Math.max(...svd.d);
    const threshold = maxSval * tol;
    return svd.d.filter(val => val > threshold).length;
  } catch {
    return Math.min(A.length, A[0]?.length || 0);
  }
}
