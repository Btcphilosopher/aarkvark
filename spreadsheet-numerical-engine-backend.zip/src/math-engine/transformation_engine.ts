import { Matrix, Vector } from "./types";
import { mean, std } from "./statistics_engine";

/**
 * Standardize matrix margins (Z-score normalize over rows or cols)
 * margin = 2 (standard columns Z-scaling), margin = 1 (row Z-scaling)
 */
export function normalize_matrix(A: Matrix, margin: 1 | 2 = 2): Matrix {
  if (A.length === 0) return [];
  const nRows = A.length;
  const nCols = A[0].length;

  const result: Matrix = Array.from({ length: nRows }, () => new Array(nCols).fill(0));

  if (margin === 2) {
    // Normalise columns
    for (let c = 0; c < nCols; c++) {
      const colVec: Vector = [];
      for (let r = 0; r < nRows; r++) {
        colVec.push(A[r][c]);
      }
      
      const m = mean(colVec);
      const s = std(colVec);
      const divisor = s === 0 ? 1.0 : s;

      for (let r = 0; r < nRows; r++) {
        const val = A[r][c];
        result[r][c] = val !== null && !isNaN(val) ? (val - m) / divisor : NaN;
      }
    }
  } else {
    // Normalise rows
    for (let r = 0; r < nRows; r++) {
      const rowVec = A[r];
      const m = mean(rowVec);
      const s = std(rowVec);
      const divisor = s === 0 ? 1.0 : s;

      for (let c = 0; c < nCols; c++) {
        const val = A[r][c];
        result[r][c] = val !== null && !isNaN(val) ? (val - m) / divisor : NaN;
      }
    }
  }

  return result;
}

export interface ColAggregation {
  column: string;
  sum: number;
  mean: number;
  min: number;
  max: number;
  count: number;
}

/**
 * Aggregate column summary sets (sums, averages, bounds, counts)
 */
export function aggregate_columns(A: Matrix, colNames?: string[]): ColAggregation[] {
  if (A.length === 0) return [];
  const nCols = A[0].length;
  const aggs: ColAggregation[] = [];

  for (let c = 0; c < nCols; c++) {
    const colVec: Vector = [];
    let sum = 0;
    let minVal = Infinity;
    let maxVal = -Infinity;
    let count = 0;

    for (let r = 0; r < A.length; r++) {
      const val = A[r][c];
      if (val !== null && !isNaN(val)) {
        colVec.push(val);
        sum += val;
        if (val < minVal) minVal = val;
        if (val > maxVal) maxVal = val;
        count++;
      }
    }

    const name = colNames && colNames[c] ? colNames[c] : `Col${c + 1}`;
    aggs.push({
      column: name,
      sum,
      mean: count > 0 ? sum / count : 0,
      min: count > 0 ? minVal : 0,
      max: count > 0 ? maxVal : 0,
      count
    });
  }

  return aggs;
}

export interface LongRecord {
  row_idx: number;
  col_name: string;
  value: number;
}

/**
 * Melt wide matrix structure to long format
 */
export function melt_matrix(A: Matrix, colNames?: string[]): LongRecord[] {
  if (A.length === 0) return [];
  const nRows = A.length;
  const nCols = A[0].length;
  const records: LongRecord[] = [];

  for (let r = 0; r < nRows; r++) {
    for (let c = 0; c < nCols; c++) {
      const colName = colNames && colNames[c] ? colNames[c] : `Col${c + 1}`;
      records.push({
        row_idx: r + 1,
        col_name: colName,
        value: A[r][c]
      });
    }
  }

  return records;
}

export interface GroupRecord {
  group: string;
  means: Vector;
}

/**
 * Segments column variables by discrete categories in grouping vector
 */
export function group_by_means(data: Matrix, groupVector: string[]): GroupRecord[] {
  if (data.length === 0 || groupVector.length !== data.length) return [];
  const nCols = data[0].length;

  const groupedMap: { [key: string]: Matrix } = {};
  for (let r = 0; r < data.length; r++) {
    const groupName = groupVector[r] || "Unknown";
    if (!groupedMap[groupName]) {
      groupedMap[groupName] = [];
    }
    groupedMap[groupName].push(data[r]);
  }

  return Object.keys(groupedMap).map(groupName => {
    const rows = groupedMap[groupName];
    const columnMeans: Vector = [];

    for (let c = 0; c < nCols; c++) {
      const colVec: Vector = [];
      for (let r = 0; r < rows.length; r++) {
        colVec.push(rows[r][c]);
      }
      columnMeans.push(mean(colVec));
    }

    return {
      group: groupName,
      means: columnMeans
    };
  });
}
