import { Vector, Matrix } from "./types";

/**
 * Standard Gaussian normal generator using Box-Muller transformation
 */
export function generate_gaussian_noise(n: number, mean: number = 0, sd: number = 1): Vector {
  const noise: Vector = [];
  for (let i = 0; i < n; i += 2) {
    let u1 = Math.random();
    let u2 = Math.random();

    // Prevent log(0)
    while (u1 === 0) u1 = Math.random();

    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    const z1 = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);

    noise.push(z0 * sd + mean);
    if (i + 1 < n) {
      noise.push(z1 * sd + mean);
    }
  }
  return noise;
}

/**
 * Simulates a standard random walk: X_t = X_{t-1} + e_t
 */
export function simulate_random_walk(n: number, x0: number = 0, drift: number = 0, noise_sd: number = 1): Vector {
  const noise = generate_gaussian_noise(n - 1, drift, noise_sd);
  const path: Vector = [x0];
  let currentVal = x0;
  for (let i = 0; i < n - 1; i++) {
    currentVal += noise[i];
    path.push(currentVal);
  }
  return path;
}

/**
 * Performs Monte Carlo Simulation of an Autoregressive system:
 * X_t = phi * X_{t-1} + drift + epsilon
 */
export function simulate_monte_carlo(
  n: number,
  pathsCount: number = 10,
  x0: number = 0,
  phi: number = 0.9,
  drift: number = 0,
  noise_sd: number = 1
): Matrix {
  const simResults: Matrix = Array.from({ length: n }, () => new Array(pathsCount).fill(0));

  for (let p = 0; p < pathsCount; p++) {
    const noise = generate_gaussian_noise(n - 1, 0, noise_sd);
    let state = x0;
    simResults[0][p] = state;

    for (let t = 1; t < n; t++) {
      state = phi * state + drift + noise[t - 1];
      simResults[t][p] = state;
    }
  }

  return simResults;
}

/**
 * Simulates state transitions via discrete Markov Transition Matrix
 */
export function simulate_markov_chain(
  nSteps: number,
  transitionMatrix: Matrix,
  initialState: number = 0
): Vector {
  const K = transitionMatrix.length;
  if (K === 0 || transitionMatrix[0].length !== K) {
    throw new Error("Transition matrix must be square");
  }

  // Row normalize to satisfy standard probability constraints
  const P: Matrix = transitionMatrix.map(row => {
    const sum = row.reduce((s, v) => s + v, 0);
    if (sum === 0) {
      return new Array(K).fill(1 / K);
    }
    return row.map(v => v / sum);
  });

  const states: Vector = [initialState];
  let current = initialState;

  for (let t = 1; t < nSteps; t++) {
    const r = Math.random();
    let cumulative = 0;
    let nextState = 0;

    const probs = P[current];
    for (let s = 0; s < K; s++) {
      cumulative += probs[s];
      if (r <= cumulative) {
        nextState = s;
        break;
      }
      if (s === K - 1) {
        nextState = K - 1;
      }
    }
    current = nextState;
    states.push(current);
  }

  return states;
}
