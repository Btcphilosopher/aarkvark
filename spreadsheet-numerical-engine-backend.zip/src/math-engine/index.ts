/**
 * Export interface of the complete numerical computation workspace
 */

export * from "./types";
export * from "./linear_algebra";
export * from "./statistics_engine";
export * from "./time_series_engine";
export * from "./stochastic_engine";
export * from "./optimisation_engine";
export * from "./transformation_engine";

/**
 * Convenience helper to convert matrices to CSV strings
 */
export function exportToCSV(matrix: number[][], headers?: string[]): string {
  if (matrix.length === 0) return "";
  const nCols = matrix[0].length;
  const actualHeaders = headers || Array.from({ length: nCols }, (_, idx) => `Column_${idx + 1}`);
  
  const csvRows = [actualHeaders.join(",")];
  for (let r = 0; r < matrix.length; r++) {
    csvRows.push(matrix[r].map(val => (val === null || isNaN(val) ? "" : val.toString())).join(","));
  }
  return csvRows.join("\n");
}
