/**
 * TypeScript Math Engine Type Declarations
 */

export type Matrix = number[][];
export type Vector = number[];

export interface SummaryStats {
  column: string;
  mean: number;
  variance: number;
  sd: number;
  min: number;
  max: number;
  median: number;
  count: number;
}

export interface EigenDecompositionResult {
  values: Vector;
  vectors: Matrix;
}

export interface SvdResult {
  u: Matrix;
  d: Vector;
  v: Matrix;
}

export interface OLSResult {
  coefficients: Vector;
  fitted_values: Vector;
  residuals: Vector;
  r_squared: number;
}

export interface MinimiseResult {
  par: Vector;
  value: number;
  iterations: number;
}

export interface RollingStatsResult {
  rolling_mean: Vector;
  rolling_sd: Vector;
}

export interface TrendResult {
  trend: Vector;
  residuals: Vector;
}
