import { Vector, TrendResult } from "./types";

/**
 * Lag operator: shifts elements by k positions
 */
export function compute_lag(x: Vector, k: number = 1, pad: number = NaN): Vector {
  const n = x.length;
  if (k === 0) return [...x];
  if (Math.abs(k) >= n) return new Array(n).fill(pad);

  const res: Vector = new Array(n).fill(pad);

  if (k > 0) {
    for (let i = k; i < n; i++) {
      res[i] = x[i - k];
    }
  } else {
    const absK = Math.abs(k);
    for (let i = 0; i < n - absK; i++) {
      res[i] = x[i + absK];
    }
  }

  return res;
}

/**
 * Higher-order differencing (d = 1 standard first difference)
 */
export function compute_difference(x: Vector, d: number = 1): Vector {
  if (d === 0) return [...x];
  if (d < 0) throw new Error("Order of differencing must be non-negative");

  let res = [...x];
  for (let step = 0; step < d; step++) {
    const lagged = compute_lag(res, 1, 0);
    res = res.map((val, idx) => (idx === 0 ? 0 : val - lagged[idx]));
  }
  return res;
}

/**
 * Exponential Moving Average
 */
export function compute_ema(x: Vector, alpha: number = 0.2): Vector {
  if (alpha <= 0 || alpha > 1) {
    throw new Error("Alpha smoothing weight must be in (0, 1]");
  }
  const n = x.length;
  const ema: Vector = new Array(n).fill(NaN);

  let startIdx = -1;
  for (let i = 0; i < n; i++) {
    if (x[i] !== null && !isNaN(x[i])) {
      ema[i] = x[i];
      startIdx = i;
      break;
    }
  }

  if (startIdx !== -1) {
    for (let i = startIdx + 1; i < n; i++) {
      if (x[i] === null || isNaN(x[i])) {
        ema[i] = ema[i - 1];
      } else {
        ema[i] = alpha * x[i] + (1 - alpha) * ema[i - 1];
      }
    }
  }

  return ema;
}

/**
 * Simple linear trend-cycle extraction using Least Squares Line Fitting
 */
export function extract_trend(x: Vector): TrendResult {
  const n = x.length;
  const indices = Array.from({ length: n }, (_, i) => i + 1);

  const cleanIndices: number[] = [];
  const cleanVals: number[] = [];

  for (let i = 0; i < n; i++) {
    if (x[i] !== null && !isNaN(x[i])) {
      cleanIndices.push(indices[i]);
      cleanVals.push(x[i]);
    }
  }

  let alpha = 0;
  let beta = 0;

  if (cleanIndices.length > 1) {
    // Ordinary least squares for y = alpha + beta * t
    const meanT = cleanIndices.reduce((s, val) => s + val, 0) / cleanIndices.length;
    const meanY = cleanVals.reduce((s, val) => s + val, 0) / cleanIndices.length;

    let numerator = 0;
    let denominator = 0;

    for (let k = 0; k < cleanIndices.length; k++) {
      const diffT = cleanIndices[k] - meanT;
      numerator += diffT * (cleanVals[k] - meanY);
      denominator += diffT * diffT;
    }

    beta = denominator !== 0 ? numerator / denominator : 0;
    alpha = meanY - beta * meanT;
  } else if (cleanIndices.length === 1) {
    alpha = cleanVals[0];
  }

  const trend: Vector = indices.map(t => alpha + beta * t);
  const residuals: Vector = x.map((val, idx) => (val !== null && !isNaN(val) ? val - trend[idx] : NaN));

  return { trend, residuals };
}
