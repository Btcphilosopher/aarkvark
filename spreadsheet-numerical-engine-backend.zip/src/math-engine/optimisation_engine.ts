import { Matrix, Vector, OLSResult, MinimiseResult } from "./types";
import { transpose, matrix_multiply, invert_matrix } from "./linear_algebra";

/**
 * Solves OLS regression models: beta = (X^T * X)^-1 * X^T * Y
 */
export function solve_least_squares(X: Matrix, Y: Vector): OLSResult {
  const m = X.length;
  if (m === 0) {
    throw new Error("No data samples provided");
  }
  const k = X[0].length;
  if (Y.length !== m) {
    throw new Error("Dimensions mismatch between features X and target vector Y");
  }

  // Compute beta coefficient vector
  const Xt = transpose(X);
  const XtX = matrix_multiply(Xt, X);
  const invXtX = invert_matrix(XtX);

  // Package target as single column matrix
  const Ymat: Matrix = Y.map(val => [val]);
  const XtY = matrix_multiply(Xt, Ymat);
  const betaMat = matrix_multiply(invXtX, XtY);

  const coefficients = betaMat.map(row => row[0]);

  // Compute fitted values & residuals
  const fitted_values: Vector = [];
  const residuals: Vector = [];
  let sumSquaredErr = 0;
  
  const sumY = Y.reduce((s, v) => s + v, 0);
  const meanY = sumY / m;
  let totalSumOfSquares = 0;

  for (let idx = 0; idx < m; idx++) {
    let fit = 0;
    for (let c = 0; c < k; c++) {
      fit += X[idx][c] * coefficients[c];
    }
    fitted_values.push(fit);
    const resid = Y[idx] - fit;
    residuals.push(resid);
    sumSquaredErr += resid * resid;
    totalSumOfSquares += (Y[idx] - meanY) * (Y[idx] - meanY);
  }

  const r_squared = totalSumOfSquares !== 0 ? 1.0 - sumSquaredErr / totalSumOfSquares : 1.0;

  return {
    coefficients,
    fitted_values,
    residuals,
    r_squared,
  };
}

/**
 * Multidimensional Gradient/Coordinate Descent Numerical Minimizer with Optional Box Boundaries
 */
export function numerical_minimise(
  objective_func: (params: Vector) => number,
  start_params: Vector,
  lowerBounds?: Vector,
  upperBounds?: Vector,
  tol: number = 1e-6,
  max_iter: number = 300
): MinimiseResult {
  const params = [...start_params];
  const nPar = params.length;
  const h = 1e-5; // local finite difference perturbation step
  let learningRate = 0.05;
  let prevVal = objective_func(params);
  let iter = 0;

  for (iter = 0; iter < max_iter; iter++) {
    const grad = new Array(nPar).fill(0);

    // Compute empirical gradients
    for (let i = 0; i < nPar; i++) {
      const tempP = [...params];
      tempP[i] += h;
      const valP = objective_func(tempP);

      const tempM = [...params];
      tempM[i] -= h;
      const valM = objective_func(tempM);

      grad[i] = (valP - valM) / (2.0 * h);
    }

    // Attempt gradient descent step
    const newParams = params.map((p, idx) => {
      let nextP = p - learningRate * grad[idx];
      // Apply clipping to upper/lower boundaries if set
      if (lowerBounds && lowerBounds[idx] !== undefined) {
        nextP = Math.max(nextP, lowerBounds[idx]);
      }
      if (upperBounds && upperBounds[idx] !== undefined) {
        nextP = Math.min(nextP, upperBounds[idx]);
      }
      return nextP;
    });

    const newVal = objective_func(newParams);

    if (newVal < prevVal) {
      // Step was successful, accept and monitor threshold
      for (let idx = 0; idx < nPar; idx++) {
        params[idx] = newParams[idx];
      }
      if (Math.abs(prevVal - newVal) < tol) {
        prevVal = newVal;
        break;
      }
      prevVal = newVal;
    } else {
      // Overestimated steps, contract learning rate
      learningRate *= 0.5;
      if (learningRate < 1e-8) {
        break;
      }
    }
  }

  return {
    par: params,
    value: prevVal,
    iterations: iter
  };
}
