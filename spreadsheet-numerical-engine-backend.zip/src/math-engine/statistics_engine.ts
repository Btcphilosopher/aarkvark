import { Matrix, Vector, SummaryStats, RollingStatsResult } from "./types";

/**
 * Computes mean of a numeric vector, ignoring NaN/null values.
 */
export function mean(x: Vector): number {
  const clean = x.filter(val => val !== null && !isNaN(val));
  if (clean.length === 0) return 0;
  return clean.reduce((sum, v) => sum + v, 0) / clean.length;
}

/**
 * Computes variance of a numeric vector, ignoring NaN/null values.
 */
export function variance(x: Vector): number {
  const clean = x.filter(val => val !== null && !isNaN(val));
  if (clean.length <= 1) return 0;
  const m = mean(clean);
  const sumSquaredDiffs = clean.reduce((sum, v) => sum + Math.pow(v - m, 2), 0);
  return sumSquaredDiffs / (clean.length - 1); // Unbiased estimator (Sample variance)
}

/**
 * Computes standard deviation of a numeric vector.
 */
export function std(x: Vector): number {
  return Math.sqrt(variance(x));
}

/**
 * Computes median of a numeric vector.
 */
export function median(x: Vector): number {
  const clean = x.filter(val => val !== null && !isNaN(val)).sort((a, b) => a - b);
  if (clean.length === 0) return 0;
  const half = Math.floor(clean.length / 2);
  if (clean.length % 2 !== 0) {
    return clean[half];
  }
  return (clean[half - 1] + clean[half]) / 2.0;
}

/**
 * Generates descriptive summaries column-wise on tabular matrices.
 */
export function compute_summary_stats(data: Matrix, colNames?: string[]): SummaryStats[] {
  if (data.length === 0) return [];
  const nCols = data[0].length;
  const summaries: SummaryStats[] = [];

  for (let c = 0; c < nCols; c++) {
    const colVector: Vector = [];
    for (let r = 0; r < data.length; r++) {
      colVector.push(data[r][c]);
    }

    const clean = colVector.filter(val => val !== null && !isNaN(val));
    const name = colNames && colNames[c] ? colNames[c] : `V${c + 1}`;

    if (clean.length === 0) {
      summaries.push({
        column: name, mean: 0, variance: 0, sd: 0, min: 0, max: 0, median: 0, count: 0
      });
      continue;
    }

    const minVal = Math.min(...clean);
    const maxVal = Math.max(...clean);
    const meanVal = mean(clean);
    const varVal = variance(clean);
    const sdVal = Math.sqrt(varVal);
    const medVal = median(clean);

    summaries.push({
      column: name,
      mean: meanVal,
      variance: varVal,
      sd: sdVal,
      min: minVal,
      max: maxVal,
      median: medVal,
      count: clean.length,
    });
  }

  return summaries;
}

/**
 * Computes covariance matrix for multi-column inputs
 */
export function compute_covariance(data: Matrix): Matrix {
  if (data.length === 0) return [];
  const nRows = data.length;
  const nCols = data[0].length;
  
  // Extract columns
  const cols: Vector[] = Array.from({ length: nCols }, () => []);
  for (let r = 0; r < nRows; r++) {
    for (let c = 0; c < nCols; c++) {
      cols[c].push(data[r][c]);
    }
  }

  // Compute col means
  const colMeansList = cols.map(col => mean(col));

  const covMat: Matrix = Array.from({ length: nCols }, () => new Array(nCols).fill(0));

  for (let i = 0; i < nCols; i++) {
    for (let j = 0; j < nCols; j++) {
      let sumProducts = 0;
      let validCount = 0;
      for (let r = 0; r < nRows; r++) {
        const vi = data[r][i];
        const vj = data[r][j];
        if (vi !== null && !isNaN(vi) && vj !== null && !isNaN(vj)) {
          sumProducts += (vi - colMeansList[i]) * (vj - colMeansList[j]);
          validCount++;
        }
      }
      covMat[i][j] = validCount > 1 ? sumProducts / (validCount - 1) : 0;
    }
  }

  return covMat;
}

/**
 * Computes correlation matrix (Pearson scale)
 */
export function compute_correlation(data: Matrix): Matrix {
  const covMat = compute_covariance(data);
  const nCols = covMat.length;
  const sds = Array.from({ length: nCols }, (_, i) => Math.sqrt(covMat[i][i]));

  const corMat: Matrix = Array.from({ length: nCols }, () => new Array(nCols).fill(0));

  for (let i = 0; i < nCols; i++) {
    for (let j = 0; j < nCols; j++) {
      const denominator = sds[i] * sds[j];
      if (denominator > 1e-15) {
        corMat[i][j] = covMat[i][j] / denominator;
      } else {
        corMat[i][j] = i === j ? 1.0 : 0.0;
      }
    }
  }

  return corMat;
}

/**
 * Computes rolling statistics (mean, SD) on vectors
 */
export function compute_rolling_stats(x: Vector, window: number): RollingStatsResult {
  const n = x.length;
  const rolling_mean: Vector = new Array(n).fill(NaN);
  const rolling_sd: Vector = new Array(n).fill(NaN);

  if (window <= 0) return { rolling_mean, rolling_sd };

  for (let i = window - 1; i < n; i++) {
    const slice = x.slice(i - window + 1, i + 1);
    const clean = slice.filter(val => val !== null && !isNaN(val));

    if (clean.length > 0) {
      rolling_mean[i] = mean(clean);
      rolling_sd[i] = std(clean);
    }
  }

  return { rolling_mean, rolling_sd };
}

/**
 * Calculates quantiles
 */
export function compute_quantiles(x: Vector, probs: Vector = [0.25, 0.5, 0.75]): Vector {
  const clean = x.filter(val => val !== null && !isNaN(val)).sort((a, b) => a - b);
  if (clean.length === 0) return probs.map(() => 0);

  return probs.map(p => {
    if (p <= 0) return clean[0];
    if (p >= 1) return clean[clean.length - 1];
    
    const pos = (clean.length - 1) * p;
    const base = Math.floor(pos);
    const rest = pos - base;
    if (clean[base + 1] !== undefined) {
      return clean[base] + rest * (clean[base + 1] - clean[base]);
    } else {
      return clean[base];
    }
  });
}

/**
 * Estimates parameter fit to distributions
 */
export interface FittedDistribution {
  distribution: string;
  mean: number;
  sd: number;
  meanlog?: number;
  sdlog?: number;
}

export function fit_distribution(x: Vector, dist: "normal" | "lognormal" = "normal"): FittedDistribution {
  const clean = x.filter(val => val !== null && !isNaN(val));
  if (clean.length === 0) {
    return { distribution: dist, mean: 0, sd: 0 };
  }

  if (dist === "normal") {
    return {
      distribution: "normal",
      mean: mean(clean),
      sd: std(clean)
    };
  } else {
    // Lognormal parameter estimations
    const posVal = clean.filter(val => val > 0);
    const logVals = posVal.map(val => Math.log(val));
    return {
      distribution: "lognormal",
      mean: mean(posVal),
      sd: std(posVal),
      meanlog: mean(logVals),
      sdlog: std(logVals)
    };
  }
}
