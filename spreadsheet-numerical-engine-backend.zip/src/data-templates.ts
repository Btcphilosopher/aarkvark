import { Matrix } from "./math-engine/types";

export interface PresetDataset {
  name: string;
  headers: string[];
  data: Matrix;
}

export const PRESETS: PresetDataset[] = [
  {
    name: "Linear Algebra & Covariance Template",
    headers: ["Asset_A", "Asset_B", "Asset_C"],
    data: [
      [12.5, 8.4, 15.1],
      [13.1, 7.9, 14.8],
      [11.9, 9.2, 16.0],
      [14.2, 6.5, 13.9],
      [13.8, 7.1, 14.1],
      [12.9, 8.8, 15.6],
      [15.0, 5.9, 13.0],
      [14.5, 6.2, 13.5]
    ]
  },
  {
    name: "Time-Series & Trend Template",
    headers: ["Timeline", "Observation", "Exogenous"],
    data: [
      [1, 102.1, 5.1],
      [2, 105.4, 5.3],
      [3, 103.8, 5.0],
      [4, 108.9, 5.6],
      [5, 111.2, 6.1],
      [6, 109.5, 5.9],
      [7, 114.7, 6.4],
      [8, 118.1, 6.8],
      [9, 116.3, 6.5],
      [10, 121.9, 7.2],
      [11, 125.4, 7.5],
      [12, 122.8, 7.1],
      [13, 128.9, 7.9],
      [14, 133.2, 8.4],
      [15, 130.5, 8.1]
    ]
  },
  {
    name: "Multiple Regression (OLS) Template",
    headers: ["Independent_X1", "Independent_X2", "Dependent_Y"],
    data: [
      [1.2, 3.4, 12.8],
      [2.1, 4.1, 16.5],
      [1.5, 3.8, 14.2],
      [2.8, 4.9, 21.1],
      [3.0, 5.2, 23.0],
      [1.8, 3.6, 13.9],
      [2.5, 4.5, 18.8],
      [3.2, 5.5, 24.5],
      [2.0, 3.9, 15.6],
      [3.5, 5.9, 26.8]
    ]
  }
];

export const MARKOV_TRANSITION_DEFAULT: Matrix = [
  [0.7, 0.2, 0.1],
  [0.3, 0.6, 0.1],
  [0.1, 0.4, 0.5]
];

export const QUADRATIC_Q_DEFAULT: Matrix = [
  [4, 1],
  [1, 2]
];

export const QUADRATIC_C_DEFAULT = [1, 2]; // weights
