/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import CodeExplorer from "./components/CodeExplorer";
import Simulator from "./components/Simulator";
import SpreadsheetSimulator from "./components/SpreadsheetSimulator";
import MonteCarloAnalyzer from "./components/MonteCarloAnalyzer";
import { FolderCode, Sliders, Sheet, Cpu, Terminal, BookOpen, Layers } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"code" | "simulator" | "spreadsheet" | "monte_carlo">("code");

  return (
    <div className="min-h-screen bg-[#050505] text-[#E0E0E0] flex flex-col font-sans select-none antialiased selection:bg-[#4F46E5]/40 selection:text-white" id="app_body_root">
      {/* Prime Header Block */}
      <header className="border-b border-[#1A1A1A] bg-[#0A0A0A] sticky top-0 z-50 px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4" id="primary_app_header">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-tr from-[#1A1A1A] to-[#333] border border-[#333] rounded-xl flex items-center justify-center shadow-lg shadow-black/80">
            <Layers className="text-[#4F46E5] stroke-[2.5] w-5 h-5" />
          </div>
          <div>
            <h1 className="font-sans font-semibold text-lg text-white tracking-tight leading-none mb-1">
              DIRICHLET ENGINE
            </h1>
            <p className="text-xs text-[#888] font-medium uppercase tracking-wider">
              Compositional Simplex Modeler & Monte Carlo Allocator
            </p>
          </div>
        </div>

        {/* Diagnostic Metadata Labels */}
        <div className="flex items-center gap-3 font-mono text-[10px] text-[#888]">
          <div className="flex items-center gap-1.5 bg-[#1A1A1A] border border-[#333] px-3 py-1.5 rounded-md">
            <span className="w-2 h-2 rounded-full bg-[#4ADE80]" />
            <span>R_RUNTIME: 4.3.1</span>
          </div>
          <div className="bg-[#1A1A1A] border border-[#333] px-3 py-1.5 rounded-md uppercase tracking-wider">
            <span>MKL_ENABLED</span>
          </div>
        </div>
      </header>

      {/* Main Container Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 space-y-8 select-text" id="primary_main_canvas">
        {/* Concept Introduction Bento Box */}
        <div className="bg-[#0A0A0A] border border-[#1A1A1A] rounded-2xl p-6" id="welcome_bento_box">
          <div className="max-w-4xl space-y-3">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#1A1A1A] border border-[#333] text-[#888] text-[10px] uppercase font-mono tracking-widest">
              <BookOpen className="w-3 h-3" />
              STATISTICAL SPECIFICATION OVERVIEW
            </div>
            <h2 className="font-sans font-semibold text-white tracking-tight text-xl leading-snug">
              Unifying Dirichlet Allocations & Compositional Vector Simplex Algebra
            </h2>
            <p className="text-sm text-[#888] leading-relaxed">
              Compositional datasets represent fractional proportions of a whole—such as market portfolios, forex reserves, or multi-dimensional corporate risks—where coordinates are non-negative and strictly sum to exactly <code className="text-[#A5B4FC] font-mono">1.0</code>. 
            </p>
            <p className="text-sm text-[#888] leading-relaxed">
              Because these allocations lie bound on a simplex ($S^K$), they cannot be assessed in unconstrained Euclidean coordinates without causing spurious correlation biases (Pearson's 1897 warning). This statistical engine provides **vectorised R libraries** mapping log-ratio transformations (CLR/ALR) for accurate compositional analysis, custom spreadsheet formulas, and rapid parallel Monte Carlo risk forecasting.
            </p>
          </div>
        </div>

        {/* Category Tab Switcher Row */}
        <div className="flex border-b border-[#1A1A1A] overflow-x-auto gap-2 pb-0.5 select-none scrollbar-none" id="tabs_switcher_row">
          {[
            { id: "code", label: "R Codebase IDE", icon: FolderCode, desc: "Explore & download R source files" },
            { id: "simulator", label: "Parameter Simulator", icon: Sliders, desc: "Manipulate concentrations" },
            { id: "spreadsheet", label: "Spreadsheet Integrator", icon: Sheet, desc: "Interactive formula sheets" },
            { id: "monte_carlo", label: "Monte Carlo Simulator", icon: Cpu, desc: "Compute portfolio joint risk" },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab_select_btn_${tab.id}`}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3.5 px-5 flex items-center gap-2.5 border-b-2 text-left truncate transition-all cursor-pointer ${
                  isSelected
                    ? "border-[#4F46E5] bg-[#0A0A0A] text-white font-medium"
                    : "border-transparent text-[#888] hover:text-[#E0E0E0] hover:bg-[#080808]"
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? "text-[#4F46E5]" : "text-[#555]"}`} />
                <div>
                  <div className="text-xs font-semibold tracking-tight">{tab.label}</div>
                  <div className="text-[10px] text-slate-500 font-normal truncate max-w-40">{tab.desc}</div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Tab Content Display Area */}
        <div className="min-h-[500px]" id="tab_contents_container">
          {activeTab === "code" && <CodeExplorer />}
          {activeTab === "simulator" && <Simulator />}
          {activeTab === "spreadsheet" && <SpreadsheetSimulator />}
          {activeTab === "monte_carlo" && <MonteCarloAnalyzer />}
        </div>
      </main>

      {/* Persistent Page Footer */}
      <footer className="border-t border-[#1A1A1A] bg-[#0A0A0A] p-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs select-none" id="application_firm_footer">
        <div className="flex items-center gap-2">
          <Terminal className="text-[#4F46E5] w-4 h-4" />
          <span className="font-mono text-[#555]">
            Dirichlet Mathematical Engine &copy; 2026. Made with Google AI Studio.
          </span>
        </div>
        <div className="flex gap-4 text-[#888] font-medium text-[11px]">
          <a href="#code_explorer_container" onClick={() => setActiveTab("code")} className="hover:text-white transition-colors">R Package</a>
          <span>&middot;</span>
          <a href="#spreadsheet_simulator_panel" onClick={() => setActiveTab("spreadsheet")} className="hover:text-white transition-colors">Solvency Framework</a>
          <span>&middot;</span>
          <a href="#welcome_bento_box" className="hover:text-white transition-colors">Documentation</a>
        </div>
      </footer>
    </div>
  );
}

