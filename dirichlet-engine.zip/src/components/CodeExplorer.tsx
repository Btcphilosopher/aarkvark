/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { rFiles } from "../lib/rCodebase";
import { Folder, FileText, Check, Copy, Download, Terminal, Settings } from "lucide-react";

export default function CodeExplorer() {
  const [selectedFile, setSelectedFile] = useState(rFiles[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy!", err);
    }
  };

  const handleDownload = (fileName: string, content: string) => {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadAll = () => {
    // We can prompt the user to download individual files or explain they can clone.
    // For single bundle, we download a single bash script or instruct how to use.
    // Or we can create an easy multi-file download block or download a shell script that sets up everything!
    // That is incredibly smart: a bash setup script that creates the whole dir structure and writes todos!
    let setupScript = "#!/bin/bash\n# Dirichlet Distribution Engine Setup Script\nmkdir -p dirichlet-engine/tests\n\n";
    rFiles.forEach(f => {
      setupScript += `cat << 'EOF' > ${f.path}\n${f.content}\nEOF\n\necho "Created ${f.path}"\n`;
    });
    setupScript += '\necho "✓ Successfully created all Dirichlet Engine R files in dirichlet-engine/!"\nchmod +x dirichlet-engine/tests/*.R || true\n';

    const blob = new Blob([setupScript], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "setup_dirichlet_engine.sh";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Group files into directories
  const coreFiles = rFiles.filter(f => !f.path.includes("tests/"));
  const testFiles = rFiles.filter(f => f.path.includes("tests/"));

  return (
    <div className="bg-[#050505] border border-[#1A1A1A] rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row h-[700px]" id="code_explorer_container">
      {/* Directory Sidebar */}
      <div className="w-full md:w-80 bg-[#080808] border-r border-[#1A1A1A] flex flex-col justify-between" id="sidebar_container">
        <div className="p-5 overflow-y-auto flex-1">
          <div className="flex items-center gap-2 mb-6">
            <Terminal className="text-[#4F46E5] w-5 h-5" />
            <h3 className="font-sans font-semibold text-white tracking-tight text-sm uppercase">Engine Directory</h3>
          </div>

          {/* Directory node: dirichlet-engine/ */}
          <div className="mb-4">
            <div className="flex items-center gap-2 text-[#E0E0E0] font-medium text-xs py-1.5 px-2 rounded hover:bg-[#111111]/50">
              <Folder className="w-4 h-4 text-[#888] fill-[#888]/15" />
              <span>dirichlet-engine/</span>
            </div>

            <div className="pl-4 mt-1 space-y-1">
              {coreFiles.map((file) => (
                <button
                  key={file.path}
                  id={`file_btn_${file.name.replace(/\.[^/.]+$/, "")}`}
                  className={`w-full flex items-center gap-2 text-left text-xs py-2 px-3 rounded-lg transition-colors ${
                    selectedFile.path === file.path
                      ? "bg-[#111] text-white border-l-2 border-[#4F46E5] font-medium"
                      : "text-[#888] hover:bg-[#111] hover:text-[#E0E0E0]"
                  }`}
                  onClick={() => setSelectedFile(file)}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span className="truncate">{file.name}</span>
                </button>
              ))}

              {/* Tests directory */}
              <div className="mt-3">
                <div className="flex items-center gap-2 text-[#888] font-medium text-[11px] py-1 px-2 uppercase tracking-wider">
                  <Folder className="w-3.5 h-3.5 text-[#555] fill-[#555]/10" />
                  <span>tests/</span>
                </div>
                <div className="pl-3 mt-1 space-y-1">
                  {testFiles.map((file) => (
                    <button
                      key={file.path}
                      id={`file_btn_${file.name.replace(/\.[^/.]+$/, "")}`}
                      className={`w-full flex items-center gap-2 text-left text-xs py-2 px-3 rounded-lg transition-colors ${
                        selectedFile.path === file.path
                          ? "bg-[#111] text-white border-l-2 border-[#4F46E5] font-medium"
                          : "text-[#888] hover:bg-[#111] hover:text-[#E0E0E0]"
                      }`}
                      onClick={() => setSelectedFile(file)}
                    >
                      <FileText className="w-3.5 h-3.5 text-[#555]" />
                      <span className="truncate">{file.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Global Downloader */}
        <div className="p-4 border-t border-[#1A1A1A] bg-[#0A0A0A]/60">
          <button
            onClick={handleDownloadAll}
            id="download_setup_script_btn"
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white hover:bg-[#E0E0E0] text-black text-xs font-semibold rounded-lg shadow-lg active:scale-98 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            Download Setup Script (.sh)
          </button>
          <p className="text-[10px] text-[#555] text-center mt-2 font-sans font-medium uppercase tracking-wider">
            REBUILDS CODEBASE STRUCTURE INSTANTLY
          </p>
        </div>
      </div>

      {/* Code Editor Body */}
      <div className="flex-1 flex flex-col h-full overflow-hidden" id="editor_body">
        {/* Header toolbar */}
        <div className="bg-[#0A0A0A] px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-[#1A1A1A] gap-3" id="editor_toolbar">
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <span className="text-[11px] font-mono text-[#555] uppercase tracking-widest">Selected file:</span>
              <span className="text-xs font-mono text-[#A5B4FC] select-all font-semibold">{selectedFile.path}</span>
            </div>
            <p className="text-xs text-[#888] max-w-xl">{selectedFile.description}</p>
          </div>

          <div className="flex gap-2 flex-shrink-0">
            <button
              onClick={() => handleCopy(selectedFile.content)}
              id="copy_file_content_btn"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1A1A1A] hover:bg-[#222] text-white text-xs font-medium rounded-lg transition-colors border border-[#333] active:scale-95 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#4ADE80]" />
                  <span className="text-[#4ADE80]">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
            <button
              onClick={() => handleDownload(selectedFile.name, selectedFile.content)}
              id="download_single_file_btn"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#111] hover:bg-[#1A1A1A] text-white text-xs font-medium rounded-lg transition-colors border border-[#333] active:scale-95 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download file</span>
            </button>
          </div>
        </div>

        {/* Code View Canvas */}
        <div className="flex-1 overflow-y-auto font-mono text-[13px] bg-[#050505] p-6 leading-relaxed select-text" id="code_view_canvas">
          <pre className="text-[#E0E0E0] overflow-x-auto">
            <code>
              {selectedFile.content.split("\n").map((line, idx) => {
                // Extremely simple, fast, robust syntax styling for comment lines in R (#/#' ... )
                const isComment = line.trim().startsWith("#");
                
                let lineElPr = line;
                let colorClass = "text-[#E0E0E0]";
                if (isComment) {
                  colorClass = "text-[#666] italic";
                } else if (line.trim().startsWith("source(") || line.trim().startsWith("library(")) {
                  colorClass = "text-[#A5B4FC] font-medium";
                } else if (line.trim().startsWith("stopifnot(") || line.trim().startsWith("tryCatch(")) {
                  colorClass = "text-red-400";
                } else if (line.trim().includes("function(")) {
                  colorClass = "text-indigo-400 font-medium";
                }
                
                return (
                  <div key={idx} className="flex hover:bg-[#111111]/40 select-text leading-5">
                    <span className="w-10 text-right select-none pr-4 text-[#555] font-normal border-r border-[#1A1A1A]/50 text-xs block self-start h-full leading-5">
                      {idx + 1}
                    </span>
                    <span className={`pl-4 select-text font-mono whitespace-pre ${colorClass}`}>
                      {lineElPr}
                    </span>
                  </div>
                );
              })}
            </code>
          </pre>
        </div>
      </div>
    </div>
  );
}
