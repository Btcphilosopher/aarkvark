/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  ALLOCATION_PRESETS,
  getDirichletMean,
  getDirichletVariance,
  getDirichletCovariance,
  sampleDirichlet,
} from "../lib/dirichlet";
import { Sliders, Plus, Trash2, RefreshCw, BarChart2, Hash, AlertTriangle, TrendingDown } from "lucide-react";

export default function Simulator() {
  // Start with a default preset
  const defaultPreset = ALLOCATION_PRESETS[0];
  const [labels, setLabels] = useState<string[]>(defaultPreset.labels);
  const [alphas, setAlphas] = useState<number[]>(defaultPreset.alpha);
  const [selectedPreset, setSelectedPreset] = useState<string>(defaultPreset.name);
  
  // Real-time random draw state
  const [rawSample, setRawSample] = useState<number[]>([]);
  
  // Custom alpha limits
  const MIN_ALPHA = 0.1;
  const MAX_ALPHA = 500;

  // Sync state with selected preset
  const handlePresetChange = (presetName: string) => {
    const preset = ALLOCATION_PRESETS.find((p) => p.name === presetName);
    if (preset) {
      setLabels(preset.labels);
      setAlphas(preset.alpha);
      setSelectedPreset(presetName);
      setRawSample([]); // clear current sample
    }
  };

  // Run initial sample draw
  useEffect(() => {
    triggerDraw();
  }, [alphas]);

  const triggerDraw = () => {
    try {
      const draw = sampleDirichlet(alphas);
      setRawSample(draw);
    } catch (e) {
      console.error(e);
    }
  };

  const handleAlphaChange = (index: number, val: number) => {
    const nextAlphas = [...alphas];
    // Keep raw numeric input sanitized
    const cleanVal = isNaN(val) ? MIN_ALPHA : Math.min(MAX_ALPHA, Math.max(MIN_ALPHA, val));
    nextAlphas[index] = Number(cleanVal.toFixed(1));
    setAlphas(nextAlphas);
    setSelectedPreset("Custom Allocation");
  };

  const handleLabelChange = (index: number, nextText: string) => {
    const nextLabels = [...labels];
    nextLabels[index] = nextText || `Asset ${index + 1}`;
    setLabels(nextLabels);
  };

  const handleAddElement = () => {
    if (alphas.length >= 6) return; // Limit to max 6 elements for perfect visual density
    setLabels([...labels, `Asset ${labels.length + 1}`]);
    setAlphas([...alphas, 10]); // default concentration
    setSelectedPreset("Custom Allocation");
  };

  const handleRemoveElement = (index: number) => {
    if (alphas.length <= 2) return; // Keep at least 2 components
    const nextAlphas = alphas.filter((_, idx) => idx !== index);
    const nextLabels = labels.filter((_, idx) => idx !== index);
    setAlphas(nextAlphas);
    setLabels(nextLabels);
    setSelectedPreset("Custom Allocation");
  };

  // Analytical outputs
  const analyticMean = getDirichletMean(alphas);
  const analyticVariance = getDirichletVariance(alphas);
  const analyticCovariance = getDirichletCovariance(alphas);

  // Totals calculations
  const totalAlpha = alphas.reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-8" id="simulator_root">
      {/* Visual Presets Selector */}
      <div className="bg-[#0A0A0A] border border-[#1A1A1A] rounded-2xl p-6 shadow-xl" id="preset_selector_panel">
        <h3 className="font-sans font-semibold text-white tracking-tight text-base mb-2">
          Interactive Context Presets
        </h3>
        <p className="text-xs text-[#888] mb-6 max-w-2xl">
          Dirichlet modeling represents asset portfolios, currency cash sheets, or operational risks. Select a financial template or define a custom concentration structure.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3" id="presets_grid">
          {ALLOCATION_PRESETS.map((p) => {
            const isSelected = p.name === selectedPreset;
            return (
              <button
                key={p.name}
                id={`preset_card_${p.name.toLowerCase().replace(/[^a-z0-9]/g, "_")}`}
                onClick={() => handlePresetChange(p.name)}
                className={`text-left p-4 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? "bg-[#111111] border-[#4F46E5] shadow-md shadow-[#4F46E5]/5 text-white"
                    : "bg-[#050505] border-[#1A1A1A] hover:border-[#333] hover:bg-[#111]/30 text-[#888]"
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="font-sans font-semibold text-sm truncate">{p.name}</span>
                  <span className="text-[9px] uppercase font-mono tracking-wider px-1.5 py-0.5 rounded bg-[#1A1A1A] text-[#888] border border-[#333]">
                    {p.category}
                  </span>
                </div>
                <p className="text-[11px] text-[#555] line-clamp-2 leading-relaxed">
                  {p.description}
                </p>
                <div className="mt-2.5 flex items-center gap-1.5 font-mono text-[10px] text-[#555]">
                  <span className="font-medium text-[#888]">α parameters:</span>
                  <span>({p.alpha.join(", ")})</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="simulator_midgrid">
        {/* Concentrations Adjustment Sidebar (Left) */}
        <div className="lg:col-span-5 bg-[#0A0A0A] border border-[#1A1A1A] rounded-2xl p-6 shadow-xl flex flex-col justify-between" id="concentration_settings">
          <div>
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#4F46E5]" />
                <h4 className="font-sans font-semibold text-white text-sm">
                  Concentration Parameters (α)
                </h4>
              </div>
              <span className="font-mono text-[10px] text-[#4ADE80] bg-[#4ADE80]/10 px-2 py-0.5 rounded border border-[#4ADE80]/20">
                Sum α₀ = {totalAlpha.toFixed(1)}
              </span>
            </div>
            
            <p className="text-xs text-[#888] mb-6 leading-relaxed">
              Higher α values decrease variance, focusing random samples tightly around the expected mean. Values below 1.0 push components towards extreme corners (sparsity).
            </p>

            <div className="space-y-4" id="alpha_adjustable_list">
              {alphas.map((alphaValue, idx) => (
                <div
                  key={idx}
                  className="bg-[#050505] rounded-xl p-4 border border-[#1A1A1A] hover:border-[#333] transition-colors"
                  id={`comp_row_${idx}`}
                >
                  <div className="flex items-center justify-between gap-3 mb-2.5">
                    <input
                      type="text"
                      id={`comp_label_input_${idx}`}
                      value={labels[idx]}
                      onChange={(e) => handleLabelChange(idx, e.target.value)}
                      className="bg-transparent text-white border-b border-transparent hover:border-[#1A1A1A] focus:border-[#4F46E5] hover:bg-[#111111] text-xs font-semibold px-1 py-0.5 rounded max-w-40 transition-all focus:outline-none"
                    />
                    
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-[10px] text-[#555]">α =</span>
                        <input
                          type="number"
                          id={`comp_alpha_input_${idx}`}
                          step="0.5"
                          value={alphaValue}
                          onChange={(e) => handleAlphaChange(idx, parseFloat(e.target.value))}
                          className="w-14 bg-[#111] text-[#E0E0E0] font-mono text-xs font-semibold text-center py-1 border border-[#1A1A1A] rounded focus:border-[#4F46E5] focus:outline-none"
                        />
                      </div>

                      {alphas.length > 2 && (
                        <button
                          onClick={() => handleRemoveElement(idx)}
                          id={`remove_elem_btn_${idx}`}
                          className="p-1 hover:bg-[#1A1A1A] text-[#555] hover:text-red-400 rounded transition-all cursor-pointer"
                          title="Remove Dimension"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Slider Control */}
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      id={`comp_slider_${idx}`}
                      min={MIN_ALPHA}
                      max="100"
                      step={alphaValue <= 5 ? "0.1" : "1"}
                      value={alphaValue}
                      onChange={(e) => handleAlphaChange(idx, parseFloat(e.target.value))}
                      className="flex-1 accent-[#4F46E5] h-1 bg-[#1A1A1A] rounded-lg cursor-pointer"
                    />
                    <span className="font-mono text-[10px] text-[#555] w-8 text-right font-medium">
                      {(analyticMean[idx] * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-[#1A1A1A] flex justify-between gap-3">
            <button
              onClick={handleAddElement}
              id="add_dimension_btn"
              disabled={alphas.length >= 6}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-[#050505] hover:bg-[#111] border border-[#1A1A1A] hover:border-[#333] text-[#888] hover:text-white text-xs font-medium rounded-xl disabled:opacity-50 disabled:cursor-not-allowed transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Dimension (Max 6)
            </button>
            <button
              onClick={triggerDraw}
              id="draw_raw_sample_btn"
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-white hover:bg-[#E0E0E0] text-black font-semibold text-xs rounded-xl shadow-lg active:scale-98 transition-all cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Draw Single Sample
            </button>
          </div>
        </div>

        {/* Statistical Allocation Charts & Analytical Dashboard (Right - Col span 7) */}
        <div className="lg:col-span-7 space-y-8" id="analytical_outputs">
          {/* Analytical Outputs (Mean & Standard Deviation bars) */}
          <div className="bg-[#0A0A0A] border border-[#1A1A1A] rounded-2xl p-6 shadow-xl" id="numerical_composition">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-[#4ADE80]" />
                <h4 className="font-sans font-semibold text-white text-sm">
                  Analytical Weights & Uncertainty Boundaries
                </h4>
              </div>
              <span className="text-[10px] font-mono text-[#555] uppercase tracking-widest bg-[#050505] px-2 py-0.5 rounded border border-[#1A1A1A]">
                Analytical Bounds
              </span>
            </div>

            <div className="space-y-4" id="distribution_components_list">
              {alphas.map((_, idx) => {
                const meanPerc = analyticMean[idx] * 100;
                // Standard deviation = sqrt(variance)
                const stdDev = Math.sqrt(analyticVariance[idx]);
                const stdDevPerc = stdDev * 100;
                
                // Sample representation
                const sampledPerc = (rawSample[idx] || 0) * 100;

                return (
                  <div key={idx} className="space-y-1.5" id={`analytics_bar_group_${idx}`}>
                    <div className="flex justify-between items-end text-xs">
                      <div className="flex items-center gap-1.5 truncate">
                        <span className="font-mono text-[10px] font-bold text-[#A5B4FC]">V{idx + 1}</span>
                        <span className="font-sans font-semibold text-[#E0E0E0] truncate">{labels[idx]}</span>
                      </div>
                      <div className="flex gap-4 font-mono text-[11px] text-[#888]">
                        <div>
                          <span className="text-[#555] text-[10px] mr-1">Mean:</span>
                          <span className="font-semibold text-white">{analyticMean[idx].toFixed(4)}</span>
                        </div>
                        <div>
                          <span className="text-[#555] text-[10px] mr-1">StdDev (σ):</span>
                          <span className="font-semibold text-[#4ADE80]">±{stdDev.toFixed(4)}</span>
                        </div>
                        <div>
                          <span className="text-[#555] text-[10px] mr-1">Draw:</span>
                          <span className="font-semibold text-[#A5B4FC]">{rawSample[idx]?.toFixed(4)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Dual visual bar - Standard Deviation Interval (Emerald) & Expected Mean (White marker) */}
                    <div className="relative h-6 bg-[#050505] rounded-lg overflow-hidden border border-[#1A1A1A] flex items-center">
                      
                      {/* Standard Deviation boundary bar */}
                      <div
                        className="absolute h-full bg-[#4ADE80]/10 border-x border-[#10B981]/25"
                        style={{
                          left: `${Math.max(0, meanPerc - stdDevPerc)}%`,
                          width: `${Math.min(100, stdDevPerc * 2)}%`,
                        }}
                      />

                      {/* Expected Value Fill */}
                      <div
                        className="absolute h-1 bg-[#4ADE80]/80 shadow-sm"
                        style={{
                          left: "0px",
                          width: `${meanPerc}%`,
                        }}
                      />

                      {/* Single sample representation marker */}
                      <div
                        className="absolute w-2.5 h-4 bg-white rounded-sm border border-[#111] shadow-lg top-1 transition-all duration-300"
                        style={{
                          left: `calc(${sampledPerc}% - 5px)`,
                        }}
                        title="Random Sample Draw Location"
                      />

                      {/* Mean target line */}
                      <div
                        className="absolute w-0.5 h-full bg-[#4F46E5] z-10"
                        style={{
                          left: `${meanPerc}%`,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-5 p-3 rounded bg-[#050505] border border-[#1A1A1A] flex items-start gap-2.5 text-[11px] text-[#888]">
              <AlertTriangle className="w-3.5 h-3.5 text-[#4ADE80] flex-shrink-0 mt-0.5" />
              <div>
                The indigo line represents the **expected mathematical mean**. The green shaded areas show **one standard deviation uncertainty (±σ)**. The white markers track your **real-time random draw**. Press **Draw Single Sample** to watch how these fluctuate on the simplex bounds.
              </div>
            </div>
          </div>

          {/* Symmetrical Covariance Heatmap */}
          <div className="bg-[#0A0A0A] border border-[#1A1A1A] rounded-2xl p-6 shadow-xl" id="covariance_heatmap_panel">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-red-400" />
                <h4 className="font-sans font-semibold text-white text-sm">
                  Symmetric Covariance Matrix (Cov(X_i, X_j))
                </h4>
              </div>
              <span className="font-mono text-[9px] uppercase text-red-400 bg-red-500/5 border border-red-500/10 px-2 py-0.5 rounded">
                Always Negative Off-Diag
              </span>
            </div>

            <p className="text-xs text-[#888] mb-5 leading-relaxed">
              Because Dirichlet compositions must sum to exactly 1.0, components are strictly constrained. Thus, **all off-diagonal covariances are negative**—increasing one asset decreases the capacity of the others.
            </p>

            {/* Matrix Table */}
            <div className="overflow-x-auto border border-[#1A1A1A] rounded-xl" id="covariance_grid_container">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#050505] hover:bg-[#050505]">
                    <th className="p-3 border-b border-[#1A1A1A] text-[10px] font-mono text-[#555] font-bold uppercase w-12">
                      ID
                    </th>
                    {labels.map((lbl, idx) => (
                      <th
                        key={idx}
                        className="p-3 border-b border-[#1A1A1A] text-[10px] font-mono text-[#888] font-semibold truncate max-w-28"
                        title={lbl}
                      >
                        V{idx + 1}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {analyticCovariance.map((row, rIdx) => (
                    <tr key={rIdx} className="border-b border-[#1A1A1A]/40 hover:bg-[#111111]/40 transition-colors">
                      <td className="p-3 font-mono text-[10px] font-bold text-[#888] bg-[#050505]/50">
                        V{rIdx + 1}
                      </td>
                      {row.map((val, cIdx) => {
                        const isDiag = rIdx === cIdx;
                        // Design background colors:
                        // Diagonal (Positive variance) -> Soft emerald green tint
                        // Off-diagonal (Negative covariance) -> Soft reddish tint proportional to intensity
                        const bgStyle = isDiag
                          ? { backgroundColor: `rgba(74, 222, 128, ${Math.min(0.20, val * 8)})` }
                          : { backgroundColor: `rgba(239, 68, 68, ${Math.min(0.18, Math.abs(val) * 12)})` };

                        return (
                          <td
                             key={cIdx}
                             style={bgStyle}
                             className="p-3 font-mono text-[11px] text-[#E0E0E0] transition-colors"
                          >
                            <span className={isDiag ? "text-[#4ADE80] font-medium" : "text-red-400"}>
                              {val >= 0 ? "+" : ""}
                              {val.toFixed(5)}
                            </span>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-start text-[10px] font-mono mt-3 text-[#555] pl-1">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-[#4ADE80]/15 border border-[#4ADE80]/20" />
                <span>Diagonal (Positive Component Variance)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded bg-red-500/15 border border-red-500/20" />
                <span>Off-Diagonal (Negative Joint Covariance)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
