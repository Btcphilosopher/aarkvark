/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from "react";
import {
  sampleDirichletMultiple,
  getDirichletMean,
  computePortfolioVariancesSim,
} from "../lib/dirichlet";
import { TrendingUp, Award, Activity, ShieldAlert, Cpu, Percent, RefreshCw } from "lucide-react";

export default function MonteCarloAnalyzer() {
  const [numSimulations, setNumSimulations] = useState<number>(20000);
  const [isSimulating, setIsSimulating] = useState(false);
  const [entropyScores, setEntropyScores] = useState<number[]>([]);
  const [varianceSamples, setVarianceSamples] = useState<number[]>([]);
  const [simulationTime, setSimulationTime] = useState(0);

  // Asset configurations for this analyzer (4 Assets: Stocks, Bonds, Gold, Cash)
  const labels = ["High-Beta Equity", "Long-Term Treasury", "Real Bullion (Gold)", "Liquid Yield Cash"];
  const alphas = [35, 30, 20, 15]; // conservative balanced model

  // Pre-defined Asset Covariance matrix representing standard macro correlation
  const assetCovariance = [
    [0.0450, -0.0050,  0.0080, -0.0010], // Eq
    [-0.0050, 0.0120, -0.0020,  0.0005], // Bnd
    [0.0080, -0.0020,  0.0350,  0.0010], // Gld
    [-0.0010, 0.0005,  0.0010,  0.0020], // Csh
  ];

  useEffect(() => {
    runSimulations();
  }, [numSimulations]);

  const runSimulations = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const start = performance.now();
      
      // Sample weights list (N rows x K columns)
      const weightsList = sampleDirichletMultiple(alphas, numSimulations);

      // Compute aggregate Portfolio Variances
      const portVariances = computePortfolioVariancesSim(weightsList, assetCovariance);
      
      // Compute Shannon entropy scores of each portfolio: H = -sum( W_i * ln(W_i) )
      const entropies = weightsList.map((weights) => {
        return -weights.reduce((acc, w) => acc + w * Math.log(w + 1e-15), 0);
      });

      const end = performance.now();
      
      // Sort portfolio variances for statistical percentiles
      const sortedVars = [...portVariances].sort((a, b) => a - b);
      
      setVarianceSamples(sortedVars);
      setEntropyScores(entropies);
      setSimulationTime(Math.round(end - start));
      setIsSimulating(false);
    }, 100);
  };

  // Perform statistics calculations based on the sorted portfolio variances
  const statistics = useMemo(() => {
    if (varianceSamples.length === 0) return null;
    const len = varianceSamples.length;

    const meanVar = varianceSamples.reduce((a, b) => a + b, 0) / len;
    const medianVar = varianceSamples[Math.floor(len * 0.5)];
    const p95VaR = varianceSamples[Math.floor(len * 0.95)]; // At 95% confidence, variance will not exceed this
    const p99VaR = varianceSamples[Math.floor(len * 0.99)];

    // Sort entropy scores
    const sortedEntropies = [...entropyScores].sort((a, b) => a - b);
    const medianEntropy = sortedEntropies[Math.floor(len * 0.5)];

    return {
      meanVar,
      medianVar,
      p95VaR,
      p99VaR,
      medianEntropy,
    };
  }, [varianceSamples, entropyScores]);

  // Compute histogram bins for standard density visualizer curve
  const histogramBins = useMemo(() => {
    if (varianceSamples.length === 0) return [];
    
    // Choose 25 uniform bins between 5th and 98th percentile to ignore extreme tails
    const len = varianceSamples.length;
    const minVal = varianceSamples[Math.floor(len * 0.01)];
    const maxVal = varianceSamples[Math.floor(len * 0.98)];
    const binCount = 30;
    const binWidth = (maxVal - minVal) / binCount;

    const bins = Array.from({ length: binCount }, (_, i) => ({
      index: i,
      lowerBound: minVal + i * binWidth,
      center: minVal + (i + 0.5) * binWidth,
      count: 0,
    }));

    varianceSamples.forEach((val) => {
      if (val >= minVal && val <= maxVal) {
        const binIndex = Math.min(binCount - 1, Math.floor((val - minVal) / binWidth));
        bins[binIndex].count++;
      }
    });

    const maxCount = Math.max(...bins.map((b) => b.count)) || 1;
    return bins.map((b) => ({
      ...b,
      density: b.count / maxCount, // normalized to 0..1 for standard layout scaling
    }));
  }, [varianceSamples]);

  return (
    <div className="bg-[#0A0A0A] border border-[#1A1A1A] rounded-2xl p-6 shadow-xl space-y-6" id="monte_carlo_analyzer_root">
      {/* Simulation Configurations Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-[#1A1A1A]" id="mc_header_row">
        <div>
          <h3 className="font-sans font-semibold text-white tracking-tight text-base mb-1 flex items-center gap-2">
            <Cpu className="text-[#4F46E5] w-4 h-4 ml-0.5" />
            Parallel Monte Carlo Allocation Simulation
          </h3>
          <p className="text-xs text-[#888] max-w-xl">
            Simulate thousands of Dirichlet compositions mapped to asset portfolio variance distributions. Compiles joint risk dispersion properties instantly.
          </p>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto" id="mc_configurations_buttons">
          <div className="flex bg-[#050505] p-1.5 rounded-xl border border-[#1A1A1A] gap-1 flex-1 md:flex-initial">
            {[10000, 50000, 100000].map((num) => (
              <button
                key={num}
                onClick={() => setNumSimulations(num)}
                id={`mc_sim_count_btn_${num}`}
                className={`px-3 py-1.5 font-mono text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  numSimulations === num
                    ? "bg-[#4F46E5] text-white"
                    : "text-[#888] hover:text-[#E0E0E0] hover:bg-[#111]"
                }`}
              >
                {num.toLocaleString()} Runs
              </button>
            ))}
          </div>
          <button
            onClick={runSimulations}
            id="mc_re_simulate_btn"
            disabled={isSimulating}
            className="flex items-center gap-1.5 px-4.5 py-2 bg-white hover:bg-[#E0E0E0] text-black text-xs font-semibold rounded-xl active:scale-98 transition-all disabled:opacity-50 font-sans shadow-lg cursor-pointer"
          >
            <Activity className="w-3.5 h-3.5" />
            Re-run
          </button>
        </div>
      </div>

      {isSimulating ? (
        <div className="flex flex-col items-center justify-center h-80 bg-[#050505]/40 rounded-2xl border border-[#1A1A1A]" id="mc_loading_canvas">
          <RefreshCw className="w-8 h-8 text-[#4F46E5] animate-spin mb-4" />
          <p className="font-mono text-xs text-[#888]">Computing joint likelihood boundaries across {numSimulations.toLocaleString()} vectors...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="mc_grid_results">
          {/* Statistical Outliner Cards (Left - Col span 4) */}
          <div className="lg:col-span-4 space-y-6" id="mc_metrics_sidebar">
            <h4 className="font-sans font-semibold text-xs text-[#555] uppercase tracking-wider pl-1">
              Simulated Risk Outcomes
            </h4>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Value at Risk (95% VaR) */}
              <div className="bg-[#050505] rounded-2xl p-5 border border-[#1A1A1A]" id="metric_card_var">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-xs text-[#888] font-sans font-medium">95% Risk Level (95% VaR)</span>
                  <ShieldAlert className="w-4 h-4 text-rose-450 stroke-[2]" />
                </div>
                <div className="font-mono text-2xl font-bold text-white flex items-baseline gap-1">
                  {(statistics?.p95VaR || 0).toFixed(5)}
                  <span className="text-xs text-[#555] font-normal">σ²</span>
                </div>
                <p className="text-[10.5px] text-[#888] mt-2 leading-relaxed">
                  Historical confidence barrier. Across simulated weights, portfolio return variance is model-bound to remain below this limit with 95% likelihood.
                </p>
              </div>

              {/* Compositional Entropy */}
              <div className="bg-[#050505] rounded-2xl p-5 border border-[#1A1A1A]" id="metric_card_entropy">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-xs text-[#888] font-sans font-medium">Shannon Entropy (Diversity)</span>
                  <TrendingUp className="w-4 h-4 text-[#4ADE80]" />
                </div>
                <div className="font-mono text-2xl font-bold text-white flex items-baseline gap-1">
                  {(statistics?.medianEntropy || 0).toFixed(4)}
                  <span className="text-xs text-[#555] font-normal">nits</span>
                </div>
                <p className="text-[10.5px] text-[#888] mt-2 leading-relaxed">
                  Quantifies diversification. A uniform portfolio has maximum entropy (1.386). Lower values signify concentration asymmetry in specific assets.
                </p>
              </div>

              {/* Execution Diagnostics */}
              <div className="bg-[#050505] rounded-2xl p-4 border border-[#1A1A1A] flex items-center justify-between" id="metric_diagnostics">
                <div className="flex items-center gap-2">
                  <Cpu className="w-3.5 h-3.5 text-[#4F46E5]" />
                  <span className="text-[11px] text-[#888] font-sans">Compiling performance:</span>
                </div>
                <div className="font-mono text-[11px] text-[#4ADE80] font-semibold bg-[#4ADE80]/10 px-2 py-0.5 rounded border border-[#4ADE80]/20">
                  {simulationTime} ms ({Math.round(numSimulations / (simulationTime || 1))}k sims/sec)
                </div>
              </div>
            </div>
          </div>

          {/* Probability Density Curve Plot (Right - Col span 8) */}
          <div className="lg:col-span-8 space-y-6" id="mc_analytics_graph_panel">
            <div className="bg-[#050505]/40 border border-[#1A1A1A] rounded-2xl p-6" id="density_graph_canvas">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h4 className="font-sans font-semibold text-white text-sm">
                    Compositional Portfolio Risk Probability Density (f(σ²))
                  </h4>
                  <p className="text-[11px] text-[#555] font-sans">
                     Distribution curve modeled for balanced assets: ({alphas.map(a => `${a}%`).join(", ")})
                  </p>
                </div>
                <span className="text-[10px] font-mono font-bold text-[#888] bg-[#050505] border border-[#1A1A1A] px-2 py-0.5 rounded">
                  Monte Carlo Density
                </span>
              </div>

              {/* Simple, pristine custom SVG drawing */}
              <div className="relative h-60 w-full" id="density_svg_wrapper">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none">
                  {/* Grid Lines */}
                  {[25, 50, 75].map((yVal) => (
                    <line
                      key={yVal}
                      x1="0"
                      y1={yVal}
                      x2="100"
                      y2={yVal}
                      stroke="rgba(255, 255, 255, 0.04)"
                      strokeWidth="0.5"
                    />
                  ))}

                  {/* Shaded Area of the Curve */}
                  <path
                    d={`
                      M 0 100
                      ${histogramBins.map((bin, i) => {
                        const x = (i / (histogramBins.length - 1)) * 100;
                        const y = 100 - bin.density * 85; // invert and scale
                        return `L ${x} ${y}`;
                      }).join(" ")}
                      L 100 100 Z
                    `}
                    fill="url(#density-grad)"
                    stroke="rgba(99, 102, 241, 0.6)"
                    strokeWidth="1.5"
                  />

                  {/* Target analytical mean marker */}
                  {statistics && (
                    <line
                      x1="50"
                      y1="0"
                      x2="50"
                      y2="100"
                      stroke="rgba(52, 211, 153, 0.4)"
                      strokeWidth="1.5"
                      strokeDasharray="2 2"
                    />
                  )}

                  {/* Analytical Gradients Definitions */}
                  <defs>
                    <linearGradient id="density-grad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="rgba(99, 102, 241, 0.35)" />
                      <stop offset="100%" stopColor="rgba(99, 102, 241, 0.01)" />
                    </linearGradient>
                  </defs>
                </svg>

                {/* Left/Right graph axes titles */}
                <div className="absolute bottom-1 left-2 font-mono text-[9px] text-[#555]">
                  Min Variance ({(histogramBins[0]?.center || 0).toFixed(4)})
                </div>
                <div className="absolute bottom-1 right-2 font-mono text-[9px] text-[#555]">
                  Max Variance ({(histogramBins[histogramBins.length - 1]?.center || 0).toFixed(4)})
                </div>

                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center select-none pointer-events-none" id="density_overlay_label">
                  <span className="font-sans font-bold text-[10px] uppercase tracking-widest text-[#4ADE80] bg-[#050505] border border-[#1A1A1A] px-2.5 py-1 rounded shadow-md">
                    Expectation Center: {(statistics?.meanVar || 0).toFixed(5)}
                  </span>
                </div>
              </div>

              <div className="flex justify-between text-[11px] font-sans text-[#888] border-t border-[#1A1A1A] pt-4 mt-2 px-1">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-1 bg-indigo-500/80 rounded" />
                  <span>Variance Likelihood Boundary Projection</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-1 border-t border-dashed border-emerald-400/60" />
                  <span className="font-semibold text-emerald-400/80">Median Expected Variance (σ² = {(statistics?.medianVar || 0).toFixed(5)})</span>
                </div>
              </div>
            </div>

            {/* Matrix Covariance Explainer Card */}
            <div className="bg-[#050505] p-5 rounded-2xl border border-[#1A1A1A] grid grid-cols-1 md:grid-cols-2 gap-4" id="mc_analytics_explainers">
              <div className="space-y-1.5">
                <h5 className="font-sans font-semibold text-white text-xs flex items-center gap-1">
                  <Percent className="w-3.5 h-3.5 text-[#4F46E5]" />
                  Simulated Asset Allocations
                </h5>
                <p className="text-[11px] text-[#555] leading-relaxed">
                  In each simulation, compositional weights are sampled from the Dirichlet distribution. Because of joint asset dependencies, portfolio variances reveal the expected density structure of diversified risk outcomes.
                </p>
              </div>

              <div className="space-y-1.5 font-sans">
                <h5 className="font-sans font-semibold text-white text-xs flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-[#4ADE80]" />
                  Diversification Metrics
                </h5>
                <p className="text-[11px] text-[#555] leading-relaxed">
                  As the alpha concentrations expand uniformly ($\alpha_0 \to \infty$), Dirichlet entropy shrinks. The portfolio density aggregates towards a single certain variance expectation, eliminating statistical fluctuations.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
