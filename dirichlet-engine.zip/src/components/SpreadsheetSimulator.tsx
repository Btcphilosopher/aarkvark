/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  getDirichletMean,
  getDirichletVariance,
  normaliseVector,
  validateProbabilityVector,
  sampleDirichlet,
} from "../lib/dirichlet";
import { Grid, HelpCircle, RefreshCw, Layers, Edit3, Bookmark } from "lucide-react";

interface CellState {
  expression: string; // user input (e.g., '=SUM(A2:C2)' or '10')
  value: string; // evaluated result shown in grid
  isHighlighted?: boolean;
}

export default function SpreadsheetSimulator() {
  const cols = ["A", "B", "C", "D", "E", "F"];
  const rows = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  // Excel-style cell registry
  const [grid, setGrid] = useState<{ [cellId: string]: CellState }>({});
  const [activeCell, setActiveCell] = useState<string | null>(null);
  const [editorText, setEditorText] = useState("");
  const [seed, setSeed] = useState(1);

  // Initialize spreadsheet with data and formulas
  useEffect(() => {
    const initialGrid: { [cellId: string]: CellState } = {
      // Row 1: Headers
      A1: { expression: "Stocks (α_1)", value: "Stocks (α_1)" },
      B1: { expression: "Bonds (α_2)", value: "Bonds (α_2)" },
      C1: { expression: "Cash (α_3)", value: "Cash (α_3)" },
      D1: { expression: "Aggregate (α_0)", value: "Aggregate (α_0)" },
      E1: { expression: "Constraint Check", value: "Constraint Check" },
      F1: { expression: "Comments", value: "Comments" },

      // Row 2: Concentration Inputs (alphas)
      A2: { expression: "40", value: "40" },
      B2: { expression: "30", value: "30" },
      C2: { expression: "10", value: "10" },
      D2: { expression: "=SUM(A2:C2)", value: "" },
      E2: { expression: "=PROBABILITY_CHECK(A2:C2)", value: "" },
      F2: { expression: "Concentration inputs", value: "Concentration inputs" },

      // Row 4: Mean Weights (Analytical Spill)
      A3: { expression: "Analytical E[X]", value: "Analytical E[X]" },
      B3: { expression: "--- Expected Mean Composition ---", value: "Expected Composition" },
      C3: { expression: "", value: "" },
      D3: { expression: "=SUM(A4:C4)", value: "" },
      E3: { expression: "=PROBABILITY_CHECK(A4:C4)", value: "" },
      F3: { expression: "Mean weight vector", value: "Mean weight vector" },
      
      A4: { expression: "=DIRICHLET_MEAN(A2:C2)", value: "" },
      B4: { expression: "(spilled)", value: "" },
      C4: { expression: "(spilled)", value: "" },

      // Row 6: Analytical Variances (Spill)
      A5: { expression: "Analytical Var[X]", value: "Analytical Var[X]" },
      B5: { expression: "--- Expected Variance Composition ---", value: "Variance Matrix" },
      C5: { expression: "", value: "" },
      D5: { expression: "Expected standard devs:", value: "Expected stddev:" },
      E5: { expression: "", value: "" },
      F5: { expression: "Variance of weights", value: "Variance of weights" },

      A6: { expression: "=DIRICHLET_VARIANCE(A2:C2)", value: "" },
      B6: { expression: "(spilled)", value: "" },
      C6: { expression: "(spilled)", value: "" },

      // Row 7: Un-normalised input vector
      A8: { expression: "Constituent Weights", value: "Portfolio Assets:" },
      B8: { expression: "15", value: "15" },
      C8: { expression: "35", value: "35" },
      D8: { expression: "50", value: "50" },
      E8: { expression: "=PROBABILITY_CHECK(B8:D8)", value: "" },
      F8: { expression: "Arbitrary percentages", value: "Arbitrary percentages" },

      // Row 9: Normalized Vector (Spill)
      A9: { expression: "=NORMALISE(B8:D8)", value: "" },
      B9: { expression: "(spilled)", value: "" },
      C9: { expression: "(spilled)", value: "" },
      D9: { expression: "(spilled)", value: "" },
      E9: { expression: "=PROBABILITY_CHECK(A9:C9)", value: "" },
      F9: { expression: "Simplex mapped weights", value: "Simplex mapped weights" },

      // Row 10: Random Allocation Drags (Spill)
      A10: { expression: "=DIRICHLET_SAMPLE(A2:C2)", value: "" },
      B10: { expression: "(spilled)", value: "" },
      C10: { expression: "(spilled)", value: "" },
    };

    setGrid(initialGrid);
  }, []);

  // Recalculate grid values
  useEffect(() => {
    if (Object.keys(grid).length === 0) return;
    evaluateGrid();
  }, [seed, Object.keys(grid).length]);

  const evaluateGrid = () => {
    const nextGrid = { ...grid };

    // Clear previous spill cells to avoid showing stale values
    cols.forEach((col) => {
      rows.forEach((row) => {
        const id = `${col}${row}`;
        if (nextGrid[id] && nextGrid[id].expression === "(spilled)") {
          nextGrid[id] = { ...nextGrid[id], value: "" };
        }
      });
    });

    // Sub-routine to resolve cell range
    const getRangeValues = (rangeStr: string): { values: number[]; cells: string[] } => {
      const match = rangeStr.match(/([A-F])([0-9]+):([A-F])([0-9]+)/i);
      if (!match) return { values: [], cells: [] };

      const startCol = match[1].toUpperCase();
      const startRow = parseInt(match[2]);
      const endCol = match[3].toUpperCase();
      const endRow = parseInt(match[4]);

      const startColIdx = cols.indexOf(startCol);
      const endColIdx = cols.indexOf(endCol);

      const resolvedCells: string[] = [];
      const resolvedValues: number[] = [];

      const rMin = Math.min(startRow, endRow);
      const rMax = Math.max(startRow, endRow);
      const cMin = Math.min(startColIdx, endColIdx);
      const cMax = Math.max(startColIdx, endColIdx);

      for (let r = rMin; r <= rMax; r++) {
        for (let c = cMin; c <= cMax; c++) {
          const colLetter = cols[c];
          const cellId = `${colLetter}${r}`;
          resolvedCells.push(cellId);
          
          const cellVal = parseFloat(nextGrid[cellId]?.value || nextGrid[cellId]?.expression || "0");
          resolvedValues.push(isNaN(cellVal) ? 0 : cellVal);
        }
      }

      return { values: resolvedValues, cells: resolvedCells };
    };

    // First, evaluate all plain numeric or string cells
    Object.keys(nextGrid).forEach((cellId) => {
      const cell = nextGrid[cellId];
      if (cell && !cell.expression.startsWith("=")) {
        cell.value = cell.expression; // identity
      }
    });

    // Helper to run formula evaluation in layers
    const evaluateFormulas = () => {
      Object.keys(nextGrid).forEach((cellId) => {
        const cell = nextGrid[cellId];
        if (!cell || !cell.expression.startsWith("=")) return;

        const expr = cell.expression.toUpperCase().trim();

        // 1. SUM
        if (expr.startsWith("=SUM(")) {
          const rangeMatch = expr.match(/SUM\((A[1-9]|B[1-9]|C[1-9]|D[1-9]|E[1-9]|F[1-9]|A10|B10|C10|D10|E10|F10):(A[1-9]|B[1-9]|C[1-9]|D[1-9]|E[1-9]|F[1-9]|A10|B10|C10|D10|E10|F10)\)/);
          if (rangeMatch) {
            const rangeStr = expr.substring(5, expr.length - 1);
            const { values } = getRangeValues(rangeStr);
            const sum = values.reduce((acc, v) => acc + v, 0);
            cell.value = sum.toFixed(4);
          }
        }

        // 2. PROBABILITY_CHECK
        if (expr.startsWith("=PROBABILITY_CHECK(")) {
          const rangeMatch = expr.match(/PROBABILITY_CHECK\((.+)\)/);
          if (rangeMatch) {
            const rangeStr = rangeMatch[1];
            const { values } = getRangeValues(rangeStr);
            const isValid = validateProbabilityVector(values, 1e-4);
            cell.value = isValid ? "TRUE" : "FALSE";
          }
        }

        // 3. DIRICHLET_MEAN (Spills horizontally)
        if (expr.startsWith("=DIRICHLET_MEAN(")) {
          const rangeMatch = expr.match(/DIRICHLET_MEAN\((.+)\)/);
          if (rangeMatch) {
            const rangeStr = rangeMatch[1];
            const { values } = getRangeValues(rangeStr);
            try {
              const means = getDirichletMean(values);
              
              // Place first value in the current cell
              cell.value = means[0].toFixed(5);
              
              // Spill the rest into subsequent horizontal columns
              const colIdx = cols.indexOf(cellId[0]);
              const rowNum = cellId.substring(1);
              for (let i = 1; i < means.length; i++) {
                const targetCol = cols[colIdx + i];
                if (targetCol) {
                  const targetId = `${targetCol}${rowNum}`;
                  nextGrid[targetId] = {
                    expression: "(spilled)",
                    value: means[i].toFixed(5),
                    isHighlighted: true
                  };
                }
              }
            } catch (err) {
              cell.value = "#VALUE!";
            }
          }
        }

        // 4. DIRICHLET_VARIANCE (Spills horizontally)
        if (expr.startsWith("=DIRICHLET_VARIANCE(")) {
          const rangeMatch = expr.match(/DIRICHLET_VARIANCE\((.+)\)/);
          if (rangeMatch) {
            const rangeStr = rangeMatch[1];
            const { values } = getRangeValues(rangeStr);
            try {
              const variances = getDirichletVariance(values);
              cell.value = variances[0].toFixed(5);

              const colIdx = cols.indexOf(cellId[0]);
              const rowNum = cellId.substring(1);
              for (let i = 1; i < variances.length; i++) {
                const targetCol = cols[colIdx + i];
                if (targetCol) {
                  const targetId = `${targetCol}${rowNum}`;
                  nextGrid[targetId] = {
                    expression: "(spilled)",
                    value: variances[i].toFixed(5),
                    isHighlighted: true
                  };
                }
              }
            } catch (err) {
              cell.value = "#VALUE!";
            }
          }
        }

        // 5. NORMALISE (Spills horizontally)
        if (expr.startsWith("=NORMALISE(")) {
          const rangeMatch = expr.match(/NORMALISE\((.+)\)/);
          if (rangeMatch) {
            const rangeStr = rangeMatch[1];
            const { values } = getRangeValues(rangeStr);
            try {
              const normalised = normaliseVector(values);
              cell.value = normalised[0].toFixed(5);

              const colIdx = cols.indexOf(cellId[0]);
              const rowNum = cellId.substring(1);
              for (let i = 1; i < normalised.length; i++) {
                const targetCol = cols[colIdx + i];
                if (targetCol) {
                  const targetId = `${targetCol}${rowNum}`;
                  nextGrid[targetId] = {
                    expression: "(spilled)",
                    value: normalised[i].toFixed(5),
                    isHighlighted: true
                  };
                }
              }
            } catch (err) {
              cell.value = "#VALUE!";
            }
          }
        }

        // 6. DIRICHLET_SAMPLE (Random distribution draw with seed spill)
        if (expr.startsWith("=DIRICHLET_SAMPLE(")) {
          const rangeMatch = expr.match(/DIRICHLET_SAMPLE\((.+)\)/);
          if (rangeMatch) {
            const rangeStr = rangeMatch[1];
            const { values } = getRangeValues(rangeStr);
            try {
              const sample = sampleDirichlet(values);
              cell.value = sample[0].toFixed(5);

              const colIdx = cols.indexOf(cellId[0]);
              const rowNum = cellId.substring(1);
              for (let i = 1; i < sample.length; i++) {
                const targetCol = cols[colIdx + i];
                if (targetCol) {
                  const targetId = `${targetCol}${rowNum}`;
                  nextGrid[targetId] = {
                    expression: "(spilled)",
                    value: sample[i].toFixed(5),
                    isHighlighted: true
                  };
                }
              }
            } catch (err) {
              cell.value = "#VALUE!";
            }
          }
        }
      });
    };

    // Run evaluations twice to resolve dependent cell layers (e.g. A2 -> SUM -> PROB_CHECK)
    evaluateFormulas();
    evaluateFormulas();

    setGrid(nextGrid);
  };

  const handleCellSelect = (cellId: string) => {
    setActiveCell(cellId);
    setEditorText(grid[cellId]?.expression || "");
  };

  const handleCellUpdate = () => {
    if (!activeCell) return;
    const nextGrid = { ...grid };
    nextGrid[activeCell] = {
      expression: editorText,
      value: editorText, // gets refreshed on eval
    };
    setGrid(nextGrid);
    setActiveCell(null);
    setSeed((s) => s + 1); // trigger eval
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleCellUpdate();
    }
  };

  const forceRecalculate = () => {
    setSeed((s) => s + 1);
  };

  return (
    <div className="bg-[#0A0A0A] border border-[#1A1A1A] rounded-2xl p-6 shadow-xl space-y-6" id="spreadsheet_simulator_panel">
      <div>
        <h3 className="font-sans font-semibold text-white tracking-tight text-base mb-1.5 flex items-center gap-2">
          <Layers className="text-[#4ADE80] w-4 h-4" />
          Excel & Sheets Formula Engine Simulator
        </h3>
        <p className="text-xs text-[#888] max-w-2xl">
          Interact with a simulated spreadsheet sheet that compiles Dirichlet metrics in real-time. Double-click any cell to edit concentration integers or custom functions, and watch values spill automatically.
        </p>
      </div>

      {/* Editor Tool-bar Row */}
      <div className="bg-[#050505] border border-[#1A1A1A] rounded-xl p-3 flex flex-col md:flex-row items-stretch md:items-center gap-3" id="sheet_toolbar_row">
        <div className="flex items-center gap-2 flex-shrink-0 bg-[#0A0A0A] px-3 py-1.5 rounded-lg border border-[#1A1A1A]">
          <span className="text-[10px] uppercase font-mono tracking-wider text-[#555] font-bold">Cell:</span>
          <span className="font-mono text-xs text-[#4F46E5] font-bold w-10 text-center uppercase bg-[#050505] px-1 py-0.5 rounded border border-[#1A1A1A]">
            {activeCell || "--"}
          </span>
        </div>

        <div className="flex-1 flex gap-2">
          <div className="bg-[#0A0A0A] flex-1 flex items-center px-3 py-1 rounded-lg border border-[#1A1A1A]">
            <span className="font-mono text-sm text-[#555] mr-2 select-none">fx</span>
            <input
              type="text"
              id="cell_editor_input_field"
              value={editorText}
              onChange={(e) => setEditorText(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Click any cell on the grid to inspect or input formulas..."
              className="w-full bg-transparent text-xs font-mono text-[#E0E0E0] outline-none placeholder:text-[#555]"
              disabled={!activeCell}
            />
          </div>
          {activeCell && (
            <button
              onClick={handleCellUpdate}
              id="save_cell_value_btn"
              className="px-3.5 py-1.5 bg-white text-black text-xs font-semibold rounded-lg hover:bg-[#E0E0E0] transition-all cursor-pointer"
            >
              Commit
            </button>
          )}
        </div>

        <button
          onClick={forceRecalculate}
          id="recalc_sheet_data_btn"
          className="flex items-center justify-center gap-1.5 px-4 py-2 bg-[#1A1A1A] hover:bg-[#222] text-white text-xs font-semibold rounded-lg shadow border border-[#333] transition-colors cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Recalculate Sheet (Draw Randoms)
        </button>
      </div>

      {/* Main Excel Sheet Grid View */}
      <div className="overflow-x-auto border border-[#1A1A1A] rounded-xl bg-[#050505]" id="google_sheets_simulator_canvas">
        <table className="w-full border-collapse select-text">
          <thead>
            <tr className="bg-[#050505]">
              {/* Corner header */}
              <th className="border-r border-b border-[#1A1A1A] w-10 bg-[#050505] text-[#555] p-2 text-center text-[10px] font-mono select-none font-bold">
                #
              </th>
              {cols.map((col) => (
                <th
                  key={col}
                  className="border-r border-b border-[#1A1A1A] p-2 text-center text-xs font-mono font-bold text-[#888] bg-[#0A0A0A] select-none min-w-36"
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row} className="hover:bg-[#111111]/30">
                {/* Side Row Header Indicator */}
                <td className="border-r border-b border-[#1A1A1A] bg-[#050505] text-[#555] p-2 text-center text-[10px] font-mono select-none font-bold">
                  {row}
                </td>
                {cols.map((col) => {
                  const cellId = `${col}${row}`;
                  const cell = grid[cellId] || { expression: "", value: "" };
                  const isActive = activeCell === cellId;

                  // Label row or spacing titles styling
                  const isTitleRow = row === 3 || row === 5;
                  
                  let bgClass = "bg-transparent";
                  let textClass = "text-[#E0E0E0]";
                  
                  if (isActive) {
                    bgClass = "bg-[#1A1A1A] ring-2 ring-[#4F46E5] ring-inset";
                    textClass = "text-white";
                  } else if (cell.isHighlighted) {
                    bgClass = "bg-[#111]";
                    textClass = "text-[#4ADE80] font-medium";
                  } else if (cell.expression.startsWith("=")) {
                    bgClass = "bg-[#111111]/30";
                    textClass = "text-[#A5B4FC] font-medium";
                  } else if (isTitleRow) {
                    bgClass = col === "A" ? "bg-[#111111]/80" : "bg-[#111111]/40";
                    textClass = col === "A" ? "text-[#888] font-sans font-bold text-[10px] scale-95 origin-left" : "text-[#555]";
                  } else if (cell.expression === "(spilled)") {
                    bgClass = "bg-[#111]/35";
                    textClass = "text-[#E0E0E0]/60 italic font-mono";
                  }

                  const displayVal = cell.value || cell.expression;

                  return (
                    <td
                      key={col}
                      id={`cell_${cellId}`}
                      onClick={() => !isTitleRow && handleCellSelect(cellId)}
                      className={`border-r border-b border-[#1A1A1A]/80 p-2.5 font-mono text-[11px] h-9 max-w-40 truncate relative cursor-pointer select-text transition-colors ${bgClass} ${textClass}`}
                      title={`${cellId}: ${cell.expression}`}
                    >
                      {displayVal}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Dynamic Spreadsheet Guide Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#050505]/55 p-4 rounded-xl border border-[#1A1A1A]" id="sheets_formulas_guide">
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 font-sans font-semibold text-xs text-[#A5B4FC] uppercase tracking-wide">
            <Bookmark className="w-3.5 h-3.5" />
            Formula References
          </div>
          <ul className="text-xs text-[#888] space-y-2 list-none pl-0">
            <li>
              <code className="text-[#A5B4FC] font-mono text-[11px] mr-1">=DIRICHLET_MEAN(A2:C2)</code> 
              Spills expectations across columns.
            </li>
            <li>
              <code className="text-[#A5B4FC] font-mono text-[11px] mr-1">=DIRICHLET_VARIANCE(A2:C2)</code>
              Calculates expected component variances.
            </li>
            <li>
              <code className="text-[#A5B4FC] font-mono text-[11px] mr-1">=DIRICHLET_SAMPLE(A2:C2)</code>
              Generates a dynamic simulated weight allocation composition vector that sums to exactly 1.0!
            </li>
          </ul>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-1.5 font-sans font-semibold text-xs text-[#4ADE80] uppercase tracking-wide">
            <HelpCircle className="w-3.5 h-3.5" />
            Did you know?
          </div>
          <p className="text-xs text-[#888] leading-relaxed">
            In standard spreadsheet platforms, functions like <code className="text-[#4ADE80] font-mono">DIRICHLET_MEAN</code> utilize an "Array Formula spill pattern". Entering the formula in a single cell automatically calculates and writes components into adjacent columns. You can edit the parameters in cells <code className="text-[#E0E0E0] font-bold">A2</code>, <code className="text-[#E0E0E0] font-bold">B2</code>, or <code className="text-[#E0E0E0] font-bold">C2</code> to watch the values ripple down.
          </p>
        </div>
      </div>
    </div>
  );
}
