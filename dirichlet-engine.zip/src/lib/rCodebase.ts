/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RFile } from "../types";

export const rFiles: RFile[] = [
  {
    name: "dirichlet_core.R",
    path: "dirichlet-engine/dirichlet_core.R",
    description: "Core Dirichlet distribution operations including vectorized random sampling, mean, variance, and covariance computations.",
    content: `#' Dirichlet Distribution Core Module
#'
#' This module provides high-performance mathematical and statistical operations
#' for the Dirichlet distribution. It is vectorised to handle 1,000,000+ samples efficiently.
#'
#' @author Senior R Developer & Statistician
#' @date 2026-06-01

#' Generate a Single Dirichlet Sample
#'
#' @param alpha Vector of length K representing concentration parameters. Must be > 0.
#' @return A vector of length K summing to 1.
#' @export
dirichlet_sample <- function(alpha) {
  if (any(alpha <= 0)) {
    stop("Concentration parameters (alpha) must be strictly positive.")
  }
  
  # Sample K independent Gamma random variables
  # Gamma(alpha_i, rate = 1)
  gammas <- rgamma(length(alpha), shape = alpha, rate = 1)
  sum_gammas <- sum(gammas)
  
  # Safe division
  if (sum_gammas == 0) {
    # Fallback to equal allocation if sum is exactly zero
    return(rep(1 / length(alpha), length(alpha)))
  }
  
  return(gammas / sum_gammas)
}


#' Generate Multiple Dirichlet Samples
#'
#' Vectorised implementation using column-major matrix creation.
#' No explicit loops used. Handles 1,000,000+ rows instantly.
#'
#' @param alpha Vector of concentration parameters of length K.
#' @param n Number of samples to generate.
#' @return A matrix of dimension n x K where each row is a composition.
#' @export
dirichlet_samples <- function(alpha, n = 1000) {
  if (any(alpha <= 0)) {
    stop("Concentration parameters (alpha) must be strictly positive.")
  }
  n <- as.integer(n)
  if (n <= 0) {
    stop("Number of samples (n) must be a positive integer.")
  }
  
  k <- length(alpha)
  
  # Draw n * k independent Gamma random variables.
  # Using column-major repetition for high performance.
  # Each column of the resulting matrix corresponds to alpha[j].
  shapes <- rep(alpha, each = n)
  gamma_samples <- matrix(
    rgamma(n * k, shape = shapes, rate = 1),
    nrow = n,
    ncol = k,
    byrow = FALSE
  )
  
  # Compute row sums for normalisation
  row_sums <- rowSums(gamma_samples)
  
  # Handle potential division by zero safely
  row_sums[row_sums == 0] <- 1e-15
  
  # Divide each row element by its row sum (recycled column-major in R)
  samples <- gamma_samples / row_sums
  
  colnames(samples) <- paste0("V", 1:k)
  return(samples)
}


#' Compute Expected Value (Mean) of Dirichlet Distribution
#'
#' @param alpha Vector of concentration parameters.
#' @return Vector of expected values of length K.
#' @export
dirichlet_mean <- function(alpha) {
  if (any(alpha <= 0)) {
    stop("Concentration parameters (alpha) must be strictly positive.")
  }
  
  return(alpha / sum(alpha))
}


#' Compute Variances of Dirichlet Components
#'
#' @param alpha Vector of concentration parameters.
#' @return Vector of variances of length K.
#' @export
dirichlet_variance <- function(alpha) {
  if (any(alpha <= 0)) {
    stop("Concentration parameters (alpha) must be strictly positive.")
  }
  
  alpha0 <- sum(alpha)
  variance <- (alpha * (alpha0 - alpha)) / (alpha0^2 * (alpha0 + 1))
  return(variance)
}


#' Compute Covariance Matrix of Dirichlet Components
#'
#' @param alpha Vector of concentration parameters.
#' @return A K x K covariance matrix.
#' @export
dirichlet_covariance <- function(alpha) {
  if (any(alpha <= 0)) {
    stop("Concentration parameters (alpha) must be strictly positive.")
  }
  
  k <- length(alpha)
  alpha0 <- sum(alpha)
  denom <- alpha0^2 * (alpha0 + 1)
  
  # Vectorized outer product for off-diagonal covariances: -alpha_i * alpha_j / denom
  cov_mat <- - (alpha %*% t(alpha)) / denom
  
  # Set diagonal values to the exact variances: alpha_i * (alpha0 - alpha_i) / denom
  diag(cov_mat) <- (alpha * (alpha0 - alpha)) / denom
  
  # Label matrix
  labels <- paste0("V", 1:k)
  rownames(cov_mat) <- labels
  colnames(cov_mat) <- labels
  
  return(cov_mat)
}
`
  },
  {
    name: "probability_utils.R",
    path: "dirichlet-engine/probability_utils.R",
    description: "Utility functions for normalizing arbitrary vectors and performing Aitchison simplex geometric calculations.",
    content: `#' Probability Vectors & Compositional Geometry Utilities
#'
#' Provides high-level normalisation utilities and basic distance matrices
#' for compositional simplex analysis.
#'
#' @author Senior R Developer & Statistician
#' @date 2026-06-01

#' Normalise an Arbitrary Vector
#'
#' Maps any real non-negative vector to the simplex S^k (summing to 1).
#'
#' @param x Vector of non-negative real numbers.
#' @return A normalised probability vector.
#' @export
normalise_vector <- function(x) {
  if (length(x) == 0) {
    stop("Input vector is empty.")
  }
  if (any(x < 0, na.rm = TRUE)) {
    stop("All elements in the vector must be non-negative for probability mapping.")
  }
  
  # Remove NAs or set them to zero
  x[is.na(x)] <- 0
  
  s <- sum(x)
  if (s == 0) {
    # If all zeros, return uniform probability vector
    return(rep(1 / length(x), length(x)))
  }
  
  return(x / s)
}


#' Compute Aitchison Distance Between Two Compositions
#'
#' Calculates the Euclidean distance of the Centered Log-Ratio (CLR) transforms.
#'
#' @param x First compositional vector (sum = 1, elements > 0).
#' @param y Second compositional vector (sum = 1, elements > 0).
#' @return Numeric Aitchison distance.
#' @export
aitchison_distance <- function(x, y) {
  if (any(x <= 0) || any(y <= 0)) {
    stop("Aitchison geometry requires elements to be strictly positive (no zero values).")
  }
  
  # Normalise internally to ensure simplex membership
  x_norm <- x / sum(x)
  y_norm <- y / sum(y)
  
  # Centered Log-Ratio transform values
  clr_x <- log(x_norm) - mean(log(x_norm))
  clr_y <- log(y_norm) - mean(log(y_norm))
  
  return(sqrt(sum((clr_x - clr_y)^2)))
}


#' Convert 3-Component Composition to 2D Ternary Coordinates
#'
#' Maps a simplex vector of length 3 to Cartesian coordinates (X, Y)
#' for plotting on an equilateral triangle (Ternary Space).
#'
#' @param x Vector of 3 positive values that sum to 1.
#' @return A list with coordinates 'x' and 'y'.
#' @export
barycentric_coords <- function(x) {
  if (length(x) != 3) {
    stop("Barycentric transformation requires a 3-component composition vector.")
  }
  
  comp <- x / sum(x)
  
  # Corner coordinates of equilateral triangle:
  # Tip A (top, index 1): (0.5, sqrt(3)/2)
  # Tip B (bottom-left, index 2): (0, 0)
  # Tip C (bottom-right, index 3): (1, 0)
  
  # Coordinate calculations
  cart_x <- 0.5 * (2 * comp[3] + comp[1]) / sum(comp)
  cart_y <- (sqrt(3) / 2) * comp[1] / sum(comp)
  
  return(list(x = cart_x, y = cart_y))
}
`
  },
  {
    name: "validation.R",
    path: "dirichlet-engine/validation.R",
    description: "Validation procedures for vector properties, simplex constraints, and model parameter boundaries.",
    content: `#' Validation Module for Dirichlet Parameters & Compositions
#'
#' Validates mathematical rules and tolerances to assure simplex validity.
#'
#' @author Senior R Developer & Statistician
#' @date 2026-06-01

#' Validate Probability Vector
#'
#' Validates that a vector lies on the probability simplex.
#'
#' @param x Vector to check.
#' @param tol Tolerance for the sum calculation.
#' @return TRUE if valid probability vector, FALSE otherwise.
#' @export
validate_probability_vector <- function(x, tol = 1e-7) {
  if (is.null(x) || length(x) == 0) {
    return(FALSE)
  }
  
  if (any(is.na(x)) || any(is.nan(x)) || any(is.infinite(x))) {
    return(FALSE)
  }
  
  # Check elements are non-negative
  if (any(x < 0)) {
    return(FALSE)
  }
  
  # Check sum constraint
  sum_x <- sum(x)
  if (abs(sum_x - 1.0) > tol) {
    return(FALSE)
  }
  
  return(TRUE)
}


#' Validate Concentration Parameters (Alpha)
#'
#' Parameters for Dirichlet must be strictly positive (alpha_i > 0).
#'
#' @param alpha Vector of parameters to check.
#' @return TRUE if valid, FALSE otherwise.
#' @export
validate_concentration_vector <- function(alpha) {
  if (is.null(alpha) || length(alpha) == 0) {
    return(FALSE)
  }
  
  if (any(is.na(alpha)) || any(is.nan(alpha)) || any(is.infinite(alpha))) {
    return(FALSE)
  }
  
  if (any(alpha <= 0)) {
    return(FALSE)
  }
  
  return(TRUE)
}
`
  },
  {
    name: "compositional_analysis.R",
    path: "dirichlet-engine/compositional_analysis.R",
    description: "Statistical transformations for compositional data including ALR, CLR, and sample geometric means.",
    content: `#' Compositional Data Analysis Transformations
#'
#' Provides standard transformations for Aitchison simplex statistics.
#' Since compositional data cannot be analyzed sub-dimensionally in standard Euclidean space
#' without spurious correlations (Pearson's 1897 warning), log-ratio transforms map
#' vectors to unconstrained real coordinates.
#'
#' @author Senior R Developer & Statistician
#' @date 2026-06-01

#' Centered Log-Ratio (CLR) Transform
#'
#' Maps compositions to R^K space subject to a zero-sum constraint.
#'
#' @param x Compositional vector (must be strictly positive).
#' @return Transformed real vector of length K.
#' @export
clr_transform <- function(x) {
  if (any(x <= 0)) {
    stop("Composition contains zero values. Use zero-replacement before CLR.")
  }
  
  comp <- x / sum(x)
  gmean <- exp(mean(log(comp)))
  
  return(log(comp / gmean))
}


#' Inverse Centered Log-Ratio (CLR) Transform
#'
#' Maps CLR transformed real values back to the simplex.
#'
#' @param y Real vector of length K mapping back to S^K.
#' @return S^K probability vector.
#' @export
clr_inverse <- function(y) {
  exp_y <- exp(y)
  return(exp_y / sum(exp_y))
}


#' Additive Log-Ratio (ALR) Transform
#'
#' Maps composition of length K to R^(K-1) using a chosen reference component.
#'
#' @param x Compositional vector (must be strictly positive).
#' @param ref_idx Index of reference variable (defaults to length of x).
#' @return Real vector of length K-1.
#' @export
alr_transform <- function(x, ref_idx = length(x)) {
  if (any(x <= 0)) {
    stop("Composition contains zero values. Use zero-replacement before ALR.")
  }
  
  comp <- x / sum(x)
  ref_val <- comp[ref_idx]
  
  # Take ratios excluding reference
  ratios <- comp[-ref_idx] / ref_val
  
  return(log(ratios))
}


#' Inverse Additive Log-Ratio (ALR) Transform
#'
#' Maps R^(K-1) back onto the K-dimensional simplex.
#'
#' @param y Real vector of length K-1.
#' @param ref_idx Index of reference variable where the omitted dimension is reconstructed.
#' @return Simplex vector of length K.
#' @export
alr_inverse <- function(y, ref_idx = length(y) + 1) {
  # Reconstitute ratios relative to reference which equals 1
  ratios <- exp(y)
  
  k <- length(y) + 1
  full_vals <- rep(1, k)
  
  # Place transformed ratios back
  indices_to_fill <- (1:k)[-ref_idx]
  full_vals[indices_to_fill] <- ratios
  
  # Normalise
  return(full_vals / sum(full_vals))
}


#' Geometric Mean of Compositional Data
#'
#' Calculates the closed geometric mean, which functions as the center/mean representation
#' for compositional datasets in the simplex.
#'
#' @param data_matrix A matrix (n x K) of positive compositions where each row sums to 1.
#' @return A closed geometric mean vector of length K.
#' @export
compositional_mean <- function(data_matrix) {
  if (!is.matrix(data_matrix)) {
    data_matrix <- as.matrix(data_matrix)
  }
  
  if (any(data_matrix <= 0)) {
    stop("Composition data contains zero values. Geometry requires strictly positive entries.")
  }
  
  # Calculate column geometric means
  geom_means <- apply(data_matrix, 2, function(col) exp(mean(log(col))))
  
  # Close (normalise) the geometric mean vector
  return(geom_means / sum(geom_means))
}
`
  },
  {
    name: "monte_carlo.R",
    path: "dirichlet-engine/monte_carlo.R",
    description: "Monte Carlo simulation routine mapping Dirichlet boundaries to portfolio risks and distribution metrics.",
    content: `#' Monte Carlo Simulation Module for Asset Allocations
#'
#' Models random compositional allocations to conduct portfolio simulations,
#' risk budgeting analysis, and standard percentile risk stress-testing.
#'
#' @author Senior R Developer & Statistician
#' @date 2026-06-01

#' Simulate Dirichlet Allocations with Statistics
#'
#' Generates simulation weights, and evaluates key compositional dispersion stats.
#'
#' @param alpha Vector of Dirichlet concentration parameters.
#' @param n Number of simulated runs (default 10,000 for stability).
#' @return A list containing:
#'   - \code{samples}: The full n x K matrix of allocation weights.
#'   - \code{means}: Expected allocation per component.
#'   - \code{variances}: Calculated variances.
#'   - \code{percentiles}: High, median, and low allocation thresholds (5%, 50%, 95%) per component.
#'   - \code{shannon_entropy}: A vector of allocation diversities (uncertainty metric) for each simulated draw.
#' @export
simulate_allocations <- function(alpha, n = 10000) {
  # Generate samples
  w_matrix <- dirichlet_samples(alpha, n)
  
  # Calculate empirical stats
  emp_mean <- colMeans(w_matrix)
  emp_var <- apply(w_matrix, 2, var)
  
  # Perform percentile calculation for interval analysis
  intervals <- apply(w_matrix, 2, quantile, probs = c(0.05, 0.50, 0.95))
  rownames(intervals) <- c("P5", "P50", "P95")
  
  # Calculate Shannon entropy for each portfolio draw (measures allocation dispersion)
  # H_j = -sum( w_ji * ln(w_ji) )
  shannon_ent <- -rowSums(w_matrix * log(w_matrix + 1e-15))
  
  return(list(
    samples = w_matrix,
    empirical_mean = emp_mean,
    empirical_variance = emp_var,
    percentiles = intervals,
    allocation_entropy = shannon_ent
  ))
}


#' Portfolio Variance Simulation
#'
#' Feeds Dirichlet weights through an asset covariance matrix to simulate
#' the distribution of aggregate portfolio risk (variances).
#'
#' @param weights_matrix Matrix (n x K) of simulated Dirichlet weights.
#' @param asset_cov A positive-definite K x K covariance matrix representing asset returns.
#' @return Vector of length n representing the portfolio returns variance in each simulation.
#' @export
simulate_portfolio_variance <- function(weights_matrix, asset_cov) {
  if (!is.matrix(weights_matrix)) {
    weights_matrix <- as.matrix(weights_matrix)
  }
  k <- ncol(weights_matrix)
  
  if (nrow(asset_cov) != k || ncol(asset_cov) != k) {
    stop("Asset covariance matrix dimensions must match the number of assets/weights columns.")
  }
  
  # Vectorized calculation: Var_p = w' * Sigma * w
  # w' * Sigma returns a (n x K) intermediate matrix
  # Then we do row-wise dot-product with w.
  w_sigma <- weights_matrix %*% asset_cov
  port_var <- rowSums(w_sigma * weights_matrix)
  
  return(port_var)
}
`
  },
  {
    name: "spreadsheet_wrappers.R",
    path: "dirichlet-engine/spreadsheet_wrappers.R",
    description: "Spreadsheet interface hooks making engine primitives accessible in Google Sheets and VBA.",
    content: `#' Spreadsheet Interface Wrappers
#'
#' These wrapper functions provide clean, flat-signature entries
#' compatible with external spreadsheet links (such as Excel via BERT,
#' ExcelR, RExcel, or Rcom, or Google Sheets web handlers).
#'
#' @author Senior R Developer & Statistician
#' @date 2026-06-01

#' Excel-Friendly Vector Normalization
#'
#' @param input_range Vector or single-column cell range.
#' @return A matrix of row/column shape matching the normalised vector.
#' @export
NORMALISE <- function(input_range) {
  # Core cleanup of range inputs (converts 2D grids to 1D vectors)
  vec <- as.numeric(as.vector(input_range))
  vec <- vec[!is.na(vec)]
  
  if (length(vec) == 0) return(NA)
  
  res <- normalise_vector(vec)
  return(res)
}


#' Excel-Friendly Probability Check
#'
#' @param input_range Vector of cell values.
#' @return Logical TRUE/FALSE.
#' @export
PROBABILITY_CHECK <- function(input_range) {
  vec <- as.numeric(as.vector(input_range))
  vec <- vec[!is.na(vec)]
  
  return(validate_probability_vector(vec))
}


#' Excel-Friendly Dirichlet Expected Mean
#'
#' @param alpha_range Cell range representing concentration vector alpha.
#' @return Expected weights vector of length K.
#' @export
DIRICHLET_MEAN <- function(alpha_range) {
  alpha <- as.numeric(as.vector(alpha_range))
  alpha <- alpha[!is.na(alpha)]
  
  if (!validate_concentration_vector(alpha)) return(NA)
  return(dirichlet_mean(alpha))
}


#' Excel-Friendly Dirichlet Variance
#'
#' @param alpha_range Cell range representing concentration vector alpha.
#' @return Expected variance of components.
#' @export
DIRICHLET_VARIANCE <- function(alpha_range) {
  alpha <- as.numeric(as.vector(alpha_range))
  alpha <- alpha[!is.na(alpha)]
  
  if (!validate_concentration_vector(alpha)) return(NA)
  return(dirichlet_variance(alpha))
}


#' Excel-Friendly Dirichlet Covariance Matrix
#'
#' @param alpha_range Cell range representing concentration vector alpha.
#' @return A 2D array (K x K) of covariances.
#' @export
DIRICHLET_COV <- function(alpha_range) {
  alpha <- as.numeric(as.vector(alpha_range))
  alpha <- alpha[!is.na(alpha)]
  
  if (!validate_concentration_vector(alpha)) return(NA)
  return(dirichlet_covariance(alpha))
}


#' Excel-Friendly Random Dirichlet Allocation
#'
#' @param alpha_range Cell range representing concentration vector alpha.
#' @return A randomised composition vector.
#' @export
DIRICHLET_SAMPLE <- function(alpha_range) {
  alpha <- as.numeric(as.vector(alpha_range))
  alpha <- alpha[!is.na(alpha)]
  
  if (!validate_concentration_vector(alpha)) return(NA)
  return(dirichlet_sample(alpha))
}
`
  },
  {
    name: "test_sampling.R",
    path: "dirichlet-engine/tests/test_sampling.R",
    description: "Unit tests evaluating random weights generation boundaries, sums, and matrix outputs.",
    content: `# Test Dirichlet Sampling Primitives
source("../dirichlet_core.R")
source("../validation.R")

print("Executing test_sampling.R...")

# Test 1: Single sample properties
alpha <- c(2, 3, 5)
sample <- dirichlet_sample(alpha)

stopifnot(length(sample) == 3)
stopifnot(all(sample >= 0))
stopifnot(abs(sum(sample) - 1.0) < 1e-9)
stopifnot(validate_probability_vector(sample))

# Test 2: Multi sample matrices
n_samples <- 50000
samples_matrix <- dirichlet_samples(alpha, n = n_samples)

stopifnot(nrow(samples_matrix) == n_samples)
stopifnot(ncol(samples_matrix) == 3)

# Row sums should all equal 1 within limit
row_sums <- rowSums(samples_matrix)
stopifnot(all(abs(row_sums - 1.0) < 1e-9))

# Columns of matrix must be non-negative
stopifnot(all(samples_matrix >= 0))

# Sample-based mean approximation check (Monte Carlo integrity)
expected_mean <- dirichlet_mean(alpha)
empirical_mean <- colMeans(samples_matrix)
mean_deviation <- abs(expected_mean - empirical_mean)

stopifnot(all(mean_deviation < 0.01))

print("✓ dirichlet_sample and dirichlet_samples passed assertions.")
`
  },
  {
    name: "test_mean.R",
    path: "dirichlet-engine/tests/test_mean.R",
    description: "Unit tests asserting mathematical expectations against custom vector lengths.",
    content: `# Test Analytical Expected Values
source("../dirichlet_core.R")

print("Executing test_mean.R...")

# Expected values: alpha_i / alpha0
stopifnot(all(dirichlet_mean(c(1, 1, 1)) == c(1/3, 1/3, 1/3)))
stopifnot(all(dirichlet_mean(c(5, 5)) == c(0.5, 0.5)))

alpha_skewed <- c(10, 5, 5, 20)
expected_skewed <- c(10, 5, 5, 20) / 40
stopifnot(all(dirichlet_mean(alpha_skewed) == expected_skewed))

# Error boundary check
tryCatch({
  dirichlet_mean(c(-1, 2, 3))
  stop("Expected error for negative alpha parameters, but none occurred.")
}, error = function(e) {
  # Error successfully raised
})

print("✓ dirichlet_mean passed assertions.")
`
  },
  {
    name: "test_variance.R",
    path: "dirichlet-engine/tests/test_variance.R",
    description: "Unit tests evaluating analytical variances and covariance matrix properties.",
    content: `# Test Dirichlet Variances & Covariances
source("../dirichlet_core.R")

print("Executing test_variance.R...")

# Alpha parameters
alpha <- c(10, 15, 25) # Sum = 50 (alpha0)
alpha0 <- sum(alpha)

# Analytical variances
analytic_vars <- dirichlet_variance(alpha)

# Component 1 variance = 10 * 40 / (50^2 * 51) = 400 / 127500 = 0.003137255
expected_var1 <- (10 * 40) / (alpha0^2 * (alpha0 + 1))
stopifnot(abs(analytic_vars[1] - expected_var1) < 1e-12)

# Verify covariance properties
cov_matrix <- dirichlet_covariance(alpha)

stopifnot(nrow(cov_matrix) == 3)
stopifnot(ncol(cov_matrix) == 3)

# Test diagonal equals variance
stopifnot(all(abs(diag(cov_matrix) - analytic_vars) < 1e-12))

# Test off-diagonals are negative as required for Dirichlet constraints
stopifnot(cov_matrix[1, 2] < 0)
stopifnot(cov_matrix[1, 3] < 0)
stopifnot(cov_matrix[2, 3] < 0)

# Symmetric matrix check
stopifnot(isSymmetric(cov_matrix))

print("✓ dirichlet_variance and dirichlet_covariance passed assertions.")
`
  },
  {
    name: "test_normalisation.R",
    path: "dirichlet-engine/tests/test_normalisation.R",
    description: "Unit tests verifying transformation correctness of the scaling operator.",
    content: `# Test Compositional Normalizer
source("../probability_utils.R")
source("../validation.R")

print("Executing test_normalisation.R...")

# Test clean mapping
v1 <- c(5, 10, 15)
res1 <- normalise_vector(v1)
stopifnot(all(abs(res1 - c(0.16666667, 0.33333333, 0.5)) < 1e-6))
stopifnot(validate_probability_vector(res1))

# Test with zero inputs
v2 <- c(0, 0, 5)
res2 <- normalise_vector(v2)
stopifnot(all(res2 == c(0, 0, 1)))
stopifnot(validate_probability_vector(res2))

# Test zero-sum input (fallback case)
v3 <- c(0, 0, 0)
res3 <- normalise_vector(v3)
stopifnot(all(abs(res3 - c(1/3, 1/3, 1/3)) < 1e-12))
stopifnot(validate_probability_vector(res3))

# Test error handling check
tryCatch({
  normalise_vector(c(-1, 5, 2))
  stop("Expected error for negative values in normalisation, but none occurred.")
}, error = function(e) {
  # Error correctly raised
})

print("✓ normalise_vector passed assertions.")
`
  },
  {
    name: "README.md",
    path: "dirichlet-engine/README.md",
    description: "A comprehensive guide on running and embedding the Dirichlet distribution module in Excel and Sheets.",
    content: `# Dirichlet Distribution Engine in R

A high-performance reusable statistical module for generating, modelling, verifying, and analyzing probability vectors and compositional datasets (where values are non-negative and sum to exactly \`1.0\`).

This engine is designed with high-efficiency vectorised math, bypassing standard \`for\` loops, making it capable of handling **1,000,000+ simulation rows** with minimal memory footprints. It contains a complete set of Excel/Spreadsheet formula wrappers.

---

## 📂 Project Structure

\`\`\`
dirichlet-engine/
├── dirichlet_core.R           # Dirichlet random drawers, means, variances, covariances
├── probability_utils.R        # Vector normaliser, barycentric coordinate conversion
├── validation.R               # High-integrity probability vector validation routines
├── compositional_analysis.R   # Log-ratio transforms (CLR & ALR) for simplex statistics
├── monte_carlo.R              # High-density Monte Carlo simulations & portfolio risks
├── spreadsheet_wrappers.R     # Clean formulas mapped for Excel (via BERT) / Sheets
│
└── tests/                     # Self-contained assertion test suites
    ├── test_sampling.R
    ├── test_mean.R
    ├── test_variance.R
    └── test_normalisation.R
\`\`\`

---

## ⚡ Mathematical Specification

The primary objective is the simulation and analysis of components $X = (X_1, \\dots, X_K)$ adhering to the Dirichlet distribution:

$$f(x_1, \\dots, x_K; \\alpha_1, \\dots, \\alpha_K) = \\frac{1}{\\mathrm{B}(\\alpha)} \\prod_{i=1}^K x_i^{\\alpha_i - 1}$$

Subject to:
1. $\\sum_{i=1}^K x_i  = 1.0$ (Simplex bounds)
2. $x_i \\ge 0$ (Non-negativity constraint)

Where:
- $\\alpha_i > 0$ represents the concentration parameter for each asset/category $i$.
- $\\alpha_0 = \\sum_{i=1}^K \\alpha_i$ is the absolute scaling dimension of the concentrations.

---

## 🚀 Getting Started with R

To load the entire statistical engine, navigate to the folder path in your R workspace and source the components:

\`\`\`r
# Set working directory to the package root
setwd("dirichlet-engine/")

# Source the core statistics and helpers
source("dirichlet_core.R")
source("probability_utils.R")
source("validation.R")
source("compositional_analysis.R")
source("monte_carlo.R")
source("spreadsheet_wrappers.R")
\`\`\`

### Example 1: Sampling Portfolio Weights

Sample an individual allocation vector for 4 assets using a concentration parameter vector:

\`\`\`r
# Set conservative concentration weights
alpha <- c(Stocks = 40, Bonds = 30, Commodities = 10, RealEstate = 20)

# Sample a random composition
portfolio_weights <- dirichlet_sample(alpha)
print(portfolio_weights)
# Output (Sums to exactly 1.0):
#  Stocks     Bonds Commodities  RealEstate 
#  0.38462    0.31291    0.10654     0.19593 
\`\`\`

### Example 2: Ultra High-Density Monte Carlo

Generate 100,000 simulations and model the aggregate portfolio variances using an asset return covariance matrix:

\`\`\`r
# Generate 100,000 Dirichlet compositions
sim_weights <- dirichlet_samples(alpha, n = 100000)

# Mock asset covariance matrix
asset_cov <- matrix(c(
  0.040, -0.005,  0.010,  0.012,
 -0.005,  0.012, -0.002,  0.001,
  0.010, -0.002,  0.035,  0.008,
  0.012,  0.001,  0.008,  0.025
), nrow = 4, byrow = TRUE)

# Calculate empirical variances for each simulation instantly without loops
simulated_variances <- simulate_portfolio_variance(sim_weights, asset_cov)

# Calculate Risk Percentiles
risk_quantiles <- quantile(simulated_variances, probs = c(0.05, 0.50, 0.95))
print(risk_quantiles)
\`\`\`

---

## 📊 Spreadsheet Integration

This module has been optimized to interface natively with spreadsheet software using common bridges like **BERT** (Basic Excel R Toolkit) or custom R server wrappers.

### Formulating Excel Custom Functions (via BERT)

By saving the files in your BERT dynamic startup folder, the following formulas are converted automatically:

| Excel Formula | Cell Range Input | Output Representation |
| :--- | :--- | :--- |
| \`=NORMALISE(A1:A10)\` | Values to map to 100% | 10x1 Column Vector summing to 1.0 |
| \`=PROBABILITY_CHECK(B1:B10)\` | Vector to validate | TRUE / FALSE |
| \`=DIRICHLET_MEAN(C1:C5)\` | Concentrations $\\vec{\\alpha}$ | 5x1 Analytical Mean composition |
| \`=DIRICHLET_VARIANCE(C1:C5)\` | Concentrations $\\vec{\\alpha}$ | 5x1 Expectation component variance |
| \`=DIRICHLET_COV(C1:C5)\` | Concentrations $\\vec{\\alpha}$ | 5x5 Full Symmetrical Covariance Grid |
| \`=DIRICHLET_SAMPLE(C1:C5)\` | Concentrations $\\vec{\\alpha}$ | Single randomized allocation vector |

---

## 🧪 Unit Testing

We verify mathematical formulas, edge-case constraints (e.g. division by zero, empty inputs, negative elements), and numerical tolerances using assertions:

\`\`\`bash
# Run tests directly in R command line
Rscript tests/test_sampling.R
Rscript tests/test_mean.R
Rscript tests/test_variance.R
Rscript tests/test_normalisation.R
\`\`\`
`
  }
];
