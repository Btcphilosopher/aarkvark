/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Gamma Distribution Sampler
 * Marsaglia and Tsang's Method (2000) for Gamma(α, 1)
 */
export function sampleGamma(alpha: number): number {
  if (alpha <= 0) {
    throw new Error("Alpha parameter must be strictly positive.");
  }

  // Booster for alpha < 1
  if (alpha < 1) {
    const u = Math.random();
    return sampleGamma(alpha + 1) * Math.pow(u, 1 / alpha);
  }

  const d = alpha - 1.0 / 3.0;
  const c = 1.0 / Math.sqrt(9.0 * d);

  while (true) {
    let z = 0;
    let u = 0;
    
    // Sample standard normal distribution using Box-Muller transform
    const u1 = Math.random();
    const u2 = Math.random();
    z = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);

    const v = 1.0 + c * z;
    if (v <= 0) continue;

    const v3 = v * v * v;
    u = Math.random();

    // Squeeze
    if (u < 1.0 - 0.0331 * z * z * z * z) {
      return d * v3;
    }

    if (Math.log(u) < 0.5 * z * z + d * (1.0 - v3 + Math.log(v3))) {
      return d * v3;
    }
  }
}

/**
 * Dirichlet Distribution Sampler
 * Samples K elements that sum to exactly 1.
 */
export function sampleDirichlet(alpha: number[]): number[] {
  if (alpha.some((a) => a <= 0)) {
    throw new Error("Concentration parameters must be strictly positive.");
  }

  try {
    const gammas = alpha.map(sampleGamma);
    const sum = gammas.reduce((acc, v) => acc + v, 0);
    if (sum === 0) {
      return alpha.map(() => 1 / alpha.length);
    }
    return gammas.map((g) => g / sum);
  } catch (e) {
    // Return uniform fallback if anything fails
    return alpha.map(() => 1 / alpha.length);
  }
}

/**
 * Generate N Dirichlet Samples (matrix of size n x K)
 */
export function sampleDirichletMultiple(alpha: number[], n: number): number[][] {
  const result: number[][] = [];
  for (let i = 0; i < n; i++) {
    result.push(sampleDirichlet(alpha));
  }
  return result;
}

/**
 * Expected Values E[X_i] = α_i / α_0
 */
export function getDirichletMean(alpha: number[]): number[] {
  const sum = alpha.reduce((acc, v) => acc + v, 0);
  if (sum === 0) return alpha.map(() => 0);
  return alpha.map((a) => a / sum);
}

/**
 * Variance Var(X_i) = α_i * (α_0 - α_i) / [α_0^2 * (α_0 + 1)]
 */
export function getDirichletVariance(alpha: number[]): number[] {
  const alpha0 = alpha.reduce((acc, v) => acc + v, 0);
  if (alpha0 === 0) return alpha.map(() => 0);
  const denom = alpha0 * alpha0 * (alpha0 + 1);
  return alpha.map((a) => (a * (alpha0 - a)) / denom);
}

/**
 * Covariance Matrix Cov(X_i, X_j)
 * Under diagonal: -α_i * α_j / [α_0^2 * (α_0 + 1)]
 * On diagonal: Var(X_i)
 */
export function getDirichletCovariance(alpha: number[]): number[][] {
  const k = alpha.length;
  const alpha0 = alpha.reduce((acc, v) => acc + v, 0);
  const cov: number[][] = Array.from({ length: k }, () => Array(k).fill(0));
  
  if (alpha0 === 0) return cov;
  const denom = alpha0 * alpha0 * (alpha0 + 1);

  for (let i = 0; i < k; i++) {
    for (let j = 0; j < k; j++) {
      if (i === j) {
        cov[i][j] = (alpha[i] * (alpha0 - alpha[i])) / denom;
      } else {
        cov[i][j] = -(alpha[i] * alpha[j]) / denom;
      }
    }
  }

  return cov;
}

/**
 * Normalise elements of a vector to a probability vector summing to 1.
 */
export function normaliseVector(x: number[]): number[] {
  if (x.length === 0) return [];
  const validVals = x.map((v) => (isNaN(v) || v < 0 ? 0 : v));
  const sum = validVals.reduce((acc, v) => acc + v, 0);
  if (sum === 0) {
    return x.map(() => 1 / x.length);
  }
  return validVals.map((v) => v / sum);
}

/**
 * Validates if the vector sums to 1.0 (within tolerance) and consists of non-negative reals.
 */
export function validateProbabilityVector(x: number[], tolerance = 1e-6): boolean {
  if (x.length === 0) return false;
  if (x.some((v) => isNaN(v) || v < 0)) return false;
  const sum = x.reduce((acc, v) => acc + v, 0);
  return Math.abs(sum - 1) <= tolerance;
}

/**
 * Run a full statistical simulation package for Dirichlet concentration options
 */
export function computeSimulationStats(alpha: number[], n: number = 1000): {
  empiricalMeans: number[];
  empiricalVariances: number[];
  percentiles: { p5: number[]; p50: number[]; p95: number[] };
  samples: number[][];
} {
  const samples = sampleDirichletMultiple(alpha, n);
  const k = alpha.length;

  const empiricalMeans = Array(k).fill(0);
  const empiricalVariances = Array(k).fill(0);
  const p5 = Array(k).fill(0);
  const p50 = Array(k).fill(0);
  const p95 = Array(k).fill(0);

  for (let col = 0; col < k; col++) {
    // Get column elements
    const colVals = samples.map((row) => row[col]).sort((a, b) => a - b);
    
    // Mean
    const colSum = colVals.reduce((acc, v) => acc + v, 0);
    const mean = colSum / n;
    empiricalMeans[col] = mean;

    // Variance
    const sqDiffs = colVals.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0);
    empiricalVariances[col] = sqDiffs / (n - 1 || 1);

    // Percentiles
    p5[col] = colVals[Math.floor(n * 0.05)];
    p50[col] = colVals[Math.floor(n * 0.5)];
    p95[col] = colVals[Math.floor(n * 0.95)];
  }

  return {
    empiricalMeans,
    empiricalVariances,
    percentiles: { p5, p50, p95 },
    samples,
  };
}

/**
 * Simulated Portfolio Variances using compositional weights and asset correlations
 */
export function computePortfolioVariancesSim(
  weightsList: number[][],
  assetCovariance: number[][]
): number[] {
  return weightsList.map((weights) => {
    let pVar = 0;
    for (let i = 0; i < weights.length; i++) {
      for (let j = 0; j < weights.length; j++) {
        pVar += weights[i] * weights[j] * assetCovariance[i][j];
      }
    }
    return pVar;
  });
}

/**
 * Standard presets of financial allocations
 */
export const ALLOCATION_PRESETS = [
  {
    name: "Classic Lazy Portfolio",
    category: "portfolio" as const,
    labels: ["Stocks", "Bonds", "Cash", "Gold"],
    alpha: [40, 30, 10, 20],
    description: "Traditional strategic asset allocation representing major diversified macro asset classes."
  },
  {
    name: "Emerging Market Venture",
    category: "portfolio" as const,
    labels: ["Large Cap", "Small Cap", "Crypto", "Alternative Risk"],
    alpha: [30, 45, 15, 10],
    description: "Highly aggressive venture composition with heightened concentration variance."
  },
  {
    name: "G10 Forex Reserve Pivot",
    category: "currency" as const,
    labels: ["PLN", "EUR", "USD", "GBP"],
    alpha: [45, 25, 20, 10],
    description: "Central bank-style balance sheet currencies modeled directly on compositional reserves."
  },
  {
    name: "Stable Gold-Hedged Treasury",
    category: "currency" as const,
    labels: ["USD", "EUR", "Gold", "CHF"],
    alpha: [50, 20, 20, 10],
    description: "Safe-haven multi-currency reserve model prioritising treasury bills and bullion."
  },
  {
    name: "Balanced Enterprise Risk Budget",
    category: "risk" as const,
    labels: ["Market Risk", "Credit Risk", "Liquidity Risk"],
    alpha: [50, 30, 20],
    description: "A secure commercial banking allocation where risk triggers sum up to a single absolute budget ceiling."
  },
  {
    name: "Asymmetrical Credit Tilt",
    category: "risk" as const,
    labels: ["Market Risk", "Credit Risk", "Liquidity Risk"],
    alpha: [20, 65, 15],
    description: "Heavy commercial credit portfolio bias. Focuses on credit spread dispersion analysis."
  }
];
