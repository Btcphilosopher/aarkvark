/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface RFile {
  name: string;
  path: string;
  content: string;
  description: string;
}

export interface ConcentrationPreset {
  name: string;
  category: "portfolio" | "currency" | "risk";
  labels: string[];
  alpha: number[];
  description: string;
}

export interface SimulationResult {
  weightsVec: number[];
  meanVec: number[];
  varianceVec: number[];
  covarianceMatrix: number[][];
  samples: number[][];
}

export interface FormulaCell {
  id: string; // e.g., 'A1'
  expression: string; // e.g., '=DIRICHLET_MEAN(C1:C3)'
  value: string; // calculated result
  isHeader?: boolean;
  label?: string;
}
