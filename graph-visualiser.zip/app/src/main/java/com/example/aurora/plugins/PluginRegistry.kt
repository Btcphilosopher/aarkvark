package com.example.aurora.plugins

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.example.aurora.renderer.Viewport
import com.example.aurora.themes.AuroraThemeSpec

interface AuroraPlugin {
    val pluginId: String
    val name: String
    val category: String
    val description: String
    var isEnabled: Boolean
}

interface CustomChartRendererPlugin : AuroraPlugin {
    fun drawPluginOverlay(
        drawScope: DrawScope,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        dataPointsCount: Int
    )
}

object PluginRegistry {
    private val _plugins = mutableListOf<AuroraPlugin>()
    val plugins: List<AuroraPlugin> get() = _plugins

    init {
        // Register default plugins
        _plugins.add(object : CustomChartRendererPlugin {
            override val pluginId = "RSI_INDICATOR"
            override val name = "RSI / MACD Indicators"
            override val category = "Financial"
            override val description = "Draws secondary Relative Strength Index bands and MACD signal thresholds beneath candlestick charts."
            override var isEnabled = false

            override fun drawPluginOverlay(
                drawScope: DrawScope,
                viewport: Viewport,
                theme: AuroraThemeSpec,
                dataPointsCount: Int
            ) {
                drawScope.apply {
                    val rsiY = viewport.top + viewport.height * 0.76f
                    // Draw horizontal RSI thresholds (30 and 70 lines)
                    drawLine(
                        color = Color(0xFFE91E63),
                        start = Offset(viewport.left, rsiY),
                        end = Offset(viewport.right, rsiY),
                        strokeWidth = 2f
                    )
                    drawLine(
                        color = Color(0xFF00BCD4),
                        start = Offset(viewport.left, rsiY + 15f),
                        end = Offset(viewport.right, rsiY + 15f),
                        strokeWidth = 2f
                    )
                }
            }
        })

        _plugins.add(object : AuroraPlugin {
            override val pluginId = "NEON_GLOW_EFFECT"
            override val name = "Vaporwave Neon Glow"
            override val category = "Visual Effects"
            override val description = "Applies dynamic radial glow overlays on active data structures, mimicking physical retro display terminals."
            override var isEnabled = false
        })

        _plugins.add(object : AuroraPlugin {
            override val pluginId = "SVG_HIGH_RES_EXPORTER"
            override val name = "SVG High-Res Vector Exporter"
            override val category = "Exporters"
            override val description = "Translates active DrawScope paths directly into XML-compliant scalable vector paths for desktop publishing."
            override var isEnabled = true
        })

        _plugins.add(object : AuroraPlugin {
            override val pluginId = "PHYSICS_SPRING_EASER"
            override val name = "Physics Elastic Spring Interpolator"
            override val category = "Animations"
            override val description = "Overrides standard cubic-bezier easing with an underdamped oscillator spring system simulation."
            override var isEnabled = false
        })
    }

    fun getPluginById(id: String): AuroraPlugin? {
        return _plugins.find { it.pluginId == id }
    }

    fun togglePlugin(id: String) {
        val plugin = getPluginById(id)
        if (plugin != null) {
            plugin.isEnabled = !plugin.isEnabled
        }
    }
}
