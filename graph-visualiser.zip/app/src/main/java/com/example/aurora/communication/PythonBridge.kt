package com.example.aurora.communication

import com.example.aurora.engine.AuroraChartSpec
import com.example.aurora.engine.AuroraColumn
import com.example.aurora.engine.AuroraDataset
import com.example.aurora.engine.AuroraRow
import com.example.aurora.engine.ChartType
import com.example.aurora.engine.ColumnType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class NetworkLog(
    val timestamp: String,
    val direction: String, // "PYTHON -> AURORA" or "AURORA -> PYTHON"
    val type: String,      // "PUSH_DATA", "RENDER_SPEC", "EVENT_HOVER", "FILTER_CHANGE"
    val payload: String
)

object PythonBridge {

    private val _logs = MutableStateFlow<List<NetworkLog>>(emptyList())
    val logs = _logs.asStateFlow()

    private val df = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun log(direction: String, type: String, payload: String) {
        val next = _logs.value.toMutableList()
        next.add(NetworkLog(df.format(Date()), direction, type, payload))
        if (next.size > 50) {
            next.removeAt(0)
        }
        _logs.value = next
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    // --- PREDEFINED MOCK DATASETS & SPECIFICATIONS ---

    val financialDataset: AuroraDataset by lazy {
        val columns = listOf(
            AuroraColumn("Index", ColumnType.NUMBER),
            AuroraColumn("Open", ColumnType.NUMBER),
            AuroraColumn("High", ColumnType.NUMBER),
            AuroraColumn("Low", ColumnType.NUMBER),
            AuroraColumn("Close", ColumnType.NUMBER),
            AuroraColumn("Volume", ColumnType.NUMBER)
        )

        // Mock Tesla Stock Candlestick prices
        val rows = listOf(
            AuroraRow(mapOf("Index" to 0f, "Open" to 220f, "High" to 228f, "Low" to 218f, "Close" to 225f, "Volume" to 12000f)),
            AuroraRow(mapOf("Index" to 1f, "Open" to 224f, "High" to 235f, "Low" to 223f, "Close" to 232f, "Volume" to 15400f)),
            AuroraRow(mapOf("Index" to 2f, "Open" to 232f, "High" to 233f, "Low" to 226f, "Close" to 228f, "Volume" to 9800f)),
            AuroraRow(mapOf("Index" to 3f, "Open" to 227f, "High" to 231f, "Low" to 221f, "Close" to 224f, "Volume" to 11000f)),
            AuroraRow(mapOf("Index" to 4f, "Open" to 224f, "High" to 242f, "Low" to 224f, "Close" to 239f, "Volume" to 24000f)),
            AuroraRow(mapOf("Index" to 5f, "Open" to 238f, "High" to 246f, "Low" to 237f, "Close" to 243f, "Volume" to 18000f)),
            AuroraRow(mapOf("Index" to 6f, "Open" to 244f, "High" to 255f, "Low" to 242f, "Close" to 251f, "Volume" to 29000f)),
            AuroraRow(mapOf("Index" to 7f, "Open" to 250f, "High" to 252f, "Low" to 240f, "Close" to 242f, "Volume" to 14200f)),
            AuroraRow(mapOf("Index" to 8f, "Open" to 242f, "High" to 248f, "Low" to 239f, "Close" to 245f, "Volume" to 11500f)),
            AuroraRow(mapOf("Index" to 9f, "Open" to 246f, "High" to 253f, "Low" to 244f, "Close" to 248f, "Volume" to 13900f))
        )

        AuroraDataset("TSLA_STOCK_H1", "Tesla Stock H1 Workspace", columns, rows)
    }

    val corporateSalesDataset: AuroraDataset by lazy {
        val columns = listOf(
            AuroraColumn("Quarter", ColumnType.STRING),
            AuroraColumn("NorthAmerica", ColumnType.NUMBER),
            AuroraColumn("Europe", ColumnType.NUMBER),
            AuroraColumn("AsiaPacific", ColumnType.NUMBER)
        )

        val rows = listOf(
            AuroraRow(mapOf("Quarter" to "Q1", "NorthAmerica" to 420f, "Europe" to 310f, "AsiaPacific" to 150f)),
            AuroraRow(mapOf("Quarter" to "Q2", "NorthAmerica" to 510f, "Europe" to 380f, "AsiaPacific" to 220f)),
            AuroraRow(mapOf("Quarter" to "Q3", "NorthAmerica" to 480f, "Europe" to 410f, "AsiaPacific" to 290f)),
            AuroraRow(mapOf("Quarter" to "Q4", "NorthAmerica" to 690f, "Europe" to 550f, "AsiaPacific" to 420f))
        )

        AuroraDataset("CORP_SALES_2026", "Global Corp Sales Q1-Q4", columns, rows)
    }

    val generalLineDataset: AuroraDataset by lazy {
        val columns = listOf(
            AuroraColumn("Index", ColumnType.NUMBER),
            AuroraColumn("Productivity", ColumnType.NUMBER),
            AuroraColumn("StressLevel", ColumnType.NUMBER)
        )

        val rows = listOf(
            AuroraRow(mapOf("Index" to 0f, "Productivity" to 15f, "StressLevel" to 90f)),
            AuroraRow(mapOf("Index" to 1f, "Productivity" to 32f, "StressLevel" to 85f)),
            AuroraRow(mapOf("Index" to 2f, "Productivity" to 45f, "StressLevel" to 70f)),
            AuroraRow(mapOf("Index" to 3f, "Productivity" to 68f, "StressLevel" to 60f)),
            AuroraRow(mapOf("Index" to 4f, "Productivity" to 80f, "StressLevel" to 45f)),
            AuroraRow(mapOf("Index" to 5f, "Productivity" to 95f, "StressLevel" to 30f)),
            AuroraRow(mapOf("Index" to 6f, "Productivity" to 85f, "StressLevel" to 55f)),
            AuroraRow(mapOf("Index" to 7f, "Productivity" to 110f, "StressLevel" to 20f))
        )

        AuroraDataset("WORK_PERFORMANCE_01", "Developer Flow Experiment", columns, rows)
    }

    fun getDatasetAndSpec(chartType: ChartType): Pair<AuroraDataset, AuroraChartSpec> {
        return when (chartType) {
            ChartType.CANDLESTICK -> {
                financialDataset to AuroraChartSpec(
                    chartType = ChartType.CANDLESTICK,
                    title = "TSLA Trading Terminal",
                    subtitle = "Simulating Real-Time OHLC Candlestick + Volume Overlay",
                    xColumn = "Index",
                    yColumns = listOf("Close")
                )
            }
            ChartType.COLUMN, ChartType.GROUPED_BAR, ChartType.STACKED_BAR -> {
                corporateSalesDataset to AuroraChartSpec(
                    chartType = chartType,
                    title = "Annual Region Performance",
                    subtitle = "Sales Volume Breakdown (Millions USD)",
                    xColumn = "Quarter",
                    yColumns = listOf("NorthAmerica", "Europe", "AsiaPacific")
                )
            }
            ChartType.LINE, ChartType.SPLINE, ChartType.STEP -> {
                generalLineDataset to AuroraChartSpec(
                    chartType = chartType,
                    title = "Cognitive Load and Yield",
                    subtitle = "Correlation between Flow and Perceived Exhaustion",
                    xColumn = "Index",
                    yColumns = listOf("Productivity", "StressLevel")
                )
            }
            ChartType.PIE, ChartType.DONUT -> {
                corporateSalesDataset to AuroraChartSpec(
                    chartType = chartType,
                    title = "Q4 Revenue Contribution",
                    subtitle = "Total Regional Share of Global Invoiced Earnings",
                    xColumn = "Quarter",
                    yColumns = listOf("NorthAmerica", "Europe", "AsiaPacific"), // Pie handles the first column values for current row (e.g., Q4)
                    labelColumn = "Quarter"
                )
            }
            ChartType.RADAR -> {
                generalLineDataset to AuroraChartSpec(
                    chartType = ChartType.RADAR,
                    title = "Aesthetic Dimensions Metric",
                    subtitle = "Evaluation of Engine Components across 8 Dimensions",
                    xColumn = "Index",
                    yColumns = listOf("Productivity"),
                    labelColumn = "Index"
                )
            }
            ChartType.SURFACE_3D -> {
                generalLineDataset to AuroraChartSpec(
                    chartType = ChartType.SURFACE_3D,
                    title = "Hyperbolic Sine Wave Topology",
                    subtitle = "Real-Time 3D Projection & Wireframe Matrix",
                    xColumn = "Index",
                    yColumns = listOf("Productivity")
                )
            }
            ChartType.TREEMAP -> {
                corporateSalesDataset to AuroraChartSpec(
                    chartType = ChartType.TREEMAP,
                    title = "Squarified Market Area",
                    subtitle = "Hierarchical Subdivision by Revenue Contribution",
                    xColumn = "Quarter",
                    yColumns = listOf("NorthAmerica"),
                    labelColumn = "Quarter"
                )
            }
            ChartType.SANKEY -> {
                generalLineDataset to AuroraChartSpec(
                    chartType = ChartType.SANKEY,
                    title = "Data Flow Pipeline Map",
                    subtitle = "Flow Volume from Python Services to Kotlin Composables",
                    xColumn = "Index",
                    yColumns = listOf("Productivity")
                )
            }
            ChartType.HEATMAP -> {
                generalLineDataset to AuroraChartSpec(
                    chartType = ChartType.HEATMAP,
                    title = "Cross-Correlation Density Matrix",
                    subtitle = "Multi-axis Covariance Heatmap",
                    xColumn = "Index",
                    yColumns = listOf("Productivity")
                )
            }
            ChartType.NETWORK -> {
                generalLineDataset to AuroraChartSpec(
                    chartType = ChartType.NETWORK,
                    title = "Module Dependency Graph",
                    subtitle = "Directed Force-Directed Graph Analysis",
                    xColumn = "Index",
                    yColumns = listOf("Productivity")
                )
            }
        }
    }
}
