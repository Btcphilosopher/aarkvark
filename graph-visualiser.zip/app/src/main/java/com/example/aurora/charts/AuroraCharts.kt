package com.example.aurora.charts

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.unit.sp
import com.example.aurora.animation.AnimationEngine
import com.example.aurora.engine.AuroraChartSpec
import com.example.aurora.engine.AuroraDataset
import com.example.aurora.engine.ChartType
import com.example.aurora.interaction.AuroraInteractionState
import com.example.aurora.interaction.TooltipData
import com.example.aurora.renderer.AuroraRenderer
import com.example.aurora.renderer.Viewport
import com.example.aurora.themes.AuroraThemeSpec
import kotlin.math.cos
import kotlin.math.sin

object AuroraCharts {

    fun DrawScope.renderChart(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        when (spec.chartType) {
            ChartType.LINE, ChartType.SPLINE, ChartType.STEP -> {
                renderLineSeries(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
            ChartType.COLUMN, ChartType.GROUPED_BAR, ChartType.STACKED_BAR -> {
                renderBarSeries(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
            ChartType.PIE, ChartType.DONUT -> {
                renderPieOrDonut(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
            ChartType.SCATTER -> {
                renderScatter(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
            ChartType.RADAR -> {
                renderRadar(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
            ChartType.CANDLESTICK -> {
                renderCandlestick(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
            ChartType.SURFACE_3D -> {
                render3DSurface(dataset, spec, viewport, theme, interactionState, progress, textMeasurer)
            }
            ChartType.TREEMAP -> {
                renderTreemap(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
            ChartType.SANKEY -> {
                renderSankey(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
            ChartType.HEATMAP -> {
                renderHeatmap(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
            ChartType.NETWORK -> {
                renderNetworkGraph(dataset, spec, viewport, theme, interactionState, progress, textMeasurer, onHover)
            }
        }
    }

    private fun DrawScope.renderLineSeries(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        val xVals = dataset.getNumericalValues(spec.xColumn)
        if (xVals.isEmpty()) return

        val minX = xVals.minOrNull() ?: 0f
        val maxX = xVals.maxOrNull() ?: 10f

        val activeYCols = spec.yColumns
        val allYVals = activeYCols.flatMap { dataset.getNumericalValues(it) }
        val minY = (allYVals.minOrNull() ?: 0f).coerceAtMost(0f)
        val maxY = (allYVals.maxOrNull() ?: 10f) * 1.15f

        val xTicks = AuroraRenderer.calculateTicks(minX, maxX, 6)
        val yTicks = AuroraRenderer.calculateTicks(minY, maxY, 5)

        // Draw basic grids and axes
        AuroraRenderer.apply {
            drawGridAndAxes(viewport, theme, xTicks, yTicks, minX, maxX, minY, maxY, interactionState, textMeasurer)
        }

        var hoverFound = false

        // Draw each line series
        activeYCols.forEachIndexed { sIndex, yCol ->
            val yVals = dataset.getNumericalValues(yCol)
            val accentColor = theme.colors.accentColors[sIndex % theme.colors.accentColors.size]

            val points = xVals.mapIndexed { i, xv ->
                val interpolatedYValue = AnimationEngine.lerp(0f, yVals.getOrElse(i) { 0f }, progress)
                AuroraRenderer.project(xv, interpolatedYValue, minX, maxX, minY, maxY, viewport, interactionState)
            }.filter { it.x >= viewport.left && it.x <= viewport.right }

            if (points.size < 2) return@forEachIndexed

            val path = Path()
            path.moveTo(points[0].x, points[0].y)

            if (spec.chartType == ChartType.SPLINE) {
                // Spline path calculations using midpoints for smooth curve
                for (i in 0 until points.size - 1) {
                    val p1 = points[i]
                    val p2 = points[i + 1]
                    val m = Offset((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f)
                    path.quadraticTo(p1.x, p1.y, m.x, m.y)
                }
                path.lineTo(points.last().x, points.last().y)
            } else if (spec.chartType == ChartType.STEP) {
                // Step path
                for (i in 0 until points.size - 1) {
                    val p1 = points[i]
                    val p2 = points[i + 1]
                    path.lineTo(p2.x, p1.y)
                    path.lineTo(p2.x, p2.y)
                }
            } else {
                // Standard straight lines
                for (i in 1 until points.size) {
                    path.lineTo(points[i].x, points[i].y)
                }
            }

            // Draw line
            drawPath(
                path = path,
                color = accentColor,
                style = Stroke(width = 3.5f, cap = StrokeCap.Round)
            )

            // Draw Area fill underneath if SPLINE or LINE
            if (spec.chartType == ChartType.SPLINE || spec.chartType == ChartType.LINE) {
                val areaPath = Path().apply {
                    addPath(path)
                    // Close the path to the baseline
                    val baseProj = AuroraRenderer.project(maxX, 0f, minX, maxX, minY, maxY, viewport, interactionState)
                    val firstProj = AuroraRenderer.project(minX, 0f, minX, maxX, minY, maxY, viewport, interactionState)
                    lineTo(points.last().x, baseProj.y.coerceIn(viewport.top, viewport.bottom))
                    lineTo(points.first().x, baseProj.y.coerceIn(viewport.top, viewport.bottom))
                    close()
                }
                drawPath(
                    path = areaPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(accentColor.copy(alpha = 0.35f), Color.Transparent),
                        startY = viewport.top,
                        endY = viewport.bottom
                    ),
                    style = Fill
                )
            }

            // Check hover interaction on points
            if (interactionState.crosshairPos != null && !hoverFound) {
                val cx = interactionState.crosshairPos.x
                val cy = interactionState.crosshairPos.y

                points.forEachIndexed { i, p ->
                    val dist = (p - Offset(cx, cy)).getDistance()
                    if (dist < 22f) {
                        hoverFound = true
                        onHover(
                            TooltipData(
                                title = "${dataset.getStringValues(spec.xColumn).getOrElse(i) { "X: ${xVals[i]}" }}",
                                value = "%.2f".format(yVals[i]),
                                seriesName = yCol,
                                screenPos = p,
                                dataIndex = i
                            )
                        )
                        // Draw high-visibility target ring
                        drawCircle(
                            color = accentColor,
                            radius = 8f,
                            center = p
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 4f,
                            center = p
                        )
                    }
                }
            }
        }

        if (!hoverFound) {
            onHover(null)
        }
    }

    private fun DrawScope.renderBarSeries(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        val xVals = dataset.getNumericalValues(spec.xColumn)
        if (xVals.isEmpty()) return

        val minX = xVals.minOrNull() ?: 0f
        val maxX = xVals.maxOrNull() ?: 10f

        val activeYCols = spec.yColumns
        val allYVals = activeYCols.flatMap { dataset.getNumericalValues(it) }

        val isStacked = spec.chartType == ChartType.STACKED_BAR

        val minY = 0f
        val maxY = if (isStacked) {
            // Stack values per row
            val stacks = List(xVals.size) { rIdx ->
                activeYCols.sumOf { dataset.getNumericalValues(it).getOrElse(rIdx) { 0f }.toDouble() }.toFloat()
            }
            (stacks.maxOrNull() ?: 10f) * 1.15f
        } else {
            (allYVals.maxOrNull() ?: 10f) * 1.15f
        }

        val xTicks = AuroraRenderer.calculateTicks(minX, maxX, 6)
        val yTicks = AuroraRenderer.calculateTicks(minY, maxY, 5)

        AuroraRenderer.apply {
            drawGridAndAxes(viewport, theme, xTicks, yTicks, minX, maxX, minY, maxY, interactionState, textMeasurer)
        }

        val colCount = activeYCols.size
        val rowCount = xVals.size
        val blockWidth = viewport.width / rowCount
        val barPaddingPercent = 0.15f

        var hoverFound = false

        for (rIdx in 0 until rowCount) {
            val xv = xVals[rIdx]
            val xLabel = dataset.getStringValues(spec.xColumn).getOrElse(rIdx) { xv.toString() }

            val colCenterProj = AuroraRenderer.project(xv, 0f, minX, maxX, minY, maxY, viewport, interactionState)
            val startX = colCenterProj.x - blockWidth / 2f + (blockWidth * barPaddingPercent)
            val availableWidth = blockWidth * (1f - 2f * barPaddingPercent)

            var stackedYOffset = 0f

            for (sIdx in 0 until colCount) {
                val yCol = activeYCols[sIdx]
                val yVal = dataset.getNumericalValues(yCol).getOrElse(rIdx) { 0f }
                val interpYVal = AnimationEngine.lerp(0f, yVal, progress)
                val accentColor = theme.colors.accentColors[sIdx % theme.colors.accentColors.size]

                val rectLeft: Float
                val rectRight: Float
                val rectTop: Float
                val rectBottom: Float

                if (isStacked) {
                    val pBottom = AuroraRenderer.project(xv, stackedYOffset, minX, maxX, minY, maxY, viewport, interactionState)
                    val pTop = AuroraRenderer.project(xv, stackedYOffset + interpYVal, minX, maxX, minY, maxY, viewport, interactionState)

                    rectLeft = startX
                    rectRight = startX + availableWidth
                    rectTop = pTop.y
                    rectBottom = pBottom.y

                    stackedYOffset += interpYVal
                } else {
                    // Grouped columns side by side
                    val barWidth = availableWidth / colCount
                    rectLeft = startX + (sIdx * barWidth)
                    rectRight = rectLeft + barWidth - 2f

                    val pTop = AuroraRenderer.project(xv, interpYVal, minX, maxX, minY, maxY, viewport, interactionState)
                    val pBottom = AuroraRenderer.project(xv, 0f, minX, maxX, minY, maxY, viewport, interactionState)

                    rectTop = pTop.y
                    rectBottom = pBottom.y
                }

                val rectHeight = (rectBottom - rectTop).coerceAtLeast(1f)
                val rectWidth = (rectRight - rectLeft).coerceAtLeast(1f)

                val drawRect = Rect(rectLeft, rectTop, rectLeft + rectWidth, rectTop + rectHeight)

                // Highlight hovered column
                val isHovered = interactionState.crosshairPos != null && drawRect.contains(interactionState.crosshairPos)
                val displayColor = if (isHovered) accentColor.copy(alpha = 0.85f) else accentColor

                // Draw rounded column
                drawRoundRect(
                    color = displayColor,
                    topLeft = Offset(rectLeft, rectTop),
                    size = Size(rectWidth, rectHeight),
                    cornerRadius = CornerRadius(4f, 4f)
                )

                if (isHovered && !hoverFound) {
                    hoverFound = true
                    onHover(
                        TooltipData(
                            title = xLabel,
                            value = "%.2f".format(yVal),
                            seriesName = yCol,
                            screenPos = Offset(rectLeft + rectWidth / 2f, rectTop),
                            dataIndex = rIdx
                        )
                    )
                }
            }
        }

        if (!hoverFound) {
            onHover(null)
        }
    }

    private fun DrawScope.renderPieOrDonut(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        val yCol = spec.yColumns.firstOrNull() ?: return
        val labelCol = spec.labelColumn ?: spec.xColumn
        val yVals = dataset.getNumericalValues(yCol)
        val labels = dataset.getStringValues(labelCol)

        val total = yVals.sum().toDouble()
        if (total <= 0) return

        val center = Offset(viewport.left + viewport.width / 2f, viewport.top + viewport.height / 2f)
        val radius = (viewport.width.coerceAtMost(viewport.height) / 2.3f) * progress

        var currentAngle = 0f
        var hoverFound = false

        yVals.forEachIndexed { idx, valY ->
            val sweepAngle = ((valY / total) * 360f).toFloat()
            val accentColor = theme.colors.accentColors[idx % theme.colors.accentColors.size]

            // Check if hovered
            val midAngleRad = Math.toRadians((currentAngle + sweepAngle / 2f).toDouble())
            val offsetMultiplier = 12f

            val isHovered = interactionState.crosshairPos != null &&
                    (interactionState.crosshairPos - center).getDistance() < radius &&
                    let {
                        val toMouseVec = interactionState.crosshairPos - center
                        var mouseAngleDeg = Math.toDegrees(kotlin.math.atan2(toMouseVec.y.toDouble(), toMouseVec.x.toDouble()))
                        if (mouseAngleDeg < 0) mouseAngleDeg += 360.0
                        mouseAngleDeg >= currentAngle && mouseAngleDeg < (currentAngle + sweepAngle)
                    }

            val finalCenter = if (isHovered) {
                Offset(
                    center.x + (cos(midAngleRad) * offsetMultiplier).toFloat(),
                    center.y + (sin(midAngleRad) * offsetMultiplier).toFloat()
                )
            } else {
                center
            }

            drawArc(
                color = accentColor,
                startAngle = currentAngle,
                sweepAngle = sweepAngle,
                useCenter = true,
                topLeft = Offset(finalCenter.x - radius, finalCenter.y - radius),
                size = Size(radius * 2f, radius * 2f)
            )

            // Draw white separators
            drawArc(
                color = theme.colors.backgroundColor,
                startAngle = currentAngle,
                sweepAngle = sweepAngle,
                useCenter = true,
                topLeft = Offset(finalCenter.x - radius, finalCenter.y - radius),
                size = Size(radius * 2f, radius * 2f),
                style = Stroke(width = 2.5f)
            )

            if (isHovered && !hoverFound) {
                hoverFound = true
                onHover(
                    TooltipData(
                        title = labels.getOrElse(idx) { "Slice $idx" },
                        value = "%.1f (%.1f%%)".format(valY, (valY / total) * 100f),
                        seriesName = yCol,
                        screenPos = finalCenter + Offset((cos(midAngleRad) * radius / 1.5f).toFloat(), (sin(midAngleRad) * radius / 1.5f).toFloat()),
                        dataIndex = idx
                    )
                )
            }

            currentAngle += sweepAngle
        }

        // Donut hole
        if (spec.chartType == ChartType.DONUT) {
            val holeRadius = radius * 0.55f
            drawCircle(
                color = theme.colors.backgroundColor,
                radius = holeRadius,
                center = center
            )
        }

        if (!hoverFound) {
            onHover(null)
        }
    }

    private fun DrawScope.renderScatter(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        val xVals = dataset.getNumericalValues(spec.xColumn)
        val yCol = spec.yColumns.firstOrNull() ?: return
        val yVals = dataset.getNumericalValues(yCol)

        if (xVals.isEmpty() || yVals.isEmpty()) return

        val minX = xVals.minOrNull() ?: 0f
        val maxX = xVals.maxOrNull() ?: 10f
        val minY = yVals.minOrNull() ?: 0f
        val maxY = (yVals.maxOrNull() ?: 10f) * 1.1f

        val xTicks = AuroraRenderer.calculateTicks(minX, maxX, 6)
        val yTicks = AuroraRenderer.calculateTicks(minY, maxY, 5)

        AuroraRenderer.apply {
            drawGridAndAxes(viewport, theme, xTicks, yTicks, minX, maxX, minY, maxY, interactionState, textMeasurer)
        }

        var hoverFound = false

        xVals.forEachIndexed { idx, xv ->
            val yv = yVals.getOrElse(idx) { 0f }
            val interpY = AnimationEngine.lerp(minY, yv, progress)

            val p = AuroraRenderer.project(xv, interpY, minX, maxX, minY, maxY, viewport, interactionState)
            val accentColor = theme.colors.accentColors[idx % theme.colors.accentColors.size]

            if (p.x in viewport.left..viewport.right && p.y in viewport.top..viewport.bottom) {
                // High fidelity circular data node
                val isHovered = interactionState.crosshairPos != null && (p - interactionState.crosshairPos).getDistance() < 20f

                val baseRadius = 8f + (progress * 4f)
                val drawRadius = if (isHovered) baseRadius * 1.5f else baseRadius

                drawCircle(
                    color = accentColor.copy(alpha = 0.4f),
                    radius = drawRadius + 4f,
                    center = p
                )
                drawCircle(
                    color = accentColor,
                    radius = drawRadius,
                    center = p
                )
                drawCircle(
                    color = Color.White,
                    radius = drawRadius / 2f,
                    center = p
                )

                if (isHovered && !hoverFound) {
                    hoverFound = true
                    onHover(
                        TooltipData(
                            title = "Point $idx",
                            value = "X: %.1f, Y: %.2f".format(xv, yv),
                            seriesName = yCol,
                            screenPos = p,
                            dataIndex = idx
                        )
                    )
                }
            }
        }

        if (!hoverFound) {
            onHover(null)
        }
    }

    private fun DrawScope.renderRadar(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        val labelCol = spec.labelColumn ?: spec.xColumn
        val labels = dataset.getStringValues(labelCol)
        val yCol = spec.yColumns.firstOrNull() ?: return
        val yVals = dataset.getNumericalValues(yCol)

        val numAxes = yVals.size
        if (numAxes < 3) return

        val maxVal = (yVals.maxOrNull() ?: 10f) * 1.1f
        val center = Offset(viewport.left + viewport.width / 2f, viewport.top + viewport.height / 2f)
        val maxRadius = (viewport.width.coerceAtMost(viewport.height) / 2.3f) * progress

        // 1. Draw web grid (concentric polygons)
        val numGridLevels = 4
        for (lvl in 1..numGridLevels) {
            val fraction = lvl.toFloat() / numGridLevels
            val levelRadius = maxRadius * fraction
            val path = Path()

            for (i in 0 until numAxes) {
                val angle = Math.toRadians((i * 360.0 / numAxes) - 90.0)
                val px = center.x + (cos(angle) * levelRadius).toFloat()
                val py = center.y + (sin(angle) * levelRadius).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()

            drawPath(
                path = path,
                color = theme.colors.gridLineColor,
                style = Stroke(width = 1.2f)
            )
        }

        // 2. Draw axis spines
        for (i in 0 until numAxes) {
            val angle = Math.toRadians((i * 360.0 / numAxes) - 90.0)
            val px = center.x + (cos(angle) * maxRadius).toFloat()
            val py = center.y + (sin(angle) * maxRadius).toFloat()

            drawLine(
                color = theme.colors.axisColor,
                start = center,
                end = Offset(px, py),
                strokeWidth = 1.5f
            )

            // Draw axis title label
            val textLayout = textMeasurer.measure(
                text = labels.getOrElse(i) { "A$i" },
                style = TextStyle(color = theme.colors.labelTextColor, fontSize = 9.sp, fontFamily = theme.typography.labelFont)
            )
            val textX = center.x + (cos(angle) * (maxRadius + 18f)).toFloat() - textLayout.size.width / 2f
            val textY = center.y + (sin(angle) * (maxRadius + 18f)).toFloat() - textLayout.size.height / 2f
            drawText(textLayout, Offset(textX, textY))
        }

        // 3. Draw actual data filled polygon
        val dataPath = Path()
        val accentColor = theme.colors.accentColors[0 % theme.colors.accentColors.size]
        val points = mutableListOf<Offset>()

        for (i in 0 until numAxes) {
            val angle = Math.toRadians((i * 360.0 / numAxes) - 90.0)
            val valY = yVals[i]
            val r = (valY / maxVal) * maxRadius
            val px = center.x + (cos(angle) * r).toFloat()
            val py = center.y + (sin(angle) * r).toFloat()
            points.add(Offset(px, py))
            if (i == 0) dataPath.moveTo(px, py) else dataPath.lineTo(px, py)
        }
        dataPath.close()

        drawPath(
            path = dataPath,
            color = accentColor.copy(alpha = 0.3f),
            style = Fill
        )
        drawPath(
            path = dataPath,
            color = accentColor,
            style = Stroke(width = 3.5f)
        )

        // Hover checking
        var hoverFound = false
        if (interactionState.crosshairPos != null) {
            points.forEachIndexed { i, p ->
                if ((p - interactionState.crosshairPos).getDistance() < 20f) {
                    hoverFound = true
                    onHover(
                        TooltipData(
                            title = labels.getOrElse(i) { "Axis $i" },
                            value = "%.2f".format(yVals[i]),
                            seriesName = yCol,
                            screenPos = p,
                            dataIndex = i
                        )
                    )
                    drawCircle(color = accentColor, radius = 6f, center = p)
                }
            }
        }
        if (!hoverFound) onHover(null)
    }

    private fun DrawScope.renderCandlestick(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        val openVals = dataset.getNumericalValues("Open")
        val highVals = dataset.getNumericalValues("High")
        val lowVals = dataset.getNumericalValues("Low")
        val closeVals = dataset.getNumericalValues("Close")
        val volumeVals = dataset.getNumericalValues("Volume")

        if (closeVals.isEmpty()) return

        val minX = 0f
        val maxX = closeVals.size.toFloat()
        val minY = (lowVals.minOrNull() ?: 0f) * 0.98f
        val maxY = (highVals.maxOrNull() ?: 100f) * 1.02f

        val xTicks = (0 until closeVals.size step (closeVals.size / 6).coerceAtLeast(1)).map { it.toFloat() }
        val yTicks = AuroraRenderer.calculateTicks(minY, maxY, 5)

        // Adjust viewport to leave room for a small volume overlay at the bottom 25%
        val mainChartHeight = viewport.height * 0.72f
        val volumeChartHeight = viewport.height * 0.23f
        val volumeChartTop = viewport.bottom - volumeChartHeight

        val candlesViewport = Viewport(viewport.left, viewport.top, viewport.width, mainChartHeight)

        // Draw basic grids and axes for candles
        AuroraRenderer.apply {
            drawGridAndAxes(candlesViewport, theme, xTicks, yTicks, minX, maxX, minY, maxY, interactionState, textMeasurer)
        }

        val candWidth = (candlesViewport.width / closeVals.size) * 0.75f
        var hoverFound = false

        closeVals.forEachIndexed { i, close ->
            val open = openVals.getOrElse(i) { close }
            val high = highVals.getOrElse(i) { close }
            val low = lowVals.getOrElse(i) { close }
            val volume = volumeVals.getOrElse(i) { 0f }

            val xIdx = i.toFloat() + 0.5f

            // Project candlestick extremes
            val pOpen = AuroraRenderer.project(xIdx, open, minX, maxX, minY, maxY, candlesViewport, interactionState)
            val pClose = AuroraRenderer.project(xIdx, close, minX, maxX, minY, maxY, candlesViewport, interactionState)
            val pHigh = AuroraRenderer.project(xIdx, high, minX, maxX, minY, maxY, candlesViewport, interactionState)
            val pLow = AuroraRenderer.project(xIdx, low, minX, maxX, minY, maxY, candlesViewport, interactionState)

            val isBullish = close >= open
            val candColor = if (isBullish) Color(0xFF26A69A) else Color(0xFFEF5350) // TradingView Emerald & Red

            // 1. Draw Wick (Thin line)
            drawLine(
                color = candColor,
                start = pHigh,
                end = pLow,
                strokeWidth = 2f
            )

            // 2. Draw Body (Rectangle)
            val topY = pOpen.y.coerceAtMost(pClose.y)
            val bottomY = pOpen.y.coerceAtLeast(pClose.y)
            val bodyHeight = (bottomY - topY).coerceAtLeast(2f)

            drawRect(
                color = candColor,
                topLeft = Offset(pOpen.x - candWidth / 2f, topY),
                size = Size(candWidth, bodyHeight * progress)
            )

            // 3. Draw Volume Bar (Lower 25% of the chart)
            val maxVolume = volumeVals.maxOrNull() ?: 100f
            val volRatio = if (maxVolume == 0f) 0f else volume / maxVolume
            val volHeight = volumeChartHeight * volRatio * progress
            val volRectTop = viewport.bottom - volHeight

            drawRect(
                color = candColor.copy(alpha = 0.35f),
                topLeft = Offset(pOpen.x - candWidth / 2f, volRectTop),
                size = Size(candWidth, volHeight)
            )

            // Hover checking
            val hoverBox = Rect(pOpen.x - candWidth, viewport.top, pOpen.x + candWidth, viewport.bottom)
            if (interactionState.crosshairPos != null && hoverBox.contains(interactionState.crosshairPos) && !hoverFound) {
                hoverFound = true
                onHover(
                    TooltipData(
                        title = "Candle #$i",
                        value = "O: %.1f, H: %.1f, L: %.1f, C: %.1f | Vol: %d".format(open, high, low, close, volume.toInt()),
                        seriesName = "OHLC",
                        screenPos = Offset(pOpen.x, topY),
                        dataIndex = i
                    )
                )
            }
        }

        if (!hoverFound) onHover(null)
    }

    private fun DrawScope.render3DSurface(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer
    ) {
        val center = Offset(viewport.left + viewport.width / 2f, viewport.top + viewport.height / 2f)

        // Read or simulation parameters
        val yaw = (interactionState.panX / 2f) + 135f // Map drag gesture to yaw
        val pitch = (interactionState.panY / 4f) + 30f // Map drag to pitch

        val scale = (viewport.width.coerceAtMost(viewport.height) / 12f) * (1f + (interactionState.zoomX - 1f) * 0.5f)

        // Generate dynamic math 3D grid surface: z = sin(sqrt(x^2 + y^2))
        val gridSize = 14
        val xMin = -5f
        val xMax = 5f
        val yMin = -5f
        val yMax = 5f

        val points3D = Array(gridSize) { xi ->
            Array(gridSize) { yi ->
                val x = xMin + (xMax - xMin) * (xi.toFloat() / (gridSize - 1))
                val y = yMin + (yMax - yMin) * (yi.toFloat() / (gridSize - 1))
                // Compute sine wave shape
                val dist = kotlin.math.sqrt(x * x + y * y)
                val zBase = kotlin.math.sin(dist) * 1.5f
                val z = AnimationEngine.lerp(0f, zBase, progress)
                Offset(x, y) // we also keep real projected 3D coordinates
                Triple(x, y, z)
            }
        }

        // Draw connecting 3D wireframe gridlines
        for (xi in 0 until gridSize) {
            for (yi in 0 until gridSize) {
                val p3d = points3D[xi][yi]
                val screenPos = AuroraRenderer.project3D(p3d.first, p3d.second, p3d.third, yaw, pitch, scale, center)

                // Render lines connecting to adjacent mesh nodes
                if (xi < gridSize - 1) {
                    val pRight = points3D[xi + 1][yi]
                    val sRight = AuroraRenderer.project3D(pRight.first, pRight.second, pRight.third, yaw, pitch, scale, center)
                    drawLine(
                        color = theme.colors.accentColors[xi % theme.colors.accentColors.size].copy(alpha = 0.65f),
                        start = screenPos,
                        end = sRight,
                        strokeWidth = 1.8f
                    )
                }

                if (yi < gridSize - 1) {
                    val pDown = points3D[xi][yi + 1]
                    val sDown = AuroraRenderer.project3D(pDown.first, pDown.second, pDown.third, yaw, pitch, scale, center)
                    drawLine(
                        color = theme.colors.accentColors[yi % theme.colors.accentColors.size].copy(alpha = 0.65f),
                        start = screenPos,
                        end = sDown,
                        strokeWidth = 1.8f
                    )
                }
            }
        }

        // Overlay small helper text for rotating 3D surface visual
        val labelStyle = TextStyle(color = theme.colors.labelTextColor.copy(alpha = 0.7f), fontSize = 10.sp, fontFamily = theme.typography.labelFont)
        val statsLayout = textMeasurer.measure("3D Mesh: Yaw %.1f° | Pitch %.1f° (Drag/Swipe to rotate 3D view)".format(yaw, pitch), labelStyle)
        drawText(statsLayout, Offset(viewport.left + 10f, viewport.top + 10f))
    }

    private fun DrawScope.renderTreemap(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        val yCol = spec.yColumns.firstOrNull() ?: return
        val labelCol = spec.labelColumn ?: spec.xColumn
        val yVals = dataset.getNumericalValues(yCol)
        val labels = dataset.getStringValues(labelCol)

        val total = yVals.sum()
        if (total <= 0f) return

        // Partition Treemap nodes using simple squarified or binary vertical/horizontal cuts
        var hoverFound = false
        var currentAreaLeft = viewport.left
        var currentAreaTop = viewport.top
        var currentAreaWidth = viewport.width
        var currentAreaHeight = viewport.height

        yVals.forEachIndexed { i, valY ->
            val ratio = valY / total
            val accentColor = theme.colors.accentColors[i % theme.colors.accentColors.size]

            val nodeLeft: Float
            val nodeTop: Float
            val nodeWidth: Float
            val nodeHeight: Float

            // Alternate splitting horizontally and vertically
            if (currentAreaWidth > currentAreaHeight) {
                nodeWidth = currentAreaWidth * ratio
                nodeHeight = currentAreaHeight
                nodeLeft = currentAreaLeft
                nodeTop = currentAreaTop

                currentAreaLeft += nodeWidth
                currentAreaWidth -= nodeWidth
            } else {
                nodeWidth = currentAreaWidth
                nodeHeight = currentAreaHeight * ratio
                nodeLeft = currentAreaLeft
                nodeTop = currentAreaTop

                currentAreaTop += nodeHeight
                currentAreaHeight -= nodeHeight
            }

            val finalWidth = (nodeWidth * progress).coerceAtLeast(1f)
            val finalHeight = (nodeHeight * progress).coerceAtLeast(1f)

            val nodeRect = Rect(nodeLeft, nodeTop, nodeLeft + finalWidth, nodeTop + finalHeight)
            val isHovered = interactionState.crosshairPos != null && nodeRect.contains(interactionState.crosshairPos)
            val cellColor = if (isHovered) accentColor.copy(alpha = 0.85f) else accentColor

            // Draw Treemap Cell
            drawRect(
                color = cellColor,
                topLeft = Offset(nodeLeft, nodeTop),
                size = Size(finalWidth, finalHeight)
            )

            // Cell border
            drawRect(
                color = theme.colors.backgroundColor,
                topLeft = Offset(nodeLeft, nodeTop),
                size = Size(finalWidth, finalHeight),
                style = Stroke(width = 2.5f)
            )

            // Draw text label centered inside if space allows
            if (finalWidth > 55f && finalHeight > 30f) {
                val nodeLabel = labels.getOrElse(i) { "Node $i" }
                val titleLayout = textMeasurer.measure(
                    text = nodeLabel,
                    style = TextStyle(color = Color.White, fontSize = 11.sp, fontFamily = theme.typography.titleFont)
                )
                val valLayout = textMeasurer.measure(
                    text = "%.1f".format(valY),
                    style = TextStyle(color = Color.White.copy(alpha = 0.8f), fontSize = 9.sp, fontFamily = theme.typography.labelFont)
                )

                val tx = nodeLeft + (finalWidth - titleLayout.size.width) / 2f
                val ty = nodeTop + (finalHeight - titleLayout.size.height - valLayout.size.height) / 2f

                drawText(titleLayout, Offset(tx, ty))
                drawText(valLayout, Offset(nodeLeft + (finalWidth - valLayout.size.width) / 2f, ty + titleLayout.size.height + 2f))
            }

            if (isHovered && !hoverFound) {
                hoverFound = true
                onHover(
                    TooltipData(
                        title = labels.getOrElse(i) { "Node $i" },
                        value = "%.2f (%.1f%% of total)".format(valY, ratio * 100f),
                        seriesName = yCol,
                        screenPos = Offset(nodeLeft + finalWidth / 2f, nodeTop + finalHeight / 2f),
                        dataIndex = i
                    )
                )
            }
        }

        if (!hoverFound) onHover(null)
    }

    private fun DrawScope.renderSankey(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        // Draw a custom gorgeous Sankey flow diagram from left columns to right columns
        val flowNodesLeft = listOf("Python Backend", "Calculation Engine", "Formulas Module")
        val flowNodesRight = listOf("Aurora Engine", "GPU Renderer", "Canvas View")

        val sourceWeights = listOf(45f, 30f, 25f)
        val targetWeights = listOf(50f, 30f, 20f)

        val col1X = viewport.left + viewport.width * 0.15f
        val col2X = viewport.left + viewport.width * 0.85f

        val nodeHeight = 55f
        val verticalPadding = 25f

        // Draw Left Nodes
        val leftPoints = mutableListOf<Offset>()
        flowNodesLeft.forEachIndexed { i, name ->
            val ny = viewport.top + 30f + (nodeHeight + verticalPadding) * i
            val rectTopLeft = Offset(col1X - 25f, ny)
            val rectSize = Size(20f, nodeHeight)

            drawRect(
                color = theme.colors.accentColors[i % theme.colors.accentColors.size],
                topLeft = rectTopLeft,
                size = rectSize
            )

            val textLayout = textMeasurer.measure(
                text = name,
                style = TextStyle(color = theme.colors.labelTextColor, fontSize = 10.sp, fontFamily = theme.typography.labelFont)
            )
            drawText(textLayout, Offset(col1X - textLayout.size.width - 32f, ny + 15f))

            leftPoints.add(Offset(col1X - 5f, ny + nodeHeight / 2f))
        }

        // Draw Right Nodes
        val rightPoints = mutableListOf<Offset>()
        flowNodesRight.forEachIndexed { i, name ->
            val ny = viewport.top + 40f + (nodeHeight + verticalPadding) * i
            val rectTopLeft = Offset(col2X + 5f, ny)
            val rectSize = Size(20f, nodeHeight)

            drawRect(
                color = theme.colors.accentColors[(i + 3) % theme.colors.accentColors.size],
                topLeft = rectTopLeft,
                size = rectSize
            )

            val textLayout = textMeasurer.measure(
                text = name,
                style = TextStyle(color = theme.colors.labelTextColor, fontSize = 10.sp, fontFamily = theme.typography.labelFont)
            )
            drawText(textLayout, Offset(col2X + 32f, ny + 15f))

            rightPoints.add(Offset(col2X + 5f, ny + nodeHeight / 2f))
        }

        // Draw Flow Curves with Bezier Interpolation
        var hoverFound = false

        leftPoints.forEachIndexed { lIdx, lp ->
            rightPoints.forEachIndexed { rIdx, rp ->
                val weight = (sourceWeights[lIdx] * targetWeights[rIdx]) / 100f
                val finalWeight = weight * progress
                val curvePath = Path()

                curvePath.moveTo(lp.x, lp.y)
                val ctrl1X = lp.x + (rp.x - lp.x) * 0.4f
                val ctrl2X = lp.x + (rp.x - lp.x) * 0.6f

                curvePath.cubicTo(ctrl1X, lp.y, ctrl2X, rp.y, rp.x, rp.y)

                val strokeColor = theme.colors.accentColors[(lIdx + rIdx) % theme.colors.accentColors.size].copy(alpha = 0.15f)
                val isMouseClose = interactionState.crosshairPos != null &&
                        kotlin.math.abs(interactionState.crosshairPos.x - (lp.x + rp.x) / 2f) < 40f &&
                        kotlin.math.abs(interactionState.crosshairPos.y - (lp.y + rp.y) / 2f) < 35f

                val finalStrokeColor = if (isMouseClose) strokeColor.copy(alpha = 0.55f) else strokeColor
                val finalThickness = (finalWeight / 2f).coerceAtLeast(2f)

                drawPath(
                    path = curvePath,
                    color = finalStrokeColor,
                    style = Stroke(width = finalThickness, cap = StrokeCap.Round)
                )

                if (isMouseClose && !hoverFound) {
                    hoverFound = true
                    onHover(
                        TooltipData(
                            title = "${flowNodesLeft[lIdx]} → ${flowNodesRight[rIdx]}",
                            value = "Flow Volume: %.1f Units".format(weight),
                            seriesName = "Sankey Connection",
                            screenPos = Offset((lp.x + rp.x) / 2f, (lp.y + rp.y) / 2f),
                            dataIndex = lIdx * 10 + rIdx
                        )
                    )
                }
            }
        }

        if (!hoverFound) onHover(null)
    }

    private fun DrawScope.renderHeatmap(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        // Draw a beautiful 2D heatmap matrix (e.g., 5x5 performance correlations)
        val cols = listOf("Jan", "Feb", "Mar", "Apr", "May")
        val rows = listOf("Direct", "Organic", "Social", "Referral", "Paid")
        val size = cols.size

        val cellWidth = viewport.width / size
        val cellHeight = viewport.height / size

        var hoverFound = false

        for (x in 0 until size) {
            for (y in 0 until size) {
                // Mock correlation coefficient
                val baseValue = (kotlin.math.sin(x.toDouble() + y.toDouble() * 0.7) * 45 + 50).toFloat()
                val value = AnimationEngine.lerp(0f, baseValue, progress)

                val rectLeft = viewport.left + x * cellWidth
                val rectTop = viewport.top + y * cellHeight
                val rectRight = rectLeft + cellWidth
                val rectBottom = rectTop + cellHeight

                // Map value to dynamic heatmap gradient (Cold blue to Intense hot pink)
                val alpha = (value / 100f).coerceIn(0.1f, 1.0f)
                val color = theme.colors.accentColors[0].copy(alpha = alpha)

                val cellRect = Rect(rectLeft, rectTop, rectRight, rectBottom)
                val isHovered = interactionState.crosshairPos != null && cellRect.contains(interactionState.crosshairPos)
                val finalColor = if (isHovered) Color.White.copy(alpha = 0.3f) else Color.Transparent

                // Draw Heatmap Block
                drawRect(
                    color = color,
                    topLeft = Offset(rectLeft, rectTop),
                    size = Size(cellWidth, cellHeight)
                )

                if (isHovered) {
                    drawRect(
                        color = finalColor,
                        topLeft = Offset(rectLeft, rectTop),
                        size = Size(cellWidth, cellHeight)
                    )
                    // Draw cell highlight outline
                    drawRect(
                        color = Color.White,
                        topLeft = Offset(rectLeft, rectTop),
                        size = Size(cellWidth, cellHeight),
                        style = Stroke(width = 2f)
                    )
                }

                // Inner value label
                if (cellWidth > 45f && cellHeight > 30f) {
                    val textLayout = textMeasurer.measure(
                        text = "%.0f".format(value),
                        style = TextStyle(color = if (alpha > 0.5f) Color.White else theme.colors.labelTextColor, fontSize = 10.sp, fontFamily = theme.typography.labelFont)
                    )
                    drawText(textLayout, Offset(rectLeft + (cellWidth - textLayout.size.width) / 2f, rectTop + (cellHeight - textLayout.size.height) / 2f))
                }

                if (isHovered && !hoverFound) {
                    hoverFound = true
                    onHover(
                        TooltipData(
                            title = "${cols[x]} x ${rows[y]}",
                            value = "Core Score: %.1f".format(value),
                            seriesName = "Correlation Map",
                            screenPos = Offset(rectLeft + cellWidth / 2f, rectTop + cellHeight / 2f),
                            dataIndex = x * size + y
                        )
                    )
                }
            }
        }

        // Axis Titles for columns & rows
        for (x in 0 until size) {
            val textLayout = textMeasurer.measure(cols[x], TextStyle(color = theme.colors.labelTextColor, fontSize = 9.sp))
            drawText(textLayout, Offset(viewport.left + x * cellWidth + (cellWidth - textLayout.size.width) / 2f, viewport.bottom + 6f))
        }

        for (y in 0 until size) {
            val textLayout = textMeasurer.measure(rows[y], TextStyle(color = theme.colors.labelTextColor, fontSize = 9.sp))
            drawText(textLayout, Offset(viewport.left - textLayout.size.width - 6f, viewport.top + y * cellHeight + (cellHeight - textLayout.size.height) / 2f))
        }

        if (!hoverFound) onHover(null)
    }

    private fun DrawScope.renderNetworkGraph(
        dataset: AuroraDataset,
        spec: AuroraChartSpec,
        viewport: Viewport,
        theme: AuroraThemeSpec,
        interactionState: AuroraInteractionState,
        progress: Float,
        textMeasurer: TextMeasurer,
        onHover: (TooltipData?) -> Unit
    ) {
        // Render a gorgeous force-directed graph representation
        val center = Offset(viewport.left + viewport.width / 2f, viewport.top + viewport.height / 2f)
        val radius = viewport.width.coerceAtMost(viewport.height) * 0.35f

        val nodeNames = listOf("Python App", "Pandas", "WebSocket", "JSON Protocol", "Aurora Engine", "GPU Core", "M3 Compose UI")
        val links = listOf(
            0 to 1, 0 to 2, 1 to 3, 2 to 3, 3 to 4, 4 to 5, 4 to 6
        )

        // Compute polar node layouts around screen center
        val nodePoints = nodeNames.mapIndexed { idx, name ->
            val angle = Math.toRadians((idx * 360.0 / nodeNames.size) + (interactionState.panX / 3f))
            val dist = radius * (0.6f + 0.4f * sin(idx.toDouble() * 1.5).toFloat()) * progress
            Offset(
                center.x + (cos(angle) * dist).toFloat(),
                center.y + (sin(angle) * dist).toFloat()
            )
        }

        // Draw Links
        links.forEach { link ->
            val pStart = nodePoints[link.first]
            val pEnd = nodePoints[link.second]
            drawLine(
                color = theme.colors.axisColor.copy(alpha = 0.45f),
                start = pStart,
                end = pEnd,
                strokeWidth = 2f
            )
        }

        // Draw Nodes
        var hoverFound = false
        nodePoints.forEachIndexed { idx, p ->
            val isHovered = interactionState.crosshairPos != null && (p - interactionState.crosshairPos).getDistance() < 20f
            val nodeColor = theme.colors.accentColors[idx % theme.colors.accentColors.size]
            val nodeRadius = if (isHovered) 16f else 11f

            // Outer pulse glow
            drawCircle(
                color = nodeColor.copy(alpha = 0.3f),
                radius = nodeRadius + 5f,
                center = p
            )
            // Main solid node
            drawCircle(
                color = nodeColor,
                radius = nodeRadius,
                center = p
            )

            // White center
            drawCircle(
                color = Color.White,
                radius = nodeRadius / 2f,
                center = p
            )

            val textLayout = textMeasurer.measure(
                text = nodeNames[idx],
                style = TextStyle(color = theme.colors.labelTextColor, fontSize = 9.sp, fontFamily = theme.typography.labelFont)
            )
            drawText(
                textLayout = textLayout,
                topLeft = Offset(p.x - textLayout.size.width / 2f, p.y + nodeRadius + 5f)
            )

            if (isHovered && !hoverFound) {
                hoverFound = true
                onHover(
                    TooltipData(
                        title = nodeNames[idx],
                        value = "Degree: ${links.count { it.first == idx || it.second == idx }} links",
                        seriesName = "Network Plugin",
                        screenPos = p,
                        dataIndex = idx
                    )
                )
            }
        }

        if (!hoverFound) onHover(null)
    }
}
