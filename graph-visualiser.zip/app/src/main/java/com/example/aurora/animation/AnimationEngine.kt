package com.example.aurora.animation

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.lerp

object AnimationEngine {

    // Helper to calculate linear interpolation between two values
    fun lerp(start: Float, stop: Float, fraction: Float): Float {
        return start + fraction * (stop - start)
    }

    // Helper to calculate linear interpolation between two offsets
    fun lerpOffset(start: Offset, stop: Offset, fraction: Float): Offset {
        return lerp(start, stop, fraction)
    }

    // A stateful Composable trigger that animates progress from 0f to 1f on key change
    @Composable
    fun rememberAnimationProgress(key: Any, durationMs: Int = 450): Float {
        val anim = remember { Animatable(0f) }
        LaunchedEffect(key) {
            anim.snapTo(0f)
            anim.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = durationMs,
                    easing = FastOutSlowInEasing
                )
            )
        }
        return anim.value
    }
}
