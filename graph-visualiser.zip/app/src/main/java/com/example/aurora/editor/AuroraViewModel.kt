package com.example.aurora.editor

import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aurora.communication.PythonBridge
import com.example.aurora.engine.AuroraChartSpec
import com.example.aurora.engine.AuroraDataset
import com.example.aurora.engine.ChartType
import com.example.aurora.interaction.AuroraInteractionState
import com.example.aurora.interaction.InteractionMode
import com.example.aurora.interaction.TooltipData
import com.example.aurora.plugins.PluginRegistry
import com.example.aurora.themes.AuroraThemeSpec
import com.example.aurora.themes.AuroraThemeType
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuroraViewModel : ViewModel() {

    private val _dataset = MutableStateFlow<AuroraDataset>(PythonBridge.financialDataset)
    val dataset = _dataset.asStateFlow()

    private val _chartSpec = MutableStateFlow<AuroraChartSpec>(
        AuroraChartSpec(
            chartType = ChartType.CANDLESTICK,
            title = "Tesla Motors Stock Terminal",
            subtitle = "Simulating Real-Time OHLC Candlestick + Volume Overlay",
            xColumn = "Index",
            yColumns = listOf("Close")
        )
    )
    val chartSpec = _chartSpec.asStateFlow()

    private val _interactionState = MutableStateFlow(AuroraInteractionState())
    val interactionState = _interactionState.asStateFlow()

    private val _activeThemeType = MutableStateFlow(AuroraThemeType.DARK_TERMINAL)
    val activeThemeType = _activeThemeType.asStateFlow()

    private val _selectedRowIndex = MutableStateFlow<Int?>(null)
    val selectedRowIndex = _selectedRowIndex.asStateFlow()

    private val _pythonScriptText = MutableStateFlow(
        "import pandas as pd\nimport aurora\n\ndf = pd.read_csv('tsla_stock.csv')\naurora.render(df, type='candlestick', theme='dark_terminal')"
    )
    val pythonScriptText = _pythonScriptText.asStateFlow()

    private val _isStreaming = MutableStateFlow(false)
    val isStreaming = _isStreaming.asStateFlow()

    init {
        // Initial setup logging
        viewModelScope.launch {
            PythonBridge.log("AURORA -> PYTHON", "INIT", "Aurora Visualisation Engine loaded. GPU hardware-acceleration initialized.")
            delay(300)
            PythonBridge.log("PYTHON -> AURORA", "WORKSPACE_ESTABLISHED", "Pandas workbook calculations synced. Awaiting render signals.")
        }
    }

    fun updateTheme(type: AuroraThemeType) {
        _activeThemeType.value = type
        PythonBridge.log("AURORA -> PYTHON", "THEME_UPDATED", "Active visual theme set to: ${type.label}")
    }

    fun updateInteractionMode(mode: InteractionMode) {
        _interactionState.value = _interactionState.value.copy(mode = mode)
        PythonBridge.log("AURORA -> PYTHON", "INTERACTION_MODE_CHANGED", "Canvas interaction mode changed to: ${mode.name}")
    }

    fun setHoverTooltip(tooltip: TooltipData?) {
        _interactionState.value = _interactionState.value.copy(hoveredTooltip = tooltip)
        if (tooltip != null) {
            // Log interaction event back to Python workspace
            PythonBridge.log(
                "AURORA -> PYTHON",
                "EVENT_HOVER",
                "User hovered on Index: ${tooltip.dataIndex}, Value: ${tooltip.value} (${tooltip.seriesName})"
            )
            _selectedRowIndex.value = tooltip.dataIndex
        }
    }

    fun updatePan(dx: Float, dy: Float) {
        val state = _interactionState.value
        _interactionState.value = state.copy(
            panX = state.panX + dx,
            panY = state.panY + dy
        )
    }

    fun handleZoomIn() {
        _interactionState.value = _interactionState.value.zoomIn()
        PythonBridge.log("AURORA -> PYTHON", "CANVAS_ZOOM", "Zoom scale factor updated to: X: ${_interactionState.value.zoomX}")
    }

    fun handleZoomOut() {
        _interactionState.value = _interactionState.value.zoomOut()
        PythonBridge.log("AURORA -> PYTHON", "CANVAS_ZOOM", "Zoom scale factor updated to: X: ${_interactionState.value.zoomX}")
    }

    fun handleResetViewport() {
        _interactionState.value = _interactionState.value.reset()
        _selectedRowIndex.value = null
        PythonBridge.log("AURORA -> PYTHON", "CANVAS_RESET", "Zoom and pan scale factors restored to default 1.0.")
    }

    fun selectRow(index: Int) {
        _selectedRowIndex.value = if (_selectedRowIndex.value == index) null else index
        if (_selectedRowIndex.value != null) {
            _interactionState.value = _interactionState.value.copy(
                selectedDataIndices = setOf(index)
            )
            PythonBridge.log("AURORA -> PYTHON", "ROW_SELECTED", "Linked selection triggered. Index: $index highlighted.")
        } else {
            _interactionState.value = _interactionState.value.copy(
                selectedDataIndices = emptySet()
            )
        }
    }

    fun applyLiveFilter(min: Float, max: Float) {
        _interactionState.value = _interactionState.value.copy(
            liveFilterMin = min,
            liveFilterMax = max
        )
        PythonBridge.log(
            "AURORA -> PYTHON",
            "FILTER_CHANGE",
            "Active dimension filtered range set: [$min to $max]. recalculating metrics."
        )
    }

    fun setPythonScript(text: String) {
        _pythonScriptText.value = text
    }

    // Runs a python simulation of loading different specs
    fun executePythonPreset(chartType: ChartType) {
        viewModelScope.launch {
            _isStreaming.value = true
            val (mockData, mockSpec) = PythonBridge.getDatasetAndSpec(chartType)

            PythonBridge.log("PYTHON -> AURORA", "CALCULATE_FORMULA", "DataFrame operation completed. Compiling matrix coordinates...")
            delay(400)

            _dataset.value = mockData
            _chartSpec.value = mockSpec
            _selectedRowIndex.value = null
            _interactionState.value = _interactionState.value.reset()

            // Auto update python script representation in editor
            val yColsStr = mockSpec.yColumns.joinToString(", ") { "'$it'" }
            _pythonScriptText.value = """
                import pandas as pd
                import aurora

                df = pd.read_csv('${mockData.id.lowercase()}.csv')
                
                # Active Chart Pipeline Specification
                spec = {
                    'title': '${mockSpec.title}',
                    'x': '${mockSpec.xColumn}',
                    'y': [$yColsStr]
                }
                
                aurora.render_chart(df, spec, type='${chartType.name.lowercase()}')
            """.trimIndent()

            val rowCount = mockData.rows.size
            val colNames = mockData.columns.map { it.name }
            PythonBridge.log(
                "PYTHON -> AURORA",
                "RENDER_SPEC",
                "Pushing dataset '${mockData.name}' ($rowCount rows, cols: $colNames). Requested plot type: ${chartType.name}."
            )

            delay(150)
            _isStreaming.value = false
        }
    }

    // Toggle plugin activation
    fun togglePlugin(pluginId: String) {
        PluginRegistry.togglePlugin(pluginId)
        val p = PluginRegistry.getPluginById(pluginId)
        val statusStr = if (p?.isEnabled == true) "ENABLED" else "DISABLED"
        PythonBridge.log("AURORA -> PYTHON", "PLUGIN_STATE_CHANGED", "Plugin '${p?.name}' set to $statusStr.")
        // Force state update by triggering a minor modification
        _interactionState.value = _interactionState.value.copy(
            comparisonMode = !_interactionState.value.comparisonMode
        )
        _interactionState.value = _interactionState.value.copy(
            comparisonMode = !_interactionState.value.comparisonMode
        )
    }
}
