package com.example.aurora.renderer

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.unit.sp
import com.example.aurora.interaction.AuroraInteractionState
import com.example.aurora.themes.AuroraThemeSpec
import kotlin.math.cos
import kotlin.math.sin

data class Viewport(
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float
) {
    val right: Float get() = left + width
    val bottom: Float get() = top + height
}

object AuroraRenderer {

    // Projects a 2D data coordinate into viewport space, incorporating Zoom & Pan
    fun project(
        dataX: Float,
        dataY: Float,
        minDataX: Float,
        maxDataX: Float,
        minDataY: Float,
        maxDataY: Float,
        viewport: Viewport,
        interactionState: AuroraInteractionState
    ): Offset {
        val rangeX = if (maxDataX == minDataX) 1f else maxDataX - minDataX
        val rangeY = if (maxDataY == minDataY) 1f else maxDataY - minDataY

        // Normalize data point to [0, 1]
        val normX = (dataX - minDataX) / rangeX
        val normY = (dataY - minDataY) / rangeY

        // Apply zoom & pan centered at the viewport center or top-left
        val zoomedNormX = (normX - 0.5f) * interactionState.zoomX + 0.5f + (interactionState.panX / viewport.width)
        val zoomedNormY = (normY - 0.5f) * interactionState.zoomY + 0.5f - (interactionState.panY / viewport.height) // Y is inverted in screen space

        // Map normalized value to the viewport boundaries
        val x = viewport.left + zoomedNormX * viewport.width
        val y = viewport.bottom - zoomedNormY * viewport.height // Inverted because higher data y is drawn higher on screen (smaller pixel y)

        return Offset(x, y)
    }

    // Unprojects a viewport screen offset back to 2D data space
    fun unproject(
        screenX: Float,
        screenY: Float,
        minDataX: Float,
        maxDataX: Float,
        minDataY: Float,
        maxDataY: Float,
        viewport: Viewport,
        interactionState: AuroraInteractionState
    ): Offset {
        val rangeX = if (maxDataX == minDataX) 1f else maxDataX - minDataX
        val rangeY = if (maxDataY == minDataY) 1f else maxDataY - minDataY

        // Reconstruct from screen x to normalized x
        val zoomedNormX = (screenX - viewport.left) / viewport.width
        val normX = (zoomedNormX - 0.5f) / interactionState.zoomX + 0.5f - (interactionState.panX / viewport.width)

        val zoomedNormY = (viewport.bottom - screenY) / viewport.height
        val normY = (zoomedNormY - 0.5f) / interactionState.zoomY + 0.5f + (interactionState.panY / viewport.height)

        val dataX = minDataX + normX * rangeX
        val dataY = minDataY + normY * rangeY

        return Offset(dataX, dataY)
    }

    // Projects a 3D point (x, y, z) to 2D Screen space with rotation
    fun project3D(
        x: Float, y: Float, z: Float,
        rotX: Float, // Yaw (Degrees)
        rotY: Float, // Pitch (Degrees)
        scale: Float,
        center: Offset
    ): Offset {
        val radX = Math.toRadians(rotX.toDouble())
        val radY = Math.toRadians(rotY.toDouble())

        // Apply yaw (rotation about Z-axis/Vertical)
        val cosX = cos(radX).toFloat()
        val sinX = sin(radX).toFloat()
        val x1 = x * cosX - y * sinX
        val y1 = x * sinX + y * cosX

        // Apply pitch (rotation about X-axis)
        val cosY = cos(radY).toFloat()
        val sinY = sin(radY).toFloat()
        val y2 = y1 * cosY - z * sinY
        val z2 = y1 * sinY + z * cosY

        // orthographic projection onto screen
        val px = center.x + x1 * scale
        val py = center.y - y2 * scale // Invert Y for screen drawing

        return Offset(px, py)
    }

    // Nice tick spacing calculation (similar to Excel / Wilkinson's algorithm)
    fun calculateTicks(min: Float, max: Float, targetTickCount: Int = 5): List<Float> {
        val range = max - min
        if (range <= 0) return listOf(min)

        val rawStep = range / targetTickCount
        val log10 = kotlin.math.log10(rawStep.toDouble())
        val power = kotlin.math.floor(log10).toFloat()
        val baseStep = kotlin.math.pow(10.0, power.toDouble()).toFloat()

        val normalizedStep = rawStep / baseStep
        val step = when {
            normalizedStep < 1.5f -> 1.0f * baseStep
            normalizedStep < 3.0f -> 2.0f * baseStep
            normalizedStep < 7.0f -> 5.0f * baseStep
            else -> 10.0f * baseStep
        }

        val startTick = kotlin.math.ceil(min / step) * step
        val ticks = mutableListOf<Float>()
        var current = startTick.toFloat()
        while (current <= max) {
            ticks.add(current)
            current += step
            // Prevent infinite loop from floating-point inaccuracy
            if (step <= 0f) break
        }
        return if (ticks.isEmpty()) listOf(min, max) else ticks
    }

    // Standard gridline and axes renderer helper
    fun DrawScope.drawGridAndAxes(
        viewport: Viewport,
        theme: AuroraThemeSpec,
        xTicks: List<Float>,
        yTicks: List<Float>,
        minX: Float, maxX: Float,
        minY: Float, maxY: Float,
        interactionState: AuroraInteractionState,
        textMeasurer: TextMeasurer,
        xFormatter: (Float) -> String = { "%.1f".format(it) },
        yFormatter: (Float) -> String = { "%.1f".format(it) }
    ) {
        val labelStyle = TextStyle(
            color = theme.colors.labelTextColor,
            fontFamily = theme.typography.labelFont,
            fontSize = 10.sp
        )

        // 1. Draw Y-Axis Gridlines & Labels
        yTicks.forEach { valY ->
            val p = project(minX, valY, minX, maxX, minY, maxY, viewport, interactionState)
            if (p.y >= viewport.top && p.y <= viewport.bottom) {
                // Draw dotted horizontal gridline
                drawLine(
                    color = theme.colors.gridLineColor,
                    start = Offset(viewport.left, p.y),
                    end = Offset(viewport.right, p.y),
                    strokeWidth = theme.gridStrokeWidth,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                // Draw Y Axis Labels
                val labelText = yFormatter(valY)
                val textLayout = textMeasurer.measure(labelText, labelStyle)
                drawText(
                    textLayout = textLayout,
                    topLeft = Offset(viewport.left - textLayout.size.width - 8f, p.y - textLayout.size.height / 2f)
                )
            }
        }

        // 2. Draw X-Axis Gridlines & Labels (with intelligent auto-rotation and skipping)
        val spacePerLabel = viewport.width / (xTicks.size.coerceAtLeast(1))
        val rotateLabels = spacePerLabel < 60f // Rotate if narrow spacing

        xTicks.forEach { valX ->
            val p = project(valX, minY, minX, maxX, minY, maxY, viewport, interactionState)
            if (p.x >= viewport.left && p.x <= viewport.right) {
                // Draw dotted vertical gridline
                drawLine(
                    color = theme.colors.gridLineColor,
                    start = Offset(p.x, viewport.top),
                    end = Offset(p.x, viewport.bottom),
                    strokeWidth = theme.gridStrokeWidth,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                // Draw X Axis Labels with optional rotation
                val labelText = xFormatter(valX)
                val textLayout = textMeasurer.measure(labelText, labelStyle)

                if (rotateLabels) {
                    withTransform({
                        rotate(degrees = -35f, pivot = Offset(p.x, viewport.bottom + 10f))
                    }) {
                        drawText(
                            textLayout = textLayout,
                            topLeft = Offset(p.x - textLayout.size.width / 2f, viewport.bottom + 10f)
                        )
                    }
                } else {
                    drawText(
                        textLayout = textLayout,
                        topLeft = Offset(p.x - textLayout.size.width / 2f, viewport.bottom + 8f)
                    )
                }
            }
        }

        // 3. Draw Axis Borders (Solid Lines)
        // Y-axis line
        drawLine(
            color = theme.colors.axisColor,
            start = Offset(viewport.left, viewport.top),
            end = Offset(viewport.left, viewport.bottom),
            strokeWidth = 2f
        )
        // X-axis line
        drawLine(
            color = theme.colors.axisColor,
            start = Offset(viewport.left, viewport.bottom),
            end = Offset(viewport.right, viewport.bottom),
            strokeWidth = 2f
        )
    }
}
