package com.example.aurora.engine

enum class ColumnType {
    NUMBER,
    STRING,
    DATETIME
}

data class AuroraColumn(
    val name: String,
    val type: ColumnType
)

data class AuroraRow(
    val cells: Map<String, Any>
)

data class AuroraDataset(
    val id: String,
    val name: String,
    val columns: List<AuroraColumn>,
    val rows: List<AuroraRow>
) {
    fun getNumericalValues(colName: String): List<Float> {
        return rows.map {
            when (val v = it.cells[colName]) {
                is Number -> v.toFloat()
                is String -> v.toFloatOrNull() ?: 0f
                else -> 0f
            }
        }
    }

    fun getStringValues(colName: String): List<String> {
        return rows.map { it.cells[colName]?.toString() ?: "" }
    }
}

enum class ChartType(val label: String, val category: String) {
    LINE("Line Chart", "Basic"),
    SPLINE("Spline Area", "Basic"),
    STEP("Step Chart", "Basic"),
    COLUMN("Column Chart", "Bar & Column"),
    GROUPED_BAR("Grouped Bars", "Bar & Column"),
    STACKED_BAR("Stacked Bars", "Bar & Column"),
    PIE("Pie Chart", "Proportions"),
    DONUT("Donut Chart", "Proportions"),
    SCATTER("Scatter & Bubble", "Relationships"),
    RADAR("Radar & Polar", "Relationships"),
    HEATMAP("2D Heatmap", "Advanced"),
    TREEMAP("Treemap", "Advanced"),
    SANKEY("Sankey Diagram", "Advanced"),
    CANDLESTICK("OHLC Candlestick", "Financial"),
    SURFACE_3D("3D Surface Plot", "Advanced"),
    NETWORK("Network Graph", "Plugins")
}

data class AuroraChartSpec(
    val chartType: ChartType,
    val title: String,
    val subtitle: String,
    val xColumn: String,
    val yColumns: List<String>,
    val groupingColumn: String? = null,
    val labelColumn: String? = null,
    val extraParams: Map<String, Any> = emptyMap()
)
