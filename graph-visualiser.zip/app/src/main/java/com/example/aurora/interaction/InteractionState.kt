package com.example.aurora.interaction

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect

enum class InteractionMode {
    ZOOM_PAN,
    BRUSH_SELECT,
    HOVER_TOOLTIP,
    DRAG_EDIT
}

data class TooltipData(
    val title: String,
    val value: String,
    val seriesName: String,
    val screenPos: Offset,
    val dataIndex: Int
)

data class AuroraInteractionState(
    val mode: InteractionMode = InteractionMode.HOVER_TOOLTIP,
    val zoomX: Float = 1.0f,
    val zoomY: Float = 1.0f,
    val panX: Float = 0.0f,
    val panY: Float = 0.0f,
    val brushBox: Rect? = null,
    val hoveredTooltip: TooltipData? = null,
    val crosshairPos: Offset? = null,
    val selectedDataIndices: Set<Int> = emptySet(),
    val liveFilterMin: Float? = null,
    val liveFilterMax: Float? = null,
    val comparisonMode: Boolean = false,
    val undoStack: List<AuroraInteractionState> = emptyList(),
    val redoStack: List<AuroraInteractionState> = emptyList()
) {
    fun zoomIn(): AuroraInteractionState {
        return copy(
            zoomX = (zoomX * 1.25f).coerceAtMost(20f),
            zoomY = (zoomY * 1.25f).coerceAtMost(20f),
            undoStack = addToUndo()
        )
    }

    fun zoomOut(): AuroraInteractionState {
        return copy(
            zoomX = (zoomX / 1.25f).coerceAtLeast(0.5f),
            zoomY = (zoomY / 1.25f).coerceAtLeast(0.5f),
            undoStack = addToUndo()
        )
    }

    fun reset(): AuroraInteractionState {
        return copy(
            zoomX = 1.0f,
            zoomY = 1.0f,
            panX = 0.0f,
            panY = 0.0f,
            brushBox = null,
            hoveredTooltip = null,
            crosshairPos = null,
            selectedDataIndices = emptySet(),
            liveFilterMin = null,
            liveFilterMax = null,
            undoStack = addToUndo()
        )
    }

    private fun addToUndo(): List<AuroraInteractionState> {
        val nextUndo = undoStack.toMutableList()
        nextUndo.add(this.copy(undoStack = emptyList(), redoStack = emptyList()))
        if (nextUndo.size > 20) {
            nextUndo.removeAt(0)
        }
        return nextUndo
    }

    fun undo(): AuroraInteractionState {
        if (undoStack.isEmpty()) return this
        val prev = undoStack.last()
        val nextUndo = undoStack.dropLast(1)
        val nextRedo = redoStack.toMutableList()
        nextRedo.add(this.copy(undoStack = emptyList(), redoStack = emptyList()))
        return prev.copy(undoStack = nextUndo, redoStack = nextRedo)
    }

    fun redo(): AuroraInteractionState {
        if (redoStack.isEmpty()) return this
        val next = redoStack.last()
        val nextRedo = redoStack.dropLast(1)
        val nextUndo = undoStack.toMutableList()
        nextUndo.add(this.copy(undoStack = emptyList(), redoStack = emptyList()))
        return next.copy(undoStack = nextUndo, redoStack = nextRedo)
    }
}
