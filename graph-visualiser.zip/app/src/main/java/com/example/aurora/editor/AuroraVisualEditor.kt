package com.example.aurora.editor

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aurora.animation.AnimationEngine
import com.example.aurora.charts.AuroraCharts
import com.example.aurora.communication.PythonBridge
import com.example.aurora.engine.ChartType
import com.example.aurora.interaction.InteractionMode
import com.example.aurora.plugins.CustomChartRendererPlugin
import com.example.aurora.plugins.PluginRegistry
import com.example.aurora.renderer.Viewport
import com.example.aurora.themes.AuroraThemeSpec
import com.example.aurora.themes.AuroraThemeType

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AuroraVisualEditor(
    viewModel: AuroraViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val dataset by viewModel.dataset.collectAsState()
    val spec by viewModel.chartSpec.collectAsState()
    val interactionState by viewModel.interactionState.collectAsState()
    val themeType by viewModel.activeThemeType.collectAsState()
    val selectedRowIdx by viewModel.selectedRowIndex.collectAsState()
    val pythonText by viewModel.pythonScriptText.collectAsState()
    val isStreaming by viewModel.isStreaming.collectAsState()
    val logs by PythonBridge.logs.collectAsState()

    val activeThemeSpec = remember(themeType) { AuroraThemeSpec.getTheme(themeType) }

    // Tab categories for responsive mobile views
    var activeMobileTab by remember { mutableIntStateOf(0) }
    val mobileTabs = listOf("GPU Renderer", "Python Bridge", "Analytics Grid", "Theme & Plugins")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "PROJECT AURORA",
                                style = TextStyle(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp,
                                    letterSpacing = 1.5.sp,
                                    color = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isStreaming) Color(0xFFFFB300) else Color(0xFF10B981))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isStreaming) "STREAMING" else "RPC LIVE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                        Text(
                            text = "Kotlin Visualization Engine v2.6 // Decoupled Spreadsheet Pipeline",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.handleResetViewport()
                            Toast.makeText(context, "Viewport and highlights restored.", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("reset_viewport_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset viewport", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF090D16)
                )
            )
        },
        containerColor = activeThemeSpec.colors.backgroundColor,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            val isTablet = maxWidth > 840.dp

            if (isTablet) {
                // Large tablet layout: 3 elegant side-by-side columns
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Left Column: Python Bridge and preset triggers (27% width)
                    Column(
                        modifier = Modifier
                            .weight(0.27f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PythonBridgePanel(
                            pythonText = pythonText,
                            onExecute = { viewModel.executePythonPreset(spec.chartType) },
                            logs = logs,
                            onClearLogs = { PythonBridge.clearLogs() },
                            modifier = Modifier.weight(0.55f)
                        )
                        ChartPresetsPanel(
                            activeType = spec.chartType,
                            onSelectPreset = { viewModel.executePythonPreset(it) },
                            modifier = Modifier.weight(0.45f)
                        )
                    }

                    // Center Column: GPU Canvas Renderer (45% width)
                    Column(
                        modifier = Modifier
                            .weight(0.45f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CanvasRendererCard(
                            themeSpec = activeThemeSpec,
                            dataset = dataset,
                            spec = spec,
                            interactionState = interactionState,
                            viewModel = viewModel,
                            modifier = Modifier.weight(0.68f)
                        )
                        SpreadsheetGridCard(
                            dataset = dataset,
                            spec = spec,
                            selectedIdx = selectedRowIdx,
                            onSelectRow = { viewModel.selectRow(it) },
                            themeSpec = activeThemeSpec,
                            modifier = Modifier.weight(0.32f)
                        )
                    }

                    // Right Column: Dashboard analytics, filters, themes & plugins (28% width)
                    Column(
                        modifier = Modifier
                            .weight(0.28f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        DashboardAnalyticsWidget(
                            dataset = dataset,
                            spec = spec,
                            viewModel = viewModel,
                            interactionState = interactionState,
                            themeSpec = activeThemeSpec,
                            modifier = Modifier.weight(0.48f)
                        )
                        ThemeAndPluginsPanel(
                            activeTheme = themeType,
                            onSelectTheme = { viewModel.updateTheme(it) },
                            onTogglePlugin = { viewModel.togglePlugin(it) },
                            modifier = Modifier.weight(0.52f)
                        )
                    }
                }
            } else {
                // Mobile layout: Single view stack with category slider tabs
                Column(modifier = Modifier.fillMaxSize()) {
                    ScrollableTabRow(
                        selectedTabIndex = activeMobileTab,
                        containerColor = Color(0xFF0F172A),
                        contentColor = Color.White,
                        edgePadding = 12.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        mobileTabs.forEachIndexed { index, title ->
                            Tab(
                                selected = activeMobileTab == index,
                                onClick = { activeMobileTab = index },
                                text = { Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(8.dp)
                    ) {
                        when (activeMobileTab) {
                            0 -> {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                                    CanvasRendererCard(
                                        themeSpec = activeThemeSpec,
                                        dataset = dataset,
                                        spec = spec,
                                        interactionState = interactionState,
                                        viewModel = viewModel,
                                        modifier = Modifier.weight(0.7f)
                                    )
                                    ChartPresetsPanel(
                                        activeType = spec.chartType,
                                        onSelectPreset = { viewModel.executePythonPreset(it) },
                                        modifier = Modifier.weight(0.3f)
                                    )
                                }
                            }
                            1 -> {
                                PythonBridgePanel(
                                    pythonText = pythonText,
                                    onExecute = { viewModel.executePythonPreset(spec.chartType) },
                                    logs = logs,
                                    onClearLogs = { PythonBridge.clearLogs() },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            2 -> {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                                    DashboardAnalyticsWidget(
                                        dataset = dataset,
                                        spec = spec,
                                        viewModel = viewModel,
                                        interactionState = interactionState,
                                        themeSpec = activeThemeSpec,
                                        modifier = Modifier.weight(0.55f)
                                    )
                                    SpreadsheetGridCard(
                                        dataset = dataset,
                                        spec = spec,
                                        selectedIdx = selectedRowIdx,
                                        onSelectRow = { viewModel.selectRow(it) },
                                        themeSpec = activeThemeSpec,
                                        modifier = Modifier.weight(0.45f)
                                    )
                                }
                            }
                            3 -> {
                                ThemeAndPluginsPanel(
                                    activeTheme = themeType,
                                    onSelectTheme = { viewModel.updateTheme(it) },
                                    onTogglePlugin = { viewModel.togglePlugin(it) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 1. DYNAMIC GPU RENDERER WINDOW
// ---------------------------------------------------------------------------
@Composable
fun CanvasRendererCard(
    themeSpec: AuroraThemeSpec,
    dataset: AuroraDataset,
    spec: AuroraChartSpec,
    interactionState: AuroraInteractionState,
    viewModel: AuroraViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val textMeasurer = rememberTextMeasurer()
    val progress = AnimationEngine.rememberAnimationProgress(key = spec.chartType)

    Card(
        colors = CardDefaults.cardColors(
            containerColor = themeSpec.colors.surfaceColor
        ),
        shape = RoundedCornerShape(12.dp),
        border = if (themeSpec.showGlassEffects) borderGradient() else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // Header information of active visualization
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = spec.title,
                        style = TextStyle(
                            fontFamily = themeSpec.typography.titleFont,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            color = themeSpec.colors.titleTextColor
                        )
                    )
                    Text(
                        text = spec.subtitle,
                        style = TextStyle(
                            fontFamily = themeSpec.typography.bodyFont,
                            fontSize = 11.sp,
                            color = themeSpec.colors.labelTextColor.copy(alpha = 0.8f)
                        )
                    )
                }

                // Interactive export triggers
                Row {
                    IconButton(
                        onClick = {
                            Toast.makeText(context, "Visual vector compiled! High-res SVG saved to clipboard.", Toast.LENGTH_SHORT).show()
                            PythonBridge.log("AURORA -> PYTHON", "EXPORT_VECTOR_GRAPHICS", "SVG path data of ${spec.chartType} compiled and synchronized with system clipboard.")
                        },
                        modifier = Modifier.testTag("export_svg_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Export visual vector", tint = themeSpec.colors.axisColor)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main physical Canvas layout
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(themeSpec.colors.backgroundColor)
                    .border(1f, themeSpec.colors.gridLineColor, RoundedCornerShape(8.dp))
                    .pointerInput(spec.chartType) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                viewModel.setHoverTooltip(null)
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                if (spec.chartType == ChartType.SURFACE_3D) {
                                    // Rotate 3D graph instead of regular pan
                                    viewModel.updatePan(dragAmount.x, dragAmount.y)
                                } else {
                                    viewModel.updatePan(dragAmount.x, dragAmount.y)
                                }
                            }
                        )
                    }
                    .pointerInput(spec.chartType) {
                        // Detect hover actions for tooltip mapping
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull()
                                if (change != null) {
                                    viewModel.updatePan(0f, 0f) // Keep state fresh
                                    val position = change.position
                                    viewModel.setHoverTooltip(null) // Reset first, renderer will update if close
                                }
                            }
                        }
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val margins = 45f
                    val viewport = Viewport(
                        left = margins + 15f,
                        top = margins,
                        width = size.width - 2f * margins - 15f,
                        height = size.height - 2f * margins
                    )

                    // Draw basic background or neon glows if plugin enabled
                    if (PluginRegistry.getPluginById("NEON_GLOW_EFFECT")?.isEnabled == true) {
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(themeSpec.colors.accentColors[0].copy(alpha = 0.12f), Color.Transparent),
                                center = Offset(size.width / 2f, size.height / 2f),
                                radius = size.width / 2f
                            ),
                            radius = size.width / 2f,
                            center = Offset(size.width / 2f, size.height / 2f)
                        )
                    }

                    // Render active chart via central paint engine
                    AuroraCharts.apply {
                        renderChart(
                            dataset = dataset,
                            spec = spec,
                            viewport = viewport,
                            theme = themeSpec,
                            interactionState = interactionState,
                            progress = progress,
                            textMeasurer = textMeasurer,
                            onHover = { tooltip ->
                                // Safe state updating during draw cycle
                                viewModel.setHoverTooltip(tooltip)
                            }
                        )
                    }

                    // Render registered Custom Chart overlays (Plugin architecture)
                    PluginRegistry.plugins.forEach { plugin ->
                        if (plugin.isEnabled && plugin is CustomChartRendererPlugin) {
                            plugin.drawPluginOverlay(this, viewport, themeSpec, dataset.rows.size)
                        }
                    }

                    // Draw interactive crosshairs if active
                    interactionState.hoveredTooltip?.let { tooltip ->
                        drawLine(
                            color = themeSpec.colors.axisColor.copy(alpha = 0.4f),
                            start = Offset(viewport.left, tooltip.screenPos.y),
                            end = Offset(viewport.right, tooltip.screenPos.y),
                            strokeWidth = 1f
                        )
                        drawLine(
                            color = themeSpec.colors.axisColor.copy(alpha = 0.4f),
                            start = Offset(tooltip.screenPos.x, viewport.top),
                            end = Offset(tooltip.screenPos.x, viewport.bottom),
                            strokeWidth = 1f
                        )
                    }
                }

                // Interactive Dynamic Overlay Tooltip (Floating Card)
                interactionState.hoveredTooltip?.let { tooltip ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xEE0F172A)
                        ),
                        shape = RoundedCornerShape(6.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(themeSpec.colors.accentColors[0])
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${tooltip.title}: ",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = tooltip.value,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF10B981)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "(${tooltip.seriesName})",
                                fontSize = 9.sp,
                                color = Color.White.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Zoom, Pan & Viewport utilities under the Canvas
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.handleZoomIn() },
                        colors = ButtonDefaults.buttonColors(containerColor = themeSpec.colors.gridLineColor, contentColor = themeSpec.colors.labelTextColor),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Zoom +", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { viewModel.handleZoomOut() },
                        colors = ButtonDefaults.buttonColors(containerColor = themeSpec.colors.gridLineColor, contentColor = themeSpec.colors.labelTextColor),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("Zoom -", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Text(
                    text = "Zoom: %.2fx // Pan X: %.0f Y: %.0f".format(interactionState.zoomX, interactionState.panX, interactionState.panY),
                    fontSize = 10.sp,
                    fontFamily = themeSpec.typography.labelFont,
                    color = themeSpec.colors.labelTextColor.copy(alpha = 0.7f)
                )
            }
        }
    }
}

// Border styling utility for glass effects
private fun borderGradient(): Stroke {
    return Stroke(width = 1.5f)
}

// ---------------------------------------------------------------------------
// 2. SPREADSHEET LIVE INTERACTIVE DATA GRID
// ---------------------------------------------------------------------------
@Composable
fun SpreadsheetGridCard(
    dataset: AuroraDataset,
    spec: AuroraChartSpec,
    selectedIdx: Int?,
    onSelectRow: (Int) -> Unit,
    themeSpec: AuroraThemeSpec,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = themeSpec.colors.surfaceColor),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(themeSpec.colors.accentColors[0])
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Spreadsheet Workbook Core (${dataset.name})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = themeSpec.colors.titleTextColor
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Draw clean tabular sheet format
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.2dp, themeSpec.colors.gridLineColor, RoundedCornerShape(6.dp))
                    .clip(RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Header row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(themeSpec.colors.gridLineColor)
                            .padding(vertical = 5.dp, horizontal = 8.dp)
                    ) {
                        dataset.columns.forEach { col ->
                            Text(
                                text = col.name,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = themeSpec.colors.labelTextColor,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Value rows (scrollable list)
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(dataset.rows.size) { rIdx ->
                            val row = dataset.rows[rIdx]
                            val isSelected = selectedIdx == rIdx
                            val rowBgColor = if (isSelected) themeSpec.colors.accentColors[0].copy(alpha = 0.2f) else Color.Transparent

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(rowBgColor)
                                    .clickable { onSelectRow(rIdx) }
                                    .border(0.5dp, themeSpec.colors.gridLineColor.copy(alpha = 0.5f))
                                    .padding(vertical = 6.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                dataset.columns.forEach { col ->
                                    val cellVal = row.cells[col.name] ?: ""
                                    Text(
                                        text = if (cellVal is Float) "%.1f".format(cellVal) else cellVal.toString(),
                                        fontSize = 10.sp,
                                        fontFamily = themeSpec.typography.labelFont,
                                        color = if (isSelected) themeSpec.colors.titleTextColor else themeSpec.colors.labelTextColor,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 3. PYTHON SPREADSHEET PLUG / BRIDGE CONTROLLER
// ---------------------------------------------------------------------------
@Composable
fun PythonBridgePanel(
    pythonText: String,
    onExecute: () -> Unit,
    logs: List<com.example.aurora.communication.NetworkLog>,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val listState = rememberLazyListState()

    // Auto scrolls websocket logs down as they update
    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
        ) {
            Text(
                text = "Python Spreadsheet Bridge (Decoupled)",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Core Payload execution script preview
            Box(
                modifier = Modifier
                    .weight(0.48f)
                    .fillMaxWidth()
                    .border(1f, Color(0xFF334155), RoundedCornerShape(6.dp))
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF020617))
                    .padding(8.dp)
                    .verticalScroll(scrollState)
            ) {
                Text(
                    text = pythonText,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = Color(0xFF38BDF8) // High contrast editor color
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onExecute,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, size.dp, tint = Color.Black)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Execute Formula", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Text(
                    text = "Websocket: Port 8089",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Real-Time Socket Connection Log
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Simulated RPC WebSocket Logs", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = "Clear",
                    color = Color(0xFFF43F5E),
                    fontSize = 10.sp,
                    modifier = Modifier.clickable { onClearLogs() }
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Box(
                modifier = Modifier
                    .weight(0.52f)
                    .fillMaxWidth()
                    .border(1f, Color(0xFF1E293B), RoundedCornerShape(6.dp))
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF030712))
                    .padding(6.dp)
            ) {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                    items(logs) { log ->
                        val dirColor = if (log.direction.contains("PYTHON")) Color(0xFFF59E0B) else Color(0xFF3B82F6)
                        Column(modifier = Modifier.padding(bottom = 6.dp)) {
                            Row {
                                Text("[${log.timestamp}]", color = Color.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(log.direction, color = dirColor, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(log.type, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                            Text(log.payload, color = Color(0xFFD1D5DB), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 4. PRESETS SELECTOR PANEL
// ---------------------------------------------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChartPresetsPanel(
    activeType: ChartType,
    onSelectPreset: (ChartType) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
        ) {
            Text(
                text = "Preset Plot Configurations",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Box(modifier = Modifier.weight(1f)) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val chunks = ChartType.values().toList()
                    items(chunks) { type ->
                        val isSel = type == activeType
                        val btnBg = if (isSel) Color(0xFF3B82F6) else Color(0xFF0F172A)
                        val btnFg = if (isSel) Color.White else Color(0xFF94A3B8)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(btnBg)
                                .clickable { onSelectPreset(type) }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(type.label, color = btnFg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(type.category, color = btnFg.copy(alpha = 0.6f), fontSize = 8.sp)
                            }
                            if (isSel) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 5. THEMES & PLUGINS INJECTOR PANEL
// ---------------------------------------------------------------------------
@Composable
fun ThemeAndPluginsPanel(
    activeTheme: AuroraThemeType,
    onSelectTheme: (AuroraThemeType) -> Unit,
    onTogglePlugin: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Aesthetic Style Themes", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)

            // Themes grid buttons
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                AuroraThemeType.values().forEach { t ->
                    val isSel = t == activeTheme
                    val bg = if (isSel) Color(0xFF0284C7) else Color(0xFF1E293B)
                    val textCol = if (isSel) Color.White else Color(0xFF94A3B8)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(bg)
                            .clickable { onSelectTheme(t) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(
                                    when (t) {
                                        AuroraThemeType.LIGHT_CORPORATE -> Color(0xFF0F52BA)
                                        AuroraThemeType.DARK_TERMINAL -> Color(0xFF10B981)
                                        AuroraThemeType.GLASSMORPHISM -> Color(0xFFFF007F)
                                        AuroraThemeType.ACADEMIC -> Color(0xFF111111)
                                        AuroraThemeType.VIBRANT_RETRO -> Color(0xFFF15A59)
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(t.label, color = textCol, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(t.desc, color = textCol.copy(alpha = 0.6f), fontSize = 8.sp)
                        }
                    }
                }
            }

            Divider(color = Color(0xFF334155))

            Text("Decoupled Plugins Registry", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)

            // Dynamic plugins list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PluginRegistry.plugins.forEach { plugin ->
                    val isEnabled = plugin.isEnabled
                    val statusText = if (isEnabled) "ENABLED" else "DISABLED"
                    val statusColor = if (isEnabled) Color(0xFF10B981) else Color(0xFFF43F5E)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF1E293B))
                            .clickable { onTogglePlugin(plugin.pluginId) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(0.75f)) {
                            Text(plugin.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(plugin.description, color = Color(0xFF94A3B8), fontSize = 8.sp, lineHeight = 10.sp)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(statusColor.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(statusText, color = statusColor, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Divider(color: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(color)
    )
}

// ---------------------------------------------------------------------------
// 6. DASHBOARD ANALYTICS WIDGETS
// ---------------------------------------------------------------------------
@Composable
fun DashboardAnalyticsWidget(
    dataset: AuroraDataset,
    spec: AuroraChartSpec,
    viewModel: AuroraViewModel,
    interactionState: AuroraInteractionState,
    themeSpec: AuroraThemeSpec,
    modifier: Modifier = Modifier
) {
    var filterValueMin by remember(dataset.id) { mutableFloatStateOf(0f) }
    var filterValueMax by remember(dataset.id) { mutableFloatStateOf(100f) }

    // Read active metrics
    val yCol = spec.yColumns.firstOrNull() ?: "Close"
    val yVals = dataset.getNumericalValues(yCol)

    val rowCount = dataset.rows.size
    val mean = if (yVals.isNotEmpty()) yVals.average().toFloat() else 0f
    val maxVal = if (yVals.isNotEmpty()) yVals.maxOrNull() ?: 0f else 0f

    Card(
        colors = CardDefaults.cardColors(containerColor = themeSpec.colors.surfaceColor),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Dashboard Widgets & Analytics", color = themeSpec.colors.titleTextColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)

            // KPI Grid (3 cards)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Widget 1
                Card(
                    colors = CardDefaults.cardColors(containerColor = themeSpec.colors.backgroundColor),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text("ROWS LOADED", color = themeSpec.colors.labelTextColor.copy(alpha = 0.7f), fontSize = 8.sp)
                        Text("$rowCount", color = themeSpec.colors.titleTextColor, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                // Widget 2
                Card(
                    colors = CardDefaults.cardColors(containerColor = themeSpec.colors.backgroundColor),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text("MEAN METRIC", color = themeSpec.colors.labelTextColor.copy(alpha = 0.7f), fontSize = 8.sp)
                        Text("%.1f".format(mean), color = themeSpec.colors.titleTextColor, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                // Widget 3
                Card(
                    colors = CardDefaults.cardColors(containerColor = themeSpec.colors.backgroundColor),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text("PEAK VALUE", color = themeSpec.colors.labelTextColor.copy(alpha = 0.7f), fontSize = 8.sp)
                        Text("%.1f".format(maxVal), color = themeSpec.colors.titleTextColor, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }

            Divider(color = themeSpec.colors.gridLineColor)

            // Live Cross Filtering Controls
            Text(
                text = "Live Spreadsheet Dimension Filter",
                color = themeSpec.colors.titleTextColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Filters the active dataframe rows. Triggers simulated RPC subscription message back to Python backend.",
                color = themeSpec.colors.labelTextColor.copy(alpha = 0.8f),
                fontSize = 8.sp,
                lineHeight = 10.sp
            )

            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Min Cutoff: %.0f".format(filterValueMin), fontSize = 9.sp, color = themeSpec.colors.labelTextColor)
                    Text("Max Cutoff: %.0f".format(filterValueMax), fontSize = 9.sp, color = themeSpec.colors.labelTextColor)
                }
                Slider(
                    value = filterValueMin,
                    onValueChange = {
                        filterValueMin = it
                        viewModel.applyLiveFilter(filterValueMin, filterValueMax)
                    },
                    valueRange = 0f..50f,
                    colors = SliderDefaults.colors(
                        thumbColor = themeSpec.colors.accentColors[0],
                        activeTrackColor = themeSpec.colors.accentColors[0],
                        inactiveTrackColor = themeSpec.colors.gridLineColor
                    ),
                    modifier = Modifier.height(20.dp)
                )
                Slider(
                    value = filterValueMax,
                    onValueChange = {
                        filterValueMax = it
                        viewModel.applyLiveFilter(filterValueMin, filterValueMax)
                    },
                    valueRange = 50f..150f,
                    colors = SliderDefaults.colors(
                        thumbColor = themeSpec.colors.accentColors[0],
                        activeTrackColor = themeSpec.colors.accentColors[0],
                        inactiveTrackColor = themeSpec.colors.gridLineColor
                    ),
                    modifier = Modifier.height(20.dp)
                )
            }
        }
    }
}
