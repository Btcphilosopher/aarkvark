package com.example.aurora.themes

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

enum class AuroraThemeType(val label: String, val desc: String) {
    LIGHT_CORPORATE("Light Corporate", "Clean, blue primary, high clarity, standard business"),
    DARK_TERMINAL("Financial Terminal", "High-contrast neon colors on cyber black, intense data density"),
    GLASSMORPHISM("Neo-Glass", "Semi-transparent glowing widgets with radial background gradients"),
    ACADEMIC("Academic Monocle", "High-fidelity serif style, monochrome publication grade"),
    VIBRANT_RETRO("Warm Cyberpunk", "Vaporwave cyberpunk hues with bright orange and pink accents")
}

data class ThemeColors(
    val backgroundColor: Color,
    val surfaceColor: Color,
    val gridLineColor: Color,
    val axisColor: Color,
    val labelTextColor: Color,
    val titleTextColor: Color,
    val accentColors: List<Color>,
    val glassBorderColor: Color = Color.Transparent
)

data class ThemeTypography(
    val titleFont: FontFamily,
    val bodyFont: FontFamily,
    val labelFont: FontFamily
)

data class AuroraThemeSpec(
    val type: AuroraThemeType,
    val colors: ThemeColors,
    val typography: ThemeTypography,
    val gridStrokeWidth: Float = 1f,
    val useAntialiasing: Boolean = true,
    val showGlassEffects: Boolean = false
) {
    companion object {
        val LightCorporate = AuroraThemeSpec(
            type = AuroraThemeType.LIGHT_CORPORATE,
            colors = ThemeColors(
                backgroundColor = Color(0xFFF4F6F9),
                surfaceColor = Color(0xFFFFFFFF),
                gridLineColor = Color(0xFFE2E8F0),
                axisColor = Color(0xFF64748B),
                labelTextColor = Color(0xFF475569),
                titleTextColor = Color(0xFF1E293B),
                accentColors = listOf(
                    Color(0xFF0F52BA), // Sapphire
                    Color(0xFF00A86B), // Jade
                    Color(0xFFDFFF00), // Chartreuse
                    Color(0xFFFFBF00), // Amber
                    Color(0xFFDE3163)  // Cerise
                )
            ),
            typography = ThemeTypography(
                titleFont = FontFamily.SansSerif,
                bodyFont = FontFamily.SansSerif,
                labelFont = FontFamily.SansSerif
            )
        )

        val DarkTerminal = AuroraThemeSpec(
            type = AuroraThemeType.DARK_TERMINAL,
            colors = ThemeColors(
                backgroundColor = Color(0xFF090D16),
                surfaceColor = Color(0xFF111827),
                gridLineColor = Color(0xFF1F2937),
                axisColor = Color(0xFF4B5563),
                labelTextColor = Color(0xFF9CA3AF),
                titleTextColor = Color(0xFF10B981), // Emerald Title
                accentColors = listOf(
                    Color(0xFF10B981), // Neon Emerald
                    Color(0xFF06B6D4), // Neon Cyan
                    Color(0xFFFBBF24), // Neon Yellow
                    Color(0xFFEC4899), // Neon Pink
                    Color(0xFF8B5CF6)  // Neon Purple
                )
            ),
            typography = ThemeTypography(
                titleFont = FontFamily.Monospace,
                bodyFont = FontFamily.Monospace,
                labelFont = FontFamily.Monospace
            )
        )

        val Glassmorphism = AuroraThemeSpec(
            type = AuroraThemeType.GLASSMORPHISM,
            colors = ThemeColors(
                backgroundColor = Color(0xFF110B29),
                surfaceColor = Color(0x33FFFFFF), // Transparent glass overlay
                gridLineColor = Color(0x22FFFFFF),
                axisColor = Color(0x66FFFFFF),
                labelTextColor = Color(0xFFE0E0FF),
                titleTextColor = Color(0xFFFFFFFF),
                accentColors = listOf(
                    Color(0xFFFF007F), // Glowing Pink
                    Color(0xFF00F5FF), // Electric Cyan
                    Color(0xFF9D00FF), // Neon Purple
                    Color(0xFFCCFF00), // Electric Lime
                    Color(0xFFFF5E00)  // Hot Orange
                ),
                glassBorderColor = Color(0x44FFFFFF)
            ),
            typography = ThemeTypography(
                titleFont = FontFamily.SansSerif,
                bodyFont = FontFamily.SansSerif,
                labelFont = FontFamily.SansSerif
            ),
            showGlassEffects = true
        )

        val Academic = AuroraThemeSpec(
            type = AuroraThemeType.ACADEMIC,
            colors = ThemeColors(
                backgroundColor = Color(0xFFFFFFFF),
                surfaceColor = Color(0xFFFFFFFF),
                gridLineColor = Color(0xFFECECEC),
                axisColor = Color(0xFF000000),
                labelTextColor = Color(0xFF222222),
                titleTextColor = Color(0xFF000000),
                accentColors = listOf(
                    Color(0xFF111111), // Charcoal
                    Color(0xFF555555), // Slate
                    Color(0xFF888888), // Grey
                    Color(0xFFB0B0B0), // Silver
                    Color(0xFFDCDCDC)  // Off-white
                )
            ),
            typography = ThemeTypography(
                titleFont = FontFamily.Serif,
                bodyFont = FontFamily.Serif,
                labelFont = FontFamily.Serif
            )
        )

        val VibrantRetro = AuroraThemeSpec(
            type = AuroraThemeType.VIBRANT_RETRO,
            colors = ThemeColors(
                backgroundColor = Color(0xFFFFF4E0), // Warm Cream
                surfaceColor = Color(0xFFFFFDF9),
                gridLineColor = Color(0xFFE6DFD3),
                axisColor = Color(0xFF503C3C),
                labelTextColor = Color(0xFF503C3C),
                titleTextColor = Color(0xFFC75B7A), // Retro Rose
                accentColors = listOf(
                    Color(0xFFF15A59), // Terracotta
                    Color(0xFFF79F1F), // Sunset Orange
                    Color(0xFF128C7E), // Deep Teal
                    Color(0xFFD980FA), // Pastel Pink
                    Color(0xFFED4C67)  // Cerise Red
                )
            ),
            typography = ThemeTypography(
                titleFont = FontFamily.SansSerif,
                bodyFont = FontFamily.SansSerif,
                labelFont = FontFamily.Monospace
            )
        )

        fun getTheme(type: AuroraThemeType): AuroraThemeSpec {
            return when (type) {
                AuroraThemeType.LIGHT_CORPORATE -> LightCorporate
                AuroraThemeType.DARK_TERMINAL -> DarkTerminal
                AuroraThemeType.GLASSMORPHISM -> Glassmorphism
                AuroraThemeType.ACADEMIC -> Academic
                AuroraThemeType.VIBRANT_RETRO -> VibrantRetro
            }
        }
    }
}
