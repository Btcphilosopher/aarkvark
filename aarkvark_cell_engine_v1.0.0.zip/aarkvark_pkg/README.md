# Aarkvark Cell Engine

**Reactive cell computation engine for the Aarkvark spreadsheet system.**

A pure Python drop-in computation back-end. Zero runtime dependencies.
The grid UI, persistence, and I/O are handled by the host application —
this module owns *only* how cells evaluate and react to each other.

---

## Features

| Capability | Detail |
|---|---|
| **Formula evaluation** | Safe recursive AST walker — no `eval()` / `exec()` |
| **Cell references** | `A1`, `B12`, `AA3`, … — case-insensitive |
| **Ranges** | `A1:C5`, `B2:D4` — 1-D columns, rows, and 2-D rectangles |
| **Arithmetic** | `+ - * / **` with standard precedence, unary `-`, `%` |
| **Functions** | `SUM AVG MIN MAX COUNT ABS SQRT ROUND POWER IF` |
| **Reactive propagation** | Incremental Kahn topological recalculation |
| **Circular detection** | Raises `CircularDependencyError`; rolls back cleanly |
| **Per-cell errors** | `#DIV0! #REF! #PARSE! #VALUE! #ERROR!` — never crash the sheet |
| **Error propagation** | Errored cells propagate `#REF!` to dependents |
| **Persistence** | `dump_state()` / `load_state()` — JSON-serialisable |

---

## Quick Start

```python
from aarkvark_cell_engine import CellEngine

engine = CellEngine()

# Literals
engine.set_cell("A1", 10)
engine.set_cell("A2", 3.5)

# Formula
engine.set_cell("B1", "=A1 + A2")
print(engine.get_cell("B1"))   # 13.5

# Reactive update — B1 recomputes automatically
engine.set_cell("A1", 20)
print(engine.get_cell("B1"))   # 23.5

# Range functions
for i in range(1, 6):
    engine.set_cell(f"C{i}", i * 10)     # C1=10 … C5=50
engine.set_cell("C6", "=SUM(C1:C5)")
print(engine.get_cell("C6"))             # 150

# Errors are stored, not raised
engine.set_cell("D1", 0)
engine.set_cell("D2", "=10 / D1")
print(engine.get_cell("D2"))             # #DIV0!

# Fixing D1 automatically recovers D2
engine.set_cell("D1", 5)
print(engine.get_cell("D2"))             # 2.0
```

---

## Installation

```bash
pip install aarkvark-cell-engine
```

Or from source:

```bash
git clone <repo-url>
cd aarkvark_pkg
pip install -e ".[dev]"
```

---

## API Reference

### `CellEngine`

```python
engine = CellEngine()
```

#### `set_cell(address, value)`

| Argument | Type | Description |
|---|---|---|
| `address` | `str` | Cell address — case-insensitive (`"A1"`, `"b12"`, `"AA3"`) |
| `value` | `str \| int \| float \| None` | Literal, formula string starting with `=`, or `None` to clear |

Raises `CircularDependencyError` if the formula would create a cycle.
Raises `ValueError` if the address is malformed.

#### `get_cell(address) -> Any`

Returns the computed value, `CellError` on formula error, or `None` for empty cells.

#### `recalculate(address=None)`

Force recalculation.  Pass an address to target a single cell + dependents,
or `None` for a full topological recalculation of the entire sheet.

#### `clear_cell(address)`

Reset to empty; dependents see `0` for empty cells.

#### `get_cell_info(address) -> Cell | None`

Full `Cell` object including `.raw`, `.value`, `.error`, `.formula`,
`.dependencies`, `.dependents`.

#### `get_dependencies(address) -> set[str]`
#### `get_dependents(address) -> set[str]`

Direct dependency / dependent sets.

#### `dump_state() -> dict`  /  `load_state(data: dict)`

JSON-serialisable `{address: raw_value}` snapshots for persistence.

---

## Supported Formula Syntax

```
=A1 + B2            cell references
=A1 * 2 - 3         arithmetic
=2 ** 10            exponentiation (right-associative)
=-A1                unary negation
=25%                percent (≡ 25 / 100)
=SUM(A1:A10)        range function
=AVG(B1:C3)         2-D range
=SUM(A1, B1:B5, 3)  mixed scalar + range arguments
=IF(A1, B1, C1)     conditional
=(A1 + A2) * A3     grouping
```

### Built-in Functions

| Function | Signature | Description |
|---|---|---|
| `SUM` | `SUM(range_or_scalars…)` | Sum of all values |
| `AVG` / `MEAN` | `AVG(range…)` | Arithmetic mean |
| `MIN` | `MIN(range…)` | Minimum value |
| `MAX` | `MAX(range…)` | Maximum value |
| `COUNT` | `COUNT(range…)` | Number of values |
| `ABS` | `ABS(x)` | Absolute value |
| `SQRT` | `SQRT(x)` | Square root |
| `ROUND` | `ROUND(x[, places])` | Round to N decimal places |
| `POWER` | `POWER(base, exp)` | `base ** exp` |
| `IF` | `IF(cond, true[, false])` | Conditional value |

### Adding Custom Functions

```python
from aarkvark_cell_engine.evaluator import FUNCTIONS

FUNCTIONS["MEDIAN"] = lambda vs: sorted(vs)[len(vs) // 2]
FUNCTIONS["STDEV"]  = lambda vs: (
    sum((x - sum(vs)/len(vs))**2 for x in vs) / len(vs)
) ** 0.5
```

---

## Error Codes

| Code | Display | Cause |
|---|---|---|
| `DIV0` | `#DIV0!` | Division by zero |
| `REF` | `#REF!` | Dependency is in error |
| `PARSE` | `#PARSE!` | Formula syntax error |
| `VALUE` | `#VALUE!` | Type error in expression |
| `ERROR` | `#ERROR!` | Unknown function or other runtime error |
| `CIRC` | `#CIRC!` | Circular dependency (stored only; normally raises) |

---

## Package Layout

```
aarkvark_cell_engine/
    __init__.py     public API surface
    exceptions.py   CellError, CircularDependencyError
    address.py      col↔num encoding, parse_addr, expand_range
    tokeniser.py    formula lexer
    parser.py       recursive-descent parser → AST tuples
    evaluator.py    safe AST walker, FUNCTIONS registry
    cell.py         Cell dataclass
    engine.py       CellEngine (reactive engine)
tests/
    test_address.py
    test_parser.py
    test_engine.py
```

---

## Running Tests

```bash
pytest                    # all tests
pytest -v                 # verbose
pytest --cov              # with coverage report
```

---

## Licence

MIT — © Aureom.AI
