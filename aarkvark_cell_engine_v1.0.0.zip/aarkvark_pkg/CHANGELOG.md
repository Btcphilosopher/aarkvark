# Changelog

All notable changes to **aarkvark-cell-engine** are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [1.0.0] — 2026-06-23

### Added

**Core engine**
- `CellEngine.set_cell(address, value)` — assign literal or formula; reactive
- `CellEngine.get_cell(address)` — retrieve computed value or `CellError`
- `CellEngine.recalculate(address=None)` — force targeted or full recalculation
- `CellEngine.clear_cell(address)` — reset to empty with propagation
- `CellEngine.get_cell_info(address)` — full `Cell` object introspection
- `CellEngine.get_dependencies / get_dependents` — graph edge queries
- `CellEngine.all_cells()` — snapshot dict of all non-empty cells
- `CellEngine.dump_state() / load_state(data)` — JSON persistence round-trip

**Formula language**
- Arithmetic: `+ - * / **` with standard operator precedence
- Unary negation: `-expr`
- Percent operator: `42%` → `0.42`
- Right-associative exponentiation: `2**3**2` → `512`
- Parenthesised grouping
- Case-insensitive cell references: `A1`, `b12`, `AA3`
- Rectangular ranges in function calls: `A1:C5`

**Built-in functions**
- `SUM`, `AVG`/`MEAN`, `MIN`, `MAX`, `COUNT`
- `ABS`, `SQRT`, `ROUND`, `POWER`
- `IF(condition, true_val[, false_val])`

**Dependency management**
- Bidirectional dependency graph (dependencies + dependents per cell)
- Incremental Kahn topological propagation on every `set_cell`
- Circular dependency detection with full pre-raise rollback
- Indirect cycle detection (A→B→C→A)

**Error handling**
- Per-cell `CellError` with codes: `DIV0 REF PARSE VALUE ERROR CIRC`
- Error propagation: errored cells become `#REF!` in their dependents
- Automatic error recovery when root cause cell is corrected
- Parse errors stored on cell; rest of sheet unaffected

**Package**
- Zero runtime dependencies (Python stdlib only)
- `pyproject.toml`-based packaging (setuptools)
- Full pytest test suite: 3 test modules, 80+ assertions
- Extensible `FUNCTIONS` registry for custom spreadsheet functions
