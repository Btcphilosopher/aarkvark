"""Tests for aarkvark_cell_engine.parser — formula tokenisation and AST construction."""
import pytest
from aarkvark_cell_engine.parser import parse_formula, ParseError


class TestLiterals:
    def test_integer(self):
        assert parse_formula("42") == ("num", 42)

    def test_float(self):
        assert parse_formula("3.14") == ("num", 3.14)

    def test_scientific(self):
        node = parse_formula("1e3")
        assert node[0] == "num"
        assert abs(node[1] - 1000.0) < 1e-9

    def test_string_double_quotes(self):
        assert parse_formula('"hello"') == ("str", "hello")

    def test_string_single_quotes(self):
        assert parse_formula("'world'") == ("str", "world")

    def test_cell_reference(self):
        assert parse_formula("A1") == ("cell", "A1")

    def test_cell_reference_case_normalised(self):
        assert parse_formula("b12") == ("cell", "B12")


class TestArithmetic:
    def test_addition(self):
        node = parse_formula("1 + 2")
        assert node == ("binop", "+", ("num", 1), ("num", 2))

    def test_subtraction(self):
        node = parse_formula("5 - 3")
        assert node[1] == "-"

    def test_multiplication(self):
        node = parse_formula("4 * 3")
        assert node[1] == "*"

    def test_division(self):
        node = parse_formula("10 / 2")
        assert node[1] == "/"

    def test_power(self):
        node = parse_formula("2 ** 8")
        assert node[1] == "**"

    def test_unary_minus(self):
        node = parse_formula("-A1")
        assert node == ("unary", "-", ("cell", "A1"))

    def test_percent(self):
        # 50% desugars to 50 / 100
        node = parse_formula("50%")
        assert node == ("binop", "/", ("num", 50), ("num", 100))

    def test_operator_precedence_mul_over_add(self):
        # 2 + 3 * 4  →  binop(+, 2, binop(*, 3, 4))
        node = parse_formula("2 + 3 * 4")
        assert node[1] == "+"
        assert node[3][1] == "*"

    def test_parentheses_override_precedence(self):
        # (2 + 3) * 4
        node = parse_formula("(2 + 3) * 4")
        assert node[1] == "*"
        assert node[2][1] == "+"

    def test_power_right_associative(self):
        # 2 ** 3 ** 2  →  binop(**, 2, binop(**, 3, 2))
        node = parse_formula("2 ** 3 ** 2")
        assert node[1] == "**"
        assert node[3][1] == "**"


class TestFunctionCalls:
    def test_sum_range(self):
        node = parse_formula("SUM(A1:A5)")
        assert node == ("call", "SUM", [("range", "A1", "A5")])

    def test_sum_lowercase(self):
        node = parse_formula("sum(a1:a5)")
        assert node == ("call", "SUM", [("range", "A1", "A5")])

    def test_avg(self):
        node = parse_formula("AVG(B1:B3)")
        assert node[0] == "call"
        assert node[1] == "AVG"

    def test_if_function(self):
        node = parse_formula("IF(A1, 1, 0)")
        assert node[0] == "call"
        assert node[1] == "IF"
        assert len(node[2]) == 3

    def test_mixed_args(self):
        node = parse_formula("SUM(A1, B1:C1, 5)")
        assert node[0] == "call"
        assert len(node[2]) == 3

    def test_nested_functions(self):
        node = parse_formula("ABS(MIN(A1:A3))")
        assert node[0] == "call"
        assert node[1] == "ABS"
        inner = node[2][0]
        assert inner[0] == "call"
        assert inner[1] == "MIN"


class TestErrors:
    def test_unknown_character(self):
        with pytest.raises(ParseError):
            parse_formula("@@@")

    def test_unmatched_paren(self):
        with pytest.raises(ParseError):
            parse_formula("(1 + 2")

    def test_name_without_parens(self):
        with pytest.raises(ParseError):
            parse_formula("SUM")

    def test_empty_string(self):
        with pytest.raises((ParseError, ValueError)):
            parse_formula("")
