"""
Comprehensive integration tests for CellEngine.

Covers: literals, arithmetic, reactive propagation, deep chains, range
functions, 2-D ranges, built-ins, error handling, error propagation,
error recovery, circular dependency detection, clear_cell, recalculate,
dump/load round-trip, and case-insensitive addressing.
"""
import pytest
from aarkvark_cell_engine import CellEngine, CellError, CircularDependencyError


# ══════════════════════════════════════════════════════════════════════════════
#  Fixtures
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def e():
    return CellEngine()


# ══════════════════════════════════════════════════════════════════════════════
#  Literals
# ══════════════════════════════════════════════════════════════════════════════

class TestLiterals:
    def test_int(self, e):
        e.set_cell("A1", 10)
        assert e.get_cell("A1") == 10

    def test_float(self, e):
        e.set_cell("A1", 3.14)
        assert e.get_cell("A1") == 3.14

    def test_string(self, e):
        e.set_cell("A1", "hello")
        assert e.get_cell("A1") == "hello"

    def test_numeric_string_coerced_to_int(self, e):
        e.set_cell("A1", "99")
        assert e.get_cell("A1") == 99

    def test_numeric_string_coerced_to_float(self, e):
        e.set_cell("A1", "3.14")
        assert abs(e.get_cell("A1") - 3.14) < 1e-9

    def test_none_clears_cell(self, e):
        e.set_cell("A1", 5)
        e.set_cell("A1", None)
        assert e.get_cell("A1") is None

    def test_bool(self, e):
        e.set_cell("A1", True)
        assert e.get_cell("A1") is True

    def test_overwrite_literal(self, e):
        e.set_cell("A1", 1)
        e.set_cell("A1", 2)
        assert e.get_cell("A1") == 2


# ══════════════════════════════════════════════════════════════════════════════
#  Basic arithmetic formulas
# ══════════════════════════════════════════════════════════════════════════════

class TestArithmeticFormulas:
    def test_addition(self, e):
        e.set_cell("A1", 10)
        e.set_cell("A2", 3.14)
        e.set_cell("B1", "=A1 + A2")
        assert abs(e.get_cell("B1") - 13.14) < 1e-9

    def test_multiplication(self, e):
        e.set_cell("A1", 10)
        e.set_cell("B1", "=A1 * 3")
        assert e.get_cell("B1") == 30

    def test_division(self, e):
        e.set_cell("A1", 30)
        e.set_cell("B1", "=A1 / 2")
        assert e.get_cell("B1") == 15.0

    def test_power(self, e):
        e.set_cell("A1", "=2 ** 10")
        assert e.get_cell("A1") == 1024

    def test_unary_minus(self, e):
        e.set_cell("A1", 5)
        e.set_cell("A2", "=-A1")
        assert e.get_cell("A2") == -5

    def test_percent(self, e):
        e.set_cell("A1", "=50%")
        assert e.get_cell("A1") == 0.5

    def test_percent_in_expression(self, e):
        e.set_cell("A1", "=200 * 10%")
        assert e.get_cell("A1") == 20.0

    def test_parentheses(self, e):
        e.set_cell("A1", "=(2 + 3) * 4")
        assert e.get_cell("A1") == 20

    def test_empty_cell_is_zero(self, e):
        e.set_cell("B1", "=A1 + 5")   # A1 not set
        assert e.get_cell("B1") == 5


# ══════════════════════════════════════════════════════════════════════════════
#  Reactive propagation
# ══════════════════════════════════════════════════════════════════════════════

class TestReactivePropagation:
    def test_direct_dependency(self, e):
        e.set_cell("C1", 5)
        e.set_cell("C2", "=C1 * 2")
        assert e.get_cell("C2") == 10
        e.set_cell("C1", 20)
        assert e.get_cell("C2") == 40

    def test_two_hops(self, e):
        e.set_cell("C1", 5)
        e.set_cell("C2", "=C1 * 2")
        e.set_cell("C3", "=C2 + C1")
        assert e.get_cell("C3") == 15
        e.set_cell("C1", 10)
        assert e.get_cell("C3") == 30

    def test_diamond(self, e):
        # A1 → B1, A1 → C1, B1 + C1 → D1
        e.set_cell("A1", 3)
        e.set_cell("B1", "=A1 + 1")
        e.set_cell("C1", "=A1 + 2")
        e.set_cell("D1", "=B1 + C1")
        assert e.get_cell("D1") == 9    # 4 + 5
        e.set_cell("A1", 10)
        assert e.get_cell("D1") == 23   # 11 + 12

    def test_deep_chain(self, e):
        e.set_cell("D1", 1)
        for i in range(2, 8):
            e.set_cell(f"D{i}", f"=D{i-1} + 1")
        assert e.get_cell("D7") == 7
        e.set_cell("D1", 10)
        assert e.get_cell("D7") == 16

    def test_fan_out(self, e):
        e.set_cell("A1", 5)
        for i in range(1, 6):
            e.set_cell(f"B{i}", f"=A1 * {i}")
        e.set_cell("A1", 2)
        for i in range(1, 6):
            assert e.get_cell(f"B{i}") == 2 * i


# ══════════════════════════════════════════════════════════════════════════════
#  Range functions
# ══════════════════════════════════════════════════════════════════════════════

class TestRangeFunctions:
    def setup_column(self, e):
        for i in range(1, 6):
            e.set_cell(f"E{i}", i * 10)   # 10 20 30 40 50

    def test_sum(self, e):
        self.setup_column(e)
        e.set_cell("E6", "=SUM(E1:E5)")
        assert e.get_cell("E6") == 150

    def test_avg(self, e):
        self.setup_column(e)
        e.set_cell("E6", "=AVG(E1:E5)")
        assert e.get_cell("E6") == 30.0

    def test_min(self, e):
        self.setup_column(e)
        e.set_cell("E6", "=MIN(E1:E5)")
        assert e.get_cell("E6") == 10

    def test_max(self, e):
        self.setup_column(e)
        e.set_cell("E6", "=MAX(E1:E5)")
        assert e.get_cell("E6") == 50

    def test_count(self, e):
        self.setup_column(e)
        e.set_cell("E6", "=COUNT(E1:E5)")
        assert e.get_cell("E6") == 5

    def test_2d_range(self, e):
        e.set_cell("F1", 1); e.set_cell("G1", 2)
        e.set_cell("F2", 3); e.set_cell("G2", 4)
        e.set_cell("H1", "=SUM(F1:G2)")
        assert e.get_cell("H1") == 10

    def test_mixed_args(self, e):
        e.set_cell("I1", 100)
        e.set_cell("I2", 10)
        e.set_cell("I3", 20)
        e.set_cell("I4", "=SUM(I1, I2:I3)")
        assert e.get_cell("I4") == 130

    def test_sum_propagates_on_change(self, e):
        self.setup_column(e)
        e.set_cell("E6", "=SUM(E1:E5)")
        assert e.get_cell("E6") == 150
        e.set_cell("E1", 100)
        assert e.get_cell("E6") == 240


# ══════════════════════════════════════════════════════════════════════════════
#  Built-in functions
# ══════════════════════════════════════════════════════════════════════════════

class TestBuiltins:
    def test_sqrt(self, e):
        e.set_cell("A1", "=SQRT(9)")
        assert e.get_cell("A1") == 3.0

    def test_abs_negative(self, e):
        e.set_cell("A1", "=ABS(-42)")
        assert e.get_cell("A1") == 42

    def test_abs_positive(self, e):
        e.set_cell("A1", "=ABS(7)")
        assert e.get_cell("A1") == 7

    def test_round(self, e):
        e.set_cell("A1", "=ROUND(3.14159, 2)")
        assert e.get_cell("A1") == 3.14

    def test_round_no_places(self, e):
        e.set_cell("A1", "=ROUND(3.7)")
        assert e.get_cell("A1") == 4

    def test_power(self, e):
        e.set_cell("A1", "=POWER(2, 8)")
        assert e.get_cell("A1") == 256

    def test_if_true_branch(self, e):
        e.set_cell("A1", "=IF(1, 100, 200)")
        assert e.get_cell("A1") == 100

    def test_if_false_branch(self, e):
        e.set_cell("A1", "=IF(0, 100, 200)")
        assert e.get_cell("A1") == 200

    def test_if_missing_else(self, e):
        e.set_cell("A1", "=IF(0, 99)")
        assert e.get_cell("A1") == 0

    def test_mean_alias(self, e):
        e.set_cell("A1", 10); e.set_cell("A2", 20)
        e.set_cell("A3", "=MEAN(A1:A2)")
        assert e.get_cell("A3") == 15.0


# ══════════════════════════════════════════════════════════════════════════════
#  Error handling
# ══════════════════════════════════════════════════════════════════════════════

class TestErrors:
    def test_div_by_zero(self, e):
        e.set_cell("A1", 0)
        e.set_cell("A2", "=10 / A1")
        assert e.get_cell("A2") == CellError("DIV0")

    def test_parse_error(self, e):
        e.set_cell("A1", "=@@@")
        assert e.get_cell("A1") == CellError("PARSE")

    def test_unknown_function(self, e):
        e.set_cell("A1", "=UNICORN(1, 2)")
        assert e.get_cell("A1") == CellError("ERROR")

    def test_error_does_not_crash_others(self, e):
        e.set_cell("A1", 0)
        e.set_cell("A2", "=10 / A1")   # error
        e.set_cell("B1", "=5 + 3")     # unrelated
        assert e.get_cell("B1") == 8

    def test_error_propagates_to_dependents(self, e):
        e.set_cell("A1", 0)
        e.set_cell("A2", "=10 / A1")
        e.set_cell("A3", "=A2 + 1")
        assert e.get_cell("A3") == CellError("REF")

    def test_error_recovery(self, e):
        e.set_cell("A1", 0)
        e.set_cell("A2", "=10 / A1")
        assert e.get_cell("A2") == CellError("DIV0")
        e.set_cell("A1", 5)
        assert e.get_cell("A2") == 2.0

    def test_error_recovery_propagates(self, e):
        e.set_cell("A1", 0)
        e.set_cell("A2", "=10 / A1")
        e.set_cell("A3", "=A2 + 1")
        e.set_cell("A1", 5)
        assert e.get_cell("A3") == 3.0

    def test_cell_info_stores_error(self, e):
        e.set_cell("A1", "=@@@")
        info = e.get_cell_info("A1")
        assert info.error is not None
        assert info.error.code == "PARSE"


# ══════════════════════════════════════════════════════════════════════════════
#  Circular dependency
# ══════════════════════════════════════════════════════════════════════════════

class TestCircularDependency:
    def test_self_reference(self, e):
        with pytest.raises(CircularDependencyError):
            e.set_cell("A1", "=A1 + 1")

    def test_direct_two_cell_cycle(self, e):
        e.set_cell("A1", "=B1 + 1")
        with pytest.raises(CircularDependencyError):
            e.set_cell("B1", "=A1 + 1")

    def test_indirect_three_cell_cycle(self, e):
        e.set_cell("A1", "=B1 + 1")
        e.set_cell("B1", "=C1 + 1")
        with pytest.raises(CircularDependencyError):
            e.set_cell("C1", "=A1 + 1")

    def test_rollback_preserves_state(self, e):
        e.set_cell("A1", "=B1 + 1")
        e.set_cell("B1", 10)
        with pytest.raises(CircularDependencyError):
            e.set_cell("B1", "=A1 + 1")
        # B1 should be restored to 10
        assert e.get_cell("B1") == 10
        assert e.get_cell("A1") == 11

    def test_rollback_dependency_graph_clean(self, e):
        e.set_cell("A1", "=B1 + 1")
        e.set_cell("B1", 5)
        with pytest.raises(CircularDependencyError):
            e.set_cell("B1", "=A1 + 1")
        # After rollback, changing B1 to a fresh value should propagate fine
        e.set_cell("B1", 20)
        assert e.get_cell("A1") == 21


# ══════════════════════════════════════════════════════════════════════════════
#  clear_cell
# ══════════════════════════════════════════════════════════════════════════════

class TestClearCell:
    def test_clear_removes_value(self, e):
        e.set_cell("A1", 99)
        e.clear_cell("A1")
        assert e.get_cell("A1") is None

    def test_clear_propagates_as_zero(self, e):
        e.set_cell("A1", 100)
        e.set_cell("A2", "=A1 * 2")
        e.clear_cell("A1")
        assert e.get_cell("A2") == 0

    def test_clear_nonexistent_is_noop(self, e):
        e.clear_cell("Z99")   # should not raise

    def test_clear_removes_from_len(self, e):
        e.set_cell("A1", 1)
        assert len(e) == 1
        e.clear_cell("A1")
        assert len(e) == 0


# ══════════════════════════════════════════════════════════════════════════════
#  recalculate
# ══════════════════════════════════════════════════════════════════════════════

class TestRecalculate:
    def test_targeted(self, e):
        e.set_cell("A1", 5)
        e.set_cell("A2", "=A1 * 3")
        e.recalculate("A2")
        assert e.get_cell("A2") == 15

    def test_full_recalc(self, e):
        e.set_cell("A1", 4)
        e.set_cell("A2", "=A1 + 1")
        e.set_cell("A3", "=A2 + 1")
        e.recalculate()
        assert e.get_cell("A3") == 6

    def test_full_recalc_nonexistent_addr(self, e):
        e.recalculate("Z99")   # should not raise


# ══════════════════════════════════════════════════════════════════════════════
#  dump / load state
# ══════════════════════════════════════════════════════════════════════════════

class TestPersistence:
    def test_round_trip_literals(self, e):
        e.set_cell("A1", 42)
        e.set_cell("A2", "hello")
        snap = e.dump_state()
        e2 = CellEngine()
        e2.load_state(snap)
        assert e2.get_cell("A1") == 42
        assert e2.get_cell("A2") == "hello"

    def test_round_trip_formula(self, e):
        for i in range(1, 6):
            e.set_cell(f"E{i}", i * 10)
        e.set_cell("E6", "=SUM(E1:E5)")
        snap = e.dump_state()
        e2 = CellEngine()
        e2.load_state(snap)
        assert e2.get_cell("E6") == 150

    def test_dump_excludes_empty(self, e):
        e.set_cell("A1", 1)
        snap = e.dump_state()
        assert "B1" not in snap


# ══════════════════════════════════════════════════════════════════════════════
#  Address handling
# ══════════════════════════════════════════════════════════════════════════════

class TestAddressHandling:
    def test_case_insensitive_set(self, e):
        e.set_cell("a1", 77)
        assert e.get_cell("A1") == 77

    def test_case_insensitive_formula(self, e):
        e.set_cell("A1", 10)
        e.set_cell("b1", "=a1 * 2")
        assert e.get_cell("B1") == 20

    def test_invalid_address_raises(self, e):
        with pytest.raises(ValueError):
            e.set_cell("NotAnAddress", 5)

    def test_contains_operator(self, e):
        e.set_cell("A1", 1)
        assert "A1" in e
        assert "a1" in e
        assert "B2" not in e


# ══════════════════════════════════════════════════════════════════════════════
#  Graph introspection
# ══════════════════════════════════════════════════════════════════════════════

class TestGraphIntrospection:
    def test_get_dependencies(self, e):
        e.set_cell("A1", 1)
        e.set_cell("B1", "=A1 + 1")
        assert e.get_dependencies("B1") == {"A1"}

    def test_get_dependents(self, e):
        e.set_cell("A1", 1)
        e.set_cell("B1", "=A1 + 1")
        assert e.get_dependents("A1") == {"B1"}

    def test_all_cells(self, e):
        e.set_cell("A1", 5)
        e.set_cell("A2", "=A1 * 2")
        snapshot = e.all_cells()
        assert snapshot["A1"] == 5
        assert snapshot["A2"] == 10

    def test_len(self, e):
        assert len(e) == 0
        e.set_cell("A1", 1)
        e.set_cell("A2", 2)
        assert len(e) == 2
