"""Tests for aarkvark_cell_engine.address — column encoding and range expansion."""
import pytest
from aarkvark_cell_engine.address import (
    col_to_num, num_to_col, parse_addr, make_addr, expand_range, normalise
)


class TestColumnEncoding:
    def test_single_letters(self):
        assert col_to_num("A") == 1
        assert col_to_num("Z") == 26

    def test_double_letters(self):
        assert col_to_num("AA") == 27
        assert col_to_num("AZ") == 52
        assert col_to_num("BA") == 53

    def test_case_insensitive(self):
        assert col_to_num("a") == col_to_num("A")
        assert col_to_num("aa") == col_to_num("AA")

    def test_roundtrip(self):
        for n in [1, 26, 27, 52, 53, 702, 703]:
            assert col_to_num(num_to_col(n)) == n


class TestParseAddr:
    def test_simple(self):
        assert parse_addr("A1") == (1, 1)
        assert parse_addr("B3") == (2, 3)

    def test_large_col(self):
        assert parse_addr("AA3") == (27, 3)

    def test_case_insensitive(self):
        assert parse_addr("a1") == parse_addr("A1")

    def test_invalid_no_digits(self):
        with pytest.raises(ValueError):
            parse_addr("ABC")

    def test_invalid_no_letters(self):
        with pytest.raises(ValueError):
            parse_addr("123")

    def test_invalid_zero_row(self):
        with pytest.raises(ValueError):
            parse_addr("A0")


class TestMakeAddr:
    def test_simple(self):
        assert make_addr(1, 1) == "A1"
        assert make_addr(2, 3) == "B3"
        assert make_addr(27, 3) == "AA3"

    def test_roundtrip(self):
        for col in [1, 5, 26, 27, 52, 100]:
            for row in [1, 10, 100]:
                c, r = parse_addr(make_addr(col, row))
                assert (c, r) == (col, row)


class TestExpandRange:
    def test_single_column(self):
        result = expand_range("A1", "A3")
        assert result == ["A1", "A2", "A3"]

    def test_single_row(self):
        result = expand_range("A1", "C1")
        assert result == ["A1", "B1", "C1"]

    def test_rectangular(self):
        result = expand_range("A1", "C2")
        assert result == ["A1", "B1", "C1", "A2", "B2", "C2"]

    def test_reversed_corners(self):
        assert set(expand_range("A1", "C2")) == set(expand_range("C2", "A1"))

    def test_single_cell(self):
        assert expand_range("B2", "B2") == ["B2"]


class TestNormalise:
    def test_uppercase(self):
        assert normalise("a1") == "A1"

    def test_strips_whitespace(self):
        assert normalise("  B3  ") == "B3"

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            normalise("NotAnAddr")
