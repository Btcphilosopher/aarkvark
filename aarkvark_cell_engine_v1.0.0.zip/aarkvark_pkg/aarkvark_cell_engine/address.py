"""
aarkvark_cell_engine.address
=============================
Cell-address encoding / decoding and rectangular range expansion.

Column encoding follows the standard spreadsheet convention:
    A=1, B=2, …, Z=26, AA=27, AB=28, …, ZZ=702, AAA=703, …
"""

from __future__ import annotations

import re
from typing import List, Tuple

_ADDR_RE = re.compile(r"^([A-Z]+)(\d+)$")


# ── column ↔ number ──────────────────────────────────────────────────────────

def col_to_num(col: str) -> int:
    """
    Convert a column letter string to its 1-based column index.

    >>> col_to_num("A")
    1
    >>> col_to_num("Z")
    26
    >>> col_to_num("AA")
    27
    """
    n = 0
    for ch in col.upper():
        n = n * 26 + (ord(ch) - ord("A") + 1)
    return n


def num_to_col(n: int) -> str:
    """
    Convert a 1-based column index to its letter string.

    >>> num_to_col(1)
    'A'
    >>> num_to_col(27)
    'AA'
    """
    if n < 1:
        raise ValueError(f"Column index must be ≥ 1, got {n}")
    s = ""
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(r + ord("A")) + s
    return s


# ── address parse / format ───────────────────────────────────────────────────

def parse_addr(addr: str) -> Tuple[int, int]:
    """
    Decode a spreadsheet address to a (col, row) pair, both 1-indexed.

    >>> parse_addr("A1")
    (1, 1)
    >>> parse_addr("b12")
    (2, 12)
    >>> parse_addr("AA3")
    (27, 3)

    Raises
    ------
    ValueError
        If *addr* is syntactically malformed or has a zero/negative row.
    """
    m = _ADDR_RE.match(addr.strip().upper())
    if not m:
        raise ValueError(f"Invalid cell address: {addr!r}")
    row = int(m.group(2))
    if row < 1:
        raise ValueError(f"Row must be ≥ 1 in address: {addr!r}")
    return col_to_num(m.group(1)), row


def make_addr(col: int, row: int) -> str:
    """
    Encode a (col, row) pair as a normalised uppercase address string.

    >>> make_addr(1, 1)
    'A1'
    >>> make_addr(27, 3)
    'AA3'
    """
    return num_to_col(col) + str(row)


def normalise(addr: str) -> str:
    """
    Strip whitespace, uppercase, and validate a cell address.

    Returns the normalised string.  Raises :class:`ValueError` if the
    address is malformed (delegates to :func:`parse_addr`).
    """
    a = addr.strip().upper()
    parse_addr(a)
    return a


# ── range expansion ──────────────────────────────────────────────────────────

def expand_range(start: str, end: str) -> List[str]:
    """
    Expand a rectangular range into an ordered list of cell addresses.

    Addresses are returned in row-major order (left→right, top→bottom).
    The range corners are normalised so ``start > end`` in either axis is
    silently accepted.

    >>> expand_range("A1", "C2")
    ['A1', 'B1', 'C1', 'A2', 'B2', 'C2']
    >>> expand_range("B2", "A1")   # reversed corners still work
    ['A1', 'B1', 'A2', 'B2']
    """
    sc, sr = parse_addr(start)
    ec, er = parse_addr(end)
    c0, c1 = min(sc, ec), max(sc, ec)
    r0, r1 = min(sr, er), max(sr, er)
    return [
        make_addr(c, r)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
    ]
