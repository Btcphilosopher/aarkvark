"""
aarkvark_cell_engine.engine
============================
:class:`CellEngine` — the main public class of the Aarkvark cell engine.

Responsibility
--------------
* Accept literal values and formula strings via :meth:`set_cell`.
* Parse formulas, resolve cell references, and evaluate safely (no
  ``eval`` / ``exec`` on user input).
* Maintain a bidirectional dependency graph.
* Incrementally re-evaluate only the transitive dependents of a changed
  cell, in topological order.
* Detect and refuse circular dependencies, rolling back cleanly.
* Store per-cell errors without crashing unrelated cells.

Thread-safety
-------------
:class:`CellEngine` is **not** thread-safe.  Wrap access with a lock
(e.g. ``threading.RLock``) for concurrent use.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Set

from .address import normalise
from .cell import Cell
from .evaluator import collect_deps, evaluate
from .exceptions import CellError, CircularDependencyError
from .parser import ParseError, parse_formula


class CellEngine:
    """
    Reactive cell computation engine for Aarkvark.

    Quick-start
    -----------
    >>> engine = CellEngine()
    >>> engine.set_cell("A1", 10)
    >>> engine.set_cell("A2", "=A1 * 2")
    >>> engine.get_cell("A2")
    20
    >>> engine.set_cell("A1", 5)   # change propagates automatically
    >>> engine.get_cell("A2")
    10

    Public interface
    ----------------
    :meth:`set_cell`         — assign a value or formula
    :meth:`get_cell`         — retrieve computed value (or CellError)
    :meth:`recalculate`      — force full or targeted recalculation
    :meth:`clear_cell`       — reset a cell to empty
    :meth:`get_cell_info`    — inspect full Cell state
    :meth:`get_dependencies` — direct deps of a cell
    :meth:`get_dependents`   — direct dependents of a cell
    :meth:`all_cells`        — snapshot of all non-empty cells
    :meth:`dump_state`       — serialisable {address: raw} dict
    :meth:`load_state`       — bulk-restore from dump_state output
    """

    def __init__(self) -> None:
        self._cells: Dict[str, Cell] = {}

    # ══════════════════════════════════════════════════════════════════════════
    #  Public API
    # ══════════════════════════════════════════════════════════════════════════

    def set_cell(self, address: str, value: Any) -> None:
        """
        Set a cell to a literal value or a formula string.

        Parameters
        ----------
        address : str
            Case-insensitive cell address (``'A1'``, ``'b12'``, ``'AA3'``, …).
        value : str | int | float | None
            * ``int`` / ``float``        → stored as a numeric literal.
            * ``str`` starting with ``=``→ parsed and evaluated as formula.
            * Any other ``str``          → string literal; auto-coerced to
                                           number when the string looks numeric.
            * ``None``                   → equivalent to :meth:`clear_cell`.

        Raises
        ------
        CircularDependencyError
            If the new formula would introduce a cycle.  The cell's previous
            state is fully restored before the exception propagates.
        ValueError
            If *address* is syntactically malformed.
        """
        if value is None:
            self.clear_cell(address)
            return

        addr = normalise(address)
        cell = self._ensure(addr)

        # Snapshot for rollback on CircularDependencyError.
        _snap = (
            cell.raw, cell.value, cell.error,
            cell.formula, cell._ast, cell.dependencies.copy(),
        )

        # Detach from old dependency graph before re-wiring.
        self._detach(addr, cell.dependencies)

        # Parse and store the new value.
        if isinstance(value, str) and value.lstrip().startswith("="):
            self._apply_formula(cell, value)
        else:
            self._apply_literal(cell, value)

        # Wire up new dependencies.
        for dep in cell.dependencies:
            self._ensure(dep).dependents.add(addr)

        # Cycle check — roll back cleanly on failure.
        if cell.has_formula and not cell.error:
            try:
                self._assert_acyclic(addr)
            except CircularDependencyError:
                self._detach(addr, cell.dependencies)
                (
                    cell.raw, cell.value, cell.error,
                    cell.formula, cell._ast, cell.dependencies,
                ) = _snap
                for dep in cell.dependencies:
                    self._ensure(dep).dependents.add(addr)
                raise

        # Evaluate the cell itself then propagate to dependents.
        if cell.has_formula and not cell.error:
            self._eval(cell)

        self._propagate(addr)

    def get_cell(self, address: str) -> Any:
        """
        Return the current value of a cell.

        Returns
        -------
        CellError   — cell is in an error state (e.g. ``#DIV0!``).
        None        — cell is empty or has never been set.
        int | float | str | bool — computed or literal value.
        """
        cell = self._cells.get(normalise(address))
        if cell is None:
            return None
        return cell.error if cell.error else cell.value

    def recalculate(self, address: Optional[str] = None) -> None:
        """
        Force recalculation.

        Parameters
        ----------
        address : str | None
            * ``str``  → recalculate that cell and propagate to all
                         transitive dependents.
            * ``None`` → recalculate every formula cell in topological order
                         (useful after :meth:`load_state`).
        """
        if address is not None:
            addr = normalise(address)
            cell = self._cells.get(addr)
            if cell and cell.has_formula:
                self._eval(cell)
            self._propagate(addr)
        else:
            for addr in self._topo_all():
                c = self._cells.get(addr)
                if c and c.has_formula:
                    self._eval(c)

    def clear_cell(self, address: str) -> None:
        """
        Reset a cell to the empty state and propagate the change.

        Existing dependents are preserved in the graph; they will be
        recalculated and will see ``0`` (the value for empty cells).
        """
        addr = normalise(address)
        cell = self._cells.get(addr)
        if cell is None:
            return
        self._detach(addr, cell.dependencies)
        cell.raw          = None
        cell.value        = None
        cell.error        = None
        cell.formula      = None
        cell._ast         = None
        cell.dependencies = set()
        self._propagate(addr)

    def get_cell_info(self, address: str) -> Optional[Cell]:
        """Return the full :class:`Cell` object, or ``None`` if unknown."""
        return self._cells.get(normalise(address))

    def get_dependencies(self, address: str) -> Set[str]:
        """Return addresses of cells that *this* cell directly reads."""
        c = self._cells.get(normalise(address))
        return c.dependencies.copy() if c else set()

    def get_dependents(self, address: str) -> Set[str]:
        """Return addresses of cells that directly read *this* cell."""
        c = self._cells.get(normalise(address))
        return c.dependents.copy() if c else set()

    def all_cells(self) -> Dict[str, Any]:
        """
        Snapshot of ``{address: value_or_error}`` for all non-empty cells.
        """
        return {
            addr: (c.error if c.error else c.value)
            for addr, c in self._cells.items()
            if c.raw is not None
        }

    def load_state(self, data: Dict[str, Any]) -> None:
        """
        Bulk-restore cells from a ``{address: raw_value}`` mapping.

        Equivalent to calling :meth:`set_cell` for each entry.  After
        loading, call :meth:`recalculate` (no argument) to force a full
        topological pass if insertion order could have produced stale values.
        """
        for addr, val in data.items():
            self.set_cell(addr, val)

    def dump_state(self) -> Dict[str, Any]:
        """
        Return a JSON-serialisable snapshot: ``{address: raw_input}``.

        Restore with :meth:`load_state`.
        """
        return {
            addr: c.raw
            for addr, c in self._cells.items()
            if c.raw is not None
        }

    # ══════════════════════════════════════════════════════════════════════════
    #  Internals — setup helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _ensure(self, address: str) -> Cell:
        if address not in self._cells:
            self._cells[address] = Cell(address=address)
        return self._cells[address]

    def _detach(self, address: str, deps: Set[str]) -> None:
        """Remove *address* from the dependents set of every cell in *deps*."""
        for dep in deps:
            c = self._cells.get(dep)
            if c:
                c.dependents.discard(address)

    # ══════════════════════════════════════════════════════════════════════════
    #  Internals — value application
    # ══════════════════════════════════════════════════════════════════════════

    @staticmethod
    def _apply_literal(cell: Cell, value: Any) -> None:
        cell.formula      = None
        cell._ast         = None
        cell.dependencies = set()
        cell.error        = None
        cell.raw          = value

        if isinstance(value, bool):
            cell.value = value
            return
        if isinstance(value, (int, float)):
            cell.value = value
            return

        s = str(value)
        cell.raw = s
        for conv in (int, float):
            try:
                cell.value = conv(s)
                return
            except (ValueError, TypeError):
                pass
        cell.value = s

    @staticmethod
    def _apply_formula(cell: Cell, raw: str) -> None:
        formula_str  = raw.lstrip()[1:]   # strip leading whitespace + '='
        cell.raw     = raw
        cell.formula = formula_str
        cell.error   = None

        try:
            ast_node          = parse_formula(formula_str)
            cell._ast         = ast_node
            cell.dependencies = collect_deps(ast_node)
        except (ParseError, ValueError) as exc:
            cell._ast         = None
            cell.dependencies = set()
            cell.error        = CellError("PARSE", str(exc))
            cell.value        = None

    # ══════════════════════════════════════════════════════════════════════════
    #  Internals — evaluation
    # ══════════════════════════════════════════════════════════════════════════

    def _eval(self, cell: Cell) -> None:
        if cell._ast is None:
            return

        def _resolver(addr: str) -> Any:
            c = self._cells.get(addr)
            if c is None:
                return 0
            if c.error:
                raise CellError("REF", f"{addr} is {c.error}")
            return c.value if c.value is not None else 0

        try:
            cell.value = evaluate(cell._ast, _resolver)
            cell.error = None
        except ZeroDivisionError:
            cell.value = None
            cell.error = CellError("DIV0", "Division by zero")
        except CellError as ce:
            cell.value = None
            cell.error = ce
        except TypeError as te:
            cell.value = None
            cell.error = CellError("VALUE", str(te))
        except Exception as exc:
            cell.value = None
            cell.error = CellError("ERROR", str(exc))

    # ══════════════════════════════════════════════════════════════════════════
    #  Internals — cycle detection
    # ══════════════════════════════════════════════════════════════════════════

    def _assert_acyclic(self, address: str) -> None:
        """
        DFS from *address*'s dependencies.  Raises
        :class:`~exceptions.CircularDependencyError` if any path loops back
        to *address*.
        """
        cell = self._cells.get(address)
        if not cell:
            return

        visited: Set[str] = set()

        def _dfs(current: str) -> None:
            if current == address:
                raise CircularDependencyError(
                    f"Circular dependency detected at {address}"
                )
            if current in visited:
                return
            visited.add(current)
            c = self._cells.get(current)
            if c:
                for dep in c.dependencies:
                    _dfs(dep)

        for dep in cell.dependencies:
            _dfs(dep)

    # ══════════════════════════════════════════════════════════════════════════
    #  Internals — incremental propagation (Kahn's algorithm)
    # ══════════════════════════════════════════════════════════════════════════

    def _propagate(self, changed: str) -> None:
        """
        Incrementally recalculate all cells that transitively depend on
        *changed*, in correct dependency-first topological order.

        Steps
        -----
        1. BFS over the *dependents* graph to find all affected cells.
        2. Kahn's topological sort over the affected sub-graph.
        3. Re-evaluate each affected formula cell in that order.
        """
        # 1. collect
        affected: Set[str] = set()
        frontier = [changed]
        while frontier:
            addr = frontier.pop()
            c = self._cells.get(addr)
            if c:
                for dep in c.dependents:
                    if dep not in affected:
                        affected.add(dep)
                        frontier.append(dep)

        if not affected:
            return

        # 2. topological sort of affected subgraph
        in_waiting: Dict[str, Set[str]] = {
            a: (self._cells[a].dependencies & affected)
            for a in affected
            if a in self._cells
        }
        ready  = [a for a in affected if not in_waiting.get(a)]
        order: List[str] = []

        while ready:
            a = ready.pop(0)
            order.append(a)
            c = self._cells.get(a)
            if c:
                for dep in c.dependents:
                    if dep in in_waiting:
                        in_waiting[dep].discard(a)
                        if not in_waiting[dep]:
                            ready.append(dep)

        # 3. re-evaluate
        for addr in order:
            c = self._cells.get(addr)
            if c and c.has_formula:
                self._eval(c)

    # ══════════════════════════════════════════════════════════════════════════
    #  Internals — full topological sort
    # ══════════════════════════════════════════════════════════════════════════

    def _topo_all(self) -> List[str]:
        """All cell addresses in dependency-first order (for full recalc)."""
        known     = set(self._cells)
        in_dep: Dict[str, Set[str]] = {
            a: (c.dependencies & known)
            for a, c in self._cells.items()
        }
        ready  = [a for a, deps in in_dep.items() if not deps]
        order: List[str] = []

        while ready:
            a = ready.pop(0)
            order.append(a)
            c = self._cells.get(a)
            if c:
                for dep in c.dependents:
                    if dep in in_dep:
                        in_dep[dep].discard(a)
                        if not in_dep[dep]:
                            ready.append(dep)

        return order

    # ── dunder helpers ────────────────────────────────────────────────────────

    def __len__(self) -> int:
        return sum(1 for c in self._cells.values() if c.raw is not None)

    def __contains__(self, address: object) -> bool:
        if not isinstance(address, str):
            return False
        try:
            return normalise(address) in self._cells
        except ValueError:
            return False

    def __repr__(self) -> str:
        n = len(self)
        return f"CellEngine({n} cell{'s' if n != 1 else ''})"
