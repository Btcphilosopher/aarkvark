"""
aarkvark_cell_engine
====================
Reactive cell computation engine for the Aarkvark spreadsheet system.

Typical usage
-------------
>>> from aarkvark_cell_engine import CellEngine
>>> engine = CellEngine()
>>> engine.set_cell("A1", 10)
>>> engine.set_cell("A2", "=A1 * 2")
>>> engine.get_cell("A2")
20
>>> engine.set_cell("A1", 5)   # propagates automatically
>>> engine.get_cell("A2")
10

Public surface
--------------
:class:`CellEngine`              — main reactive engine
:class:`Cell`                    — per-cell data container
:class:`CellError`               — formula evaluation error sentinel
:class:`CircularDependencyError` — raised on cyclic formulas

Extending the function library
-------------------------------
Add custom spreadsheet functions before instantiating a CellEngine::

    from aarkvark_cell_engine.evaluator import FUNCTIONS
    FUNCTIONS["MEDIAN"] = lambda vs: sorted(vs)[len(vs) // 2]
"""

from .cell       import Cell
from .engine     import CellEngine
from .exceptions import CellError, CircularDependencyError

__all__ = [
    "CellEngine",
    "Cell",
    "CellError",
    "CircularDependencyError",
]

__version__ = "1.0.0"
__author__  = "Aureom.AI"
