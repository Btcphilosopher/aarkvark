"""
aarkvark_cell_engine.parser
============================
Recursive-descent parser for Aarkvark formula expressions.

Converts a token stream (produced by :mod:`tokeniser`) into a lightweight
AST represented as plain tuples.  No third-party dependencies.

AST node shapes
---------------
``('num',   value)``               — numeric literal (int or float)
``('str',   value)``               — string literal (quotes stripped)
``('cell',  address)``             — single cell reference, e.g. ``'A1'``
``('range', start_addr, end_addr)``— rectangular range (inside calls only)
``('binop', op,  lhs,  rhs)``      — binary operator
``('unary', op,  operand)``        — unary ``+`` / ``-``
``('call',  name, [arg_nodes])``   — function call

Grammar (EBNF)
--------------
::

    expr       = add_expr
    add_expr   = mul_expr  { ('+' | '-')  mul_expr  }
    mul_expr   = pow_expr  { ('*' | '/')  pow_expr  }
    pow_expr   = unary     { '**'          unary     }    ← right-assoc
    unary      = ('-' | '+') unary  |  pct_expr
    pct_expr   = primary  [ '%' ]
    primary    = NUMBER
               | STRING
               | CELL
               | NAME '(' arg_list ')'
               | '(' expr ')'
    arg_list   = [ func_arg  { ','  func_arg } ]
    func_arg   = CELL ':' CELL           (range literal)
               | expr                    (general expression)
"""

from __future__ import annotations

from typing import Any, List, Optional, Tuple

from .tokeniser import Token, _TT, tokenise

# Public type alias for AST nodes
ASTNode = tuple


class ParseError(ValueError):
    """Raised for syntactically invalid formulas."""


class _Parser:
    """Internal recursive-descent parser.  Use :func:`parse_formula`."""

    def __init__(self, tokens: List[Token]) -> None:
        self._tok = tokens
        self._pos = 0

    # ── low-level helpers ─────────────────────────────────────────────────────

    def _peek(self) -> Token:
        return self._tok[self._pos]

    def _eat(self, expected: Optional[_TT] = None) -> Token:
        tok = self._tok[self._pos]
        if expected is not None and tok[0] != expected:
            raise ParseError(
                f"Expected {expected.name}, got {tok[0].name} ({tok[1]!r})"
            )
        self._pos += 1
        return tok

    # ── public entry ──────────────────────────────────────────────────────────

    def parse(self) -> ASTNode:
        """Parse the full token stream and return the root AST node."""
        node = self._add()
        if self._peek()[0] != _TT.EOF:
            t = self._peek()
            raise ParseError(
                f"Unexpected token {t[1]!r} ({t[0].name}) after expression"
            )
        return node

    # ── grammar rules ─────────────────────────────────────────────────────────

    def _add(self) -> ASTNode:
        node = self._mul()
        while self._peek()[0] in (_TT.PLUS, _TT.MINUS):
            op = self._eat()[1]
            node = ("binop", op, node, self._mul())
        return node

    def _mul(self) -> ASTNode:
        node = self._pow()
        while self._peek()[0] in (_TT.STAR, _TT.SLASH):
            op = self._eat()[1]
            node = ("binop", op, node, self._pow())
        return node

    def _pow(self) -> ASTNode:
        """Right-associative: ``2**3**2`` == ``2**(3**2)`` == 512."""
        base = self._unary()
        if self._peek()[0] == _TT.POWER:
            self._eat()
            return ("binop", "**", base, self._pow())
        return base

    def _unary(self) -> ASTNode:
        if self._peek()[0] == _TT.MINUS:
            self._eat()
            return ("unary", "-", self._unary())
        if self._peek()[0] == _TT.PLUS:
            self._eat()
            return self._unary()
        return self._pct()

    def _pct(self) -> ASTNode:
        """``42%`` desugars to ``42 / 100``."""
        node = self._primary()
        if self._peek()[0] == _TT.PERCENT:
            self._eat()
            node = ("binop", "/", node, ("num", 100))
        return node

    def _primary(self) -> ASTNode:
        tt, val = self._peek()

        if tt == _TT.NUMBER:
            self._eat()
            v: Any = (
                float(val) if ("." in val or "e" in val.lower()) else int(val)
            )
            return ("num", v)

        if tt == _TT.STRING:
            self._eat()
            return ("str", val[1:-1])   # strip surrounding quotes

        if tt == _TT.CELL:
            self._eat()
            return ("cell", val)        # already uppercased by tokeniser

        if tt == _TT.NAME:
            name = self._eat()[1]
            if self._peek()[0] == _TT.LPAREN:
                return self._func_call(name)
            raise ParseError(
                f"Unknown name {name!r} — did you forget parentheses?"
            )

        if tt == _TT.LPAREN:
            self._eat()
            node = self._add()
            self._eat(_TT.RPAREN)
            return node

        raise ParseError(f"Unexpected token {val!r} ({tt.name})")

    # ── function calls ────────────────────────────────────────────────────────

    def _func_call(self, name: str) -> ASTNode:
        self._eat(_TT.LPAREN)
        args: List[ASTNode] = []
        if self._peek()[0] != _TT.RPAREN:
            args.append(self._func_arg())
            while self._peek()[0] == _TT.COMMA:
                self._eat()
                args.append(self._func_arg())
        self._eat(_TT.RPAREN)
        return ("call", name, args)

    def _func_arg(self) -> ASTNode:
        """
        A function argument may be a ``CELL:CELL`` range literal or any
        expression.  Peeks ahead one token to decide; if not a range,
        backtracks and parses normally.
        """
        if self._peek()[0] == _TT.CELL:
            saved = self._pos
            start = self._eat()[1]
            if self._peek()[0] == _TT.COLON:
                self._eat()
                end = self._eat(_TT.CELL)[1]
                return ("range", start, end)
            self._pos = saved   # backtrack
        return self._add()


# ── public function ───────────────────────────────────────────────────────────

def parse_formula(formula: str) -> ASTNode:
    """
    Parse *formula* (with the leading ``=`` already stripped) into an AST.

    Parameters
    ----------
    formula : str
        The formula body, e.g. ``"A1 * 2"`` or ``"SUM(A1:A10)"``.

    Returns
    -------
    ASTNode
        Root tuple of the abstract syntax tree.

    Raises
    ------
    ParseError
        On any tokenisation or grammar error.
    """
    try:
        tokens = tokenise(formula)
        return _Parser(tokens).parse()
    except (ValueError, ParseError) as exc:
        raise ParseError(str(exc)) from exc
