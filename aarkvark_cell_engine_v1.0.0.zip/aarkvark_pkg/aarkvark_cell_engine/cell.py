"""
aarkvark_cell_engine.cell
==========================
Per-cell data container.

:class:`Cell` is the unit of state managed by :class:`~aarkvark_cell_engine.CellEngine`.
It holds both the raw input (literal or formula string), the last computed
value, error state, and the two halves of the bidirectional dependency graph.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional, Set

from .exceptions import CellError
from .parser import ASTNode


@dataclass
class Cell:
    """
    Internal representation of one spreadsheet cell.

    Attributes
    ----------
    address : str
        Normalised (uppercased) cell address, e.g. ``'A1'``.
    raw : Any
        The original value passed to :meth:`~aarkvark_cell_engine.CellEngine.set_cell`.
        ``None`` means the cell is empty.
    value : Any
        Last successfully computed or assigned value.
    error : CellError | None
        Set when evaluation fails; ``None`` when the cell is healthy.
    formula : str | None
        Formula body (the ``=`` prefix stripped), or ``None`` for literals.
    dependencies : set[str]
        Addresses of cells that *this* cell reads from.
    dependents : set[str]
        Addresses of cells that read from *this* cell.

    Notes
    -----
    ``_ast`` is an internal field holding the parsed AST for formula cells.
    It is intentionally excluded from ``__repr__`` and equality checks.
    """

    address:      str
    raw:          Any                 = None
    value:        Any                 = None
    error:        Optional[CellError] = None
    formula:      Optional[str]       = None
    _ast:         Optional[ASTNode]   = field(default=None, repr=False, compare=False)
    dependencies: Set[str]            = field(default_factory=set)
    dependents:   Set[str]            = field(default_factory=set)

    @property
    def has_formula(self) -> bool:
        """``True`` if this cell contains a formula (not a bare literal)."""
        return self.formula is not None

    @property
    def is_empty(self) -> bool:
        """``True`` if the cell has never been given a value."""
        return self.raw is None

    @property
    def display_value(self) -> Any:
        """
        Value suitable for display in a UI.

        Returns the error string (e.g. ``'#DIV0!'``) if the cell is in error,
        otherwise the computed/literal value.
        """
        return str(self.error) if self.error else self.value

    def __repr__(self) -> str:
        if self.is_empty:
            return f"Cell({self.address}, <empty>)"
        if self.error:
            return f"Cell({self.address}, {self.error})"
        if self.has_formula:
            return f"Cell({self.address}, ={self.formula!r} → {self.value!r})"
        return f"Cell({self.address}, {self.value!r})"
