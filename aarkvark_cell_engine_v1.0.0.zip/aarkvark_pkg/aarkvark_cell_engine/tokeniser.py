"""
aarkvark_cell_engine.tokeniser
================================
Lexer for Aarkvark formula strings.

Produces a flat list of (_TT, raw_str) token tuples from the body of a
formula (the leading ``=`` must be stripped before calling
:func:`tokenise`).  All identifier tokens (cell addresses and function
names) are uppercased so the rest of the pipeline is case-insensitive.
"""

from __future__ import annotations

import re
from enum import Enum, auto
from typing import List, Tuple


class _TT(Enum):
    """Token type tags — internal to the parsing pipeline."""
    NUMBER  = auto()   # 42  3.14  1e5
    STRING  = auto()   # "hello"  or  'hello'
    CELL    = auto()   # A1  B12  AA3   (letter(s) followed by digit(s))
    NAME    = auto()   # SUM  AVG  IF   (letters only, no trailing digit)
    PLUS    = auto()   # +
    MINUS   = auto()   # -
    STAR    = auto()   # *
    SLASH   = auto()   # /
    POWER   = auto()   # **
    PERCENT = auto()   # %
    COLON   = auto()   # :
    COMMA   = auto()   # ,
    LPAREN  = auto()   # (
    RPAREN  = auto()   # )
    EOF     = auto()


# Type alias used throughout the pipeline
Token = Tuple[_TT, str]

# Patterns tried in order — POWER before STAR, CELL before NAME.
_RULES: List[Tuple[_TT, str]] = [
    (_TT.NUMBER,  r"\d+\.?\d*(?:[eE][+-]?\d+)?"),
    (_TT.STRING,  r'"[^"]*"' + r"|'[^']*'"),
    (_TT.CELL,    r"[A-Za-z]+\d+"),    # must have trailing digit(s)
    (_TT.NAME,    r"[A-Za-z_]\w*"),    # no trailing digit required
    (_TT.POWER,   r"\*\*"),
    (_TT.STAR,    r"\*"),
    (_TT.PLUS,    r"\+"),
    (_TT.MINUS,   r"-"),
    (_TT.SLASH,   r"/"),
    (_TT.PERCENT, r"%"),
    (_TT.COLON,   r":"),
    (_TT.COMMA,   r","),
    (_TT.LPAREN,  r"\("),
    (_TT.RPAREN,  r"\)"),
]

_UPPER_TTS = {_TT.CELL, _TT.NAME}   # these get uppercased


def tokenise(expr: str) -> List[Token]:
    """
    Lex *expr* into a list of ``(_TT, raw_string)`` pairs terminated by
    a single ``(_TT.EOF, "")``.  Whitespace is silently consumed.

    Parameters
    ----------
    expr : str
        Formula body with the leading ``=`` already stripped.

    Raises
    ------
    ValueError
        If an unrecognised character is encountered.

    Examples
    --------
    >>> tokenise("A1 + 2")
    [(_TT.CELL, 'A1'), (_TT.PLUS, '+'), (_TT.NUMBER, '2'), (_TT.EOF, '')]
    """
    tokens: List[Token] = []
    i = 0
    while i < len(expr):
        if expr[i].isspace():
            i += 1
            continue
        matched = False
        for tt, pat in _RULES:
            m = re.match(pat, expr[i:])
            if m:
                raw = m.group(0)
                val = raw.upper() if tt in _UPPER_TTS else raw
                tokens.append((tt, val))
                i += len(raw)
                matched = True
                break
        if not matched:
            raise ValueError(
                f"Unexpected character {expr[i]!r} at position {i} in {expr!r}"
            )
    tokens.append((_TT.EOF, ""))
    return tokens
