"""
aarkvark_cell_engine.exceptions
================================
Public exception types for the Aarkvark cell engine.
"""

from __future__ import annotations
from typing import Dict


class CircularDependencyError(Exception):
    """
    Raised by ``CellEngine.set_cell`` when the new formula would create a
    cycle in the dependency graph.

    The engine performs a full rollback before raising, so the cell and
    the graph are left in the state they were in before the offending call.
    """


class CellError(Exception):
    """
    Stored on a cell when evaluation fails.

    Inherits from :class:`Exception` so it can be raised and caught during
    formula evaluation, then stored on the cell object.  CellErrors propagate:
    any cell that reads an errored cell also becomes a ``#REF!`` error.

    Parameters
    ----------
    code   : str
        Short spreadsheet-style error token, e.g. ``"DIV0"``, ``"PARSE"``.
    detail : str
        Human-readable description of what went wrong (optional).

    Examples
    --------
    >>> err = CellError("DIV0", "denominator is zero")
    >>> str(err)
    '#DIV0!'
    >>> err == CellError("DIV0")
    True
    """

    LABELS: Dict[str, str] = {
        "DIV0":  "Division by zero",
        "REF":   "Invalid reference",
        "VALUE": "Wrong value type",
        "NAME":  "Unknown function",
        "PARSE": "Formula parse error",
        "CIRC":  "Circular dependency",
        "ERROR": "Evaluation error",
    }

    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(detail or code)
        self.code   = code.upper()
        self.detail = detail

    def __str__(self)  -> str: return f"#{self.code}!"
    def __repr__(self) -> str: return f"CellError({self.code!r}, {self.detail!r})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, CellError) and self.code == other.code

    def __hash__(self) -> int:
        return hash(self.code)
