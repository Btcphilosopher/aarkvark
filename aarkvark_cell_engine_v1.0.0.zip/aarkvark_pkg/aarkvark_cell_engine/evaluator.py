"""
aarkvark_cell_engine.evaluator
================================
Safe AST evaluator and static dependency collector.

**No use of** ``eval()`` **or** ``exec()`` **anywhere in this module.**
All computation goes through an explicit AST walker with an allow-list of
operators and functions.

Built-in functions
------------------
SUM, AVG / MEAN, MIN, MAX, COUNT, ABS, SQRT, ROUND, POWER, IF

Adding a custom function
------------------------
Register it in :data:`FUNCTIONS` before constructing a :class:`CellEngine`::

    from aarkvark_cell_engine.evaluator import FUNCTIONS
    FUNCTIONS["MEDIAN"] = lambda vs: sorted(vs)[len(vs)//2]
"""

from __future__ import annotations

import operator
from typing import Any, Callable, Dict, List, Set

from .address import expand_range
from .exceptions import CellError
from .parser import ASTNode

# ── operator dispatch table ───────────────────────────────────────────────────

BINOP_FNS: Dict[str, Callable[[Any, Any], Any]] = {
    "+":  operator.add,
    "-":  operator.sub,
    "*":  operator.mul,
    "/":  operator.truediv,
    "**": operator.pow,
}

# ── built-in function dispatch table ─────────────────────────────────────────

FUNCTIONS: Dict[str, Callable[[List[Any]], Any]] = {
    "SUM":   lambda vs: sum(vs) if vs else 0,
    "AVG":   lambda vs: sum(vs) / len(vs) if vs else 0,
    "MEAN":  lambda vs: sum(vs) / len(vs) if vs else 0,
    "MIN":   lambda vs: min(vs) if vs else 0,
    "MAX":   lambda vs: max(vs) if vs else 0,
    "COUNT": lambda vs: len(vs),
    "ABS":   lambda vs: abs(vs[0]),
    "SQRT":  lambda vs: vs[0] ** 0.5,
    "ROUND": lambda vs: round(vs[0], int(vs[1]) if len(vs) > 1 else 0),
    "POWER": lambda vs: vs[0] ** vs[1],
    # Eager IF (all branches evaluated before dispatch)
    "IF":    lambda vs: vs[1] if vs[0] else (vs[2] if len(vs) > 2 else 0),
}


# ── dependency collection ─────────────────────────────────────────────────────

def collect_deps(node: ASTNode) -> Set[str]:
    """
    Walk *node* and return the flat set of all cell addresses it references.

    Ranges are expanded so the result contains individual addresses only.

    Parameters
    ----------
    node : ASTNode
        Root of an AST produced by :func:`~aarkvark_cell_engine.parser.parse_formula`.

    Returns
    -------
    set[str]
        Normalised uppercase addresses, e.g. ``{'A1', 'B2', 'B3'}``.
    """
    deps: Set[str] = set()

    def _walk(n: ASTNode) -> None:
        k = n[0]
        if k == "cell":
            deps.add(n[1])
        elif k == "range":
            deps.update(expand_range(n[1], n[2]))
        elif k == "binop":
            _walk(n[2]); _walk(n[3])
        elif k == "unary":
            _walk(n[2])
        elif k == "call":
            for arg in n[2]:
                _walk(arg)
        # 'num' and 'str' — no references

    _walk(node)
    return deps


# ── AST evaluator ─────────────────────────────────────────────────────────────

def evaluate(node: ASTNode, resolver: Callable[[str], Any]) -> Any:
    """
    Recursively evaluate *node*.

    Parameters
    ----------
    node : ASTNode
        AST produced by :func:`~aarkvark_cell_engine.parser.parse_formula`.
    resolver : callable(address: str) -> Any
        Callback that returns the current value for a cell address.
        Should return ``0`` for empty / unknown cells.
        Should raise :class:`~aarkvark_cell_engine.exceptions.CellError`
        if the referenced cell is itself in an error state.

    Returns
    -------
    int | float | str | bool
        The computed result.

    Raises
    ------
    CellError
        Re-raised from *resolver* (propagates errors from dependencies).
    ZeroDivisionError
        On ``x / 0``.
    TypeError
        On type-incompatible operations (e.g. adding a string to a number).
    ValueError
        On unknown operator or function name.
    """
    k = node[0]

    if k == "num":
        return node[1]

    if k == "str":
        return node[1]

    if k == "cell":
        return resolver(node[1])

    if k == "range":
        # Materialise as a list; consumed by the 'call' branch.
        return [resolver(a) for a in expand_range(node[1], node[2])]

    if k == "binop":
        _, op, lhs, rhs = node
        left  = evaluate(lhs, resolver)
        right = evaluate(rhs, resolver)
        if op == "/" and right == 0:
            raise ZeroDivisionError("Division by zero")
        fn = BINOP_FNS.get(op)
        if fn is None:
            raise ValueError(f"Unknown operator: {op!r}")
        return fn(left, right)

    if k == "unary":
        _, op, operand = node
        val = evaluate(operand, resolver)
        return -val if op == "-" else val

    if k == "call":
        _, name, args = node
        flat: List[Any] = []
        for arg in args:
            result = evaluate(arg, resolver)
            if isinstance(result, list):
                flat.extend(v for v in result if v is not None)
            elif result is not None:
                flat.append(result)
        fn = FUNCTIONS.get(name)
        if fn is None:
            raise ValueError(f"Unknown function: {name!r}")
        return fn(flat)

    raise ValueError(f"Unknown AST node kind: {k!r}")
