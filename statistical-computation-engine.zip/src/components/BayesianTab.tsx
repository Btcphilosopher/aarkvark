/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { bayesianEngine } from "../engine/main";
import { Compass, Settings2, PlayCircle, EyeOff } from "lucide-react";

type PriorStyle = "beta-binomial" | "normal-normal" | "mcmc";

export function BayesianTab() {
  const [styleMode, setStyleMode] = useState<PriorStyle>("beta-binomial");

  // Beta Binomial prior states
  const [betaAlpha, setBetaAlpha] = useState(2.0);
  const [betaBeta, setBetaBeta] = useState(2.0);
  const [trials, setTrials] = useState(15);
  const [successes, setSuccesses] = useState(8);

  // Normal Normal states
  const [priorMean, setPriorMean] = useState(100.0);
  const [priorSD, setPriorSD] = useState(15.0);
  const [sampleSize, setSampleSize] = useState(30);
  const [sampleMean, setSampleMean] = useState(108.5);
  const [knownSigma, setKnownSigma] = useState(12.0);

  // MCMC states; target PDF represents a bi-modal Gaussian grid mix
  const [mcmcChain, setMcmcChain] = useState<number[]>([]);
  const [mcmcStart, setMcmcStart] = useState(0.0);
  const [mcmcSteps, setMcmcSteps] = useState(1000);
  const [mcmcProposalSD, setMcmcProposalSD] = useState(1.5);

  // Computation of conjugation prior analytical results
  const posteriorAnalysis = useMemo(() => {
    if (styleMode === "beta-binomial") {
      return bayesianEngine.bayesianBetaBinomial(betaAlpha, betaBeta, successes, trials - successes, 0.95);
    } else {
      return bayesianEngine.bayesianNormalNormal(priorMean, priorSD * priorSD, knownSigma * knownSigma, sampleMean, sampleSize, 0.95);
    }
  }, [styleMode, betaAlpha, betaBeta, trials, successes, priorMean, priorSD, sampleSize, sampleMean, knownSigma]);

  // Handle MCMC run
  const triggerMCMC = () => {
    // Mixture PDF target
    const targetPDF = (x: number) => {
      // 0.4 * N(-2, 0.7) + 0.6 * N(2.5, 1.2)
      const pdf1 = Math.exp(-Math.pow(x + 2, 2) / (2 * 0.49)) / Math.sqrt(2 * Math.PI * 0.49);
      const pdf2 = Math.exp(-Math.pow(x - 2.5, 2) / (2 * 1.44)) / Math.sqrt(2 * Math.PI * 1.44);
      return 0.4 * pdf1 + 0.6 * pdf2;
    };

    const chain = bayesianEngine.metropolisHastings(targetPDF, mcmcStart, mcmcSteps, mcmcProposalSD);
    setMcmcChain(chain);
  };

  // Trajectory coordinates of posterior distribution PDF for SVG drawings
  const posteriorPlotPoints = useMemo(() => {
    if (mcmcChain.length > 0 && styleMode === "mcmc") return null;

    const points: { x: number; y: number }[] = [];
    const steps = 100;

    if (styleMode === "beta-binomial") {
      const res = posteriorAnalysis as any;
      const postAlpha = res.posteriorAlpha;
      const postBeta = res.posteriorBeta;

      // Draw Beta PDF from 0 to 1
      for (let i = 0; i <= steps; i++) {
        const x = i / steps;
        // Simple approximation of Beta PDF: x^(a-1) * (1-x)^(b-1) scaled to fit SVG
        // Calculate log PDF for stability
        const lpdf = (postAlpha - 1) * Math.log(x || 0.0001) + (postBeta - 1) * Math.log(1 - x || 0.0001);
        const y = Math.exp(lpdf);
        if (!isNaN(y) && isFinite(y)) {
          points.push({ x, y });
        }
      }
    } else {
      const res = posteriorAnalysis as any;
      const postMean = res.posteriorMean;
      const postSD = res.posteriorSD;

      // Draw Gaussian shape
      const minX = postMean - 3.5 * postSD;
      const maxX = postMean + 3.5 * postSD;
      const range = maxX - minX || 1.0;

      for (let i = 0; i <= steps; i++) {
        const pct = i / steps;
        const x = minX + pct * range;
        const y = (1.0 / (postSD * Math.sqrt(2.0 * Math.PI))) * Math.exp(-Math.pow(x - postMean, 2) / (2.0 * Math.pow(postSD, 2)));
        if (!isNaN(y) && isFinite(y)) {
          points.push({ x, y });
        }
      }
    }

    return points;
  }, [styleMode, posteriorAnalysis, mcmcChain]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black pb-4">
        <div>
          <h2 className="text-lg font-bold uppercase tracking-tight text-black font-sans">
            Bayesian Inference Suite
          </h2>
          <p className="text-xs text-black/70 mt-1 font-mono">
            Conducts posterior estimations, conjugate prior calculations, and active Metropolis-Hastings MCMC processes.
          </p>
        </div>

        <div className="flex gap-2">
          {(["beta-binomial", "normal-normal", "mcmc"] as PriorStyle[]).map((mode) => (
            <button
              key={mode}
              onClick={() => setStyleMode(mode)}
              className={`text-xs px-3 py-1.5 rounded-none font-mono font-bold transition-colors cursor-pointer border ${
                styleMode === mode
                  ? "bg-black border-black text-[#E4E3E0] shadow-none"
                  : "bg-[#E4E3E0] border-black text-black hover:bg-[#D4D3D0] shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
              }`}
            >
              {mode.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input Configuration */}
        <div className="bg-[#E4E3E0] border border-black p-5 rounded-none space-y-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <h3 className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold flex items-center gap-1.5 border-b border-black pb-2">
            <Settings2 className="w-4 h-4 text-black" /> Bayesian Priors
          </h3>

          <div className="space-y-3 font-sans text-xs">
            {styleMode === "beta-binomial" && (
              <>
                <div className="space-y-1">
                  <label className="text-black/60 block font-mono text-[10px] font-bold">Prior Alpha (α): {betaAlpha}</label>
                  <input
                    type="range"
                    min="0.5"
                    max="15"
                    step="0.5"
                    value={betaAlpha}
                    onChange={(e) => setBetaAlpha(Number(e.target.value))}
                    className="w-full h-1.5 bg-black/10 rounded-none accent-black appearance-none cursor-pointer"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-black/60 block font-mono text-[10px] font-bold">Prior Beta (β): {betaBeta}</label>
                  <input
                    type="range"
                    min="0.5"
                    max="15"
                    step="0.5"
                    value={betaBeta}
                    onChange={(e) => setBetaBeta(Number(e.target.value))}
                    className="w-full h-1.5 bg-black/10 rounded-none accent-black appearance-none cursor-pointer"
                  />
                </div>
                <div className="pt-2 border-t border-black space-y-2">
                  <div className="space-y-1">
                    <label className="text-black/60 block font-mono text-[10px] font-bold">Recorded Successes (y):</label>
                    <input
                      type="number"
                      min="0"
                      max={trials}
                      value={successes}
                      onChange={(e) => setSuccesses(Math.max(0, Math.min(trials, Number(e.target.value))))}
                      className="w-full border border-black rounded-none px-2 py-1 bg-[#E4E3E0] font-mono font-bold text-black focus:outline-hidden"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-black/60 block font-mono text-[10px] font-bold">Recorded Trials (n):</label>
                    <input
                      type="number"
                      min="0"
                      value={trials}
                      onChange={(e) => {
                        const tr = Math.max(0, Number(e.target.value));
                        setTrials(tr);
                        if (successes > tr) setSuccesses(tr);
                      }}
                      className="w-full border border-black rounded-none px-2 py-1 bg-[#E4E3E0] font-mono font-bold text-black focus:outline-hidden"
                    />
                  </div>
                </div>
              </>
            )}

            {styleMode === "normal-normal" && (
              <>
                <div className="space-y-1">
                  <label className="text-black/60 block font-mono text-[10px] font-bold">Prior Mean (μ_p):</label>
                  <input
                    type="number"
                    step="any"
                    value={priorMean}
                    onChange={(e) => setPriorMean(Number(e.target.value))}
                    className="w-full border border-black rounded-none px-2 py-1 bg-[#E4E3E0] font-mono font-bold text-black focus:outline-hidden"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-black/60 block font-mono text-[10px] font-bold">Prior SD (σ_p): {priorSD}</label>
                  <input
                    type="range"
                    min="1"
                    max="50"
                    step="1"
                    value={priorSD}
                    onChange={(e) => setPriorSD(Number(e.target.value))}
                    className="w-full h-1.5 bg-black/10 rounded-none accent-black appearance-none cursor-pointer"
                  />
                </div>
                <div className="pt-2 border-t border-black space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-black/60 block font-mono text-[10px] font-bold">Sample Size (n):</label>
                      <input
                        type="number"
                        min="1"
                        value={sampleSize}
                        onChange={(e) => setSampleSize(Math.max(1, Number(e.target.value)))}
                        className="w-full border border-black rounded-none px-2 py-1 bg-[#E4E3E0] font-mono font-bold text-black focus:outline-hidden"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-black/60 block font-mono text-[10px] font-bold">Known SD (σ):</label>
                      <input
                        type="number"
                        min="0.1"
                        step="0.1"
                        value={knownSigma}
                        onChange={(e) => setKnownSigma(Math.max(0.1, Number(e.target.value)))}
                        className="w-full border border-black rounded-none px-2 py-1 bg-[#E4E3E0] font-mono font-bold text-black focus:outline-hidden"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-black/60 block font-mono text-[10px] font-bold">Sample Mean (x̄):</label>
                    <input
                      type="number"
                      step="any"
                      value={sampleMean}
                      onChange={(e) => setSampleMean(Number(e.target.value))}
                      className="w-full border border-black rounded-none px-2 py-1 bg-[#E4E3E0] font-mono font-bold text-black focus:outline-hidden"
                    />
                  </div>
                </div>
              </>
            )}

            {styleMode === "mcmc" && (
              <>
                <div className="space-y-2 p-3 bg-black/5 border border-black rounded-none">
                  <h4 className="text-[10px] font-mono uppercase text-black font-bold">MH Target density</h4>
                  <p className="text-[10px] text-black/70 leading-normal font-mono font-bold">
                    π(x) ∝ 0.4 * N(-2.0, 0.7²) + 0.6 * N(2.5, 1.2²)
                  </p>
                </div>
                <div className="space-y-1">
                  <label className="text-black/60 block font-mono text-[10px] font-bold">Start Coordinate (x₀):</label>
                  <input
                    type="number"
                    step="any"
                    value={mcmcStart}
                    onChange={(e) => setMcmcStart(Number(e.target.value))}
                    className="w-full border border-black rounded-none px-2 py-1 bg-[#E4E3E0] font-mono font-bold text-black focus:outline-hidden"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-black/60 block font-mono text-[10px] font-bold">MCMC Steps (Chain length):</label>
                  <input
                    type="number"
                    min="100"
                    max="5000"
                    step="100"
                    value={mcmcSteps}
                    onChange={(e) => setMcmcSteps(Number(e.target.value))}
                    className="w-full border border-black rounded-none px-2 py-1 bg-[#E4E3E0] font-mono font-bold text-black focus:outline-hidden"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-black/60 block font-mono text-[10px] font-bold">Proposal Transition SD: {mcmcProposalSD}</label>
                  <input
                    type="range"
                    min="0.2"
                    max="5"
                    step="0.1"
                    value={mcmcProposalSD}
                    onChange={(e) => setMcmcProposalSD(Number(e.target.value))}
                    className="w-full h-1.5 bg-black/10 rounded-none accent-black appearance-none cursor-pointer"
                  />
                </div>
                <button
                  onClick={triggerMCMC}
                  className="w-full mt-2 text-xs font-mono font-bold bg-black text-[#E4E3E0] rounded-none py-2 hover:bg-[#1C1C1C] flex items-center justify-center gap-1.5 cursor-pointer border border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                >
                  <PlayCircle className="w-4 h-4" /> Run Gibbs/MH Chain
                </button>
              </>
            )}
          </div>
        </div>

        {/* Visual Report Output Canvas */}
        <div className="lg:col-span-2 space-y-6">
          {styleMode !== "mcmc" && posteriorPlotPoints && posteriorAnalysis ? (
            <div className="p-5 bg-[#E4E3E0] border border-black rounded-none space-y-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
              <div className="flex justify-between items-center border-b border-black pb-2">
                <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-1">
                  <Compass className="w-4 h-4 text-black" /> Posterior Parameter Distribution
                </h3>
                <span className="text-[10px] font-mono text-black/60 uppercase font-bold">95% Highest Density Interval (HDI)</span>
              </div>

              {/* PDF Curve Plot */}
              <div className="relative w-full h-44 bg-black/5 border border-black p-2.5 flex items-end">
                <svg viewBox="0 0 500 120" className="w-full h-full" preserveAspectRatio="none">
                  {(() => {
                    const pts = posteriorPlotPoints;
                    if (pts.length === 0) return null;

                    const maxY = Math.max(...pts.map((p) => p.y), 0.001);
                    const drawLines = pts.map((pt, idx) => {
                      const screenX = 50 + (idx / (pts.length - 1)) * 400;
                      const screenY = 105 - (pt.y / maxY) * 90;
                      return `${screenX},${screenY}`;
                    });

                    const polygonPoints = [`50,105`, ...drawLines, `450,105`].join(" ");

                    return (
                      <>
                        <polygon points={polygonPoints} fill="#C4C3C0" opacity="0.4" />
                        <polyline
                          fill="none"
                          stroke="#141414"
                          strokeWidth="3"
                          points={drawLines.join(" ")}
                        />
                      </>
                    );
                  })()}

                  {/* Horizontal baseline */}
                  <line x1="40" y1="105" x2="470" y2="105" stroke="#141414" strokeWidth="2" />
                </svg>
              </div>

              {/* Posterior Metrics Report */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs pt-2">
                <div className="bg-black/5 p-3 border border-black rounded-none">
                  <span className="text-[10px] text-black/60 uppercase font-bold">Posterior Mean</span>
                  <span className="text-md text-black font-bold block mt-1">
                    {"posteriorMean" in posteriorAnalysis
                      ? posteriorAnalysis.posteriorMean.toLocaleString(undefined, { maximumFractionDigits: 5 })
                      : posteriorAnalysis.posteriorExpected.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                  </span>
                </div>
                <div className="bg-black/5 p-3 border border-black rounded-none">
                  <span className="text-[10px] text-black/60 uppercase font-bold">Posterior SD</span>
                  <span className="text-md text-black font-bold block mt-1">
                    {posteriorAnalysis.posteriorSD.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                  </span>
                </div>
                <div className="bg-black/5 p-3 border border-black rounded-none">
                  <span className="text-[10px] text-black/60 uppercase font-bold">Credible Interval (HDI)</span>
                  <span className="text-md text-amber-900 font-bold block mt-1">
                    [{posteriorAnalysis.highestDensityInterval[0].toLocaleString(undefined, { maximumFractionDigits: 3 })},{" "}
                    {posteriorAnalysis.highestDensityInterval[1].toLocaleString(undefined, { maximumFractionDigits: 3 })}]
                  </span>
                </div>
              </div>
            </div>
          ) : styleMode === "mcmc" ? (
            <div className="p-5 bg-[#E4E3E0] border border-black rounded-none space-y-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
              <h3 className="text-xs font-mono font-bold text-black border-b border-black pb-2 uppercase">
                Metropolis Trace-Plot Trajectory
              </h3>

              {mcmcChain.length > 0 ? (
                <div className="space-y-4">
                  <div className="relative w-full h-40 bg-black border border-black p-2 flex items-end">
                    <svg viewBox="0 0 500 120" className="w-full h-full" preserveAspectRatio="none">
                      {(() => {
                        // Plot trace path
                        const minY = Math.min(...mcmcChain);
                        const maxY = Math.max(...mcmcChain);
                        const rangeY = maxY - minY || 1.0;

                        const linePoints: string[] = [];
                        const steps = mcmcChain.length;
                        
                        // Scale points down to reduce path bloating
                        const scaleSkip = Math.max(1, Math.ceil(steps / 400));

                        for (let i = 0; i < steps; i += scaleSkip) {
                          const sx = 20 + (i / steps) * 460;
                          const sy = 110 - ((mcmcChain[i] - minY) / rangeY) * 100;
                          linePoints.push(`${sx},${sy}`);
                        }

                        return (
                          <polyline
                            fill="none"
                            stroke="#E4E3E0"
                            strokeWidth="1.0"
                            points={linePoints.join(" ")}
                          />
                        );
                      })()}
                    </svg>
                  </div>

                  <div className="p-4 bg-black/5 border border-black rounded-none font-mono text-[11px] leading-relaxed text-black/80">
                    <p className="text-black font-bold mb-1 border-b border-black pb-1 uppercase">MCMC Sampling Diagnostics:</p>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-1 font-bold">
                      <span>Total Chain Length: <strong className="text-black">{mcmcChain.length}</strong></span>
                      <span>Empirical Posterior Mean: <strong className="text-black">{(mcmcChain.reduce((a,b)=>a+b,0)/mcmcChain.length).toFixed(4)}</strong></span>
                      <span>Posterior 2.5% quantile: <strong className="text-black">{[...mcmcChain].sort((a,b)=>a-b)[Math.floor(mcmcChain.length * 0.025)]?.toFixed(3)}</strong></span>
                      <span>Posterior 97.5% quantile: <strong className="text-black">{[...mcmcChain].sort((a,b)=>a-b)[Math.floor(mcmcChain.length * 0.975)]?.toFixed(3)}</strong></span>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-black/60 bg-black/5 border border-dashed border-black p-8 rounded-none text-center font-mono font-bold">
                  No Markov chains simulation generated yet. Click &quot;Run Gibbs/MH Chain&quot; on left configuration to simulate.
                </p>
              )}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
