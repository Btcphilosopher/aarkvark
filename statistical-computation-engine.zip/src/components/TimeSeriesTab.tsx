/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { timeSeriesStats } from "../engine/main";
import { Clock, BarChart3, LineChart, ShieldCheck } from "lucide-react";

interface TimeSeriesTabProps {
  headers: string[];
  data: number[][];
}

export function TimeSeriesTab({ headers, data }: TimeSeriesTabProps) {
  const [selectedCol, setSelectedCol] = useState(0);
  const [rollingWindow, setRollingWindow] = useState(5);
  const [ewmaSpan, setEwmaSpan] = useState(10);
  const [acfLags, setAcfLags] = useState(12);

  const series = useMemo(() => {
    if (data.length === 0 || selectedCol >= headers.length) return [];
    return data.map((row) => row[selectedCol]);
  }, [data, selectedCol]);

  // Compute SMA and EWMA lines
  const rollingMeans = useMemo(() => {
    if (series.length === 0) return [];
    return timeSeriesStats.rollingMean(series, rollingWindow);
  }, [series, rollingWindow]);

  const ewmaMeans = useMemo(() => {
    if (series.length === 0) return [];
    const alpha = 2.0 / (ewmaSpan + 1.0);
    return timeSeriesStats.ewma(series, alpha);
  }, [series, ewmaSpan]);

  // Compute ACF/PACF graphs values
  const lagDats = useMemo(() => {
    if (series.length < acfLags + 5) return null;
    const acf = timeSeriesStats.acf(series, acfLags);
    const pacf = timeSeriesStats.pacf(series, acfLags);
    return { acf, pacf };
  }, [series, acfLags]);

  // Stationarity results (ADF unit test approximating regression)
  const adfStationary = useMemo(() => {
    if (series.length < 15) return null;
    return timeSeriesStats.dickeyFullerTest(series);
  }, [series]);

  // Coordinates of trend plot SVG lines
  const seriesPlot = useMemo(() => {
    if (series.length === 0) return null;
    const minY = Math.min(...series);
    const maxY = Math.max(...series);
    const range = maxY - minY || 1.0;

    const seriesPoints: string[] = [];
    const smaPoints: string[] = [];
    const ewmaPoints: string[] = [];
    const n = series.length;

    for (let i = 0; i < n; i++) {
      const sx = 40 + (i / (n - 1)) * 420;
      
      const rSy = 105 - ((series[i] - minY) / range) * 85;
      seriesPoints.push(`${sx},${rSy}`);

      const smaVal = rollingMeans[i];
      if (smaVal !== undefined && !isNaN(smaVal)) {
        const smaSy = 105 - ((smaVal - minY) / range) * 85;
        smaPoints.push(`${sx},${smaSy}`);
      }

      const ewmaVal = ewmaMeans[i];
      if (ewmaVal !== undefined && !isNaN(ewmaVal)) {
        const ewmaSy = 105 - ((ewmaVal - minY) / range) * 85;
        ewmaPoints.push(`${sx},${ewmaSy}`);
      }
    }

    return {
      seriesPoints,
      smaPoints,
      ewmaPoints,
      minY,
      maxY,
    };
  }, [series, rollingMeans, ewmaMeans]);

  if (headers.length === 0 || data.length === 0) {
    return (
      <div className="p-8 text-center text-gray-400 font-sans">
        Time series analysis requires a numeric dataset to be loaded first.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black pb-4">
        <div>
          <h2 className="text-lg font-bold uppercase tracking-tight text-black font-sans">
            Time-Series Statistics Engine
          </h2>
          <p className="text-xs font-mono text-black/70 mt-1">
            Builds lag correlation ACF PACF, stationarity unit tests, and exponentially weighted trend bounds.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold">Select Series:</label>
          <select
            value={selectedCol}
            onChange={(e) => setSelectedCol(Number(e.target.value))}
            className="text-xs font-mono border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] text-black font-bold focus:outline-hidden"
          >
            {headers.map((h, i) => (
              <option key={i} value={i}>Col {i}: {h}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Configurations column */}
        <div className="bg-[#E4E3E0] border border-black p-5 rounded-none space-y-4 font-sans text-xs shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <h3 className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold flex items-center gap-1.5 border-b border-black pb-2">
            <Clock className="w-4 h-4 text-black" /> Series Parameters
          </h3>

          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex justify-between font-mono text-[10px] text-black font-bold">
                <span>SMA window:</span>
                <span>{rollingWindow} periods</span>
              </div>
              <input
                type="range"
                min="2"
                max="20"
                value={rollingWindow}
                onChange={(e) => setRollingWindow(Number(e.target.value))}
                className="w-full h-1.5 bg-black/10 rounded-none accent-black appearance-none cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-mono text-[10px] text-black font-bold">
                <span>EWMA span (periods):</span>
                <span>{ewmaSpan}</span>
              </div>
              <input
                type="range"
                min="3"
                max="40"
                value={ewmaSpan}
                onChange={(e) => setEwmaSpan(Number(e.target.value))}
                className="w-full h-1.5 bg-black/10 rounded-none accent-black appearance-none cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between font-mono text-[10px] text-black font-bold">
                <span>Autocorrelation Lags (K):</span>
                <span>{acfLags}</span>
              </div>
              <input
                type="range"
                min="4"
                max={Math.min(24, Math.floor(series.length / 3))}
                value={acfLags}
                onChange={(e) => setAcfLags(Number(e.target.value))}
                className="w-full h-1.5 bg-black/10 rounded-none accent-black appearance-none cursor-pointer"
              />
            </div>
          </div>

          {/* Dickey Fuller Unit test diagnostic results */}
          {adfStationary && (
            <div className="pt-3 border-t border-black space-y-2 font-mono text-[11px]">
              <span className="text-[9px] text-black/60 font-bold uppercase tracking-wider block">ADF Stationarity Unit-Root Report</span>
              <div className="p-3 bg-black/5 border border-black rounded-none space-y-1 text-black font-bold">
                <div className="flex justify-between">
                  <span>ADF t-statistic:</span>
                  <span className="text-black">{adfStationary.statistic.toFixed(4)}</span>
                </div>
                <div className="flex justify-between border-b border-black/30 pb-1">
                  <span>Critical (5% level):</span>
                  <span className="text-black/60">{adfStationary.criticalValue5Pct.toFixed(3)}</span>
                </div>
                <div className="pt-1 flex justify-between">
                  <span>Stationary status:</span>
                  <span className={`font-extrabold uppercase ${adfStationary.isStationary ? "text-amber-950 underline" : "text-black/70"}`}>
                    {adfStationary.isStationary ? "STATIONARY" : "UNIT-ROOT"}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Visual Panels column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Main trendline chart plots */}
          {seriesPlot && (
            <div className="p-5 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
              <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-1.5 border-b border-black pb-2 mb-3">
                <LineChart className="w-4 h-4 text-black" /> Exponential/Simple Trend Bounds Plots
              </h3>

              <div className="relative w-full h-44 bg-black/5 border border-black p-2.5 flex items-end">
                <svg viewBox="0 0 500 120" className="w-full h-full" preserveAspectRatio="none">
                  {/* Original line */}
                  <polyline
                    fill="none"
                    stroke="#141414"
                    strokeWidth="1.0"
                    opacity="0.3"
                    points={seriesPlot.seriesPoints.join(" ")}
                  />
                  {/* SMA line */}
                  {seriesPlot.smaPoints.length > 1 && (
                    <polyline
                      fill="none"
                      stroke="#141414"
                      strokeWidth="1.5"
                      strokeDasharray="4 3"
                      points={seriesPlot.smaPoints.join(" ")}
                    />
                  )}
                  {/* EWMA line */}
                  {seriesPlot.ewmaPoints.length > 1 && (
                    <polyline
                      fill="none"
                      stroke="#141414"
                      strokeWidth="3.0"
                      points={seriesPlot.ewmaPoints.join(" ")}
                    />
                  )}
                </svg>
              </div>

              <div className="flex justify-between items-center text-[10px] font-mono text-black/60 mt-2 px-6">
                <div className="flex gap-4 font-bold uppercase">
                  <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-black/30 block" /> Series</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-0.5 border-t border-dashed border-black block" /> {rollingWindow}-SMA</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-black block" /> {ewmaSpan}-EWMA</span>
                </div>
                <span className="font-bold">Bound: [{seriesPlot.minY.toFixed(1)}, {seriesPlot.maxY.toFixed(1)}]</span>
              </div>
            </div>
          )}

          {/* ACF PACF charts */}
          {lagDats && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <h4 className="text-xs uppercase tracking-wider font-bold text-black flex items-center gap-1 mb-2 border-b border-black pb-1.5">
                  <BarChart3 className="w-3.5 h-3.5 text-black" /> Autocorrelation (ACF) Lags
                </h4>

                <div className="relative w-full h-32 bg-black/5 border border-black p-1 flex items-end">
                  <svg viewBox="0 0 250 100" className="w-full h-full" preserveAspectRatio="none">
                    {lagDats.acf.map((acfVal, lagIdx) => {
                      const xCoord = 25 + (lagIdx / lagDats.acf.length) * 200;
                      // map ACFval [-1, 1] to height [10, 90]
                      const yVal = 50 - acfVal * 40;
                      return (
                        <g key={lagIdx}>
                          <line
                            x1={xCoord}
                            y1="50"
                            x2={xCoord}
                            y2={yVal}
                            stroke="#141414"
                            strokeWidth="3.5"
                          />
                          <title>{`Lag ${lagIdx}: ACF = ${acfVal.toFixed(4)}`}</title>
                        </g>
                      );
                    })}
                    {/* Zero baseline */}
                    <line x1="15" y1="50" x2="235" y2="50" stroke="#141414" strokeWidth="1.5" strokeDasharray="3 3" />
                  </svg>
                </div>
                <div className="flex justify-between text-[9px] font-mono text-black/60 font-bold mt-1 uppercase">
                  <span>Lag 0</span>
                  <span>Lag {acfLags}</span>
                </div>
              </div>

              <div className="p-4 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <h4 className="text-xs uppercase tracking-wider font-bold text-black flex items-center gap-1 mb-2 border-b border-black pb-1.5">
                  <BarChart3 className="w-3.5 h-3.5 text-black" /> Partial Autocorrelation (PACF)
                </h4>

                <div className="relative w-full h-32 bg-black/5 border border-black p-1 flex items-end">
                  <svg viewBox="0 0 250 100" className="w-full h-full" preserveAspectRatio="none">
                    {lagDats.pacf.map((pacfVal, lagIdx) => {
                      const xCoord = 25 + (lagIdx / lagDats.pacf.length) * 200;
                      const yVal = 50 - pacfVal * 40;
                      return (
                        <g key={lagIdx}>
                          <line
                            x1={xCoord}
                            y1="50"
                            x2={xCoord}
                            y2={yVal}
                            stroke="#141414"
                            strokeWidth="3.5"
                          />
                          <title>{`Lag ${lagIdx}: PACF = ${pacfVal.toFixed(4)}`}</title>
                        </g>
                      );
                    })}
                    {/* Zero baseline */}
                    <line x1="15" y1="50" x2="235" y2="50" stroke="#141414" strokeWidth="1.5" strokeDasharray="3 3" />
                  </svg>
                </div>
                <div className="flex justify-between text-[9px] font-mono text-black/60 font-bold mt-1 uppercase">
                  <span>Lag 0</span>
                  <span>Lag {acfLags}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
