/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { simulationEngine } from "../engine/main";
import { Sparkles, BarChart, TrendingUp, Info } from "lucide-react";

interface SimulationTabProps {
  headers: string[];
  data: number[][];
}

type ModeType = "bootstrap" | "montecarlo";

export function SimulationTab({ headers, data }: SimulationTabProps) {
  const [activeSubMode, setActiveSubMode] = useState<ModeType>("bootstrap");

  // Bootstrap states
  const [selectedCol, setSelectedCol] = useState(0);
  const [bootstrapReplicates, setBootstrapReplicates] = useState(1000);
  const [bootstrapTarget, setBootstrapTarget] = useState<"mean" | "median" | "stdDev">("mean");
  const [bootstrapOutputs, setBootstrapOutputs] = useState<any | null>(null);

  // Monte Carlo parameters
  const [initialCapital, setInitialCapital] = useState(10000);
  const [expectedReturn, setExpectedReturn] = useState(0.08);
  const [volatility, setVolatility] = useState(0.20);
  const [simulationDays, setSimulationDays] = useState(252);
  const [portfolioVarResult, setPortfolioVarResult] = useState<any | null>(null);
  const [samplePaths, setSamplePaths] = useState<number[][]>([]);

  // Selected bootstrap column vector
  const bootstrapVector = useMemo(() => {
    if (data.length === 0 || selectedCol >= headers.length) return [];
    return data.map((row) => row[selectedCol]);
  }, [data, selectedCol]);

  // Handle bootstrap resampling run
  const triggerBootstrap = () => {
    if (bootstrapVector.length === 0) return;

    let callbackFn = (s: number[]) => s.reduce((a, b) => a + b, 0) / s.length;
    if (bootstrapTarget === "median") {
      callbackFn = (s: number[]) => {
        const sorted = [...s].sort((a, b) => a - b);
        return sorted[Math.floor(sorted.length / 2)];
      };
    } else if (bootstrapTarget === "stdDev") {
      callbackFn = (s: number[]) => {
        const avg = s.reduce((a, b) => a + b, 0) / s.length;
        const vrSum = s.reduce((acc, v) => acc + Math.pow(v - avg, 2), 0);
        return Math.sqrt(vrSum / (s.length - 1)) || 0.0;
      };
    }

    const report = simulationEngine.bootstrap(bootstrapVector, callbackFn, bootstrapReplicates, 0.05);
    setBootstrapOutputs(report);
  };

  // Handle Monte Carlo portfolio run
  const triggerMonteCarlo = () => {
    const res = simulationEngine.portfolioMonteCarlo(
      initialCapital,
      expectedReturn,
      volatility,
      simulationDays,
      2000, // simulations
      0.95 // VaR level
    );
    setPortfolioVarResult(res);

    // Generate 5 visual paths to plot
    const pathways = simulationEngine.simulateGBM(
      simulationDays,
      initialCapital,
      expectedReturn,
      volatility,
      1.0 / 252.0,
      5
    );
    setSamplePaths(pathways);
  };

  // Bootstrap replicates histogram plot coordinates
  const replPlot = useMemo(() => {
    if (!bootstrapOutputs) return null;
    const reps = bootstrapOutputs.replicates as number[];
    const sorted = [...reps].sort((a,b)=>a-b);
    const min = sorted[0];
    const max = sorted[sorted.length - 1];
    const range = max - min || 1.0;

    const binCount = 12;
    const binWidth = range / binCount;
    const bins = Array(binCount).fill(0);

    for (const val of sorted) {
      let idx = Math.floor((val - min) / binWidth);
      if (idx >= binCount) idx = binCount - 1;
      if (idx < 0) idx = 0;
      bins[idx]++;
    }

    return {
      bins,
      min,
      max,
      maxBin: Math.max(...bins, 1),
    };
  }, [bootstrapOutputs]);

  // Monte Carlo path coordinates for SVG lines
  const pathsPlot = useMemo(() => {
    if (samplePaths.length === 0) return null;
    
    // Find absolute bounds over all paths to scale SVG
    let minCoord = Infinity;
    let maxCoord = -Infinity;
    for (const path of samplePaths) {
      for (const val of path) {
        if (val < minCoord) minCoord = val;
        if (val > maxCoord) maxCoord = val;
      }
    }
    const rangeY = maxCoord - minCoord || 1.0;

    const linePaths: string[][] = [];
    const n = simulationDays;

    for (const path of samplePaths) {
      const pts: string[] = [];
      for (let i = 0; i <= n; i++) {
        const sx = 40 + (i / n) * 420;
        const sy = 110 - ((path[i] - minCoord) / rangeY) * 90;
        pts.push(`${sx},${sy}`);
      }
      linePaths.push(pts);
    }

    return {
      linePaths,
      minCoord,
      maxCoord,
    };
  }, [samplePaths, simulationDays]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black pb-4">
        <div>
          <h2 className="text-lg font-bold uppercase tracking-tight text-black font-sans">
            Simulation & Resampling Engine
          </h2>
          <p className="text-xs font-mono text-black/70 mt-1">
            Conducts bootstrapping distributions and Monte Carlo portfolio risk valuations.
          </p>
        </div>

        <div className="flex gap-2">
          {(["bootstrap", "montecarlo"] as ModeType[]).map((mode) => (
            <button
              key={mode}
              onClick={() => setActiveSubMode(mode)}
              className={`text-xs px-3 py-1.5 rounded-none font-mono font-bold transition-colors cursor-pointer border ${
                activeSubMode === mode
                  ? "bg-black border-black text-[#E4E3E0] shadow-none"
                  : "bg-[#E4E3E0] border-black text-black hover:bg-[#D4D3D0] shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
              }`}
            >
              {mode.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {activeSubMode === "bootstrap" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
          {/* Controls */}
          <div className="bg-[#E4E3E0] border border-black p-5 rounded-none space-y-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <h3 className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold flex items-center gap-1.5 border-b border-black pb-2">
              <Sparkles className="w-4 h-4 text-black" /> Boot Parameters
            </h3>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-black/60 block font-mono text-[10px] font-bold">Select Data Vector:</label>
                <select
                  value={selectedCol}
                  onChange={(e) => setSelectedCol(Number(e.target.value))}
                  className="w-full text-xs font-mono border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] text-black font-bold focus:outline-hidden"
                >
                  {headers.map((h, i) => (
                    <option key={i} value={i}>Col {i}: {h}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1 bg-black/5 p-2 border border-black/20">
                <label className="text-black/60 block font-mono text-[10px] font-bold mb-1.5">Target Statistic (theta):</label>
                <div className="flex flex-col gap-1 text-[11px] text-black font-semibold">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      className="accent-black"
                      checked={bootstrapTarget === "mean"}
                      onChange={() => setBootstrapTarget("mean")}
                    />
                    Mean (Expected value)
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      className="accent-black"
                      checked={bootstrapTarget === "median"}
                      onChange={() => setBootstrapTarget("median")}
                    />
                    Median (50th percentile)
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      className="accent-black"
                      checked={bootstrapTarget === "stdDev"}
                      onChange={() => setBootstrapTarget("stdDev")}
                    />
                    SD (Standard Deviation)
                  </label>
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between font-mono text-[10px] text-black/60 font-bold">
                  <span>Replicates Number:</span>
                  <span className="font-extrabold">{bootstrapReplicates}</span>
                </div>
                <input
                  type="range"
                  min="200"
                  max="2000"
                  step="100"
                  value={bootstrapReplicates}
                  onChange={(e) => setBootstrapReplicates(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none accent-black appearance-none cursor-pointer"
                />
              </div>

              <button
                onClick={triggerBootstrap}
                className="w-full text-xs font-mono font-bold bg-black hover:bg-black/90 text-[#E4E3E0] rounded-none py-2 transition-colors cursor-pointer flex items-center justify-center gap-1.5 border border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-0.5"
              >
                Perform Resampling
              </button>
            </div>
          </div>

          {/* Results dashboard */}
          <div className="lg:col-span-2 space-y-4">
            {bootstrapOutputs ? (
              <div className="p-5 bg-[#E4E3E0] border border-black rounded-none space-y-3 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-1 border-b border-black pb-2 mb-2">
                  <BarChart className="w-4 h-4 text-black" /> Bootstrap Distribution of Replicates
                </h3>

                {replPlot && (
                  <div className="relative w-full h-32 bg-black/5 border border-black p-2.5 flex items-end">
                    <svg viewBox="0 0 500 120" className="w-full h-full" preserveAspectRatio="none">
                      {replPlot.bins.map((val, idx) => {
                        const totalBins = replPlot.bins.length;
                        const width = 400 / totalBins;
                        const gap = 3;
                        const height = (val / replPlot.maxBin) * 90;
                        const x = 50 + idx * width;
                        const y = 105 - height;
                        
                        return (
                          <rect
                            key={idx}
                            x={x + gap/2}
                            y={y}
                            width={width - gap}
                            height={height}
                            fill="#141414"
                            opacity="0.65"
                          />
                        );
                      })}
                      {/* Baseline */}
                      <line x1="40" y1="105" x2="470" y2="105" stroke="#141414" strokeWidth="1.5" />
                    </svg>
                  </div>
                )}

                <div className="flex justify-between text-[10px] text-black/60 font-mono font-bold uppercase pt-1">
                  <span>Rep Min: {replPlot?.min.toFixed(4)}</span>
                  <span>Rep Max: {replPlot?.max.toFixed(4)}</span>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs pt-3">
                  <div className="bg-black/5 p-3 rounded-none border border-black">
                    <span className="text-[10px] text-black/60 font-bold block">Original value</span>
                    <span className="text-sm text-black font-extrabold block mt-0.5">
                      {bootstrapOutputs.originalValue.toFixed(5)}
                    </span>
                  </div>
                  <div className="bg-black/5 p-3 rounded-none border border-black">
                    <span className="text-[10px] text-black/60 font-bold block">Estimated bias</span>
                    <span className="text-sm text-black font-extrabold block mt-0.5">
                      {bootstrapOutputs.bias.toFixed(6)}
                    </span>
                  </div>
                  <div className="bg-black/5 p-3 rounded-none border border-black">
                    <span className="text-[10px] text-black/60 font-bold block">Standard error</span>
                    <span className="text-sm text-black font-extrabold block mt-0.5">
                      {bootstrapOutputs.stdError.toFixed(5)}
                    </span>
                  </div>
                  <div className="bg-black/5 p-3 rounded-none border border-black">
                    <span className="text-[10px] text-black/60 font-bold block">Percentile CI (95%)</span>
                    <span className="text-sm text-amber-950 font-extrabold block mt-0.5 underline">
                      [{bootstrapOutputs.confidenceInterval[0].toFixed(3)}, {bootstrapOutputs.confidenceInterval[1].toFixed(3)}]
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-xs text-black/60 bg-black/5 border-2 border-dashed border-black/20 p-12 rounded-none text-center font-mono font-bold uppercase">
                No bootstrap runs simulated. Adjust parameters and click &quot;Perform Resampling&quot;.
              </div>
            )}
          </div>
        </div>
      )}

      {activeSubMode === "montecarlo" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
          {/* Controls */}
          <div className="bg-[#E4E3E0] border border-black p-5 rounded-none space-y-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <h3 className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold flex items-center gap-1.5 border-b border-black pb-2">
              <TrendingUp className="w-4 h-4 text-black" /> Portfolio Params
            </h3>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-black/60 block font-mono text-[10px] font-bold">Initial Investment ($):</label>
                <input
                  type="number"
                  step="1000"
                  value={initialCapital}
                  onChange={(e) => setInitialCapital(Math.max(100, Number(e.target.value)))}
                  className="w-full border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] font-mono font-bold focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-black/60 block font-mono text-[10px] font-bold">Expected Yearly returns (%):</label>
                <input
                  type="number"
                  step="0.01"
                  value={expectedReturn}
                  onChange={(e) => setExpectedReturn(Number(e.target.value))}
                  className="w-full border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] font-mono font-bold focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-black/60 block font-mono text-[10px] font-bold">Expected Volatility (σ):</label>
                <input
                  type="number"
                  step="0.01"
                  value={volatility}
                  onChange={(e) => setVolatility(Number(e.target.value))}
                  className="w-full border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] font-mono font-bold focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between font-mono text-[10px] text-black/60 font-bold">
                  <span>Timeline (Days):</span>
                  <span>{simulationDays}</span>
                </div>
                <input
                  type="range"
                  min="30"
                  max="500"
                  step="10"
                  value={simulationDays}
                  onChange={(e) => setSimulationDays(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none accent-black appearance-none cursor-pointer"
                />
              </div>

              <button
                onClick={triggerMonteCarlo}
                className="w-full text-xs font-mono font-bold bg-black hover:bg-black/90 text-[#E4E3E0] rounded-none py-2 transition-colors cursor-pointer flex items-center justify-center gap-1.5 border border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-0.5"
              >
                Simulate Risk
              </button>
            </div>
          </div>

          {/* Results display */}
          <div className="lg:col-span-2 space-y-4">
            {portfolioVarResult ? (
              <div className="p-5 bg-[#E4E3E0] border border-black rounded-none space-y-3 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-1 border-b border-black pb-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-black" /> GBM Stochastic Paths Projection (5 Paths)
                </h3>

                {pathsPlot && (
                  <div className="relative w-full h-40 bg-black/5 border border-black p-2.5 flex items-end">
                    <svg viewBox="0 0 500 120" className="w-full h-full" preserveAspectRatio="none">
                      {pathsPlot.linePaths.map((pts, pIdx) => {
                        const opacityVal = (1.0 - pIdx * 0.18).toFixed(2);
                        return (
                          <polyline
                            key={pIdx}
                            fill="none"
                            stroke="#141414"
                            strokeWidth={pIdx === 0 ? "2.5" : "1.2"}
                            strokeDasharray={pIdx % 2 === 1 ? "4 3" : undefined}
                            points={pts.join(" ")}
                            opacity={opacityVal}
                          />
                        );
                      })}
                    </svg>
                  </div>
                )}

                <div className="flex justify-between text-[10px] text-black/60 font-mono font-bold uppercase pt-1">
                  <span>S Min: ${pathsPlot?.minCoord.toLocaleString(undefined, { maximumFractionDigits: 1 })}</span>
                  <span>S Max: ${pathsPlot?.maxCoord.toLocaleString(undefined, { maximumFractionDigits: 1 })}</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs pt-3">
                  <div className="bg-black/5 p-3 rounded-none border border-red-950/40 border">
                    <span className="text-[10px] text-red-950 font-bold block">95% Value-at-Risk (VaR)</span>
                    <span className="text-sm text-amber-950 font-extrabold block mt-0.5">
                      ${portfolioVarResult.valueAtRisk.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="bg-black/5 p-3 rounded-none border border-black">
                    <span className="text-[10px] text-black/60 font-bold block">Mean Final Portfolio</span>
                    <span className="text-sm text-black font-extrabold block mt-0.5">
                      ${portfolioVarResult.meanFinalValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                    </span>
                  </div>
                  <div className="bg-black/5 p-3 rounded-none border border-red-950/45 border">
                    <span className="text-[10px] text-red-950 font-bold block">CVaR (Expected Shortfall)</span>
                    <span className="text-sm text-amber-950 font-extrabold block mt-0.5">
                      ${portfolioVarResult.expectedShortfall.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-black space-y-1.5 font-mono text-[11px] text-black">
                  <span className="text-[9px] uppercase font-bold text-black/60 tracking-wider block">Empirical Quantile Outcomes distribution</span>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-1 bg-black/5 p-2.5 border border-black/10 font-bold text-[10px]">
                    {Object.entries(portfolioVarResult.quantilesDistribution).map(([k, v]) => (
                      <span key={k}>{k}: <strong className="text-black font-extrabold">${(v as number).toLocaleString(undefined, { maximumFractionDigits: 0 })}</strong></span>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-xs text-black/60 bg-black/5 border-2 border-dashed border-black/20 p-12 rounded-none text-center font-mono font-bold uppercase">
                No portfolios simulated. Click &quot;Simulate Risk&quot; to compute Value-at-Risk profiles.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
