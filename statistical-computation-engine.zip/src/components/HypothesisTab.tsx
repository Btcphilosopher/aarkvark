/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { hypothesisTesting } from "../engine/main";
import { FileText, Radio, CheckSquare, ShieldCheck } from "lucide-react";

interface HypothesisTabProps {
  headers: string[];
  data: number[][];
}

type TestCategory = "t-test" | "anova" | "chi-square" | "correlation" | "nonparametric";

export function HypothesisTab({ headers, data }: HypothesisTabProps) {
  const [testCat, setTestCat] = useState<TestCategory>("t-test");
  
  // States below are customized for specific tests
  const [tTestType, setTTestType] = useState<"one-sample" | "two-sample" | "paired">("one-sample");
  const [mu0, setMu0] = useState(0);
  const [alpha, setAlpha] = useState(0.05);
  const [col1Idx, setCol1Idx] = useState(0);
  const [col2Idx, setCol2Idx] = useState(1);
  const [corrType, setCorrType] = useState<"pearson" | "spearman">("pearson");
  const [nonparType, setNonparType] = useState<"mann-whitney" | "wilcoxon-signed">("mann-whitney");

  // Run the selected test and retrieve the report
  const testReport = useMemo(() => {
    if (data.length === 0 || col1Idx >= headers.length) return null;

    try {
      const v1 = data.map((row) => row[col1Idx]);
      const v2 = col2Idx < headers.length ? data.map((row) => row[col2Idx]) : [];

      if (testCat === "t-test") {
        if (tTestType === "one-sample") {
          return hypothesisTesting.oneSampleTTest(v1, mu0, alpha);
        } else if (tTestType === "two-sample") {
          return hypothesisTesting.twoSampleTTest(v1, v2, false, alpha);
        } else {
          return hypothesisTesting.pairedTTest(v1, v2, alpha);
        }
      }

      if (testCat === "correlation") {
        return hypothesisTesting.correlationTest(v1, v2, corrType, alpha);
      }

      if (testCat === "nonparametric") {
        if (nonparType === "mann-whitney") {
          return hypothesisTesting.mannWhitneyUTest(v1, v2, alpha);
        } else {
          return hypothesisTesting.wilcoxonSignedRankTest(v1, v2, alpha);
        }
      }

      if (testCat === "anova") {
        // One-Way ANOVA: We can split v1 (predictor score) based on a categorical grouper v2 (discrete codings e.g. 0, 1, 2)
        // Group raw scores based on group values
        const uniqueGroups = Array.from(new Set(v2));
        if (uniqueGroups.length < 2) {
          return { error: "One-Way ANOVA grouper column (selected as Col 2) must contain at least 2 distinct groups." };
        }
        const blocks: number[][] = uniqueGroups.map((gVal) => {
          const groupScores: number[] = [];
          for (let i = 0; i < data.length; i++) {
            if (data[i][col2Idx] === gVal) {
              groupScores.push(data[i][col1Idx]);
            }
          }
          return groupScores;
        });
        return hypothesisTesting.oneWayANOVA(blocks, alpha);
      }

      if (testCat === "chi-square") {
        // Chi-Square Test of Independence on a 2D contingency table
        // We'll cross-tabulate Col 1 and Col 2. For simplicity, we round continuous columns to integers to form categories!
        const cat1 = v1.map((v) => Math.round(v));
        const cat2 = v2.map((v) => Math.round(v));
        
        const set1 = Array.from(new Set(cat1)).sort((a,b)=>a-b).slice(0, 5); // limit categories to prevent explode
        const set2 = Array.from(new Set(cat2)).sort((a,b)=>a-b).slice(0, 5);

        if (set1.length < 2 || set2.length < 2) {
          return { error: "Chi-Square Independence requires both columns to have at least 2 distinct rounded categories." };
        }

        const contingency: number[][] = Array.from({ length: set1.length }, () => Array(set2.length).fill(0));
        for (let i = 0; i < cat1.length; i++) {
          const idx1 = set1.indexOf(cat1[i]);
          const idx2 = set2.indexOf(cat2[i]);
          if (idx1 !== -1 && idx2 !== -1) {
            contingency[idx1][idx2]++;
          }
        }
        return hypothesisTesting.chiSquareIndependence(contingency, alpha);
      }

      return null;
    } catch (err: any) {
      return { error: err.message || "Numerical / group testing error." };
    }
  }, [testCat, tTestType, mu0, alpha, col1Idx, col2Idx, corrType, nonparType, headers, data]);

  if (headers.length === 0 || data.length === 0) {
    return (
      <div className="p-8 text-center text-gray-400 font-sans">
        Hypothesis testing requires tabular data to be loaded first.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black pb-4">
        <div>
          <h2 className="text-lg font-bold uppercase tracking-tight text-black font-sans">
            Hypothesis Testing Engine
          </h2>
          <p className="text-xs text-black/70 mt-1 font-mono">
            Validates statistical variations, correlations, cross-tabs, and non-parametric shifts.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          {(["t-test", "anova", "chi-square", "correlation", "nonparametric"] as TestCategory[]).map((cat) => (
            <button
              key={cat}
              onClick={() => setTestCat(cat)}
              className={`text-xs px-3 py-1.5 rounded-none font-mono font-bold transition-colors cursor-pointer border ${
                testCat === cat
                  ? "bg-black border-black text-[#E4E3E0] shadow-none"
                  : "bg-[#E4E3E0] border-black text-black hover:bg-[#D4D3D0] shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
              }`}
            >
              {cat.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Settings Panel */}
        <div className="bg-[#E4E3E0] border border-black p-5 rounded-none space-y-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <h3 className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold flex items-center gap-1.5 border-b border-black pb-2">
            <ShieldCheck className="w-4 h-4 text-black" /> Test Configuration
          </h3>

          <div className="space-y-3 text-xs font-sans">
            {/* Column Selections */}
            <div className="space-y-1">
              <label className="text-black/60 block font-mono text-[10px] font-bold">Select Vector 1:</label>
              <select
                value={col1Idx}
                onChange={(e) => setCol1Idx(Number(e.target.value))}
                className="w-full text-xs font-mono border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] text-black font-bold focus:outline-hidden"
              >
                {headers.map((h, i) => (
                  <option key={i} value={i}>Col {i}: {h}</option>
                ))}
              </select>
            </div>

            {testCat !== "t-test" || tTestType !== "one-sample" ? (
              <div className="space-y-1">
                <label className="text-black/60 block font-mono text-[10px] font-bold">
                  {testCat === "anova" ? "Grouper Column (Discrete codes):" : "Select Vector 2:"}
                </label>
                <select
                  value={col2Idx}
                  onChange={(e) => setCol2Idx(Number(e.target.value))}
                  className="w-full text-xs font-mono border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] text-black font-bold focus:outline-hidden"
                >
                  {headers.map((h, i) => (
                    <option key={i} value={i}>Col {i}: {h}</option>
                  ))}
                </select>
              </div>
            ) : null}

            {/* If T-test subgroup select */}
            {testCat === "t-test" && (
              <div className="pt-2 border-t border-black space-y-2">
                <label className="text-black/60 block font-mono text-[10px] font-bold">T-Test Variant:</label>
                <div className="flex flex-col gap-1 text-[11px] font-mono font-semibold text-black">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      checked={tTestType === "one-sample"}
                      onChange={() => setTTestType("one-sample")}
                      className="accent-black"
                    />
                    One-Sample vs. Null Mean (μ₀)
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      checked={tTestType === "two-sample"}
                      onChange={() => setTTestType("two-sample")}
                      className="accent-black"
                    />
                    Two-Sample Unpaired Welch
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      checked={tTestType === "paired"}
                      onChange={() => setTTestType("paired")}
                      className="accent-black"
                    />
                    Paired Samples
                  </label>
                </div>

                {tTestType === "one-sample" && (
                  <div className="pt-2 space-y-1">
                    <label className="text-black/60 block font-mono text-[10px] font-bold">Null Hypothesis Mean (μ₀):</label>
                    <input
                      type="number"
                      step="any"
                      value={mu0}
                      onChange={(e) => setMu0(Number(e.target.value))}
                      className="w-full border border-black rounded-none px-2 py-1.5 font-mono bg-[#E4E3E0] text-black font-bold focus:outline-hidden"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Correlation type select */}
            {testCat === "correlation" && (
              <div className="pt-2 border-t border-black space-y-1">
                <label className="text-black/60 block font-mono text-[10px] font-bold">Method Coefficient:</label>
                <select
                  value={corrType}
                  onChange={(e) => setCorrType(e.target.value as any)}
                  className="w-full border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] text-black font-bold font-mono focus:outline-hidden"
                >
                  <option value="pearson">Pearson Product-Moment (r)</option>
                  <option value="spearman">Spearman Rank Transformation (ρ)</option>
                </select>
              </div>
            )}

            {/* Nonparametric selects */}
            {testCat === "nonparametric" && (
              <div className="pt-2 border-t border-black space-y-2">
                <label className="text-black/60 block font-mono text-[10px] font-bold">Wilcoxon Type:</label>
                <div className="flex flex-col gap-1 text-[11px] font-mono font-semibold text-black">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      checked={nonparType === "mann-whitney"}
                      onChange={() => setNonparType("mann-whitney")}
                      className="accent-black"
                    />
                    Mann-Whitney U (Independent)
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      checked={nonparType === "wilcoxon-signed"}
                      onChange={() => setNonparType("wilcoxon-signed")}
                      className="accent-black"
                    />
                    Wilcoxon Signed-Rank (Paired)
                  </label>
                </div>
              </div>
            )}

            {/* Alpha select slider */}
            <div className="pt-2 border-t border-black space-y-1">
              <div className="flex justify-between font-mono text-[10px] text-black font-bold">
                <span>Significance Level (α):</span>
                <span>{alpha.toFixed(3)}</span>
              </div>
              <input
                type="range"
                min="0.005"
                max="0.2"
                step="0.005"
                value={alpha}
                onChange={(e) => setAlpha(Number(e.target.value))}
                className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
              />
            </div>
          </div>
        </div>

        {/* Results Report Canvas */}
        <div className="lg:col-span-2">
          {testReport && "error" in testReport ? (
            <div className="p-4 bg-amber-950 border border-black text-amber-200 rounded-none text-xs font-mono font-bold">
              <strong>Selection Warning:</strong> {testReport.error}
            </div>
          ) : testReport ? (
            <div className="bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] overflow-hidden space-y-4">
              <div className="px-5 py-4 bg-black text-[#E4E3E0] border-b border-black flex justify-between items-center">
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#E4E3E0]" /> Statistical Inference Report
                </h3>
                <span className={`text-[10px] font-mono px-2 py-0.5 border font-bold uppercase ${
                  testReport.isSignificant ? "bg-amber-950 border-black text-amber-200" : "bg-black/20 border-black text-black"
                }`}>
                  {testReport.isSignificant ? "Significant Reject H₀" : "Fail to Reject H₀"}
                </span>
              </div>

              <div className="p-5 space-y-5 font-mono">
                {/* Method Name */}
                <div>
                  <h4 className="text-[10px] font-bold text-black/60 uppercase tracking-widest">Statistical Method</h4>
                  <p className="text-md font-bold text-black mt-0.5">{testReport.testName}</p>
                </div>

                {/* Core Hypothesis statements */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-black/5 p-4 rounded-none border border-black text-xs">
                  <div>
                    <span className="text-[10px] uppercase text-black/60 font-bold block">Null Hypothesis (H₀)</span>
                    <span className="text-black mt-1 block leading-relaxed font-semibold">{testReport.nullHypothesis}</span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-black/60 font-bold block">Alternative Hypothesis (H₁)</span>
                    <span className="text-black mt-1 block leading-relaxed font-semibold">{testReport.alternativeHypothesis}</span>
                  </div>
                </div>

                {/* Analytical Numbers Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-black">
                  <div className="bg-black/5 p-4 rounded-none border border-black">
                    <span className="text-[9px] text-black/60 uppercase font-bold block">{testReport.statisticName} statistic</span>
                    <span className="text-base text-black font-bold mt-1 block">
                      {testReport.statistic.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                    </span>
                  </div>

                  <div className="bg-black/5 p-4 rounded-none border border-black">
                    <span className="text-[9px] text-black/60 uppercase font-bold block">Calculated p-value</span>
                    <span className={`text-base font-bold mt-1 block ${testReport.pValue < alpha ? "text-amber-800" : "text-black"}`}>
                      {testReport.pValue < 1e-5 ? "< 0.00001" : testReport.pValue.toLocaleString(undefined, { maximumFractionDigits: 6 })}
                    </span>
                  </div>

                  <div className="bg-black/5 p-4 rounded-none border border-black">
                    <span className="text-[9px] text-black/60 uppercase font-bold block">Degrees of Freedom</span>
                    <span className="text-base text-black font-bold mt-1 block">
                      {testReport.df !== undefined ? testReport.df.toLocaleString(undefined, { maximumFractionDigits: 2 }) : "N/A"}
                    </span>
                  </div>

                  <div className="bg-black/5 p-4 rounded-none border border-black">
                    <span className="text-[9px] text-black/60 uppercase font-bold block">alpha boundary (α)</span>
                    <span className="text-base text-black font-bold mt-1 block">
                      {testReport.alpha}
                    </span>
                  </div>
                </div>

                {/* Dynamic analytical conclusion text */}
                <div className="p-4 rounded-none text-xs leading-relaxed border border-black font-mono font-semibold bg-black/5 text-black">
                  <p>
                    <strong>Conclusion:</strong> Since the computed p-value (<strong>{testReport.pValue.toLocaleString(undefined, { maximumFractionDigits: 6 })}</strong>)
                    is {testReport.isSignificant ? "less" : "greater"} than the significance threshold α (<strong>{testReport.alpha}</strong>),
                    we {testReport.isSignificant ? "REJECT the null hypothesis" : "FAIL TO REJECT the null hypothesis"}. There is
                    {" "}{testReport.isSignificant ? "strong, statistically sound evidence in favor of the alternative hypothesis." : "insufficient evidence to conclude that the variations are statistically significant."}
                  </p>
                </div>

                {/* Additional parameters dump */}
                {testReport.additionalInfo && (
                  <div className="pt-2">
                    <span className="text-[10px] text-black/60 uppercase font-bold block mb-1">Detailed parameters (Engine Output)</span>
                    <div className="flex flex-wrap gap-x-6 gap-y-2 text-[10.5px] text-black/80 bg-black/5 p-3 rounded-none border border-black leading-relaxed">
                      {Object.entries(testReport.additionalInfo).map(([k, v]) => (
                        <span key={k}>
                          <strong>{k}</strong>:{" "}
                          {Array.isArray(v)
                            ? `[${v.map((item) => typeof item === "number" ? item.toFixed(4) : item).join(", ")}]`
                            : typeof v === "number"
                            ? v.toFixed(5)
                            : String(v)}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
