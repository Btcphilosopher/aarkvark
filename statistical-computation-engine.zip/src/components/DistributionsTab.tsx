/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { distributions } from "../engine/main";
import { Sparkles } from "lucide-react";

type DistType = "normal" | "lognormal" | "binomial" | "poisson" | "exponential" | "gamma";

export function DistributionsTab() {
  const [distType, setDistType] = useState<DistType>("normal");
  
  // Parameter states
  const [normMean, setNormMean] = useState(0);
  const [normSD, setNormSD] = useState(1);
  const [logmu, setLogmu] = useState(0);
  const [logsigma, setLogsigma] = useState(0.5);
  const [binomN, setBinomN] = useState(20);
  const [binomP, setBinomP] = useState(0.5);
  const [poisLambda, setPoisLambda] = useState(5.0);
  const [expLambda, setExpLambda] = useState(1.0);
  const [gammaShape, setGammaShape] = useState(2.0);
  const [gammaScale, setGammaScale] = useState(2.0);

  // Calculation coordinates states
  const [evalX, setEvalX] = useState("1.0");
  const [sampledData, setSampledData] = useState<number[]>([]);

  // Calculate PDF/CDF at specific input coordinate
  const coordinateInference = useMemo(() => {
    const x = parseFloat(evalX);
    if (isNaN(x)) return { pdf: NaN, cdf: NaN };

    switch (distType) {
      case "normal":
        return {
          pdf: distributions.NormalMode.pdf(x, normMean, normSD),
          cdf: distributions.NormalMode.cdf(x, normMean, normSD),
        };
      case "lognormal":
        return {
          pdf: distributions.LognormalMode.pdf(x, logmu, logsigma),
          cdf: distributions.LognormalMode.cdf(x, logmu, logsigma),
        };
      case "binomial":
        return {
          pdf: distributions.BinomialMode.pdf(Math.round(x), binomN, binomP),
          cdf: distributions.BinomialMode.cdf(x, binomN, binomP),
        };
      case "poisson":
        return {
          pdf: distributions.PoissonMode.pdf(Math.round(x), poisLambda),
          cdf: distributions.PoissonMode.cdf(x, poisLambda),
        };
      case "exponential":
        return {
          pdf: distributions.ExponentialMode.pdf(x, expLambda),
          cdf: distributions.ExponentialMode.cdf(x, expLambda),
        };
      case "gamma":
        return {
          pdf: distributions.GammaMode.pdf(x, gammaShape, gammaScale),
          cdf: distributions.GammaMode.cdf(x, gammaShape, gammaScale),
        };
    }
  }, [distType, evalX, normMean, normSD, logmu, logsigma, binomN, binomP, poisLambda, expLambda, gammaShape, gammaScale]);

  // Generate stochastic samples
  const triggerSampling = () => {
    const draws: number[] = [];
    const count = 100;
    
    for (let i = 0; i < count; i++) {
      let sampleVal = 0;
      switch (distType) {
        case "normal":
          sampleVal = distributions.NormalMode.sample(normMean, normSD);
          break;
        case "lognormal":
          sampleVal = distributions.LognormalMode.sample(logmu, logsigma);
          break;
        case "binomial":
          sampleVal = distributions.BinomialMode.sample(binomN, binomP);
          break;
        case "poisson":
          sampleVal = distributions.PoissonMode.sample(poisLambda);
          break;
        case "exponential":
          sampleVal = distributions.ExponentialMode.sample(expLambda);
          break;
        case "gamma":
          sampleVal = distributions.GammaMode.sample(gammaShape, gammaScale);
          break;
      }
      if (!isNaN(sampleVal)) {
        draws.push(sampleVal);
      }
    }
    setSampledData(draws);
  };

  // Compute PDF curves lines for dynamic drawing
  const plottableCurves = useMemo(() => {
    let start = -4;
    let end = 4;
    let isDiscrete = false;

    // determine domains
    switch (distType) {
      case "normal":
        start = normMean - 3 * normSD;
        end = normMean + 3 * normSD;
        break;
      case "lognormal":
        start = 0.01;
        end = Math.exp(logmu + 3 * logsigma);
        break;
      case "binomial":
        start = 0;
        end = binomN;
        isDiscrete = true;
        break;
      case "poisson":
        start = 0;
        end = Math.ceil(poisLambda + 3 * Math.sqrt(poisLambda));
        isDiscrete = true;
        break;
      case "exponential":
        start = 0;
        end = 4 / expLambda;
        break;
      case "gamma":
        start = 0.01;
        end = gammaShape * gammaScale + 3 * Math.sqrt(gammaShape) * gammaScale;
        break;
    }

    const diff = end - start;
    const steps = 100;
    const pdfPoints: { x: number; y: number }[] = [];
    const cdfPoints: { x: number; y: number }[] = [];

    if (isDiscrete) {
      const discreteLimit = Math.floor(end);
      for (let k = Math.floor(start); k <= discreteLimit; k++) {
        let pdf = 0;
        let cdf = 0;
        if (distType === "binomial") {
          pdf = distributions.BinomialMode.pdf(k, binomN, binomP);
          cdf = distributions.BinomialMode.cdf(k, binomN, binomP);
        } else if (distType === "poisson") {
          pdf = distributions.PoissonMode.pdf(k, poisLambda);
          cdf = distributions.PoissonMode.cdf(k, poisLambda);
        }
        pdfPoints.push({ x: k, y: pdf });
        cdfPoints.push({ x: k, y: cdf });
      }
    } else {
      for (let i = 0; i <= steps; i++) {
        const x = start + (pct => pct * diff)(i / steps);
        let pdf = 0;
        let cdf = 0;

        if (distType === "normal") {
          pdf = distributions.NormalMode.pdf(x, normMean, normSD);
          cdf = distributions.NormalMode.cdf(x, normMean, normSD);
        } else if (distType === "lognormal") {
          pdf = distributions.LognormalMode.pdf(x, logmu, logsigma);
          cdf = distributions.LognormalMode.cdf(x, logmu, logsigma);
        } else if (distType === "exponential") {
          pdf = distributions.ExponentialMode.pdf(x, expLambda);
          cdf = distributions.ExponentialMode.cdf(x, expLambda);
        } else if (distType === "gamma") {
          pdf = distributions.GammaMode.pdf(x, gammaShape, gammaScale);
          cdf = distributions.GammaMode.cdf(x, gammaShape, gammaScale);
        }

        if (!isNaN(pdf) && !isNaN(cdf)) {
          pdfPoints.push({ x, y: pdf });
          cdfPoints.push({ x, y: cdf });
        }
      }
    }

    return {
      pdfPoints,
      cdfPoints,
      start,
      end,
      isDiscrete,
    };
  }, [distType, normMean, normSD, logmu, logsigma, binomN, binomP, poisLambda, expLambda, gammaShape, gammaScale]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black pb-4">
        <div>
          <h2 className="text-lg font-bold uppercase tracking-tight text-black font-sans">
            Distribution Engine Workspace
          </h2>
          <p className="text-xs text-black/70 mt-1 font-mono">
            Visualizes and samples continuous and discrete probability distributions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold">Select Distribution:</label>
          <select
            value={distType}
            onChange={(e) => {
              const val = e.target.value as DistType;
              setDistType(val);
              // Set defaults to match distributions
              if (val === "normal") setEvalX("1.0");
              else if (val === "binomial") setEvalX("10");
              else if (val === "poisson") setEvalX("5");
              else setEvalX("2.0");
              setSampledData([]);
            }}
            className="text-xs font-mono border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] text-black shadow-none focus:outline-hidden font-bold"
          >
            <option value="normal">Normal (Gaussian)</option>
            <option value="lognormal">Lognormal</option>
            <option value="binomial">Binomial (Discrete)</option>
            <option value="poisson">Poisson (Discrete)</option>
            <option value="exponential">Exponential</option>
            <option value="gamma">Gamma</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Parameters Sliders Panel */}
        <div className="bg-[#E4E3E0] border border-black p-5 rounded-none space-y-5 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <h3 className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold">
            Distribution Parameters
          </h3>

          {distType === "normal" && (
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Mean (μ): {normMean}</span>
                </div>
                <input
                  type="range"
                  min="-10"
                  max="10"
                  step="1"
                  value={normMean}
                  onChange={(e) => setNormMean(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Std Dev (σ): {normSD}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="5"
                  step="0.1"
                  value={normSD}
                  onChange={(e) => setNormSD(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
            </div>
          )}

          {distType === "lognormal" && (
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Meanlog (μ_log): {logmu}</span>
                </div>
                <input
                  type="range"
                  min="-3"
                  max="3"
                  step="0.1"
                  value={logmu}
                  onChange={(e) => setLogmu(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Sdlog (σ_log): {logsigma}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="2"
                  step="0.1"
                  value={logsigma}
                  onChange={(e) => setLogsigma(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
            </div>
          )}

          {distType === "binomial" && (
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Trials (n): {binomN}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="100"
                  step="1"
                  value={binomN}
                  onChange={(e) => setBinomN(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Probability (p): {binomP.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min="0.01"
                  max="0.99"
                  step="0.01"
                  value={binomP}
                  onChange={(e) => setBinomP(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
            </div>
          )}

          {distType === "poisson" && (
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Rate (λ): {poisLambda}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="25"
                  step="0.5"
                  value={poisLambda}
                  onChange={(e) => setPoisLambda(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
            </div>
          )}

          {distType === "exponential" && (
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Rate (λ): {expLambda}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="5"
                  step="0.1"
                  value={expLambda}
                  onChange={(e) => setExpLambda(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
            </div>
          )}

          {distType === "gamma" && (
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Shape (k): {gammaShape}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="10"
                  step="0.1"
                  value={gammaShape}
                  onChange={(e) => setGammaShape(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono text-black font-bold">
                  <span>Scale (θ): {gammaScale}</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="5"
                  step="0.1"
                  value={gammaScale}
                  onChange={(e) => setGammaScale(Number(e.target.value))}
                  className="w-full h-1.5 bg-black/10 rounded-none appearance-none cursor-pointer accent-black"
                />
              </div>
            </div>
          )}

          {/* Coordinate Evaluator */}
          <div className="pt-4 border-t border-black">
            <h4 className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold mb-2">
              Coordinate Inference
            </h4>
            <div className="flex items-center gap-2">
              <input
                type="number"
                step="any"
                value={evalX}
                onChange={(e) => setEvalX(e.target.value)}
                className="w-full text-xs font-mono border border-black rounded-none px-2.5 py-1.5 focus:outline-hidden bg-[#E4E3E0] font-bold text-black"
                placeholder="Value X"
              />
            </div>
            
            <div className="mt-3 font-mono text-xs space-y-1 bg-black/5 p-3 rounded-none border border-black">
              <div className="flex justify-between text-black/60">
                <span>PDF (Density / PMF):</span>
                <span className="text-black font-bold">
                  {coordinateInference.pdf.toLocaleString(undefined, { maximumFractionDigits: 6 })}
                </span>
              </div>
              <div className="flex justify-between text-black/60">
                <span>Cumulative CDF:</span>
                <span className="text-black font-bold">
                  {coordinateInference.cdf.toLocaleString(undefined, { maximumFractionDigits: 6 })}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic PDF Plotting Panel */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-5 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <h3 className="text-xs font-mono font-bold text-black mb-3 uppercase tracking-wider">
              Probability Density Function (PDF / PMF)
            </h3>
            
            <div className="relative w-full h-52 bg-black/5 border border-black p-2 flex items-end">
              <svg viewBox="0 0 500 160" className="w-full h-full" preserveAspectRatio="none">
                {(() => {
                  const pts = plottableCurves.pdfPoints;
                  if (pts.length === 0) return null;

                  const maxY = Math.max(...pts.map((p) => p.y), 0.01);
                  const minX = plottableCurves.start;
                  const maxX = plottableCurves.end;

                  if (plottableCurves.isDiscrete) {
                    // discrete distribution: render bar heights
                    return pts.map((pt, idx) => {
                      const screenX = 50 + ((pt.x - minX) / (maxX - minX || 1)) * 400;
                      const height = (pt.y / maxY) * 120;
                      const screenY = 140 - height;
                      return (
                        <g key={idx} className="group">
                          <line
                            x1={screenX}
                            y1="140"
                            x2={screenX}
                            y2={screenY}
                            stroke="#141414"
                            strokeWidth="3.5"
                            strokeLinecap="square"
                          />
                          <circle cx={screenX} cy={screenY} r="3" fill="#141414" />
                          <title>{`X = ${pt.x}, PMF = ${pt.y.toFixed(5)}`}</title>
                        </g>
                      );
                    });
                  } else {
                    const polyPoints: string[] = [];
                    const shadedPoints: string[] = [`50,140`];
                    
                    for (const pt of pts) {
                      const screenX = 50 + ((pt.x - minX) / (maxX - minX || 1)) * 400;
                      const screenY = 140 - (pt.y / maxY) * 120;
                      if (!isNaN(screenY) && screenY <= 140) {
                        polyPoints.push(`${screenX},${screenY}`);
                        shadedPoints.push(`${screenX},${screenY}`);
                      }
                    }
                    shadedPoints.push(`450,140`);

                    return (
                      <>
                        <polygon
                          points={shadedPoints.join(" ")}
                          fill="#C4C3C0"
                          opacity="0.4"
                        />
                        <polyline
                          fill="none"
                          stroke="#141414"
                          strokeWidth="3"
                          points={polyPoints.join(" ")}
                        />
                      </>
                    );
                  }
                })()}

                {/* Baseline */}
                <line x1="40" y1="140" x2="465" y2="140" stroke="#141414" strokeWidth="2" />
              </svg>
            </div>
            
            <div className="flex justify-between text-[10px] font-mono text-black mt-2">
              <span>Domain lower: {plottableCurves.start.toFixed(2)}</span>
              <span>Domain upper: {plottableCurves.end.toFixed(2)}</span>
            </div>
          </div>

          {/* Random Sampling Simulator */}
          <div className="p-5 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <div className="flex items-center justify-between border-b border-black pb-3 mb-4">
              <h3 className="text-xs font-mono font-bold text-black uppercase tracking-wider">
                Stochastic Sampler Simulation
              </h3>
              <button
                onClick={triggerSampling}
                className="text-xs font-sans font-bold bg-black text-[#E4E3E0] rounded-none px-3 py-1.5 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:bg-[#1C1C1C] transition-colors flex items-center gap-1.5 cursor-pointer border border-black"
              >
                Draw 100 Samples
              </button>
            </div>

            {sampledData.length > 0 ? (
              <div className="space-y-3">
                <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto leading-relaxed border border-black p-3 rounded-none bg-black/5 font-mono text-[10px]">
                  {sampledData.map((val, idx) => (
                    <span key={idx} className="bg-[#E4E3E0] border border-black rounded-none px-1.5 py-0.5 text-black font-bold">
                      {val.toLocaleString(undefined, { maximumFractionDigits: 4 })}
                    </span>
                  ))}
                </div>
                <div className="text-xs text-black/60 space-x-4 flex font-mono font-bold">
                  <span>Generated mean: (<strong>{(sampledData.reduce((a,b)=>a+b,0)/sampledData.length).toFixed(4)}</strong>)</span>
                  <span>Generated SD: (<strong>{Math.sqrt(sampledData.reduce((acc, v)=>acc+Math.pow(v-(sampledData.reduce((a,b)=>a+b,0)/sampledData.length),2),0)/(sampledData.length-1)).toFixed(4)}</strong>)</span>
                </div>
              </div>
            ) : (
              <p className="text-xs text-black/60 bg-black/5 border border-dashed border-black p-6 rounded-none text-center font-mono font-bold">
                No active stochastic draws generated yet. Click &quot;Draw 100 Samples&quot; to test.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
