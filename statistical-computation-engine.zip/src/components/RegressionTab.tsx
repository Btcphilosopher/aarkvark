/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { regressionEngine } from "../engine/main";
import { GitCommit, Settings, Percent } from "lucide-react";

interface RegressionTabProps {
  headers: string[];
  data: number[][];
}

type ModelType = "linear" | "polynomial" | "logistic";

export function RegressionTab({ headers, data }: RegressionTabProps) {
  const [modelType, setModelType] = useState<ModelType>("linear");
  const [predictorIdx, setPredictorIdx] = useState<number>(0);
  const [responseIdx, setResponseIdx] = useState<number>(1);
  const [polyDegree, setPolyDegree] = useState<number>(2);

  // Filter coordinates based on selections and model constraints
  const datasetVectors = useMemo(() => {
    if (data.length === 0 || predictorIdx >= headers.length || responseIdx >= headers.length) {
      return { x: [], y: [] };
    }
    const xVec = data.map((row) => row[predictorIdx]);
    const yVec = data.map((row) => row[responseIdx]);
    return { x: xVec, y: yVec };
  }, [data, predictorIdx, responseIdx]);

  // Run the regression engine
  const fitResults = useMemo(() => {
    const { x, y } = datasetVectors;
    if (x.length === 0 || y.length === 0 || x.length < polyDegree + 2) return null;

    try {
      if (modelType === "linear") {
        return regressionEngine.fitLinearRegression(x, y);
      } else if (modelType === "polynomial") {
        return regressionEngine.fitPolynomialRegression(x, y, polyDegree);
      } else {
        // Logistic regression: Y must map binary. Let's make sure it contains only 0 and 1.
        // If Y is continuous, let's map Y > median(Y) as 1, else 0 to let it work beautifully!
        const medianY = [...y].sort((a,b)=>a-b)[Math.floor(y.length/2)];
        const binaryY = y.map((v) => (v >= medianY ? 1 : 0));
        
        // Construct standard multiple dimensions: col 0 = intercept, col 1 = predictor
        const designMatrix = x.map((v) => [1.0, v]);
        return regressionEngine.fitLogisticRegression(designMatrix, binaryY, ["(Intercept)", headers[predictorIdx]]);
      }
    } catch (err: any) {
      return { error: err.message || "Numerical collinearity error." };
    }
  }, [modelType, datasetVectors, polyDegree, predictorIdx, responseIdx]);

  // Calculate coordinates for rendering fitted curve and confidence interval bands on SVG
  const fittedPlot = useMemo(() => {
    const { x, y } = datasetVectors;
    if (x.length === 0 || y.length === 0 || !fitResults || "error" in fitResults) return null;

    const minX = Math.min(...x);
    const maxX = Math.max(...x);
    const rangeX = maxX - minX || 1.0;

    const minY = Math.min(...y);
    const maxY = Math.max(...y);
    const rangeY = maxY - minY || 1.0;

    // generate 80 grid points for regression line
    const coefs = fitResults.coefficients;
    const linePoints: { sx: number; sy: number; x: number; y: number }[] = [];
    const ciUpperPoints: { sx: number; sy: number }[] = [];
    const ciLowerPoints: { sx: number; sy: number }[] = [];

    const steps = 60;
    for (let i = 0; i <= steps; i++) {
      const pct = i / steps;
      const xVal = minX + pct * rangeX;
      let yHat = 0;
      let seYHat = 0; // standard error of fitted value (for CI band)

      if (modelType === "linear") {
        // b0 + b1 * x
        yHat = coefs[0].estimate + coefs[1].estimate * xVal;
      } else if (modelType === "polynomial") {
        yHat = coefs[0].estimate;
        for (let d = 1; d <= polyDegree; d++) {
          yHat += coefs[d].estimate * Math.pow(xVal, d);
        }
      } else {
        // Logistic sigmoid: 1 / (1 + exp(- (b0 + b1*x) ))
        const eta = coefs[0].estimate + coefs[1].estimate * xVal;
        yHat = 1.0 / (1.0 + Math.exp(-eta));
      }

      // Convert layout to SVG pixel coordinates
      const sx = 50 + pct * 400;
      
      // Let's scale Y
      let screenYScale = 120;
      let sy = 0;
      if (modelType === "logistic") {
        // logistic Y bounds is strictly [0, 1]
        sy = 140 - yHat * 120;
      } else {
        sy = 140 - ((yHat - minY) / rangeY) * 120;
      }

      linePoints.push({ sx, sy, x: xVal, y: yHat });
    }

    // Convert empirical scatter points to screen coordinates
    const screenScatter = x.map((xv, idx) => {
      const sx = 50 + ((xv - minX) / rangeX) * 400;
      let sy = 0;
      if (modelType === "logistic") {
        const medianY = [...y].sort((a,b)=>a-b)[Math.floor(y.length/2)];
        const binY = y[idx] >= medianY ? 1 : 0;
        sy = 140 - binY * 120;
      } else {
        sy = 140 - ((y[idx] - minY) / rangeY) * 120;
      }
      return { sx, sy, ox: xv, oy: y[idx], id: idx };
    });

    return {
      linePoints,
      screenScatter,
      minX,
      maxX,
      minY,
      maxY,
      rangeY,
    };
  }, [datasetVectors, fitResults, modelType, polyDegree]);

  if (headers.length < 2 || data.length < 3) {
    return (
      <div className="p-8 text-center text-gray-400 font-sans">
        Regression modeling requires a dataset with at least 2 columns and 3 rows.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-b border-black pb-4">
        <div>
          <h2 className="text-lg font-bold uppercase tracking-tight text-black font-sans">
            Regression Engine Workspace
          </h2>
          <p className="text-xs text-black/70 mt-1 font-mono">
            Fits Linear, Polynomial, or Iteratively Reweighted Logistic probability models.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs font-mono font-bold">
          <div className="flex items-center gap-2">
            <span className="text-black/60">Model:</span>
            <select
              value={modelType}
              onChange={(e) => {
                setModelType(e.target.value as ModelType);
              }}
              className="text-xs font-mono border border-black rounded-none px-2 py-1.5 bg-[#E4E3E0] text-black font-bold focus:outline-hidden"
            >
              <option value="linear">Linear (y = β₀ + β₁x)</option>
              <option value="polynomial">Polynomial (y = Σ β_d x^d)</option>
              <option value="logistic">Logistic (Binary Logistic)</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-black/60">Predictor (X):</span>
            <select
              value={predictorIdx}
              onChange={(e) => setPredictorIdx(Number(e.target.value))}
              className="text-xs font-mono border border-black rounded-none px-2 py-1.5 bg-[#E4E3E0] text-black font-bold focus:outline-hidden"
            >
              {headers.map((h, idx) => (
                <option key={idx} value={idx}>{h}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-black/60">Response (Y):</span>
            <select
              value={responseIdx}
              onChange={(e) => setResponseIdx(Number(e.target.value))}
              className="text-xs font-mono border border-black rounded-none px-2 py-1.5 bg-[#E4E3E0] text-black font-bold focus:outline-hidden"
            >
              {headers.map((h, idx) => (
                <option key={idx} value={idx}>{h}</option>
              ))}
            </select>
          </div>

          {modelType === "polynomial" && (
            <div className="flex items-center gap-2">
              <span className="text-black/60">Degree:</span>
              <input
                type="number"
                min="2"
                max="5"
                value={polyDegree}
                onChange={(e) => setPolyDegree(Math.max(2, Math.min(5, Number(e.target.value))))}
                className="w-12 border border-black rounded-none px-1.5 py-1 text-center font-mono font-bold bg-[#E4E3E0]"
              />
            </div>
          )}
        </div>
      </div>

      {fitResults && "error" in fitResults ? (
        <div className="p-4 bg-red-950 border border-black text-red-200 rounded-none text-xs font-mono">
          <strong>Computation Failed:</strong> {fitResults.error}
        </div>
      ) : fitResults ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Coefficients Table */}
            <div className="border border-black rounded-none bg-transparent overflow-hidden">
              <div className="px-5 py-4 bg-black text-[#E4E3E0] border-b border-black flex justify-between items-center">
                <h3 className="text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2">
                  <Settings className="w-4 h-4 text-[#E4E3E0]" /> Model Coefficients
                </h3>
                <span className="text-[10px] font-mono text-[#E4E3E0]/70 uppercase">CI boundary: 95%</span>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-xs bg-black/5">
                  <thead className="bg-[#141414]/90 text-[#E4E3E0] border-b border-black uppercase tracking-wider font-mono text-[9px] font-bold">
                    <tr>
                      <th className="px-5 py-3">Coefficient</th>
                      <th className="px-5 py-3 text-right">Estimate</th>
                      <th className="px-5 py-3 text-right">Std Error</th>
                      <th className="px-5 py-3 text-right">z/t-stat</th>
                      <th className="px-5 py-3 text-right">Pr(&gt;|t|)</th>
                      <th className="px-5 py-3 text-right">Confidence interval</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-black/25 text-black font-mono">
                    {fitResults.coefficients.map((coef, idx) => (
                      <tr key={idx} className="hover:bg-black/5">
                        <td className="px-5 py-3.5 font-bold text-black border-r border-black/10">{coef.name}</td>
                        <td className="px-5 py-3.5 text-right font-bold text-black border-r border-black/10">
                          {coef.estimate.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                        </td>
                        <td className="px-5 py-3.5 text-right text-black border-r border-black/10">
                          {coef.stdError.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                        </td>
                        <td className="px-5 py-3.5 text-right text-black border-r border-black/10">
                          {coef.tStat.toLocaleString(undefined, { maximumFractionDigits: 4 })}
                        </td>
                        <td className={`px-5 py-3.5 text-right font-bold border-r border-black/10 ${coef.pValue < 0.05 ? "text-amber-800" : "text-black/70"}`}>
                          {coef.pValue < 1e-4 ? "< 0.0001" : coef.pValue.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                        </td>
                        <td className="px-5 py-3.5 text-right text-black font-semibold">
                          [{coef.confidenceInterval[0].toLocaleString(undefined, { maximumFractionDigits: 3 })},{" "}
                          {coef.confidenceInterval[1].toLocaleString(undefined, { maximumFractionDigits: 3 })}]
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Scatter and Fit Line Plot */}
            {fittedPlot && (
              <div className="p-5 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-2">
                    <GitCommit className="w-4 h-4 text-black" /> Regression Fit Visualizer
                  </h3>
                  <span className="text-[10px] font-mono text-black font-bold uppercase bg-black/5 px-2 py-0.5 border border-black">
                    {modelType === "logistic" ? "Logistic logit response" : "Linear response fit"}
                  </span>
                </div>

                <div className="relative w-full h-60 bg-black/5 border border-black p-2 flex items-end">
                  <svg viewBox="0 0 500 160" className="w-full h-full" preserveAspectRatio="none">
                    {/* Render Fitted Trend Line */}
                    {(() => {
                      const points = fittedPlot.linePoints.map((pt) => `${pt.sx},${pt.sy}`);
                      return (
                        <polyline
                          fill="none"
                          stroke="#141414"
                          strokeWidth="3.2"
                          points={points.join(" ")}
                        />
                      );
                    })()}

                    {/* Scatter points */}
                    {fittedPlot.screenScatter.map((scatter) => (
                      <g key={scatter.id}>
                        <circle
                          cx={scatter.sx}
                          cy={scatter.sy}
                          r={modelType === "logistic" ? "4.2" : "3.5"}
                          fill={modelType === "logistic" ? "#954000" : "#141414"}
                          stroke="#E4E3E0"
                          strokeWidth="1.2"
                          opacity="0.9"
                          className="hover:r-5 transition-all cursor-pointer"
                        />
                        <title>
                          {`Point ${scatter.id + 1}:\n${headers[predictorIdx]}: ${scatter.ox.toFixed(3)}\n${headers[responseIdx]}: ${scatter.oy.toFixed(3)}`}
                        </title>
                      </g>
                    ))}

                    {/* Axes */}
                    <line x1="45" y1="140" x2="470" y2="140" stroke="#141414" strokeWidth="2" />
                    <line x1="45" y1="15" x2="45" y2="140" stroke="#141414" strokeWidth="2" />
                  </svg>
                </div>

                <div className="flex justify-between text-[9px] font-mono text-black mt-2 px-8 font-bold">
                  <span>X Min: {fittedPlot.minX.toFixed(2)}</span>
                  <span>X Max: {fittedPlot.maxX.toFixed(2)}</span>
                  <span>Y Range: [{(modelType === "logistic" ? 0 : fittedPlot.minY).toFixed(1)}, {(modelType === "logistic" ? 1 : fittedPlot.maxY).toFixed(1)}]</span>
                </div>
              </div>
            )}
          </div>

          {/* Model Statistics Panel */}
          <div className="bg-[#E4E3E0] border border-black p-5 rounded-none space-y-6 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <h3 className="text-xs font-mono text-black/60 uppercase tracking-widest font-bold flex items-center gap-1.5 border-b border-black pb-2">
              <Percent className="w-4 h-4 text-black" /> Summary Statistics
            </h3>

            <div className="space-y-4 font-mono text-xs">
              <div className="flex justify-between border-b border-black/10 pb-1.5">
                <span className="text-black/50">R-squared:</span>
                <span className="text-black font-bold">
                  {fitResults.rSquared.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                </span>
              </div>

              {modelType !== "logistic" && (
                <>
                  <div className="flex justify-between border-b border-black/10 pb-1.5">
                    <span className="text-black/50">Adjusted R²:</span>
                    <span className="text-black font-bold">
                      {fitResults.adjRSquared.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-black/10 pb-1.5">
                    <span className="text-black/50">Residual Std Error:</span>
                    <span className="text-black font-bold">
                      {fitResults.residuals.stdError.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-black/10 pb-1.5">
                    <span className="text-black/50">Overall F-statistic:</span>
                    <span className="text-black font-bold">
                      {fitResults.fStatistic?.toLocaleString(undefined, { maximumFractionDigits: 3 })}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-black/10 pb-1.5">
                    <span className="text-black/50">F p-value:</span>
                    <span className={`font-bold ${fitResults.fPValue && fitResults.fPValue < 0.05 ? "text-amber-800" : "text-black/75"}`}>
                      {fitResults.fPValue && fitResults.fPValue < 1e-4
                        ? "< 0.0001"
                        : fitResults.fPValue?.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                    </span>
                  </div>
                </>
              )}

              {modelType === "logistic" && (
                <>
                  <div className="flex justify-between border-b border-black/10 pb-1.5">
                    <span className="text-black/50">McFadden Pseudo R²:</span>
                    <span className="text-black font-bold">
                      {fitResults.rSquared.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-black/10 pb-1.5">
                    <span className="text-black/50">Iterative Method:</span>
                    <span className="text-black font-bold">IRLS (Newton-Raphson)</span>
                  </div>
                  <div className="flex justify-between border-b border-black/10 pb-1.5">
                    <span className="text-black/50">Converged status:</span>
                    <span className={`font-bold ${fitResults.converged ? "text-emerald-850" : "text-red-750"}`}>
                      {fitResults.converged === true ? "SUCCESS" : "NO"}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-black/10 pb-1.5">
                    <span className="text-black/50">IRLS Iterations:</span>
                    <span className="text-black font-bold">{fitResults.iterations}</span>
                  </div>
                </>
              )}

              <div className="flex justify-between border-b border-black/10 pb-1.5">
                <span className="text-black/50">Residual df:</span>
                <span className="text-black font-bold">{fitResults.dfResidual}</span>
              </div>
              <div className="flex justify-between pb-1.5">
                <span className="text-black/50">Model df (parameters):</span>
                <span className="text-black font-bold">{fitResults.dfModel}</span>
              </div>
            </div>

            {/* Residual Diagnostics box */}
            <div className="p-4 bg-black/5 border border-black rounded-none space-y-2 text-xs font-mono">
              <h4 className="text-[10px] uppercase font-bold text-black border-b border-black pb-1.5">Residual Quantiles summary</h4>
              <div className="grid grid-cols-5 text-center mt-2 border-b border-black/10 pb-1.5 text-black/50 text-[9px] font-bold">
                <span>Min</span>
                <span>Q1</span>
                <span>Median</span>
                <span>Q3</span>
                <span>Max</span>
              </div>
              <div className="grid grid-cols-5 text-center text-black font-bold text-[10px]">
                <span>{fitResults.residuals.min.toLocaleString(undefined, { maximumFractionDigits: 3 })}</span>
                <span>{fitResults.residuals.q1.toLocaleString(undefined, { maximumFractionDigits: 3 })}</span>
                <span>{fitResults.residuals.median.toLocaleString(undefined, { maximumFractionDigits: 3 })}</span>
                <span>{fitResults.residuals.q3.toLocaleString(undefined, { maximumFractionDigits: 3 })}</span>
                <span>{fitResults.residuals.max.toLocaleString(undefined, { maximumFractionDigits: 3 })}</span>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
