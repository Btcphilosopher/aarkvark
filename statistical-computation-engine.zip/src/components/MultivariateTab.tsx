/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { multivariateEngine } from "../engine/main";
import { LayoutGrid, Grid, BarChart, Percent, Layers } from "lucide-react";

interface MultivariateTabProps {
  headers: string[];
  data: number[][];
}

type TabType = "matrix" | "pca" | "kmeans";

export function MultivariateTab({ headers, data }: MultivariateTabProps) {
  const [subTab, setSubTab] = useState<TabType>("matrix");
  const [selectedCols, setSelectedCols] = useState<Record<number, boolean>>(() => {
    // Select first 3 or cols as default
    const defaults: Record<number, boolean> = {};
    for (let i = 0; i < Math.min(4, headers.length); i++) {
      defaults[i] = true;
    }
    return defaults;
  });

  const [scalePCA, setScalePCA] = useState(true);
  const [kmeansK, setKmeansK] = useState(3);

  const activeColIndexes = useMemo(() => {
    return Object.entries(selectedCols)
      .filter(([_, enabled]) => enabled)
      .map(([idx]) => Number(idx))
      .sort((a,b)=>a-b);
  }, [selectedCols]);

  const activeHeaders = useMemo(() => {
    return activeColIndexes.map((idx) => headers[idx]);
  }, [activeColIndexes, headers]);

  // Handle building filtered submatrix
  const subsetMatrix = useMemo(() => {
    if (data.length === 0 || activeColIndexes.length < 2) return null;
    return data.map((row) => activeColIndexes.map((colIdx) => row[colIdx]));
  }, [data, activeColIndexes]);

  // Compute Covariance and Correlation matrices
  const matrixResults = useMemo(() => {
    if (!subsetMatrix || subsetMatrix.length < 3) return null;
    return {
      covariance: multivariateEngine.covarianceMatrix(subsetMatrix),
      correlation: multivariateEngine.correlationMatrix(subsetMatrix),
    };
  }, [subsetMatrix]);

  // Compute PCA
  const pcaOutput = useMemo(() => {
    if (!subsetMatrix || subsetMatrix.length < 3 || subTab !== "pca") return null;
    try {
      return multivariateEngine.pca(subsetMatrix, scalePCA);
    } catch (e: any) {
      return { error: e.message || "Eigenvalue solver deflation convergence failure." };
    }
  }, [subsetMatrix, scalePCA, subTab]);

  // Compute K-means clustering
  const kmeansOutput = useMemo(() => {
    if (!subsetMatrix || subsetMatrix.length < 4 || subTab !== "kmeans") return null;
    try {
      return multivariateEngine.kmeans(subsetMatrix, kmeansK);
    } catch (e: any) {
      return { error: e.message || "Centroid dispersion error." };
    }
  }, [subsetMatrix, kmeansK, subTab]);

  if (headers.length < 2 || data.length < 4) {
    return (
      <div className="p-8 text-center text-gray-400 font-sans">
        Multivariate engine runs on datasets with at least 2 columns and 4 rows.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black pb-4 text-sans">
        <div>
          <h2 className="text-lg font-bold uppercase tracking-tight text-black">
            Multivariate & Dimension Reduction
          </h2>
          <p className="text-xs font-mono text-black/70 mt-1">
            Builds multi-column covariance matrices, principal components, and K-means centroid clusters.
          </p>
        </div>

        <div className="flex gap-2">
          {(["matrix", "pca", "kmeans"] as TabType[]).map((tab) => (
            <button
              key={tab}
              onClick={() => setSubTab(tab)}
              className={`text-xs px-3 py-1.5 rounded-none font-mono font-bold transition-colors cursor-pointer border ${
                subTab === tab
                  ? "bg-black border-black text-[#E4E3E0] shadow-none"
                  : "bg-[#E4E3E0] border-black text-black hover:bg-[#D4D3D0] shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
              }`}
            >
              {tab.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Target Column Selectors Checklist */}
      <div className="p-4 bg-black/5 border border-black rounded-none space-y-2">
        <span className="text-[10px] font-mono font-bold uppercase text-black/60 tracking-wider">
          Column Vector Inputs Selectors (Choose at least 2)
        </span>
        <div className="flex flex-wrap gap-x-6 gap-y-2">
          {headers.map((h, idx) => (
            <label key={idx} className="flex items-center gap-1.5 text-xs text-black font-semibold cursor-pointer select-none font-mono">
              <input
                type="checkbox"
                checked={!!selectedCols[idx]}
                onChange={(e) => {
                  setSelectedCols((prev) => {
                    const next = { ...prev, [idx]: e.target.checked };
                    // forbid selecting less than 2
                    const count = Object.values(next).filter(Boolean).length;
                    return count >= 2 ? next : prev;
                  });
                }}
                className="accent-black border-black rounded-none"
              />
              <span>{h}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Sub-Tab Output Modules */}
      {subTab === "matrix" && matrixResults && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Correlation matrix rendered as a styled heatmap */}
          <div className="p-5 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-1.5 border-b border-black pb-2">
              <LayoutGrid className="w-4 h-4 text-black" /> Pearson Correlation Matrix (Heat grid)
            </h3>
            <div className="overflow-x-auto">
              <div className="min-w-64 max-w-lg mx-auto">
                {/* Heatmap Grid */}
                <div style={{ display: "grid", gridTemplateColumns: `auto repeat(${activeHeaders.length}, minmax(0, 1fr))` }} className="gap-1 font-mono text-[10px] text-center">
                  <div />
                  {activeHeaders.map((colh, i) => (
                    <div key={i} className="text-black/60 font-bold truncate px-1" title={colh}>{colh}</div>
                  ))}

                  {matrixResults.correlation.map((row, rIdx) => (
                    <React.Fragment key={rIdx}>
                      <div className="text-left font-mono font-bold text-black pr-2 truncate self-center">{activeHeaders[rIdx]}</div>
                      {row.map((val, cIdx) => {
                        // Color intensity based on absolute value (correlation slider colors: black/white high-contrast)
                        const absVal = Math.abs(val);
                        // Blend between beige-[#E4E3E0] and dark charcoal-[#141414] depending on correlation strength
                        const pct = Math.floor(absVal * 100);
                        const bgCell = `rgba(20, 20, 20, ${(absVal * 0.7 + 0.15).toFixed(2)})`;
                        const txtColor = absVal > 0.4 ? "#ffffff" : "#000000";

                        return (
                          <div
                            key={cIdx}
                            style={{ backgroundColor: bgCell, color: txtColor }}
                            className="aspect-square flex items-center justify-center font-bold font-mono transition-transform rounded-none border border-black/40 hover:scale-105 cursor-pointer leading-none"
                            title={`Corr(${activeHeaders[rIdx]}, ${activeHeaders[cIdx]}): ${val.toFixed(5)}`}
                          >
                            {val.toFixed(2)}
                          </div>
                        );
                      })}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Covariance matrix numerical summary */}
          <div className="p-5 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] space-y-4">
            <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-1.5 border-b border-black pb-2">
              <Grid className="w-4 h-4 text-black" /> Covariance Matrix Dataframe
            </h3>
            <div className="overflow-x-auto text-[11px]">
              <table className="w-full text-left border border-black divide-y divide-black font-mono">
                <thead className="bg-[#D4D3D0] text-[10px] uppercase text-black font-bold tracking-wider">
                  <tr>
                    <th className="px-3 py-2 border-r border-black">Variable</th>
                    {activeHeaders.map((colh, i) => (
                      <th key={i} className="px-3 py-2 text-right border-l border-black/30">{colh}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-black/30 text-black">
                  {matrixResults.covariance.map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-black/5 font-semibold">
                      <td className="px-3 py-2.5 font-bold text-black border-r border-black bg-black/5">{activeHeaders[rIdx]}</td>
                      {row.map((val, cIdx) => (
                        <td key={cIdx} className="px-3 py-2.5 text-right font-bold border-l border-black/10">
                          {val.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {subTab === "pca" && pcaOutput && (
        <>
          {/* Deflation errors */}
          {"error" in pcaOutput ? (
            <div className="p-4 bg-amber-950 border border-black text-amber-200 rounded-none font-mono text-xs font-bold font-mono">
              PCA computation error: {pcaOutput.error}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Explained variance block */}
              <div className="bg-[#E4E3E0] border border-black p-5 rounded-none space-y-4 font-mono text-xs shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <div className="flex justify-between items-center border-b border-black pb-2">
                  <h3 className="text-xs uppercase font-bold text-black/60 tracking-wider">
                    PC Loading Significance
                  </h3>
                  <label className="flex items-center gap-1 text-[11px] font-mono text-black font-bold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={scalePCA}
                      onChange={(e) => setScalePCA(e.target.checked)}
                      className="accent-black border-black rounded-none size-3"
                    />
                    Unit scale
                  </label>
                </div>

                <div className="space-y-4">
                  {pcaOutput.proportionOfVariance.map((pVar, idx) => {
                    const pcLabel = `PC${idx + 1}`;
                    const varPct = pVar * 100;
                    const cumPct = pcaOutput.cumulativeVariance[idx] * 100;
                    
                    return (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between text-[11px] font-bold">
                          <span className="text-black">{pcLabel} (σ = {pcaOutput.standardDeviations[idx].toFixed(4)})</span>
                          <span className="text-black/60">Explained: {varPct.toFixed(1)}% | Cum: {cumPct.toFixed(1)}%</span>
                        </div>
                        <div className="w-full h-2.5 bg-black/10 border border-black rounded-none overflow-hidden">
                          <div style={{ width: `${varPct}%` }} className="h-full bg-black rounded-none" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* PC Loading coefficients vectors mapping weights */}
              <div className="lg:col-span-2 p-5 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] space-y-4">
                <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-1 border-b border-black pb-2">
                  <BarChart className="w-4 h-4 text-black" /> PC Loading Weight Eigenvectors
                </h3>
                <div className="overflow-x-auto text-[11px]">
                  <table className="w-full border border-black text-left divide-y border-gray-55 divide-black font-mono">
                    <thead className="bg-[#D4D3D0] font-bold uppercase text-[10px] text-black tracking-wider border-b border-black">
                      <tr>
                        <th className="px-3 py-2 border-r border-black">Variable</th>
                        {pcaOutput.loadings.map((_, i) => (
                          <th key={i} className="px-3 py-2 text-right border-l border-black/30">PC{i + 1}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-black/30 text-black">
                      {activeHeaders.map((varh, rIdx) => (
                        <tr key={rIdx} className="hover:bg-black/5 font-semibold">
                          <td className="px-3 py-2.5 font-bold text-black border-r border-black bg-black/5">{varh}</td>
                          {pcaOutput.loadings.map((pcVec, cIdx) => {
                            const loadingCellVal = pcVec[rIdx] || 0.0;
                            const isStrong = Math.abs(loadingCellVal) > 0.4;
                            return (
                              <td key={cIdx} className={`px-3 py-2.5 text-right font-bold border-l border-black/10 ${isStrong ? "text-amber-900 underline font-extrabold" : "text-black/60"}`}>
                                {loadingCellVal.toFixed(5)}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {subTab === "kmeans" && kmeansOutput && (
        <>
          {"error" in kmeansOutput ? (
            <div className="p-4 bg-amber-950 border border-black text-amber-200 rounded-none font-mono text-xs font-bold">
              K-Means failed: {kmeansOutput.error}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
              <div className="bg-[#E4E3E0] border border-black p-5 rounded-none space-y-5 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <div className="flex justify-between items-center border-b border-black pb-3">
                  <h3 className="text-xs font-mono font-bold uppercase text-black/60 tracking-wider">
                    Centroid Clusters Config
                  </h3>
                  <div className="flex items-center gap-1 font-mono text-[11px] font-bold">
                    <span>K:</span>
                    <input
                      type="range"
                      min="2"
                      max="6"
                      value={kmeansK}
                      onChange={(e) => setKmeansK(Number(e.target.value))}
                      className="w-16 h-1 bg-black/10 accent-black appearance-none"
                    />
                    <span className="font-extrabold border border-black px-1.5 py-0.5 bg-black/5">{kmeansK}</span>
                  </div>
                </div>

                <div className="space-y-4">
                  {/* Cluster assignments counts */}
                  {Array.from({ length: kmeansK }).map((_, cIdx) => {
                    const size = kmeansOutput.assignments.filter((a) => a === cIdx).length;
                    
                    return (
                      <div key={cIdx} className="p-3 bg-black/5 border border-black rounded-none space-y-1">
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider block text-black underline">
                          Cluster {cIdx + 1} Assignment
                        </span>
                        <div className="flex justify-between font-mono text-xs text-black/70 font-semibold">
                          <span>Data Counts:</span>
                          <span className="font-extrabold text-black">{size} rows</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Centroid coordinates dataframe */}
              <div className="lg:col-span-2 p-5 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] space-y-4">
                <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-1 border-b border-black pb-2">
                  <Layers className="w-4 h-4 text-black" /> Multi-variable Centroid Coordinates
                </h3>
                <div className="overflow-x-auto text-[11px]">
                  <table className="w-full border border-black text-left divide-y border-gray-100 divide-black font-mono">
                    <thead className="bg-[#D4D3D0] text-[10px] font-bold uppercase text-black tracking-wider border-b border-black">
                      <tr>
                        <th className="px-3 py-2 border-r border-black">Variable</th>
                        {kmeansOutput.centroids.map((_, i) => (
                          <th key={i} className="px-3 py-2 text-right border-l border-black/30">Cluster {i + 1}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-black/30 text-black">
                      {activeHeaders.map((varh, rIdx) => (
                        <tr key={rIdx} className="hover:bg-black/5 font-semibold">
                          <td className="px-3 py-2 font-bold text-black border-r border-black bg-black/5">{varh}</td>
                          {kmeansOutput.centroids.map((centroidRow, cIdx) => {
                            const centVal = centroidRow[rIdx] || 0;
                            return (
                              <td key={cIdx} className="px-3 py-2 text-right font-extrabold text-black border-l border-black/10">
                                {centVal.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
