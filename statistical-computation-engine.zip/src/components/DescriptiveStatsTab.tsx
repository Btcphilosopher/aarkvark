/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { descriptiveStats } from "../engine/main";
import { Eye, TrendingUp, Info } from "lucide-react";

interface DescriptiveStatsTabProps {
  headers: string[];
  data: number[][];
}

export function DescriptiveStatsTab({ headers, data }: DescriptiveStatsTabProps) {
  const [selectedColIdx, setSelectedColIdx] = useState<number>(0);

  const columnData = useMemo(() => {
    if (data.length === 0 || selectedColIdx >= headers.length) return [];
    return data.map((row) => row[selectedColIdx]);
  }, [data, selectedColIdx]);

  const summary = useMemo(() => {
    if (columnData.length === 0) return null;
    return descriptiveStats.summary(columnData);
  }, [columnData]);

  // Generate SVG histogram bins and normal curve
  const chartData = useMemo(() => {
    if (columnData.length < 3) return null;
    const sorted = [...columnData].sort((a, b) => a - b);
    const min = sorted[0];
    const max = sorted[sorted.length - 1];
    const range = max - min;
    
    const binCount = Math.max(5, Math.min(15, Math.ceil(Math.sqrt(sorted.length))));
    const binWidth = range / binCount;
    const bins = Array(binCount).fill(0);
    const binLabels = Array.from({ length: binCount }, (_, i) => {
      const val = min + i * binWidth + binWidth / 2;
      return val.toFixed(1);
    });

    for (const val of sorted) {
      let bIdx = Math.floor((val - min) / binWidth);
      if (bIdx >= binCount) bIdx = binCount - 1;
      if (bIdx < 0) bIdx = 0;
      bins[bIdx]++;
    }

    const maxBinVal = Math.max(...bins, 1);
    
    // Normal curve calculations
    const meanVal = sorted.reduce((a, b) => a + b, 0) / sorted.length;
    let vrSum = 0;
    for (const v of sorted) vrSum += Math.pow(v - meanVal, 2);
    const stdVal = Math.sqrt(vrSum / (sorted.length - 1)) || 1.0;

    // Normal probability density function function
    const normPDF = (x: number) => {
      return (1.0 / (stdVal * Math.sqrt(2.0 * Math.PI))) * Math.exp(-Math.pow(x - meanVal, 2) / (2.0 * Math.pow(stdVal, 2)));
    };

    return {
      bins,
      binLabels,
      maxBinVal,
      min,
      max,
      meanVal,
      stdVal,
      normPDF,
      binWidth,
      binCount
    };
  }, [columnData]);

  if (headers.length === 0 || data.length === 0) {
    return (
      <div className="p-8 text-center text-gray-400 font-sans">
        No tabular data loaded. Please select or import a dataset first.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black pb-4">
        <div>
          <h2 className="text-lg font-bold uppercase tracking-tight text-black font-sans flex items-center gap-2">
            Descriptive Statistics Engine
          </h2>
          <p className="text-xs text-black/70 mt-1 font-mono">
            Computes central tendencies, dispersion distributions, shapes, and percentile boundaries.
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <label className="text-xs font-mono text-black/60 uppercase tracking-wider font-bold">Select Column:</label>
          <select
            value={selectedColIdx}
            onChange={(e) => setSelectedColIdx(Number(e.target.value))}
            className="text-xs font-mono border border-black rounded-none px-3 py-1.5 bg-[#E4E3E0] text-black shadow-none focus:outline-hidden font-bold"
          >
            {headers.map((h, idx) => (
              <option key={idx} value={idx}>
                Col {idx}: {h}
              </option>
            ))}
          </select>
        </div>
      </div>

      {summary && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Statistical Metrics Table */}
          <div className="lg:col-span-2 grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="p-4 bg-black/5 border border-black rounded-none">
              <span className="text-xs font-mono text-black/50 uppercase tracking-wider block font-bold">Sample Count (n)</span>
              <span className="text-2xl font-mono text-black mt-1 block font-bold">{summary.n}</span>
            </div>
            <div className="p-4 bg-black/5 border border-black rounded-none">
              <span className="text-xs font-mono text-black/50 uppercase tracking-wider block font-bold">Mean (μ)</span>
              <span className="text-2xl font-mono text-black mt-1 block font-bold">{summary.mean.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
            </div>
            <div className="p-4 bg-black/5 border border-black rounded-none">
              <span className="text-xs font-mono text-black/50 uppercase tracking-wider block font-bold">Median (M)</span>
              <span className="text-2xl font-mono text-black mt-1 block font-bold">{summary.median.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
            </div>
            <div className="p-4 bg-black/5 border border-black rounded-none">
              <span className="text-xs font-mono text-black/50 uppercase tracking-wider block font-bold">Variance (s²)</span>
              <span className="text-2xl font-mono text-black mt-1 block font-bold">{summary.variance.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
            </div>
            <div className="p-4 bg-black/5 border border-black rounded-none">
              <span className="text-xs font-mono text-black/50 uppercase tracking-wider block font-bold">Std Deviation (σ)</span>
              <span className="text-2xl font-mono text-black mt-1 block font-bold">{summary.stdDev.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
            </div>
            <div className="p-4 bg-black/5 border border-black rounded-none">
              <span className="text-xs font-mono text-black/50 uppercase tracking-wider block font-bold">Std Error (SE)</span>
              <span className="text-2xl font-mono text-black mt-1 block font-bold">{summary.seMean.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
            </div>
            <div className="p-4 bg-black/5 border border-black rounded-none">
              <span className="text-xs font-mono text-black/50 uppercase tracking-wider block font-bold">Skewness (g₁)</span>
              <span className={`text-2xl font-mono mt-1 block font-bold ${summary.skewness > 1 ? "text-amber-800" : summary.skewness < -1 ? "text-blue-900" : "text-black"}`}>
                {summary.skewness.toLocaleString(undefined, { maximumFractionDigits: 5 })}
              </span>
            </div>
            <div className="p-4 bg-black/5 border border-black rounded-none">
              <span className="text-xs font-mono text-black/50 uppercase tracking-wider block font-bold">Excess Kurtosis (g₂)</span>
              <span className="text-2xl font-mono text-black mt-1 block font-bold">{summary.kurtosis.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
            </div>
            <div className="p-4 bg-black/5 border border-black rounded-none">
              <span className="text-xs font-mono text-black/50 uppercase tracking-wider block font-bold">Statistical Range</span>
              <span className="text-2xl font-mono text-black mt-1 block font-bold">{summary.range.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
            </div>
          </div>

          {/* Tukey Five-Number Box boundaries */}
          <div className="p-5 bg-[#E4E3E0] border border-black rounded-none space-y-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <h3 className="text-sm font-mono font-bold text-black uppercase tracking-wider flex items-center gap-2">
              <Eye className="w-4 h-4 text-black" /> Five-Number Summary
            </h3>
            <div className="space-y-2 font-mono text-sm">
              <div className="flex justify-between border-b border-black/10 pb-1">
                <span className="text-black/50">Maximum (100%):</span>
                <span className="text-black font-bold">{summary.max.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
              </div>
              <div className="flex justify-between border-b border-black/10 pb-1">
                <span className="text-black/50">Third Quantile (Q3 - 75%):</span>
                <span className="text-black font-bold">{summary.q3.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
              </div>
              <div className="flex justify-between border-b border-black/10 pb-1">
                <span className="text-black/50">Median (Q2 - 50%):</span>
                <span className="text-black font-bold">{summary.median.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
              </div>
              <div className="flex justify-between border-b border-black/10 pb-1">
                <span className="text-black/50">First Quantile (Q1 - 25%):</span>
                <span className="text-black font-bold">{summary.q1.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
              </div>
              <div className="flex justify-between pb-1">
                <span className="text-black/50">Minimum (0%):</span>
                <span className="text-black font-bold">{summary.min.toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
              </div>
            </div>
            <div className="pt-2 border-t border-black">
              <span className="text-xs font-mono text-black/50 uppercase tracking-widest block font-bold">Interquartile Range (IQR)</span>
              <span className="text-lg font-mono text-black mt-1 block font-bold">{(summary.q3 - summary.q1).toLocaleString(undefined, { maximumFractionDigits: 5 })}</span>
            </div>
          </div>
        </div>
      )}

      {/* Histogram SVG Section */}
      {chartData && (
        <div className="p-5 bg-[#E4E3E0] border border-black rounded-none shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xs font-mono font-bold text-black uppercase flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-black" /> Empirical Distribution Overlay (Normal bell-curve)
            </h3>
            <span className="text-xs font-mono text-black/60 bg-black/5 px-2 py-0.5 border border-black">
              bin width ~ {chartData.binWidth.toFixed(4)}
            </span>
          </div>

          <div className="relative w-full h-64 bg-black/5 border border-black p-2 flex items-end">
            <svg viewBox="0 0 500 200" className="w-full h-full" preserveAspectRatio="none">
              {/* Plot Bins */}
              {chartData.bins.map((val, idx) => {
                const totalBins = chartData.bins.length;
                const width = 400 / totalBins;
                const gap = 2;
                const height = (val / chartData.maxBinVal) * 160;
                const x = 50 + idx * width;
                const y = 180 - height;
                
                return (
                  <g key={idx} className="group">
                    <rect
                      x={x + gap/2}
                      y={y}
                      width={width - gap}
                      height={height}
                      fill="#C4C3C0"
                      stroke="#141414"
                      strokeWidth="1.5"
                      className="hover:fill-black/20 transition-colors cursor-pointer"
                    />
                    {/* Tooltip on hover */}
                    <title>{`Bin ${idx + 1}: ${chartData.binLabels[idx]} (Count: ${val})`}</title>
                  </g>
                );
              })}

              {/* Render Normal distribution curve line */}
              {(() => {
                const points: string[] = [];
                const steps = 100;
                
                // Scale factor for normal curve scaling: we want area under normal curve
                // to roughly scale to histogram bins.
                const totalN = columnData.length;
                const scalingArea = totalN * chartData.binWidth;
                
                for (let i = 0; i <= steps; i++) {
                  const pct = i / steps;
                  // Map X coordinate from min - 0.5*range to max + 0.5*range for smooth curve heads
                  const xVal = chartData.min - 0.25 * (chartData.max - chartData.min) + pct * 1.5 * (chartData.max - chartData.min);
                  const pdfVal = chartData.normPDF(xVal);
                  
                  // Scale normal curve height to match histogram coordinate system:
                  // bin density is val / (N * binWidth). Since rect height maps val / maxBinVal * 160:
                  // height_scaled = pdfVal * scalingArea / maxBinVal * 160
                  const curveYVal = pdfVal * scalingArea;
                  const screenX = 50 + (pct * 400);
                  const screenY = 180 - Math.min(160, (curveYVal / chartData.maxBinVal) * 160);
                  
                  if (!isNaN(screenY) && screenY <= 180 && screenY >= 10) {
                    points.push(`${screenX},${screenY}`);
                  }
                }

                if (points.length < 2) return null;
                return (
                  <polyline
                    fill="none"
                    stroke="#141414"
                    strokeWidth="2.5"
                    points={points.join(" ")}
                  />
                );
              })()}

              {/* Baseline axis */}
              <line x1="40" y1="180" x2="470" y2="180" stroke="#141414" strokeWidth="2" />
            </svg>
          </div>

          <div className="flex justify-between text-[10px] font-mono text-black mt-2 px-12">
            <span>Min: {chartData.min.toFixed(2)}</span>
            <span>Mean (μ): {chartData.meanVal.toFixed(2)}</span>
            <span>Max: {chartData.max.toFixed(2)}</span>
          </div>
        </div>
      )}
    </div>
  );
}
