/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { DATA_PRESETS } from "./engine/data_presets";
import { exportToCSV, parseCSV } from "./engine/main";

// Sub-components
import { DescriptiveStatsTab } from "./components/DescriptiveStatsTab";
import { DistributionsTab } from "./components/DistributionsTab";
import { RegressionTab } from "./components/RegressionTab";
import { HypothesisTab } from "./components/HypothesisTab";
import { BayesianTab } from "./components/BayesianTab";
import { MultivariateTab } from "./components/MultivariateTab";
import { TimeSeriesTab } from "./components/TimeSeriesTab";
import { SimulationTab } from "./components/SimulationTab";

// Icons
import {
  FileCode,
  TableProperties,
  ArrowRightLeft,
  Sliders,
  TrendingUp,
  Brain,
  ShieldAlert,
  Database,
  Download,
  Upload,
  Plus,
  RefreshCcw,
  CheckCircle,
  HelpCircle
} from "lucide-react";

type TabName =
  | "descriptive"
  | "distributions"
  | "regression"
  | "hypothesis"
  | "bayesian"
  | "multivariate"
  | "timeseries"
  | "simulation";

export default function App() {
  const [activeTab, setActiveTab] = useState<TabName>("descriptive");
  const [activePresetIdx, setActivePresetIdx] = useState(0);

  // Loaded dataset sheets matrix
  const [headers, setHeaders] = useState<string[]>(DATA_PRESETS[0].headers);
  const [data, setData] = useState<number[][]>(DATA_PRESETS[0].data);

  // CSV paste input states
  const [csvText, setCsvText] = useState("");
  const [showCSVPaster, setShowCSVPaster] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Set preset trigger
  const handleSelectPreset = (idx: number) => {
    setActivePresetIdx(idx);
    setHeaders(DATA_PRESETS[idx].headers);
    setData(DATA_PRESETS[idx].data);
    setImportStatus(null);
  };

  // Cell editor in interactive table grid
  const handleCellChange = (rowIdx: number, colIdx: number, val: string) => {
    const floatVal = parseFloat(val);
    const updated = [...data.map((r) => [...r])];
    updated[rowIdx][colIdx] = isNaN(floatVal) ? 0.0 : floatVal;
    setData(updated);
  };

  // Standard CSV Import trigger
  const handleCSVImport = () => {
    if (!csvText.trim()) return;
    try {
      const parsed = parseCSV(csvText);
      if (parsed.headers.length === 0 || parsed.data.length === 0) {
        throw new Error("CSV contains no valid columns or numeric rows.");
      }
      setHeaders(parsed.headers);
      setData(parsed.data);
      setImportStatus("Imported successfully! Running diagnostics.");
      setTimeout(() => setImportStatus(null), 3000);
      setShowCSVPaster(false);
    } catch (err: any) {
      setImportStatus(`Import Error: ${err.message}`);
    }
  };

  // Standard direct download of mutated matrix
  const handleCSVDownload = () => {
    const csvContent = exportToCSV(data, headers);
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `r_calculus_export_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Add random observation Row to dataset
  const handleAddRandomRow = () => {
    if (data.length === 0) return;
    const lastRow = data[data.length - 1];
    // Generate new random observations around the last row values with minor jitter variance
    const newRow = lastRow.map((val) => {
      const jitter = (Math.random() - 0.5) * (val * 0.1 || 1.0);
      return Number((val + jitter).toFixed(4));
    });
    setData([...data, newRow]);
  };

  // Clear dataset
  const handleClearData = () => {
    setData([]);
    setHeaders([]);
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] flex flex-col font-mono selection:bg-black selection:text-white border-2 sm:border-8 border-[#141414]">
      {/* Dynamic Header Block */}
      <header className="bg-transparent border-b border-black px-6 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 bg-black flex items-center justify-center shrink-0">
            <div className="w-4 h-4 bg-[#E4E3E0] rotate-45"></div>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tighter uppercase font-sans text-black">
              STAT-CORE-R / V2.0.4
            </h1>
            <p className="text-[10px] text-black/60 uppercase tracking-widest font-mono">
              Deterministic vectorized matrix diagnostics, distributions, bayesian structures, and timeseries engines.
            </p>
          </div>
        </div>

        {/* Live system status block to match the original design layout spec */}
        <div className="flex flex-wrap items-center gap-4 md:gap-6 text-[11px] font-mono tracking-wider">
          <div className="flex gap-1.5 items-center">
            <span className="text-black/50 font-bold">CPU:</span>
            <span className="bg-black text-[#E4E3E0] px-1.5 py-0.5 text-[10px] font-bold">04.2%</span>
          </div>
          <div className="flex gap-1.5 items-center">
            <span className="text-black/50 font-bold">MEM:</span>
            <span className="bg-black text-[#E4E3E0] px-1.5 py-0.5 text-[10px] font-bold">1.2GB/8GB</span>
          </div>
          <div className="flex gap-1.5 items-center">
            <span className="text-black/50 font-bold">THREAD:</span>
            <span className="bg-black text-[#E4E3E0] px-1.5 py-0.5 text-[10px] font-bold">VECTOR_AVX512</span>
          </div>
        </div>
      </header>

      {/* Main Workspace Body layout Grid */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        
        {/* Left Side: Analytical Playground/Spreadsheet Sidebar Workspace */}
        <aside className="w-full lg:w-80 bg-[#E4E3E0] border-b lg:border-b-0 lg:border-r border-black flex flex-col overflow-hidden shrink-0">
          
          {/* Metadata Preset details */}
          <div className="p-4 bg-black/5 border-b border-black space-y-1.5 leading-relaxed font-mono">
            <span className="text-[10px] text-black/50 uppercase tracking-widest block font-bold">CONNECTED PRESET CONTEXT</span>
            <h3 className="text-xs font-bold text-black uppercase break-words">{DATA_PRESETS[activePresetIdx].name}</h3>
            <p className="text-[11px] text-[#141414]/85 leading-normal font-sans italic">{DATA_PRESETS[activePresetIdx].description}</p>
          </div>

          {/* Preset Selector Dropdown in sidebar styled following the classic menu layout */}
          <div className="p-4 border-b border-black bg-black text-[#E4E3E0] text-[10px] uppercase tracking-widest font-mono font-bold">
            STATISTIC HARDWARE SET
          </div>
          <div className="p-4 border-b border-black bg-black/5">
            <select
              value={activePresetIdx}
              onChange={(e) => handleSelectPreset(Number(e.target.value))}
              className="w-full text-xs font-mono border border-black rounded-none px-2.5 py-1.5 bg-[#E4E3E0] text-black focus:outline-hidden font-bold"
            >
              {DATA_PRESETS.map((preset, idx) => (
                <option key={idx} value={idx}>
                  Preset {idx + 1}: {preset.name.split(" (")[0]}
                </option>
              ))}
            </select>
          </div>

          {/* Table Container area */}
          <div className="flex-1 overflow-auto p-4 flex flex-col space-y-4 bg-[#E4E3E0]">
            <div className="flex justify-between items-center bg-[#E4E3E0]">
              <span className="text-[10px] font-mono font-bold text-black uppercase tracking-wider flex items-center gap-1">
                <TableProperties className="w-3.5 h-3.5" /> Matrix ({data.length}r x {headers.length}c)
              </span>

              <div className="flex gap-1.5">
                <button
                  onClick={handleAddRandomRow}
                  title="Insert jittered random observation row"
                  className="p-1 text-black hover:bg-black hover:text-[#E4E3E0] border border-black rounded-none cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={handleCSVDownload}
                  title="Export Current matrix back to PC as CSV"
                  className="p-1 text-black hover:bg-black hover:text-[#E4E3E0] border border-black rounded-none cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Custom CSV upload toggles */}
            {showCSVPaster ? (
              <div className="space-y-2 border border-black p-3 bg-white/50 rounded-none font-mono">
                <textarea
                  value={csvText}
                  onChange={(e) => setCsvText(e.target.value)}
                  placeholder="Paste raw CSV string e.g.:&#10;ColA,ColB&#10;1.2,3.4&#10;5.6,7.8"
                  className="w-full h-24 text-[10px] font-mono border border-black rounded-none p-1.5 focus:outline-hidden bg-[#E4E3E0]"
                />
                <div className="flex gap-2 text-[10px]">
                  <button
                    onClick={handleCSVImport}
                    className="bg-black text-[#E4E3E0] rounded-none px-3 py-1 font-medium cursor-pointer border border-black"
                  >
                    Confirm Import
                  </button>
                  <button
                    onClick={() => setShowCSVPaster(false)}
                    className="text-black hover:underline px-1 py-1"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => {
                  setCsvText("");
                  setShowCSVPaster(true);
                }}
                className="w-full text-left text-[11px] font-mono font-bold text-black bg-[#E4E3E0] hover:bg-black hover:text-[#E4E3E0] border border-black rounded-none p-2 flex items-center justify-center gap-1.5 cursor-pointer shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all active:translate-x-[1px] active:translate-y-[1px] active:shadow-none"
              >
                <Upload className="w-3.5 h-3.5" /> Import CSV File
              </button>
            )}

            {importStatus && (
              <div className="p-2 border border-black text-[10.5px] font-mono bg-[#141414] text-emerald-400 leading-normal">
                {importStatus}
              </div>
            )}

            {/* Data Sheet Grid Table view */}
            {data.length > 0 ? (
              <div className="flex-1 min-h-32 border border-black rounded-none overflow-hidden bg-[#E4E3E0] max-h-96 lg:max-h-none scrollbar-none">
                <div className="overflow-auto h-full max-h-[420px] lg:max-h-none">
                  <table className="w-full text-left font-mono text-[10px] border-collapse bg-[#E4E3E0]">
                    <thead className="bg-[#141414] text-[#E4E3E0] sticky top-0 uppercase tracking-wider font-bold z-10 select-none">
                      <tr className="border-b border-black">
                        <th className="p-1.5 px-2 bg-black text-[#E4E3E0] border-r border-[#E4E3E0]/20 text-center text-[9px]">Row</th>
                        {headers.map((colh, i) => (
                          <th key={i} className="p-1.5 px-2.5 truncate max-w-24 text-right border-r border-[#E4E3E0]/20" title={colh}>{colh}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-black/30">
                      {data.map((rowVal, rowIdx) => (
                        <tr key={rowIdx} className="hover:bg-black/5 transition-colors">
                          <td className="p-1 px-1.5 bg-black/5 border-r border-black/30 text-center text-black/50 select-none">{rowIdx + 1}</td>
                          {rowVal.map((cellNum, colIdx) => (
                            <td key={colIdx} className="p-0.5 px-1.5 text-right border-r border-black/10">
                              <input
                                type="text"
                                value={cellNum}
                                onChange={(e) => handleCellChange(rowIdx, colIdx, e.target.value)}
                                className="w-16 text-right px-1 py-0.5 rounded-none focus:bg-white focus:ring-1 focus:ring-black focus:outline-hidden font-bold select-all bg-transparent text-black"
                              />
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="p-8 border-2 border-dashed border-black text-center text-black/60 text-xs font-mono rounded-none">
                Tabular workspace is empty. Load preset or complete CSV import.
              </div>
            )}
          </div>
        </aside>

        {/* Right Side: Interactive Analytical Compute Console */}
        <main className="flex-1 flex flex-col overflow-hidden">
          
          {/* Main Top Navigation Engine select Tab-Row */}
          <div className="bg-[#E4E3E0] border-b border-black px-6 py-2.5 flex overflow-x-auto shrink-0 gap-1.5 scrollbar-none items-center z-10 border-t lg:border-t-0">
            {[
              { id: "descriptive", label: "Descriptive", icon: Sliders },
              { id: "distributions", label: "Distributions", icon: TrendingUp },
              { id: "regression", label: "Regression", icon: ArrowRightLeft },
              { id: "hypothesis", label: "Hypothesis", icon: HelpCircle },
              { id: "bayesian", label: "Bayesian", icon: Brain },
              { id: "multivariate", label: "Multivariate", icon: Sliders },
              { id: "timeseries", label: "Time-Series", icon: FileCode },
              { id: "simulation", label: "Simulations", icon: ArrowRightLeft },
            ].map((tab) => {
              const TabIcon = tab.icon;
              const isSelected = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabName)}
                  className={`flex items-center gap-1.5 text-xs font-mono font-bold uppercase px-3 py-1.5 border border-black rounded-none shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all active:translate-x-[0.5px] active:translate-y-[0.5px] active:shadow-none cursor-pointer whitespace-nowrap ${
                    isSelected
                      ? "bg-black text-[#E4E3E0]"
                      : "bg-[#E4E3E0] text-black hover:bg-black/10"
                  }`}
                >
                  <TabIcon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Output Content Wrapper */}
          <div className="flex-1 overflow-auto p-6 max-w-7xl mx-auto w-full bg-[#E4E3E0]">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.15 }}
                className="bg-[#E4E3E0] p-6 rounded-none border border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
              >
                {activeTab === "descriptive" && <DescriptiveStatsTab headers={headers} data={data} />}
                {activeTab === "distributions" && <DistributionsTab />}
                {activeTab === "regression" && <RegressionTab headers={headers} data={data} />}
                {activeTab === "hypothesis" && <HypothesisTab headers={headers} data={data} />}
                {activeTab === "bayesian" && <BayesianTab />}
                {activeTab === "multivariate" && <MultivariateTab headers={headers} data={data} />}
                {activeTab === "timeseries" && <TimeSeriesTab headers={headers} data={data} />}
                {activeTab === "simulation" && <SimulationTab headers={headers} data={data} />}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>

      </div>
    </div>
  );
}
