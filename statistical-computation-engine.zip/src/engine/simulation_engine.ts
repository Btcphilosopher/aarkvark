/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BootstrapReport } from "./types";
import { NormalMode } from "./distributions";
import { quantiles, stdDev, mean } from "./descriptive_stats";

/**
 * Perform Bootstrap Resampling with replacement to construct empirical distributions.
 * @param data Original observation array
 * @param statFn Callback function calculating target statistic on an array of numbers
 * @param replicatesNumber Number of resampled datasets to build
 * @param alpha Significance boundary for Confidence Interval (default 0.05, yielding 95% CI)
 */
export function bootstrap(
  data: number[],
  statFn: (sample: number[]) => number,
  replicatesNumber = 1000,
  alpha = 0.05
): BootstrapReport {
  const n = data.length;
  if (n === 0) {
    throw new Error("Cannot run bootstrap on an empty dataset.");
  }

  const originalValue = statFn(data);
  const replicates: number[] = [];

  for (let r = 0; r < replicatesNumber; r++) {
    // Resample with replacement
    const bootstrapSample: number[] = [];
    for (let i = 0; i < n; i++) {
      const idx = Math.floor(Math.random() * n);
      bootstrapSample.push(data[idx]);
    }
    // Calculate and log statistic
    replicates.push(statFn(bootstrapSample));
  }

  // Diagnostics
  const repMean = mean(replicates);
  const bias = repMean - originalValue;
  const sErr = stdDev(replicates, true);

  // Percentile confidence interval
  const qLow = alpha / 2;
  const qHigh = 1.0 - alpha / 2;
  const ciVals = quantiles(replicates, [qLow, qHigh]);

  return {
    originalValue,
    bias,
    stdError: sErr,
    confidenceInterval: [ciVals[0], ciVals[1]],
    replicates,
  };
}

/**
 * Simulate standard Random Walk paths.
 * X_t = X_{t-1} + e_t, where e_t ~ N(drift, std)
 */
export function simulateRandomWalk(
  steps: number,
  x0 = 0,
  drift = 0,
  noiseStd = 1.0,
  pathsCount = 1
): number[][] {
  const paths: number[][] = [];
  
  for (let p = 0; p < pathsCount; p++) {
    const path = [x0];
    let current = x0;
    for (let t = 1; t <= steps; t++) {
      const e = NormalMode.sample(drift, noiseStd);
      current += e;
      path.push(current);
    }
    paths.push(path);
  }
  
  return paths;
}

/**
 * Simulate Geometric Brownian Motion (GBM) trajectories.
 * S_t = S_{t-1} * exp( (mu - sigma^2/2)*dt + sigma*W_t )
 */
export function simulateGBM(
  steps: number,
  s0 = 100.0,
  driftMu = 0.05,
  volatilitySigma = 0.2,
  dt = 1.0 / 252.0, // daily increment assuming yearly scaling
  pathsCount = 1
): number[][] {
  const paths: number[][] = [];
  const driftTerm = (driftMu - Math.pow(volatilitySigma, 2) / 2.0) * dt;
  const diffusionCoeff = volatilitySigma * Math.sqrt(dt);

  for (let p = 0; p < pathsCount; p++) {
    const path = [s0];
    let current = s0;
    for (let t = 1; t <= steps; t++) {
      const z = NormalMode.sample(0, 1);
      current = current * Math.exp(driftTerm + diffusionCoeff * z);
      path.push(current);
    }
    paths.push(path);
  }

  return paths;
}

/**
 * Portfolio Value-at-Risk (VaR) Monte Carlo Simulator.
 * Simulates portfolio final outcomes given mean and standard deviation of asset returns,
 * and outputs Value-at-Risk and standard quantile percentiles.
 */
export function portfolioMonteCarlo(
  initialInvestment: number,
  expectedReturn: number,
  volatility: number,
  days = 252,
  simulationsCount = 5000,
  varConfidence = 0.95
): {
  finalValues: number[];
  meanFinalValue: number;
  expectedShortfall: number;
  valueAtRisk: number;
  quantilesDistribution: Record<string, number>;
} {
  const dt = 1.0 / 252.0;
  const paths = simulateGBM(days, initialInvestment, expectedReturn, volatility, dt, simulationsCount);
  const finalValues = paths.map((path) => path[path.length - 1]);

  // Sort values to compute Value-at-Risk quantiles
  const sortedValues = [...finalValues].sort((a, b) => a - b);
  
  // Value-at-Risk represents the expected cut-off loss at a specified confidence level
  // e.g. for 95% confidence, it is the 5% quantile of final portfolio valuation
  const varQuantileIdx = Math.floor(simulationsCount * (1 - varConfidence));
  const varValue = initialInvestment - sortedValues[varQuantileIdx];

  // Expected Shortfall (CVaR): average loss in the worst (1 - confidence) % cases
  let worstSum = 0;
  for (let i = 0; i <= varQuantileIdx; i++) {
    worstSum += (initialInvestment - sortedValues[i]);
  }
  const esValue = worstSum / (varQuantileIdx + 1);

  // Core quantiles
  const qvals = quantiles(sortedValues, [0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99]);

  return {
    finalValues,
    meanFinalValue: mean(finalValues),
    valueAtRisk: Math.max(0, varValue),
    expectedShortfall: Math.max(0, esValue),
    quantilesDistribution: {
      "1% (Worst case)": qvals[0],
      "5% (VaR boundary)": qvals[1],
      "25% (Q1)": qvals[2],
      "50% (Median)": qvals[3],
      "75% (Q3)": qvals[4],
      "95% (Upside boundary)": qvals[5],
      "99% (Upside extreme)": qvals[6],
    },
  };
}
