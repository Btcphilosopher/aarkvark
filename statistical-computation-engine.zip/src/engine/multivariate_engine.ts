/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PCAOutput, ClusterSummary } from "./types";
import { eigenPowerMethod } from "./matrix_utils";
import { mean, stdDev } from "./descriptive_stats";

/**
 * Compute symmetric Covariance Matrix of dataset columns.
 * @param X Input data matrix (n x p): rows represent samples, columns represent variables
 */
export function covarianceMatrix(X: number[][]): number[][] {
  const n = X.length;
  if (n === 0) return [];
  const p = X[0].length;
  
  // Calculate average of each column
  const colMeans: number[] = [];
  for (let j = 0; j < p; j++) {
    const col: number[] = [];
    for (let i = 0; i < n; i++) col.push(X[i][j]);
    colMeans.push(mean(col));
  }

  // Construct covariance matrix
  const cov: number[][] = Array.from({ length: p }, () => Array(p).fill(0));
  for (let j = 0; j < p; j++) {
    for (let k = j; k < p; k++) {
      let sum = 0;
      for (let i = 0; i < n; i++) {
        sum += (X[i][j] - colMeans[j]) * (X[i][k] - colMeans[k]);
      }
      const val = sum / (n - 1);
      cov[j][k] = val;
      cov[k][j] = val; // symmetric mapping
    }
  }

  return cov;
}

/**
 * Compute Correlation Matrix of dataset columns.
 */
export function correlationMatrix(X: number[][]): number[][] {
  const n = X.length;
  if (n === 0) return [];
  const p = X[0].length;
  
  const cov = covarianceMatrix(X);
  const stds: number[] = [];
  for (let j = 0; j < p; j++) {
    const col: number[] = [];
    for (let i = 0; i < n; i++) col.push(X[i][j]);
    const s = stdDev(col, true);
    stds.push(s === 0 ? 1 : s); // avoid division by zero
  }

  const corr: number[][] = Array.from({ length: p }, () => Array(p).fill(0));
  for (let j = 0; j < p; j++) {
    for (let k = 0; k < p; k++) {
      corr[j][k] = cov[j][k] / (stds[j] * stds[k]);
    }
  }
  return corr;
}

/**
 * Perform Principal Component Analysis (PCA).
 * @param X Matrix (N x P)
 * @param scale If true, standardizes each column (z-scores). If false, centers only.
 * @param maxComponents Limit returned axes
 */
export function pca(X: number[][], scale = true, maxComponents?: number): PCAOutput {
  const n = X.length;
  if (n === 0) {
    throw new Error("Cannot run PCA on empty dataset.");
  }
  const p = X[0].length;

  // 1. Center and scale data
  const centers: number[] = [];
  const scales: number[] = [];
  const Z: number[][] = Array.from({ length: n }, () => Array(p).fill(0));

  for (let j = 0; j < p; j++) {
    const col: number[] = [];
    for (let i = 0; i < n; i++) col.push(X[i][j]);
    
    const m = mean(col);
    const s = scale ? stdDev(col, true) : 1;
    
    centers.push(m);
    scales.push(scale ? s : 1.0);

    for (let i = 0; i < n; i++) {
      Z[i][j] = (X[i][j] - m) / (s === 0 ? 1.0 : s);
    }
  }

  // 2. Compute Covariance of Centered (and scaled) data
  const cov = covarianceMatrix(Z);

  // 3. Perform Eigenvalue Decomposition
  const componentsCount = maxComponents ? Math.min(maxComponents, p) : p;
  const { eigenvalues, eigenvectors } = eigenPowerMethod(cov, componentsCount);

  // 4. Summarize Explained Variance
  const sumEigenvalues = eigenvalues.reduce((a, b) => a + Math.max(0, b), 0);
  const proportionOfVariance = eigenvalues.map((ev) => (sumEigenvalues > 0 ? Math.max(0, ev) / sumEigenvalues : 0));
  
  const cumulativeVariance: number[] = [];
  let runningSum = 0;
  for (const v of proportionOfVariance) {
    runningSum += v;
    cumulativeVariance.push(runningSum);
  }

  // 5. Calculate scores: scores S = Z * V
  // In our code eigenvectors[c] represents the c-th principal projection vector.
  const scores: number[][] = Array.from({ length: n }, () => Array(componentsCount).fill(0));
  for (let i = 0; i < n; i++) {
    for (let c = 0; c < componentsCount; c++) {
      let sum = 0;
      for (let j = 0; j < p; j++) {
        sum += Z[i][j] * eigenvectors[c][j];
      }
      scores[i][c] = sum;
    }
  }

  // 6. PCA Loadings: variable directions mapping
  // loadings are the eigenvectors represented as (variables x components)
  const loadings: number[][] = Array.from({ length: p }, () => Array(componentsCount).fill(0));
  for (let j = 0; j < p; j++) {
    for (let c = 0; c < componentsCount; c++) {
      loadings[j][c] = eigenvectors[c][j];
    }
  }

  return {
    eigenvalues,
    eigenvectors,
    proportionOfVariance,
    cumulativeVariance,
    loadings,
    scores,
    centers,
    scales,
  };
}

/**
 * Standard K-means++ seeding to find optimal centroid starts
 */
function kmeansPlusPlusSeeding(X: number[][], k: number): number[][] {
  const n = X.length;
  const p = X[0].length;
  const centroids: number[][] = [];

  // 1. Choose first centroid randomly
  let idx = Math.floor(Math.random() * n);
  centroids.push([...X[idx]]);

  // 2. Sample subsequent centroids
  for (let c = 1; c < k; c++) {
    const minDistancesSq: number[] = [];
    let sumDistSq = 0;

    for (let i = 0; i < n; i++) {
      // Find distance to nearest centroid
      let nearestDistSq = Infinity;
      for (let j = 0; j < centroids.length; j++) {
        let sd = 0;
        for (let r = 0; r < p; r++) {
          sd += Math.pow(X[i][r] - centroids[j][r], 2);
        }
        if (sd < nearestDistSq) {
          nearestDistSq = sd;
        }
      }
      minDistancesSq.push(nearestDistSq);
      sumDistSq += nearestDistSq;
    }

    // Roulette wheel selection based on squared distance
    let thresh = Math.random() * sumDistSq;
    let selectedIdx = n - 1;
    for (let i = 0; i < n; i++) {
      thresh -= minDistancesSq[i];
      if (thresh <= 0) {
        selectedIdx = i;
        break;
      }
    }
    centroids.push([...X[selectedIdx]]);
  }

  return centroids;
}

/**
 * Perform K-means clustering (converges reliably using K-means++ initials).
 */
export function kmeans(X: number[][], k: number, maxIter = 100, tol = 1e-4): ClusterSummary {
  const n = X.length;
  if (n === 0) {
    throw new Error("Cannot run K-means on empty dataset.");
  }
  const p = X[0].length;
  const numClusters = Math.min(k, n);

  // Initialize centroids with K-means++
  let centroids = kmeansPlusPlusSeeding(X, numClusters);
  let assignments = Array(n).fill(-1);
  let sizes = Array(numClusters).fill(0);
  let inertia = 0;

  for (let iter = 0; iter < maxIter; iter++) {
    const nextAssignments = Array(n).fill(-1);
    const nextCentroids: number[][] = Array.from({ length: numClusters }, () => Array(p).fill(0));
    const nextSizes = Array(numClusters).fill(0);
    let totalSqDist = 0;

    // 1. Assignment step
    for (let i = 0; i < n; i++) {
      let minDistSq = Infinity;
      let clusterIdx = 0;

      for (let c = 0; c < numClusters; c++) {
        let distSq = 0;
        for (let j = 0; j < p; j++) {
          distSq += Math.pow(X[i][j] - centroids[c][j], 2);
        }
        if (distSq < minDistSq) {
          minDistSq = distSq;
          clusterIdx = c;
        }
      }

      nextAssignments[i] = clusterIdx;
      nextSizes[clusterIdx]++;
      totalSqDist += minDistSq;
    }

    // 2. Update step
    for (let i = 0; i < n; i++) {
      const cIdx = nextAssignments[i];
      for (let j = 0; j < p; j++) {
        nextCentroids[cIdx][j] += X[i][j];
      }
    }

    for (let c = 0; c < numClusters; c++) {
      if (nextSizes[c] > 0) {
        for (let j = 0; j < p; j++) {
          nextCentroids[c][j] /= nextSizes[c];
        }
      } else {
        // Handle empty cluster: re-assign to a random data point
        const rIdx = Math.floor(Math.random() * n);
        nextCentroids[c] = [...X[rIdx]];
      }
    }

    // Check centroid shift convergence
    let maxShift = 0;
    for (let c = 0; c < numClusters; c++) {
      let shift = 0;
      for (let j = 0; j < p; j++) {
        shift += Math.pow(centroids[c][j] - nextCentroids[c][j], 2);
      }
      maxShift = Math.max(maxShift, Math.sqrt(shift));
    }

    centroids = nextCentroids;
    assignments = nextAssignments;
    sizes = nextSizes;
    inertia = totalSqDist;

    if (maxShift < tol) {
      break;
    }
  }

  return {
    numClusters,
    centroids,
    assignments,
    sizes,
    inertia,
    points: X,
  };
}
