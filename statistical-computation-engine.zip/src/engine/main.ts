/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Re-export all type definitions
export * from "./types";

// Import modules for internal usage
import * as matrixUtils from "./matrix_utils";
import * as descriptiveStats from "./descriptive_stats";
import * as distributions from "./distributions";
import * as regressionEngine from "./regression_engine";
import * as hypothesisTesting from "./hypothesis_testing";
import * as bayesianEngine from "./bayesian_engine";
import * as multivariateEngine from "./multivariate_engine";
import * as timeSeriesStats from "./time_series_stats";
import * as simulationEngine from "./simulation_engine";

// Re-export individual engines
export {
  matrixUtils,
  descriptiveStats,
  distributions,
  regressionEngine,
  hypothesisTesting,
  bayesianEngine,
  multivariateEngine,
  timeSeriesStats,
  simulationEngine
};

/**
 * Parsers & Exporters for Tabular spreadsheet integrations.
 */

/**
 * Export 2D numeric grid as a CSV spreadsheet.
 * @param data Rows of floats
 * @param headers Optional column headings
 */
export function exportToCSV(data: number[][], headers?: string[]): string {
  const rows: string[] = [];
  
  if (headers && headers.length > 0) {
    rows.push(headers.map((h) => `"${h.replace(/"/g, '""')}"`).join(","));
  }

  for (let i = 0; i < data.length; i++) {
    rows.push(data[i].join(","));
  }

  return rows.join("\n");
}

/**
 * Export key-value structures or reports to CSV.
 */
export function exportObjectToCSV(obj: Record<string, any>): string {
  const rows: string[] = [];
  rows.push('"Metric","Value"');
  
  for (const [key, val] of Object.entries(obj)) {
    let strVal = "";
    if (Array.isArray(val)) {
      strVal = `"[${val.join(", ")}]"`;
    } else if (typeof val === "object" && val !== null) {
      strVal = `"${JSON.stringify(val).replace(/"/g, '""')}"`;
    } else {
      strVal = `"${String(val).replace(/"/g, '""')}"`;
    }
    rows.push(`"${key.replace(/"/g, '""')}",${strVal}`);
  }
  
  return rows.join("\n");
}

/**
 * Parse standard CSV file text into a 2D tabular array of values,
 * attempting to automatically extract headers and load numeric columns.
 */
export function parseCSV(csvText: string): { headers: string[]; data: number[][] } {
  const lines = csvText.split(/\r?\n/).map((line) => line.trim()).filter((line) => line.length > 0);
  if (lines.length === 0) {
    return { headers: [], data: [] };
  }

  // Parse first row as headers or check if it represents data
  const firstRowCells = parseCSVLine(lines[0]);
  const isHeaderNumeric = firstRowCells.every((cell) => !isNaN(parseFloat(cell)));

  let headers: string[] = [];
  let startIdx = 0;

  if (!isHeaderNumeric) {
    headers = firstRowCells;
    startIdx = 1;
  } else {
    headers = firstRowCells.map((_, i) => `Col${i + 1}`);
    startIdx = 0;
  }

  const data: number[][] = [];
  for (let i = startIdx; i < lines.length; i++) {
    const cells = parseCSVLine(lines[i]);
    const rowValues = cells.map((cell) => {
      const val = parseFloat(cell);
      return isNaN(val) ? 0.0 : val; // default non-numerics to 0
    });
    
    if (rowValues.length > 0) {
      data.push(rowValues);
    }
  }

  return { headers, data };
}

/**
 * Regex-based standard CSV line parser supporting quoted fields.
 */
function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let currentCell = "";
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === "," && !inQuotes) {
      result.push(currentCell.trim());
      currentCell = "";
    } else {
      currentCell += char;
    }
  }
  result.push(currentCell.trim());
  return result;
}

/**
 * Primary Unified Engine Class for orchestrating simple spreadsheet range operations.
 */
export class StatisticalEngine {
  /**
   * Helper to extract a single column as vector from a 2D tabular spreadsheet range.
   */
  static getColumnVector(data: number[][], colIdx: number): number[] {
    return data.map((row) => row[colIdx]);
  }

  /**
   * Run descriptive analytics on a spreadsheet column.
   */
  static analyzeColumn(data: number[][], colIdx: number): Record<string, any> {
    const vector = this.getColumnVector(data, colIdx);
    return descriptiveStats.summary(vector);
  }

  /**
   * Run a regression analysis between specific columns.
   */
  static runRegression(
    data: number[][],
    predictorCols: number[],
    responseCol: number,
    regressionType: "linear" | "multiple" | "polynomial" = "multiple",
    polyDegree = 2
  ) {
    const Y = this.getColumnVector(data, responseCol);

    if (regressionType === "linear" && predictorCols.length > 0) {
      const XVec = this.getColumnVector(data, predictorCols[0]);
      return regressionEngine.fitLinearRegression(XVec, Y);
    }

    if (regressionType === "polynomial" && predictorCols.length > 0) {
      const XVec = this.getColumnVector(data, predictorCols[0]);
      return regressionEngine.fitPolynomialRegression(XVec, Y, polyDegree);
    }

    // Default: Multiple regression
    const XMatrix = data.map((row) => {
      const designRow = [1.0]; // include intercept
      for (const idx of predictorCols) {
        designRow.push(row[idx]);
      }
      return designRow;
    });

    const coefNames = ["(Intercept)", ...predictorCols.map((c) => `Column_${c}`)];
    return regressionEngine.fitMultipleRegression(XMatrix, Y, coefNames);
  }

  /**
   * Run PCA on specific subset of spreadsheet columns.
   */
  static runPCA(data: number[][], columns: number[], scale = true) {
    const subMatrix = data.map((row) => columns.map((idx) => row[idx]));
    return multivariateEngine.pca(subMatrix, scale);
  }

  /**
   * Run K-means clustering on specific spreadsheet columns.
   */
  static runKMeans(data: number[][], columns: number[], k: number) {
    const subMatrix = data.map((row) => columns.map((idx) => row[idx]));
    return multivariateEngine.kmeans(subMatrix, k);
  }
}
