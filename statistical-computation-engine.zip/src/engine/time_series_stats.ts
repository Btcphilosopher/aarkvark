/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { StationarityTestResult } from "./types";
import { mean, variance, stdDev } from "./descriptive_stats";
import { fitMultipleRegression } from "./regression_engine";

/**
 * Compute Simple Moving Average (SMA) of window k.
 */
export function rollingMean(x: number[], k: number): number[] {
  const n = x.length;
  const result: number[] = Array(n).fill(NaN);
  if (k <= 0 || k > n) return result;

  let sum = 0;
  for (let i = 0; i < k; i++) {
    sum += x[i];
  }
  result[k - 1] = sum / k;

  for (let i = k; i < n; i++) {
    sum += x[i] - x[i - k];
    result[i] = sum / k;
  }
  return result;
}

/**
 * Compute Rolling Standard Deviation of window k.
 */
export function rollingStdDev(x: number[], k: number): number[] {
  const n = x.length;
  const result: number[] = Array(n).fill(NaN);
  if (k < 2 || k > n) return result;

  for (let i = k - 1; i < n; i++) {
    const slice = x.slice(i - k + 1, i + 1);
    result[i] = stdDev(slice, true);
  }
  return result;
}

/**
 * Compute Exponentially Weighted Moving Average (EWMA) with smoothing factor alpha.
 * @param alpha Smoothing parameter, normally alpha = 2 / (span + 1)
 */
export function ewma(x: number[], span: number, alpha?: number): number[] {
  const n = x.length;
  const result: number[] = Array(n).fill(NaN);
  if (n === 0) return result;

  const a = alpha !== undefined ? alpha : 2.0 / (span + 1.0);
  
  result[0] = x[0];
  for (let i = 1; i < n; i++) {
    result[i] = a * x[i] + (1 - a) * result[i - 1];
  }
  return result;
}

/**
 * Compute Autocorrelation Function (ACF) up to a max lag.
 */
export function acf(x: number[], maxLag = 20): number[] {
  const n = x.length;
  if (n === 0) return [];
  const limit = Math.min(maxLag, n - 1);
  const avg = mean(x);

  // Compute variance (lag 0 covariance)
  let c0 = 0;
  for (let i = 0; i < n; i++) {
    c0 += Math.pow(x[i] - avg, 2);
  }
  c0 = c0 / n;

  const r: number[] = [1.0]; // lag 0 is always 1

  for (let l = 1; l <= limit; l++) {
    let cl = 0;
    for (let t = 0; t < n - l; t++) {
      cl += (x[t] - avg) * (x[t + l] - avg);
    }
    cl = cl / n;
    r.push(c0 > 0 ? cl / c0 : 0);
  }
  return r;
}

/**
 * Compute Partial Autocorrelation Function (PACF) using Durbin-Levinson recursion.
 */
export function pacf(x: number[], maxLag = 20): number[] {
  const rIdx = acf(x, maxLag);
  const limit = rIdx.length - 1;
  const p: number[] = [1.0]; // lag 0 is 1

  if (limit <= 0) return p;
  
  // Durbin-Levinson recursion
  p.push(rIdx[1]); // lag 1 is identical to ACF

  let phiCurrent = [rIdx[1]];

  for (let k = 2; k <= limit; k++) {
    let numSum = 0;
    for (let j = 1; j < k; j++) {
      numSum += phiCurrent[j - 1] * rIdx[k - j];
    }
    const pk = (rIdx[k] - numSum) / (1 - phiCurrent.reduce((acc, val, idx) => acc + val * rIdx[idx + 1], 0)); // denominator logic
    
    // Stabilized Durbin-Levinson ratio alternative:
    // Solve Yule-Walker equations for PACF coefficients
    let numer = rIdx[k];
    let denom = 1.0;
    const phiNext = Array(k).fill(0);
    
    // Using a simple approximation of PACF solve or direct solve as k remains small
    // Re-writing Durbin-Levinson update for standard representation:
    let numerator = rIdx[k];
    let denominatorTotal = 1.0;
    for (let i = 0; i < k - 1; i++) {
      numerator -= phiCurrent[i] * rIdx[k - 1 - i];
    }
    
    // Recompute denominator
    let sumDenom = 0;
    for (let i = 0; i < k - 1; i++) {
      let temp = 0;
      for (let j = 0; j < k - 1; j++) {
        temp += phiCurrent[j] * rIdx[Math.abs(i - j)];
      }
      sumDenom += phiCurrent[i] * rIdx[i + 1];
    }
    
    const phiKK = numerator / (1.0 - sumDenom);
    p.push(isNaN(phiKK) || Math.abs(phiKK) > 1.0 ? 0.05 : phiKK); // guard stability

    // Update coefficient vector
    for (let j = 0; j < k - 1; j++) {
      phiNext[j] = phiCurrent[j] - phiKK * phiCurrent[k - 2 - j];
    }
    phiNext[k - 1] = phiKK;
    phiCurrent = phiNext;
  }

  return p;
}

/**
 * Perform Augmented Dickey-Fuller (ADF) unit-root test to identify stationarity.
 * We perform the model: dy_t = alpha + gamma * y_{t-1} + e_t
 * If lag differences is specified (ADF), we add them as regressors.
 * Null hypothesis (gamma = 0) indicates non-stationarity (unit root).
 * Alternative (gamma < 0) indicates stationarity.
 */
export function dickeyFullerTest(y: number[], lagDifferences = 0): StationarityTestResult {
  const n = y.length;
  if (n < lagDifferences + 5) {
    throw new Error("Timeline series too short to evaluate stationarity.");
  }

  // Calculate dy_t = y_t - y_{t-1}
  const dy: number[] = [];
  for (let i = 1; i < n; i++) {
    dy.push(y[i] - y[i - 1]);
  }

  // Regress dy_t on: Intercept, y_{t-1} [lagged level], and lagged dy [if specified]
  // Size of regression dataset
  const startIdx = lagDifferences; // skip first elements for lags
  const regY: number[] = [];
  const regX: number[][] = [];

  for (let t = startIdx + 1; t < n; t++) {
    // response: dy[t-1] since dy is shifted by 1 index compared to y
    regY.push(y[t] - y[t - 1]);

    // regressors
    const designRow = [
      1.0, // Intercept (drift)
      y[t - 1], // y_{t-1} (lag 1 level)
    ];

    // Add lagged differences dy_{t-1} ...
    for (let L = 1; L <= lagDifferences; L++) {
      // index in dy: (t - 1 - L)
      designRow.push(y[t - L] - y[t - 1 - L]);
    }

    regX.push(designRow);
  }

  // Fit Multiple Linear Regression
  const fit = fitMultipleRegression(regX, regY);
  
  // Extract coefficient for y_{t-1} (located at index 1 in coefficients list)
  const gammaCoef = fit.coefficients[1];
  const tStat = gammaCoef.tStat;

  // 5% critical values for Dickey-Fuller distribution table (with Constant / Drift)
  // For standard sample sizes n ~ 100, the 5% critical value is roughly -2.89
  const criticalValue5Pct = -2.89;
  const isStationary = tStat < criticalValue5Pct;

  // Approximate p-value logic for DF statistic (approximates the non-standard DF distribution)
  // For drift model, t_stat maps to standard DF critical boundaries:
  // t < -3.5 (p < 0.01), t < -2.9 (p < 0.05), t < -2.6 (p < 0.1), t > -1.5 (p > 0.5)
  let pValApprox = 0;
  if (tStat < -3.49) pValApprox = 0.005;
  else if (tStat < -2.89) pValApprox = 0.035;
  else if (tStat < -2.57) pValApprox = 0.085;
  else if (tStat < -1.94) pValApprox = 0.35;
  else if (tStat < -1.5) pValApprox = 0.55;
  else pValApprox = 0.85;

  return {
    statistic: tStat,
    criticalValue5Pct,
    isStationary,
    pValueApproximation: pValApprox,
    laggedDifferences: lagDifferences,
  };
}

/**
 * Historical Log-Returns Volatility (Standardized to annual volatility assuming 252 periods).
 */
export function historicalVolatility(series: number[], annualPeriods = 252): number {
  const n = series.length;
  if (n < 3) return 0;

  // Compute log returns: r_t = ln(S_t / S_{t-1})
  const returns: number[] = [];
  for (let i = 1; i < n; i++) {
    if (series[i - 1] > 0 && series[i] > 0) {
      returns.push(Math.log(series[i] / series[i - 1]));
    }
  }

  if (returns.length < 2) return 0;
  const s = stdDev(returns, true);
  return s * Math.sqrt(annualPeriods);
}

/**
 * Basic GARCH(1,1) volatility filter simulation.
 * sigma_t^2 = omega + alpha * e_{t-1}^2 + beta * sigma_{t-1}^2
 */
export function garchVolatility(series: number[], omega = 1e-6, alpha = 0.1, beta = 0.85): number[] {
  const n = series.length;
  if (n < 3) return Array(n).fill(0);

  // Compute returns
  const returns: number[] = [0];
  for (let i = 1; i < n; i++) {
    returns.push(series[i - 1] !== 0 ? (series[i] - series[i - 1]) / series[i - 1] : 0);
  }

  const unconditionalVar = variance(returns.slice(1));
  const sigSq: number[] = [unconditionalVar];

  for (let i = 1; i < n; i++) {
    const prevRet = returns[i];
    const s2 = omega + alpha * Math.pow(prevRet, 2) + beta * sigSq[i - 1];
    sigSq.push(s2);
  }

  return sigSq.map((val) => Math.sqrt(val));
}
