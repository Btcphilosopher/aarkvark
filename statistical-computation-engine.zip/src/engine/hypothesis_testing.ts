/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HypothesisTestReport } from "./types";
import { mean, variance, stdDev } from "./descriptive_stats";
import { studentTCDF, studentTInvCDF } from "./regression_engine";
import { gammap, stdNormalCDF, stdNormalInvCDF, betai } from "./distributions";

/**
 * Perform a 1-Sample Student's t-test.
 */
export function oneSampleTTest(x: number[], mu0 = 0, alpha = 0.05, alternative: "two-sided" | "less" | "greater" = "two-sided"): HypothesisTestReport {
  const n = x.length;
  if (n < 2) {
    throw new Error("One-sample t-test requires at least 2 data points.");
  }
  const xMean = mean(x);
  const s = stdDev(x, true);
  const df = n - 1;
  const se = s / Math.sqrt(n);
  
  const tStat = se > 0 ? (xMean - mu0) / se : 0;
  
  let pValue = 0;
  if (alternative === "two-sided") {
    pValue = 2 * (1 - studentTCDF(Math.abs(tStat), df));
  } else if (alternative === "less") {
    pValue = studentTCDF(tStat, df);
  } else {
    pValue = 1 - studentTCDF(tStat, df);
  }
  
  // Confidence Interval for mean
  const tCrit = studentTInvCDF(1 - alpha / 2, df);
  const ci: [number, number] = [xMean - tCrit * se, xMean + tCrit * se];
  
  return {
    testName: "1-Sample Student's t-test",
    statisticName: "t",
    statistic: tStat,
    pValue,
    df,
    confidenceInterval: ci,
    nullHypothesis: `True mean is equal to ${mu0}`,
    alternativeHypothesis: `True mean is ${alternative === "two-sided" ? "not equal to" : alternative === "less" ? "less than" : "greater than"} ${mu0}`,
    isSignificant: pValue < alpha,
    alpha,
    method: "Analytical Student's T CDF based on Incomplete Beta Function",
    additionalInfo: {
      mean: xMean,
      stdDev: s,
      se,
      n,
    },
  };
}

/**
 * Perform a 2-Sample t-test. Handles both Student's (equal variances) and Welch's (unequal variances, default).
 */
export function twoSampleTTest(
  x1: number[],
  x2: number[],
  equalVar = false,
  alpha = 0.05,
  alternative: "two-sided" | "less" | "greater" = "two-sided"
): HypothesisTestReport {
  const n1 = x1.length;
  const n2 = x2.length;
  if (n1 < 2 || n2 < 2) {
    throw new Error("Both groups must contain at least 2 observations.");
  }

  const m1 = mean(x1);
  const m2 = mean(x2);
  const v1 = variance(x1, true);
  const v2 = variance(x2, true);

  let tStat = 0;
  let df = 0;
  let se = 0;
  let method = "";

  if (equalVar) {
    // Student's t-test
    df = n1 + n2 - 2;
    const pooledVar = ((n1 - 1) * v1 + (n2 - 1) * v2) / df;
    se = Math.sqrt(pooledVar * (1 / n1 + 1 / n2));
    tStat = se > 0 ? (m1 - m2) / se : 0;
    method = "Pooled Identical Variance Student's t-test";
  } else {
    // Welch's t-test
    const term1 = v1 / n1;
    const term2 = v2 / n2;
    se = Math.sqrt(term1 + term2);
    tStat = se > 0 ? (m1 - m2) / se : 0;
    
    // Welch-Satterthwaite equation
    const num = Math.pow(term1 + term2, 2);
    const den = Math.pow(term1, 2) / (n1 - 1) + Math.pow(term2, 2) / (n2 - 1);
    df = den > 0 ? num / den : 1;
    method = "Welch's Unequal Variance t-test (Satterthwaite df)";
  }

  let pValue = 0;
  if (alternative === "two-sided") {
    pValue = 2 * (1 - studentTCDF(Math.abs(tStat), df));
  } else if (alternative === "less") {
    pValue = studentTCDF(tStat, df);
  } else {
    pValue = 1 - studentTCDF(tStat, df);
  }

  const tCrit = studentTInvCDF(1 - alpha / 2, df);
  const meanDiff = m1 - m2;
  const ci: [number, number] = [meanDiff - tCrit * se, meanDiff + tCrit * se];

  return {
    testName: equalVar ? "Two-Sample Student's t-test" : "Two-Sample Welch's t-test",
    statisticName: "t",
    statistic: tStat,
    pValue,
    df,
    confidenceInterval: ci,
    nullHypothesis: "True difference in means is equal to 0",
    alternativeHypothesis: `True difference in means is ${alternative === "two-sided" ? "not equal to" : alternative === "less" ? "less than" : "greater than"} 0`,
    isSignificant: pValue < alpha,
    alpha,
    method,
    additionalInfo: {
      mean1: m1,
      mean2: m2,
      variance1: v1,
      variance2: v2,
      n1,
      n2,
      meanDiff,
      se,
    },
  };
}

/**
 * Perform a Paired t-test
 */
export function pairedTTest(
  x1: number[],
  x2: number[],
  alpha = 0.05,
  alternative: "two-sided" | "less" | "greater" = "two-sided"
): HypothesisTestReport {
  if (x1.length !== x2.length) {
    throw new Error("Paired groups must contain an identical number of observations.");
  }
  const differences = x1.map((val, idx) => val - x2[idx]);
  const report = oneSampleTTest(differences, 0, alpha, alternative);
  
  return {
    ...report,
    testName: "Paired Student's t-test",
    nullHypothesis: "Mean difference between paired groups is equal to 0",
    alternativeHypothesis: `Mean difference in paired groups is ${alternative === "two-sided" ? "not equal to" : alternative === "less" ? "less than" : "greater than"} 0`,
    additionalInfo: {
      ...report.additionalInfo,
      mean1: mean(x1),
      mean2: mean(x2),
      meanDifference: report.additionalInfo?.mean,
    },
  };
}

/**
 * Chi-Square Goodness-of-Fit Test
 * @param observed Counts in each category
 * @param expected Either expected counts or probabilities (summing to 1)
 */
export function chiSquareGoodnessOfFit(observed: number[], expected: number[], alpha = 0.05): HypothesisTestReport {
  const k = observed.length;
  if (k < 2 || k !== expected.length) {
    throw new Error("Goodness-of-fit test requires at least 2 matching categories.");
  }

  const nObs = observed.reduce((a, b) => a + b, 0);
  const sumExp = expected.reduce((a, b) => a + b, 0);

  // If expected represents probabilities (sums close to 1), scale to actual expected counts
  let actualExpected: number[] = [...expected];
  if (Math.abs(sumExp - 1) < 1e-5) {
    actualExpected = expected.map((p) => p * nObs);
  }

  let chi2 = 0;
  for (let i = 0; i < k; i++) {
    if (actualExpected[i] <= 0) {
      throw new Error("Expected frequencies must be strictly greater than 0.");
    }
    chi2 += Math.pow(observed[i] - actualExpected[i], 2) / actualExpected[i];
  }

  const df = k - 1;
  // p-value: Chi-Square CDF = lower complete gamma.
  // P-value = 1 - gammap(df/2, chi2/2)
  const pValue = 1 - gammap(df / 2, chi2 / 2);

  return {
    testName: "Chi-Square Goodness-of-Fit Test",
    statisticName: "X-squared",
    statistic: chi2,
    pValue,
    df,
    nullHypothesis: "Population probabilities match the specified distribution",
    alternativeHypothesis: "Population probabilities do not match the specified distribution",
    isSignificant: pValue < alpha,
    alpha,
    method: "Pearson chi-square goodness-of-fit, p-value from Regularized Gamma representation",
    additionalInfo: {
      observed,
      expected: actualExpected,
    },
  };
}

/**
 * Chi-Square Test of Independence (Contingency Table)
 * @param table r x c matrix of observed categories
 */
export function chiSquareIndependence(table: number[][], alpha = 0.05): HypothesisTestReport {
  const r = table.length;
  if (r < 2) throw new Error("Contingency table must contain at least 2 rows.");
  const c = table[0].length;
  if (c < 2) throw new Error("Contingency table must contain at least 2 columns.");

  // Row and columns sums
  const rowSums = Array(r).fill(0);
  const colSums = Array(c).fill(0);
  let total = 0;

  for (let i = 0; i < r; i++) {
    for (let j = 0; j < c; j++) {
      rowSums[i] += table[i][j];
      colSums[j] += table[i][j];
      total += table[i][j];
    }
  }

  // Expecteds
  let chi2 = 0;
  const expectedTable: number[][] = Array.from({ length: r }, () => Array(c).fill(0));

  for (let i = 0; i < r; i++) {
    for (let j = 0; j < c; j++) {
      const exp = (rowSums[i] * colSums[j]) / total;
      expectedTable[i][j] = exp;
      if (exp > 0) {
        chi2 += Math.pow(table[i][j] - exp, 2) / exp;
      }
    }
  }

  const df = (r - 1) * (c - 1);
  const pValue = 1 - gammap(df / 2, chi2 / 2);

  return {
    testName: "Chi-Square Test of Independence",
    statisticName: "X-squared",
    statistic: chi2,
    pValue,
    df,
    nullHypothesis: "Categorical variables are fully independent",
    alternativeHypothesis: "Categorical variables are statistically associated",
    isSignificant: pValue < alpha,
    alpha,
    method: "Pearson Contingency Table independence test",
    additionalInfo: {
      observedTable: table,
      expectedTable,
      rowSums,
      colSums,
      total,
    },
  };
}

/**
 * Helper to compute ranks of an array, averaging ties.
 * Returns Rank vector. Very critical for Spearman correlation and nonparametric tests!
 */
export function computeRanks(arr: number[]): number[] {
  const withIndices = arr.map((val, idx) => ({ val, idx }));
  withIndices.sort((a, b) => a.val - b.val);

  const ranks = Array(arr.length).fill(0);
  let i = 0;
  while (i < arr.length) {
    let j = i;
    while (j < arr.length - 1 && withIndices[j + 1].val === withIndices[i].val) {
      j++;
    }

    // Average rank for these elements (ranks are 1-based)
    const avgRank = (i + 1 + j + 1) / 2;
    for (let k = i; k <= j; k++) {
      ranks[withIndices[k].idx] = avgRank;
    }
    i = j + 1;
  }
  return ranks;
}

/**
 * Pearson & Spearman Correlation Test
 */
export function correlationTest(x: number[], y: number[], type: "pearson" | "spearman" = "pearson", alpha = 0.05): HypothesisTestReport {
  const n = x.length;
  if (n !== y.length || n < 4) {
    throw new Error("Correlation test requires at least 4 observations in matching pairs.");
  }

  let coeff = 0;
  let method = "";
  let nullHyp = "";
  let altHyp = "";

  if (type === "pearson") {
    const mx = mean(x);
    const my = mean(y);
    let num = 0;
    let denX = 0;
    let denY = 0;
    for (let i = 0; i < n; i++) {
      const dx = x[i] - mx;
      const dy = y[i] - my;
      num += dx * dy;
      denX += dx * dx;
      denY += dy * dy;
    }
    coeff = denX > 0 && denY > 0 ? num / Math.sqrt(denX * denY) : 0;
    method = "Pearson Product-Moment Correlation Test";
    nullHyp = "True Pearson correlation coefficient is equal to 0";
    altHyp = "True Pearson correlation coefficient is not equal to 0";
  } else {
    // Spearman Rank Correlation
    const rx = computeRanks(x);
    const ry = computeRanks(y);
    const mrx = mean(rx);
    const mry = mean(ry);
    let num = 0;
    let denX = 0;
    let denY = 0;
    for (let i = 0; i < n; i++) {
      const dx = rx[i] - mrx;
      const dy = ry[i] - mry;
      num += dx * dy;
      denX += dx * dx;
      denY += dy * dy;
    }
    coeff = denX > 0 && denY > 0 ? num / Math.sqrt(denX * denY) : 0;
    method = "Spearman Rank Correlation Test (Rank transformations)";
    nullHyp = "True Spearman rank-correlation coefficient is equal to 0";
    altHyp = "True Spearman rank-correlation coefficient is not equal to 0";
  }

  // Assess significance: t = correlation * sqrt((n-2) / (1 - correlation^2))
  const df = n - 2;
  const denom = 1 - coeff * coeff;
  const tStat = denom > 0 ? coeff * Math.sqrt(df / denom) : (coeff > 0 ? Infinity : -Infinity);
  const pValue = 2 * (1 - studentTCDF(Math.abs(tStat), df));

  // Pearson confidence intervals can be computed via Fisher Z-Transformation
  let ci: [number, number] | undefined;
  if (type === "pearson" && Math.abs(coeff) < 1.0) {
    const z = 0.5 * Math.log((1 + coeff) / (1 - coeff));
    const seZ = 1.0 / Math.sqrt(n - 3);
    const zCrit = stdNormalInvCDF(1 - alpha / 2);
    const zLow = z - zCrit * seZ;
    const zHigh = z + zCrit * seZ;
    const rLow = (Math.exp(2 * zLow) - 1) / (Math.exp(2 * zLow) + 1);
    const rHigh = (Math.exp(2 * zHigh) - 1) / (Math.exp(2 * zHigh) + 1);
    ci = [rLow, rHigh];
  }

  return {
    testName: type === "pearson" ? "Pearson's Correlation Test" : "Spearman's Rank Correlation Test",
    statisticName: "t-statistic",
    statistic: tStat,
    pValue,
    df,
    confidenceInterval: ci,
    nullHypothesis: nullHyp,
    alternativeHypothesis: altHyp,
    isSignificant: pValue < alpha,
    alpha,
    method,
    additionalInfo: {
      coefficient: coeff,
      sampleSize: n,
    },
  };
}

/**
 * One-way ANOVA (Analysis of Variance)
 * @param groups Map or array of groups, each containing array of numbers
 */
export function oneWayANOVA(groups: number[][], alpha = 0.05): HypothesisTestReport {
  const k = groups.length;
  if (k < 2) {
    throw new Error("One-Way ANOVA requires at least 2 treatment groups.");
  }

  // Get total count, sum, means
  let N = 0;
  let overallSum = 0;
  const nGroup: number[] = [];
  const meanGroup: number[] = [];

  for (let i = 0; i < k; i++) {
    const len = groups[i].length;
    if (len === 0) {
      throw new Error("Groups must not be empty.");
    }
    N += len;
    nGroup.push(len);
    
    let sum = 0;
    for (let j = 0; j < len; j++) {
      sum += groups[i][j];
    }
    overallSum += sum;
    meanGroup.push(sum / len);
  }

  const grandMean = overallSum / N;

  // SSB (Sum of Squares Between Groups)
  let ssb = 0;
  for (let i = 0; i < k; i++) {
    ssb += nGroup[i] * Math.pow(meanGroup[i] - grandMean, 2);
  }

  // SSW (Sum of Squares Within Groups / Residuals)
  let ssw = 0;
  for (let i = 0; i < k; i++) {
    for (let j = 0; j < groups[i].length; j++) {
      ssw += Math.pow(groups[i][j] - meanGroup[i], 2);
    }
  }

  const dfModel = k - 1;
  const dfResidual = N - k;

  const msb = ssb / dfModel;
  const msw = ssw / dfResidual;

  const fStat = msw > 0 ? msb / msw : 0;

  // p-value from F-distribution cumulative CDF
  const xF = (dfModel * fStat) / (dfModel * fStat + dfResidual);
  const pValue = 1 - betai(dfModel / 2, dfResidual / 2, xF);

  return {
    testName: "One-Way ANOVA (Analysis of Variance)",
    statisticName: "F",
    statistic: fStat,
    pValue,
    df: dfResidual, // traditionally df residual is returned as main test df
    nullHypothesis: "All treatment group means are statistically equal",
    alternativeHypothesis: "At least one treatment group mean is statistically different",
    isSignificant: pValue < alpha,
    alpha,
    method: "F-test for equality of row means, p-value from Incomplete Beta representing F CDF",
    additionalInfo: {
      dfBetween: dfModel,
      dfWithin: dfResidual,
      sumSquaresBetween: ssb,
      sumSquaresWithin: ssw,
      meanSquaresBetween: msb,
      meanSquaresWithin: msw,
      groupMeans: meanGroup,
      groupSizes: nGroup,
      grandMean,
    },
  };
}

/**
 * Mann-Whitney U Nonparametric Test (Independent Samples Wilcoxon)
 */
export function mannWhitneyUTest(col1: number[], col2: number[], alpha = 0.05): HypothesisTestReport {
  const n1 = col1.length;
  const n2 = col2.length;

  if (n1 === 0 || n2 === 0) {
    throw new Error("Both groups must contain observations.");
  }

  // Combine and rank
  const combined = [...col1, ...col2];
  const groupIndicators = [...Array(n1).fill(1), ...Array(n2).fill(2)];
  const ranks = computeRanks(combined);

  // Sum of ranks for group 1
  let rankSum1 = 0;
  for (let i = 0; i < combined.length; i++) {
    if (groupIndicators[i] === 1) {
      rankSum1 += ranks[i];
    }
  }

  // Calculate U1 and U2
  const U1 = n1 * n2 + (n1 * (n1 + 1)) / 2 - rankSum1;
  const U2 = n1 * n2 - U1;
  const U = Math.min(U1, U2);

  // Normal approximation (appropriate for n1, n2 >= 10, but widely used for all)
  const muU = (n1 * n2) / 2;

  // Compute tie correction factor
  const sorted = [...combined].sort((a, b) => a - b);
  let tieCorrection = 0;
  let i = 0;
  while (i < sorted.length) {
    let j = i;
    while (j < sorted.length - 1 && sorted[j + 1] === sorted[i]) {
      j++;
    }
    const t = j - i + 1;
    if (t > 1) {
      tieCorrection += (t * t * t - t);
    }
    i = j + 1;
  }

  const N = n1 + n2;
  const sigmaU = Math.sqrt(
    (n1 * n2 / 12) * ((N + 1) - tieCorrection / (N * (N - 1)))
  );

  // Z-statistic (including continuity-correction of 0.5)
  const zStat = sigmaU > 0 ? (Math.abs(U1 - muU) - 0.5) / sigmaU : 0;
  const pValue = 2 * (1 - stdNormalCDF(zStat));

  return {
    testName: "Mann-Whitney U Test (Wilcoxon Rank-Sum)",
    statisticName: "W / U",
    statistic: U,
    pValue,
    nullHypothesis: "The distributions of both populations are statistically identical",
    alternativeHypothesis: "The distributions of both populations differ by a systematic shift",
    isSignificant: pValue < alpha,
    alpha,
    method: "Wilcoxon rank-sum test with normal approximation and tie correction",
    additionalInfo: {
      U1,
      U2,
      rankSum1,
      rankSum2: (N * (N + 1)) / 2 - rankSum1,
      zScore: zStat,
    },
  };
}

/**
 * Wilcoxon Signed-Rank Nonparametric Test (Paired Samples)
 */
export function wilcoxonSignedRankTest(x1: number[], x2: number[], alpha = 0.05): HypothesisTestReport {
  if (x1.length !== x2.length) {
    throw new Error("Wilcoxon signed-rank test requires paired groups.");
  }

  // Filter zero differences
  const differences: number[] = [];
  for (let i = 0; i < x1.length; i++) {
    const diff = x1[i] - x2[i];
    if (diff !== 0) {
      differences.push(diff);
    }
  }

  const n = differences.length;
  if (n < 4) {
    throw new Error("Wilcoxon signed-rank test requires at least 4 non-zero paired differences.");
  }

  const absDiffs = differences.map((d) => Math.abs(d));
  const ranks = computeRanks(absDiffs);

  let wPlus = 0;
  let wMinus = 0;
  for (let i = 0; i < n; i++) {
    if (differences[i] > 0) {
      wPlus += ranks[i];
    } else {
      wMinus += ranks[i];
    }
  }

  const W = Math.min(wPlus, wMinus);

  // Normal approximation
  const muW = (n * (n + 1)) / 4;
  
  // Tie correction
  const sortedAbs = [...absDiffs].sort((a, b) => a - b);
  let tieCorrection = 0;
  let jIdx = 0;
  while (jIdx < sortedAbs.length) {
    let kIdx = jIdx;
    while (kIdx < sortedAbs.length - 1 && sortedAbs[kIdx + 1] === sortedAbs[jIdx]) {
      kIdx++;
    }
    const t = kIdx - jIdx + 1;
    if (t > 1) {
      tieCorrection += (t * t * t - t);
    }
    jIdx = kIdx + 1;
  }

  const sigmaW = Math.sqrt(
    (n * (n + 1) * (2 * n + 1)) / 24 - tieCorrection / 48
  );

  const zStat = sigmaW > 0 ? (Math.abs(wPlus - muW) - 0.5) / sigmaW : 0;
  const pValue = 2 * (1 - stdNormalCDF(zStat));

  return {
    testName: "Wilcoxon Signed-Rank Test",
    statisticName: "V",
    statistic: wPlus, // standard representing statistic for R output
    pValue,
    nullHypothesis: "Median difference between pairs is equal to 0",
    alternativeHypothesis: "Median difference between pairs is not equal to 0",
    isSignificant: pValue < alpha,
    alpha,
    method: "Paired Wilcoxon signed-rank test, asymptotic p-value with tie-reconciled variance",
    additionalInfo: {
      wPlus,
      wMinus,
      zScore: zStat,
      nFilteredPairs: n,
    },
  };
}
