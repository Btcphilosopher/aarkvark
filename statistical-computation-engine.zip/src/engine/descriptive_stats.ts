/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DescriptiveSummary } from "./types";

/**
 * Compute the arithmetic mean of an array of numbers.
 */
export function mean(x: number[]): number {
  if (x.length === 0) return NaN;
  const sum = x.reduce((a, b) => a + b, 0);
  return sum / x.length;
}

/**
 * Compute the median of an array of numbers.
 */
export function median(x: number[]): number {
  if (x.length === 0) return NaN;
  const sorted = [...x].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 !== 0) {
    return sorted[mid];
  }
  return (sorted[mid - 1] + sorted[mid]) / 2;
}

/**
 * Compute the modes of an array of numbers (returns an array of values that are most frequent).
 */
export function mode(x: number[]): number[] {
  if (x.length === 0) return [];
  const freq: Record<number, number> = {};
  let maxCount = 0;
  for (const val of x) {
    freq[val] = (freq[val] || 0) + 1;
    if (freq[val] > maxCount) {
      maxCount = freq[val];
    }
  }
  const modes: number[] = [];
  for (const key in freq) {
    if (freq[key] === maxCount) {
      modes.push(Number(key));
    }
  }
  return modes;
}

/**
 * Compute the variance of an array of numbers.
 * @param sample If true, computes unbiased sample variance (denominator n-1). If false, computes population variance (denominator n).
 */
export function variance(x: number[], sample = true): number {
  const n = x.length;
  if (n < (sample ? 2 : 1)) return NaN;
  const avg = mean(x);
  const sqDiffSum = x.reduce((acc, val) => acc + Math.pow(val - avg, 2), 0);
  return sqDiffSum / (n - (sample ? 1 : 0));
}

/**
 * Compute the standard deviation of an array of numbers.
 */
export function stdDev(x: number[], sample = true): number {
  return Math.sqrt(variance(x, sample));
}

/**
 * Compute the Fisher-Pearson standardized skewness coefficient.
 */
export function skewness(x: number[]): number {
  const n = x.length;
  if (n < 3) return NaN;
  const avg = mean(x);
  const dev = stdDev(x, true); // sample std dev
  if (dev === 0) return 0;

  let sumCube = 0;
  for (const val of x) {
    sumCube += Math.pow((val - avg) / dev, 3);
  }

  // Unbiased Fisher-Pearson skewness (similar to R's e1071 / SAS / SPSS)
  return (n * sumCube) / ((n - 1) * (n - 2));
}

/**
 * Compute the kurtosis.
 * @param excess If true, returns excess kurtosis (kurtosis - 3, normal distribution has excess kurtosis of 0).
 */
export function kurtosis(x: number[], excess = true): number {
  const n = x.length;
  if (n < 4) return NaN;
  const avg = mean(x);
  const dev = stdDev(x, true); // sample std dev
  if (dev === 0) return 0;

  let sumFourth = 0;
  for (const val of x) {
    sumFourth += Math.pow((val - avg) / dev, 4);
  }

  // Unbiased Excess Kurtosis (R/SAS/SPSS formula)
  const g2 = ((n * (n + 1)) / ((n - 1) * (n - 2) * (n - 3))) * sumFourth - (3 * Math.pow(n - 1, 2)) / ((n - 2) * (n - 3));
  return excess ? g2 : g2 + 3;
}

/**
 * Obtain quantiles for given probabilities using R Type 7 linear interpolation.
 * @param x Values
 * @param probs Probabilities between 0 and 1
 */
export function quantiles(x: number[], probs: number[]): number[] {
  if (x.length === 0) return probs.map(() => NaN);
  const sorted = [...x].sort((a, b) => a - b);
  const n = sorted.length;

  return probs.map((p) => {
    if (p < 0 || p > 1) throw new Error("Quantile probabilities must be between 0 and 1.");
    if (p === 0) return sorted[0];
    if (p === 1) return sorted[n - 1];

    const h = (n - 1) * p;
    const i = Math.floor(h);
    const g = h - i;

    return (1 - g) * sorted[i] + g * sorted[i + 1];
  });
}

/**
 * Compute a single percentile (value between 0 and 100).
 */
export function percentile(x: number[], p: number): number {
  return quantiles(x, [p / 100])[0];
}

/**
 * Generate a complete descriptive statistics summary of a numeric vector.
 */
export function summary(x: number[]): DescriptiveSummary {
  const n = x.length;
  if (n === 0) {
    return {
      n: 0,
      min: NaN,
      q1: NaN,
      median: NaN,
      mean: NaN,
      q3: NaN,
      max: NaN,
      range: NaN,
      variance: NaN,
      stdDev: NaN,
      skewness: NaN,
      kurtosis: NaN,
      seMean: NaN,
    };
  }

  const sorted = [...x].sort((a, b) => a - b);
  const min = sorted[0];
  const max = sorted[n - 1];
  const range = max - min;
  const avg = mean(sorted);
  const qvals = quantiles(sorted, [0.25, 0.5, 0.75]);
  const q1 = qvals[0];
  const med = qvals[1];
  const q3 = qvals[2];

  const s2 = variance(sorted, true);
  const s = stdDev(sorted, true);
  const skew = skewness(sorted);
  const kurt = kurtosis(sorted, true);
  const seMean = n > 0 ? s / Math.sqrt(n) : NaN;

  return {
    n,
    min,
    q1,
    median: med,
    mean: avg,
    q3,
    max,
    range,
    variance: s2,
    stdDev: s,
    skewness: skew,
    kurtosis: kurt,
    seMean,
  };
}
