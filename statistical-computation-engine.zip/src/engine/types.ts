/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface DescriptiveSummary {
  n: number;
  min: number;
  q1: number;
  median: number;
  mean: number;
  q3: number;
  max: number;
  range: number;
  variance: number;
  stdDev: number;
  skewness: number;
  kurtosis: number;
  seMean: number; // Standard Error of Mean
}

export interface RegressionCoefficients {
  name: string;
  estimate: number;
  stdError: number;
  tStat: number;
  pValue: number;
  confidenceInterval: [number, number];
}

export interface RegressionSummary {
  type: "linear" | "multiple" | "logistic" | "polynomial";
  coefficients: RegressionCoefficients[];
  residuals: {
    min: number;
    q1: number;
    median: number;
    q3: number;
    max: number;
    stdError: number;
  };
  rSquared: number;
  adjRSquared: number;
  fStatistic?: number;
  fPValue?: number;
  dfResidual: number;
  dfModel: number;
  converged?: boolean; // For logistic IRLS
  iterations?: number;
}

export interface HypothesisTestReport {
  testName: string;
  statisticName: string;
  statistic: number;
  pValue: number;
  df?: number;
  confidenceInterval?: [number, number];
  nullHypothesis: string;
  alternativeHypothesis: string;
  isSignificant: boolean;
  alpha: number;
  method: string;
  additionalInfo?: Record<string, any>;
}

export interface PCAOutput {
  eigenvalues: number[];
  eigenvectors: number[][]; // eigenvectors as columns or rows
  proportionOfVariance: number[];
  cumulativeVariance: number[];
  loadings: number[][]; // variables by components
  scores: number[][]; // samples by components
  centers: number[];
  scales: number[];
}

export interface ClusterSummary {
  numClusters: number;
  centroids: number[][];
  assignments: number[];
  sizes: number[];
  inertia: number; // Sum of squared errors
  points: number[][]; // Original points for mapping
}

export interface BayesianBetaBinomialResult {
  priorAlpha: number;
  priorBeta: number;
  successes: number;
  failures: number;
  posteriorAlpha: number;
  posteriorBeta: number;
  priorMean: number;
  posteriorMean: number;
  posteriorVariance: number;
  hdi: [number, number]; // 95% Highest Density Interval
}

export interface BayesianNormalNormalResult {
  priorMean: number;
  priorVar: number;
  knownVar: number;
  dataMean: number;
  n: number;
  posteriorMean: number;
  posteriorVar: number;
  hdi: [number, number];
}

export interface BootstrapReport {
  originalValue: number;
  bias: number;
  stdError: number;
  confidenceInterval: [number, number]; // Percentile CI
  replicates: number[];
}

export interface StationarityTestResult {
  statistic: number;
  criticalValue5Pct: number;
  isStationary: boolean;
  pValueApproximation: number;
  laggedDifferences?: number;
}
