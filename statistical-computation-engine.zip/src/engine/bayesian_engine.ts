/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BayesianBetaBinomialResult, BayesianNormalNormalResult } from "./types";
import { betai } from "./distributions";
import { stdNormalInvCDF, NormalMode } from "./distributions";

/**
 * Beta distribution CDF = regularized incomplete beta function Ix(a, b).
 */
export function betaCDF(x: number, alpha: number, beta: number): number {
  return betai(alpha, beta, x);
}

/**
 * Inverse Cumulative Distribution Function of Beta distribution.
 * Solved via bisection root finding on the incomplete beta function.
 */
export function betaInvCDF(p: number, alpha: number, beta: number, maxIter = 100, tol = 1e-12): number {
  if (p <= 0 || p >= 1) {
    if (p === 0) return 0;
    if (p === 1) return 1;
    return NaN;
  }

  let low = 0;
  let high = 1;
  let mid = 0.5;

  for (let i = 0; i < maxIter; i++) {
    mid = (low + high) / 2;
    const val = betaCDF(mid, alpha, beta);
    if (Math.abs(val - p) < tol) {
      break;
    }
    if (val < p) {
      low = mid;
    } else {
      high = mid;
    }
  }

  return mid;
}

/**
 * Perform Bayesian conjugacy updating on Beta-Binomial models.
 * Prior: Beta(alpha, beta)
 * Likelihood: Binomial (n trials, k successes)
 * Posterior: Beta(alpha + k, beta + n - k)
 */
export function bayesianBetaBinomial(
  priorAlpha: number,
  priorBeta: number,
  successes: number,
  failures: number,
  credibility = 0.95
): BayesianBetaBinomialResult {
  const posteriorAlpha = priorAlpha + successes;
  const posteriorBeta = priorBeta + failures;

  const priorMean = priorAlpha / (priorAlpha + priorBeta);
  const posteriorMean = posteriorAlpha / (posteriorAlpha + posteriorBeta);
  const posteriorVariance =
    (posteriorAlpha * posteriorBeta) /
    (Math.pow(posteriorAlpha + posteriorBeta, 2) * (posteriorAlpha + posteriorBeta + 1));

  // Determine standard 95% Highest Density Interval (HDI)
  // For unimodal Beta distribution, we find the interval [a, b] minimizing length
  // satisfying integrated probability = credibility.
  let bestLow = 0;
  let bestHigh = 1;
  let minLength = Infinity;

  const alphaGrid = 1.0 - credibility;
  // Sweep start probabilities from 0 to alphaGrid
  const steps = 100;
  for (let i = 0; i <= steps; i++) {
    const pLow = (alphaGrid * i) / steps;
    const pHigh = pLow + credibility;

    const bLow = betaInvCDF(pLow, posteriorAlpha, posteriorBeta);
    const bHigh = betaInvCDF(pHigh, posteriorAlpha, posteriorBeta);
    const len = bHigh - bLow;

    if (len < minLength) {
      minLength = len;
      bestLow = bLow;
      bestHigh = bHigh;
    }
  }

  return {
    priorAlpha,
    priorBeta,
    successes,
    failures,
    posteriorAlpha,
    posteriorBeta,
    priorMean,
    posteriorMean,
    posteriorVariance,
    hdi: [bestLow, bestHigh],
  };
}

/**
 * Perform Bayesian conjugacy updating on Normal-Normal models (known variance).
 * Prior: N(mu0, var0)
 * Data: mean, size N, known variance
 */
export function bayesianNormalNormal(
  priorMean: number,
  priorVar: number,
  knownVar: number,
  dataMean: number,
  n: number,
  credibility = 0.95
): BayesianNormalNormalResult {
  if (priorVar <= 0 || knownVar <= 0 || n <= 0) {
    throw new Error("Variances and sample sizes must be strictly positive.");
  }

  // Precision updating
  const precisionPrior = 1.0 / priorVar;
  const precisionData = n / knownVar;
  const precisionPosterior = precisionPrior + precisionData;

  const posteriorVar = 1.0 / precisionPosterior;
  const posteriorMean = posteriorVar * (priorMean * precisionPrior + dataMean * precisionData);

  // HDI is symmetric for Normal distribution
  const zCrit = stdNormalInvCDF(1 - (1.0 - credibility) / 2);
  const se = Math.sqrt(posteriorVar);
  const hdi: [number, number] = [posteriorMean - zCrit * se, posteriorMean + zCrit * se];

  return {
    priorMean,
    priorVar,
    knownVar,
    dataMean,
    n,
    posteriorMean,
    posteriorVar,
    hdi,
  };
}

/**
 * General Metropolis-Hastings MCMC Sampler to generate draws from any arbitrary
 * 1D mathematical target PDF (unnormalized is fine).
 * @param targetPDF Callback calculating relative probability amplitude f(x)
 * @param x0 Starter value
 * @param numSamples Sample count
 * @param proposalStd Standard deviation of step size
 */
export function metropolisHastings(
  targetPDF: (x: number) => number,
  x0: number,
  numSamples = 5000,
  proposalStd = 1.0,
  burnInFraction = 0.2
): { samples: number[]; acceptanceRate: number; trajectory: number[] } {
  const result: number[] = [];
  const trajectory: number[] = [];
  let currentX = x0;
  let currentProb = targetPDF(currentX);
  
  if (currentProb === 0) {
    // Attempt to search for non-zero coordinates
    for (let offset = -10; offset <= 10; offset += 0.5) {
      const prob = targetPDF(x0 + offset);
      if (prob > 0) {
        currentX = x0 + offset;
        currentProb = prob;
        break;
      }
    }
  }

  let accepted = 0;

  for (let i = 0; i < numSamples; i++) {
    // Speculate candidate via Normal proposal
    const candidate = NormalMode.sample(currentX, proposalStd);
    const candidateProb = targetPDF(candidate);

    // Hastings ratio
    const ratio = currentProb > 0 ? candidateProb / currentProb : 1;
    const acceptanceProb = Math.min(1, ratio);

    if (Math.random() < acceptanceProb) {
      currentX = candidate;
      currentProb = candidateProb;
      accepted++;
    }

    trajectory.push(currentX);

    // Save outputs after burn-in
    const burnLimit = Math.floor(numSamples * burnInFraction);
    if (i >= burnLimit) {
      result.push(currentX);
    }
  }

  return {
    samples: result,
    acceptanceRate: accepted / numSamples,
    trajectory: trajectory.slice(0, 1000), // Return sample clip of trajectory for telemetry plot
  };
}
