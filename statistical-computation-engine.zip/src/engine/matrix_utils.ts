/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Perform matrix transposition.
 */
export function transpose(matrix: number[][]): number[][] {
  const rows = matrix.length;
  if (rows === 0) return [];
  const cols = matrix[0].length;
  const result: number[][] = Array.from({ length: cols }, () => Array(rows).fill(0));
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      result[c][r] = matrix[r][c];
    }
  }
  return result;
}

/**
 * Matrix multiplication A * B.
 */
export function matmul(A: number[][], B: number[][]): number[][] {
  const rA = A.length;
  const cA = A[0].length;
  const rB = B.length;
  const cB = B[0].length;

  if (cA !== rB) {
    throw new Error(`Incompatible matrix dimensions for multiplication: ${cA} !== ${rB}`);
  }

  const result: number[][] = Array.from({ length: rA }, () => Array(cB).fill(0));
  for (let i = 0; i < rA; i++) {
    for (let j = 0; j < cB; j++) {
      let sum = 0;
      for (let k = 0; k < cA; k++) {
        sum += A[i][k] * B[k][j];
      }
      result[i][j] = sum;
    }
  }
  return result;
}

/**
 * Create an identity matrix of size n.
 */
export function identity(n: number): number[][] {
  return Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))
  );
}

/**
 * Invert a square matrix using Gauss-Jordan elimination with pivoting.
 */
export function invert(matrix: number[][]): number[][] {
  const n = matrix.length;
  if (n === 0 || matrix[0].length !== n) {
    throw new Error("Matrix must be square to invert.");
  }

  // Augment with identity matrix
  const A: number[][] = matrix.map((row) => [...row]);
  const I: number[][] = identity(n);

  for (let i = 0; i < n; i++) {
    // Search for maximum in this column (pivoting)
    let maxEl = Math.abs(A[i][i]);
    let maxRow = i;
    for (let k = i + 1; k < n; k++) {
      if (Math.abs(A[k][i]) > maxEl) {
        maxEl = Math.abs(A[k][i]);
        maxRow = k;
      }
    }

    // Swap maximum row with current row in both A and I
    if (maxRow !== i) {
      const tempA = A[i];
      A[i] = A[maxRow];
      A[maxRow] = tempA;

      const tempI = I[i];
      I[i] = I[maxRow];
      I[maxRow] = tempI;
    }

    const pivot = A[i][i];
    if (Math.abs(pivot) < 1e-12) {
      throw new Error("Matrix is singular or near-singular, cannot be inverted.");
    }

    // Scale current row to make the pivot 1
    for (let k = 0; k < n; k++) {
      A[i][k] /= pivot;
      I[i][k] /= pivot;
    }

    // Subtract from other rows to make column element 0
    for (let j = 0; j < n; j++) {
      if (j !== i) {
        const factor = A[j][i];
        for (let k = 0; k < n; k++) {
          A[j][k] -= factor * A[i][k];
          I[j][k] -= factor * I[i][k];
        }
      }
    }
  }

  return I;
}

/**
 * Solve a linear equation system Ax = b using Gaussian elimination.
 */
export function solve(A: number[][], b: number[]): number[] {
  const n = A.length;
  if (n === 0 || A[0].length !== n || b.length !== n) {
    throw new Error("Invalid dimensions for solve Ax = b.");
  }
  const AInverted = invert(A);
  // x = AInverted * b
  const x: number[] = Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    let sum = 0;
    for (let j = 0; j < n; j++) {
      sum += AInverted[i][j] * b[j];
    }
    x[i] = sum;
  }
  return x;
}

/**
 * Perform Dot Product of two vectors.
 */
export function dotProduct(v1: number[], v2: number[]): number {
  if (v1.length !== v2.length) {
    throw new Error("Vector lengths must match for dot product.");
  }
  let sum = 0;
  const len = v1.length;
  for (let i = 0; i < len; i++) {
    sum += v1[i] * v2[i];
  }
  return sum;
}

/**
 * Vector magnitude / Euclidean norm.
 */
export function norm(v: number[]): number {
  return Math.sqrt(dotProduct(v, v));
}

/**
 * Normalize a vector.
 */
export function normalize(v: number[]): number[] {
  const mag = norm(v);
  if (mag === 0) return [...v];
  return v.map((x) => x / mag);
}

/**
 * Compute the eigenvalues and eigenvectors of a symmetric matrix using Hotelling's Deflation
 * with Power Iteration, which is robust, fast, and does not require complex QR algorithms.
 */
export function eigenPowerMethod(
  matrix: number[][],
  numComponents: number,
  maxIter = 500,
  tol = 1e-9
): { eigenvalues: number[]; eigenvectors: number[][] } {
  const n = matrix.length;
  const comp = Math.min(numComponents, n);
  const eigenvalues: number[] = [];
  const eigenvectors: number[][] = [];

  // Work on a copy since we deflate it
  let A: number[][] = matrix.map((row) => [...row]);

  for (let c = 0; c < comp; c++) {
    // Initial guess to start power iteration: standard random vector or non-trivial vector
    let v: number[] = Array.from({ length: n }, (_, i) => Math.sin(i + 1 + c)); // Deterministic seed-like start
    v = normalize(v);

    let l = 0;
    let converged = false;

    for (let iter = 0; iter < maxIter; iter++) {
      // Multiply: Av = A * v
      const Av: number[] = Array(n).fill(0);
      for (let r = 0; r < n; r++) {
        let sum = 0;
        for (let j = 0; j < n; j++) {
          sum += A[r][j] * v[j];
        }
        Av[r] = sum;
      }

      const vNext = normalize(Av);
      
      // Calculate eigenvalue (Rayleigh quotient)
      const lNext = dotProduct(vNext, Av);

      // Check convergence of the eigenvalue
      if (Math.abs(lNext - l) < tol) {
        v = vNext;
        l = lNext;
        converged = true;
        break;
      }

      v = vNext;
      l = lNext;
    }

    eigenvalues.push(l);
    eigenvectors.push(v);

    // Deflate: A_next = A - l * v * v^T
    const deflated: number[][] = Array.from({ length: n }, () => Array(n).fill(0));
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        deflated[i][j] = A[i][j] - l * v[i] * v[j];
      }
    }
    A = deflated;
  }

  return { eigenvalues, eigenvectors };
}

/**
 * Calculate transpose(X) * X for design matrix X
 */
export function xtx(X: number[][]): number[][] {
  const n = X.length;
  const p = X[0].length;
  const res: number[][] = Array.from({ length: p }, () => Array(p).fill(0));
  for (let i = 0; i < p; i++) {
    for (let j = 0; j < p; j++) {
      let sum = 0;
      for (let k = 0; k < n; k++) {
        sum += X[k][i] * X[k][j];
      }
      res[i][j] = sum;
    }
  }
  return res;
}

/**
 * Calculate transpose(X) * Y for design matrix X and response vector Y
 */
export function xty(X: number[][], Y: number[]): number[] {
  const n = X.length;
  const p = X[0].length;
  const res: number[] = Array(p).fill(0);
  for (let i = 0; i < p; i++) {
    let sum = 0;
    for (let k = 0; k < n; k++) {
      sum += X[k][i] * Y[k];
    }
    res[i] = sum;
  }
  return res;
}
