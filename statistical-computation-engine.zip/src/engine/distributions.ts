/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Natural logarithm of the Gamma function using Lanczos approximation (extremely high precision, error < 1e-15).
 */
export function gammaln(xx: number): number {
  if (xx <= 0) return NaN;
  const cof = [
    57.15623566586287, -59.59796035547549, 14.13609497958214, -0.4919138160976202,
    0.3399464998481189e-4, 0.4652362892704858e-4, -0.9837447530487956e-4,
    0.1580887032249125e-3, -0.2102644415743393e-3, 0.2174396181152126e-3,
    -0.1643181065367637e-3, 0.8441822398385275e-4, -0.2619083840158141e-4,
    0.3689918265953162e-5,
  ];
  let x = xx;
  let y = x;
  let tmp = x + 5.2421875; // 671/128
  tmp = (x + 0.5) * Math.log(tmp) - tmp;
  let ser = 0.99999999999999709182;
  for (let j = 0; j < 14; j++) {
    y += 1;
    ser += cof[j] / y;
  }
  return tmp + Math.log(2.5066282746310005 * ser / x);
}

/**
 * Gamma function itself (derived from gammaln to avoid overflow).
 */
export function gamma(x: number): number {
  return Math.exp(gammaln(x));
}

/**
 * Regularized lower incomplete gamma function P(a, x) = 1/Gamma(a) * \int_0^x t^{a-1} e^-t dt
 * Implemented using series expansion (for x < a + 1) and continued fraction (for x >= a + 1).
 */
export function gammap(a: number, x: number): number {
  if (x < 0 || a <= 0) return NaN;
  if (x === 0) return 0;

  // Series expansion
  if (x < a + 1) {
    let sum = 1 / a;
    let term = 1 / a;
    for (let n = 1; n < 100; n++) {
      term = (term * x) / (a + n);
      sum += term;
      if (Math.abs(term) < 1e-15 * Math.abs(sum)) {
        break;
      }
    }
    return sum * Math.exp(-x + a * Math.log(x) - gammaln(a));
  }

  // Continued fraction (using Lentz's method)
  let b = x + 1 - a;
  let c = 1 / 1e-30;
  let d = 1 / b;
  let h = d;
  for (let an = 1; an < 100; an++) {
    const temp = an * (a - an);
    b += 2;
    d = temp * d + b;
    if (Math.abs(d) < 1e-30) d = 1e-30;
    c = b + temp / c;
    if (Math.abs(c) < 1e-30) c = 1e-30;
    d = 1 / d;
    const del = c * d;
    h *= del;
    if (Math.abs(del - 1) < 1e-15) {
      break;
    }
  }
  return 1 - h * Math.exp(-x + a * Math.log(x) - gammaln(a));
}

/**
 * Cumulative error function erf(x) using high precision rational approximation (Abramowitz & Stegun 7.1.26).
 * Max absolute error < 1.5e-7.
 */
export function erf(x: number): number {
  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x);

  const p = 0.3275911;
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;

  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);

  return sign * y;
}

/**
 * Standard Normal Cumulative Distribution Function Phi(z).
 */
export function stdNormalCDF(z: number): number {
  return 0.5 * (1 + erf(z / Math.sqrt(2)));
}

/**
 * Standard Normal Inverse Cumulative Distribution Function using Moro's rational approximation.
 * Handles precision very close to 0 and 1.
 */
export function stdNormalInvCDF(p: number): number {
  if (p <= 0 || p >= 1) {
    if (p === 0) return -Infinity;
    if (p === 1) return Infinity;
    return NaN;
  }

  const y = p - 0.5;
  if (Math.abs(y) < 0.42) {
    // Central region Beasley-Springer-Moro
    const a0 = 2.50662823884;
    const a1 = -18.61500062529;
    const a2 = 41.39119773534;
    const a3 = -25.44106049037;

    const b1 = -8.47351093090;
    const b2 = 23.08336743743;
    const b3 = -21.06224101826;
    const b4 = 3.13082909833;

    const r = y * y;
    const num = ((a3 * r + a2) * r + a1) * r + a0;
    const den = (((b4 * r + b3) * r + b2) * r + b1) * r + 1;
    return y * (num / den);
  } else {
    // Tail region
    const r = p < 0.5 ? p : 1.0 - p;
    const s = Math.sqrt(-Math.log(r));

    const c0 = 2.92212037676;
    const c1 = -3.32231227756;
    const c2 = -1.13963500581;
    const c3 = 1.37189449835;
    const c4 = 0.51474474847;
    const c5 = -0.53039795708;
    const c6 = -0.11624458268;
    const c7 = 0.13314166789;
    const c8 = 0.00902268455;
    const c9 = -0.01633455269;

    let x = (((((((((c9 * s + c8) * s + c7) * s + c6) * s + c5) * s + c4) * s + c3) * s + c2) * s + c1) * s + c0);
    x = x + 0.000000000001; // tiny offset to stabilize
    return p < 0.5 ? -x : x;
  }
}

/**
 * Helper to get a random uniform number in (0, 1)
 */
function rand(): number {
  let r = Math.random();
  while (r === 0 || r === 1) r = Math.random(); // ensure open interval (0, 1)
  return r;
}

/**
 * Incomplete Beta Function, Ix(a, b)
 * Evaluated via continued fraction after making sure x < (a+1)/(a+b+2) using symmetry.
 */
export function betai(a: number, b: number, x: number): number {
  if (x < 0 || x > 1) return NaN;
  if (x === 0) return 0;
  if (x === 1) return 1;

  // factor in front of the continued fraction
  const bt = Math.exp(
    gammaln(a + b) - gammaln(a) - gammaln(b) + a * Math.log(x) + b * Math.log(1.0 - x)
  );

  // Symmetry transformation
  if (x < (a + 1.0) / (a + b + 2.0)) {
    return (bt * betaFraction(a, b, x)) / a;
  } else {
    return 1.0 - (bt * betaFraction(b, a, 1.0 - x)) / b;
  }
}

function betaFraction(a: number, b: number, x: number): number {
  const maxIter = 100;
  const qab = a + b;
  const qap = a + 1.0;
  const qam = a - 1.0;
  let c = 1.0;
  let d = 1.0 - (qab * x) / qap;
  if (Math.abs(d) < 1e-30) d = 1e-30;
  d = 1.0 / d;
  let h = d;

  for (let m = 1; m <= maxIter; m++) {
    const m2 = 2 * m;
    let aa = (m * (b - m) * x) / ((qam + m2) * (a + m2));
    d = 1.0 + aa * d;
    if (Math.abs(d) < 1e-30) d = 1e-30;
    c = 1.0 + aa / c;
    if (Math.abs(c) < 1e-30) c = 1e-30;
    d = 1.0 / d;
    h *= d * c;

    aa = (-(a + m) * (qab + m) * x) / ((a + m2) * (qap + m2));
    d = 1.0 + aa * d;
    if (Math.abs(d) < 1e-30) d = 1e-30;
    c = 1.0 + aa / c;
    if (Math.abs(c) < 1e-30) c = 1e-30;
    d = 1.0 / d;
    const del = d * c;
    h *= del;

    if (Math.abs(del - 1.0) < 1e-15) break;
  }
  return h;
}

// ==========================================
// INDIVIDUAL DISTRIBUTIONS REPRESENTATION
// ==========================================

export const NormalMode = {
  pdf(x: number, mean = 0, std = 1): number {
    if (std <= 0) return NaN;
    const exponent = -Math.pow(x - mean, 2) / (2 * Math.pow(std, 2));
    return (1 / (std * Math.sqrt(2 * Math.PI))) * Math.exp(exponent);
  },

  cdf(x: number, mean = 0, std = 1): number {
    if (std <= 0) return NaN;
    return stdNormalCDF((x - mean) / std);
  },

  invCDF(p: number, mean = 0, std = 1): number {
    if (std <= 0) return NaN;
    return mean + std * stdNormalInvCDF(p);
  },

  sample(mean = 0, std = 1): number {
    if (std <= 0) return NaN;
    // Box-Muller transform
    const u1 = rand();
    const u2 = rand();
    const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return mean + std * z;
  },
};

export const LognormalMode = {
  pdf(x: number, mu = 0, sigma = 1): number {
    if (x <= 0 || sigma <= 0) return 0;
    const lnX = Math.log(x);
    const exponent = -Math.pow(lnX - mu, 2) / (2 * Math.pow(sigma, 2));
    return (1 / (x * sigma * Math.sqrt(2 * Math.PI))) * Math.exp(exponent);
  },

  cdf(x: number, mu = 0, sigma = 1): number {
    if (x <= 0) return 0;
    if (sigma <= 0) return NaN;
    return stdNormalCDF((Math.log(x) - mu) / sigma);
  },

  invCDF(p: number, mu = 0, sigma = 1): number {
    if (sigma <= 0) return NaN;
    const z = stdNormalInvCDF(p);
    return Math.exp(mu + sigma * z);
  },

  sample(mu = 0, sigma = 1): number {
    if (sigma <= 0) return NaN;
    const z = NormalMode.sample(0, 1);
    return Math.exp(mu + sigma * z);
  },
};

export const BinomialMode = {
  pdf(k: number, n: number, p: number): number {
    if (k < 0 || k > n || !Number.isInteger(k)) return 0;
    if (p < 0 || p > 1) return NaN;
    if (p === 0) return k === 0 ? 1 : 0;
    if (p === 1) return k === n ? 1 : 0;

    // binomial coefficient via log gamma
    const lnCoeff = gammaln(n + 1) - gammaln(k + 1) - gammaln(n - k + 1);
    const lnProb = lnCoeff + k * Math.log(p) + (n - k) * Math.log(1 - p);
    return Math.exp(lnProb);
  },

  cdf(k: number, n: number, p: number): number {
    if (k < 0) return 0;
    if (k >= n) return 1;
    if (p < 0 || p > 1) return NaN;
    const kFloor = Math.floor(k);

    // Sum if small n, otherwise use Regularized Incomplete Beta
    if (n < 50) {
      let sum = 0;
      for (let i = 0; i <= kFloor; i++) {
        sum += this.pdf(i, n, p);
      }
      return Math.min(1, Math.max(0, sum));
    }
    // I_{1-p}(n-k, k+1)
    return betai(n - kFloor, kFloor + 1, 1 - p);
  },

  invCDF(prob: number, n: number, p: number): number {
    if (prob < 0 || prob > 1) return NaN;
    if (prob === 0) return 0;
    if (prob === 1) return n;

    // Binary search/linear search on CDF since domain is discrete
    let low = 0;
    let high = n;
    while (low < high) {
      const mid = Math.floor((low + high) / 2);
      if (this.cdf(mid, n, p) >= prob) {
        high = mid;
      } else {
        low = mid + 1;
      }
    }
    return low;
  },

  sample(n: number, p: number): number {
    if (p < 0 || p > 1 || n < 0) return NaN;
    if (p === 0) return 0;
    if (p === 1) return n;

    // For very large scale, use Normal approximation to keep simulation high performance
    if (n > 200) {
      const mean = n * p;
      const dev = Math.sqrt(n * p * (1 - p));
      const z = NormalMode.sample(0, 1);
      const val = Math.round(mean + dev * z);
      return Math.max(0, Math.min(n, val));
    }

    let successes = 0;
    for (let i = 0; i < n; i++) {
      if (Math.random() < p) {
        successes++;
      }
    }
    return successes;
  },
};

export const PoissonMode = {
  pdf(k: number, lambda: number): number {
    if (k < 0 || !Number.isInteger(k)) return 0;
    if (lambda <= 0) return NaN;
    // log form: ln(pdf) = k*ln(lambda) - lambda - ln(k!)
    const lnF = k * Math.log(lambda) - lambda - gammaln(k + 1);
    return Math.exp(lnF);
  },

  cdf(k: number, lambda: number): number {
    if (k < 0) return 0;
    if (lambda <= 0) return NaN;
    const kFloor = Math.floor(k);

    // Sum if small, otherwise use incomplete gamma: Q(k+1, lambda) = 1 - P(k+1, lambda)
    if (kFloor < 100) {
      let sum = 0;
      for (let i = 0; i <= kFloor; i++) {
        sum += this.pdf(i, lambda);
      }
      return Math.min(1, Math.max(0, sum));
    }
    return 1 - gammap(kFloor + 1, lambda);
  },

  invCDF(prob: number, lambda: number): number {
    if (prob < 0 || prob > 1) return NaN;
    if (prob === 0) return 0;

    // Linear/binary search starting near lambda
    let k = Math.floor(lambda);
    if (this.cdf(k, lambda) >= prob) {
      while (k > 0 && this.cdf(k - 1, lambda) >= prob) {
        k--;
      }
      return k;
    } else {
      while (this.cdf(k, lambda) < prob) {
        k++;
      }
      return k;
    }
  },

  sample(lambda: number): number {
    if (lambda <= 0) return NaN;

    // For larger lambda, use Wilson-Hilferty transformation or direct normal approximation
    if (lambda > 30) {
      // Gaussian approximation with continuity correction
      const z = NormalMode.sample(0, 1);
      const val = Math.round(lambda + Math.sqrt(lambda) * z);
      return Math.max(0, val);
    }

    // Knuth's algorithm
    const L = Math.exp(-lambda);
    let k = 0;
    let p = 1.0;
    do {
      k++;
      p *= rand();
    } while (p > L);
    return k - 1;
  },
};

export const ExponentialMode = {
  pdf(x: number, lambda: number): number {
    if (x < 0) return 0;
    if (lambda <= 0) return NaN;
    return lambda * Math.exp(-lambda * x);
  },

  cdf(x: number, lambda: number): number {
    if (x < 0) return 0;
    if (lambda <= 0) return NaN;
    return 1 - Math.exp(-lambda * x);
  },

  invCDF(p: number, lambda: number): number {
    if (p < 0 || p >= 1) return p === 1 ? Infinity : NaN;
    if (lambda <= 0) return NaN;
    return -Math.log(1 - p) / lambda;
  },

  sample(lambda: number): number {
    if (lambda <= 0) return NaN;
    return -Math.log(rand()) / lambda;
  },
};

export const GammaMode = {
  pdf(x: number, shape: number, scale: number): number {
    if (x <= 0) return 0;
    if (shape <= 0 || scale <= 0) return NaN;
    // log (f(x)) = (alpha-1)*ln(x) - x/theta - alpha*ln(theta) - ln(Gamma(alpha))
    const lnF = (shape - 1) * Math.log(x) - x / scale - shape * Math.log(scale) - gammaln(shape);
    return Math.exp(lnF);
  },

  cdf(x: number, shape: number, scale: number): number {
    if (x <= 0) return 0;
    if (shape <= 0 || scale <= 0) return NaN;
    // P(alpha, x/theta)
    return gammap(shape, x / scale);
  },

  invCDF(p: number, shape: number, scale: number, maxIter = 100, tol = 1e-12): number {
    if (p < 0 || p >= 1) return p === 1 ? Infinity : NaN;
    if (shape <= 0 || scale <= 0) return NaN;
    if (p === 0) return 0;

    // Wilson-Hilferty approximation as an initial guess
    const z = stdNormalInvCDF(p);
    const d = 1 / (9 * shape);
    let x = shape * Math.pow(1 - d + z * Math.sqrt(d), 3);
    if (x < 0) x = 1e-5;

    // Newton-Raphson refinement
    for (let i = 0; i < maxIter; i++) {
      const c = this.cdf(x, shape, 1);
      const diff = c - p;
      if (Math.abs(diff) < tol) break;

      const deriv = this.pdf(x, shape, 1);
      if (deriv === 0) break;

      x = x - diff / deriv;
      if (x <= 0) x = 1e-5;
    }

    return x * scale;
  },

  sample(shape: number, scale: number): number {
    if (shape <= 0 || scale <= 0) return NaN;

    // Marsaglia and Tsang method (2000) for shape >= 1
    if (shape < 1) {
      // Boost shape by drawing Gamma(shape + 1, scale) * U^(1/shape)
      return this.sample(shape + 1, scale) * Math.pow(rand(), 1 / shape);
    }

    const d = shape - 1 / 3;
    const c = 1 / Math.sqrt(9 * d);

    while (true) {
      let z = NormalMode.sample(0, 1);
      let v = 1 + c * z;
      while (v <= 0) {
        z = NormalMode.sample(0, 1);
        v = 1 + c * z;
      }
      v = v * v * v;
      const u = rand();
      const z2 = z * z;
      if (u < 1 - 0.0331 * z2 * z2) {
        return d * v * scale;
      }
      if (Math.log(u) < 0.5 * z2 + d * (1 - v + Math.log(v))) {
        return d * v * scale;
      }
    }
  },
};
