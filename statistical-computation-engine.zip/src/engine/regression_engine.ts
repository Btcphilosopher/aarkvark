/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RegressionSummary, RegressionCoefficients } from "./types";
import { transpose, matmul, invert, identity, solve } from "./matrix_utils";
import { betai, gammaln, stdNormalCDF, stdNormalInvCDF } from "./distributions";

/**
 * Probability Density Function (PDF) of Student's T distribution.
 */
export function studentTPDF(t: number, df: number): number {
  const coeff = Math.exp(gammaln((df + 1) / 2) - gammaln(df / 2)) / Math.sqrt(df * Math.PI);
  return coeff * Math.pow(1 + (t * t) / df, -(df + 1) / 2);
}

/**
 * Cumulative Distribution Function (CDF) of Student's T distribution.
 */
export function studentTCDF(t: number, df: number): number {
  if (df <= 0) return NaN;
  const x = df / (df + t * t);
  const val = betai(df / 2, 0.5, x);
  return t > 0 ? 1 - 0.5 * val : 0.5 * val;
}

/**
 * Inverse Cumulative Distribution Function of Student's T distribution.
 * Implemented using Newton-Raphson root finding starting from Normal approximation.
 */
export function studentTInvCDF(p: number, df: number, maxIter = 50, tol = 1e-12): number {
  if (p <= 0 || p >= 1) {
    if (p === 0) return -Infinity;
    if (p === 1) return Infinity;
    return NaN;
  }
  
  // Starting guess using normal quantile
  let t = stdNormalInvCDF(p);
  
  // Newton-Raphson loop
  for (let i = 0; i < maxIter; i++) {
    const c = studentTCDF(t, df);
    const diff = c - p;
    if (Math.abs(diff) < tol) break;
    
    const d = studentTPDF(t, df);
    if (d === 0) break;
    
    t = t - diff / d;
  }
  return t;
}

/**
 * Solve simple linear regression y = beta0 + beta1 * x
 */
export function fitLinearRegression(x: number[], y: number[], alpha = 0.05): RegressionSummary {
  const n = x.length;
  if (n !== y.length || n < 3) {
    throw new Error("Dataset size must be identical and at least 3 to perform linear regression.");
  }

  // Construct design matrix for multiple linear regression
  const X = x.map((val) => [1, val]);
  return fitMultipleRegression(X, y, ["(Intercept)", "Predictor"], alpha, "linear");
}

/**
 * Fit Polynomial Regression y = beta0 + beta1*x + beta2*x^2 + ...
 */
export function fitPolynomialRegression(x: number[], y: number[], degree: number, alpha = 0.05): RegressionSummary {
  const n = x.length;
  if (n !== y.length || n < degree + 2) {
    throw new Error(`Dataset size must be at least ${degree + 2} for polynomial degree ${degree}.`);
  }

  const X: number[][] = [];
  const names = ["(Intercept)"];
  for (let i = 0; i < n; i++) {
    const row = [1];
    for (let d = 1; d <= degree; d++) {
      row.push(Math.pow(x[i], d));
    }
    X.push(row);
  }

  for (let d = 1; d <= degree; d++) {
    names.push(`x^${d}`);
  }

  return fitMultipleRegression(X, y, names, alpha, "polynomial");
}

/**
 * Fit Multiple Linear Regression Y = X * Beta
 * @param X Design matrix (n x p), should already contain intercept col of 1's if desired
 * @param Y Response vector (n)
 * @param coefNames Optional names for components
 */
export function fitMultipleRegression(
  X: number[][],
  Y: number[],
  coefNames?: string[],
  alpha = 0.05,
  regressionType: "linear" | "multiple" | "polynomial" = "multiple"
): RegressionSummary {
  const n = X.length;
  const p = X[0].length;

  if (n !== Y.length || n <= p) {
    throw new Error(`Insufficient data points (${n}) compared to predictors (${p}).`);
  }

  const names = coefNames || Array.from({ length: p }, (_, i) => `Beta${i}`);

  // Solve beta = (X^T * X)^-1 * X^T * Y
  const Xt = transpose(X);
  const XtX = matmul(Xt, X);
  const XtXInv = invert(XtX);
  const XtY = X.map((_, i) => [Y[i]]); // response vector as matrix
  const XtYProd = matmul(Xt, XtY);
  const betaMat = matmul(XtXInv, XtYProd);
  const beta = betaMat.map((val) => val[0]);

  // Compute residuals
  const residuals: number[] = [];
  let rss = 0;
  let ySum = 0;
  for (let i = 0; i < n; i++) {
    ySum += Y[i];
    let yHat = 0;
    for (let j = 0; j < p; j++) {
      yHat += X[i][j] * beta[j];
    }
    const resid = Y[i] - yHat;
    residuals.push(resid);
    rss += resid * resid;
  }

  const yMean = ySum / n;
  let tss = 0;
  for (let i = 0; i < n; i++) {
    tss += Math.pow(Y[i] - yMean, 2);
  }

  const dfResidual = n - p;
  const dfModel = p - 1;
  const s2 = rss / dfResidual; // residual variance

  // Standard errors of beta
  const seBeta: number[] = [];
  const tStats: number[] = [];
  const pValues: number[] = [];
  const confidenceIntervals: [number, number][] = [];

  // Critical t value for CI
  const tCrit = studentTInvCDF(1 - alpha / 2, dfResidual);

  for (let j = 0; j < p; j++) {
    const varianceBetaJ = s2 * XtXInv[j][j];
    const se = Math.sqrt(Math.max(0, varianceBetaJ));
    seBeta.push(se);

    const tVal = se > 0 ? beta[j] / se : 0;
    tStats.push(tVal);

    // Two-tailed p-value
    const pVal = 2 * (1 - studentTCDF(Math.abs(tVal), dfResidual));
    pValues.push(pVal);

    confidenceIntervals.push([beta[j] - tCrit * se, beta[j] + tCrit * se]);
  }

  const rSquared = tss > 0 ? 1 - rss / tss : 0;
  const adjRSquared = tss > 0 ? 1 - (rss / dfResidual) / (tss / (n - 1)) : 0;

  // F-statistic for overall significance
  let fStatistic: number | undefined;
  let fPValue: number | undefined;
  if (dfModel > 0 && dfResidual > 0 && tss > 0) {
    const msModel = (tss - rss) / dfModel;
    const msResidual = rss / dfResidual;
    fStatistic = msResidual > 0 ? msModel / msResidual : 0;

    // Approximating F distribution p-value using beta function relationship
    // F(f, d1, d2) has cumulative distribution related to incomplete beta: I_{x}(d1/2, d2/2) with x = d1*f / (d1*f + d2)
    const xF = (dfModel * fStatistic) / (dfModel * fStatistic + dfResidual);
    const fRes = betai(dfModel / 2, dfResidual / 2, xF);
    fPValue = 1 - fRes;
  }

  // Calculate residual quantiles/stats
  const sortedResids = [...residuals].sort((a, b) => a - b);
  const resMin = sortedResids[0];
  const resMax = sortedResids[n - 1];
  const resQ1 = sortedResids[Math.floor(n * 0.25)];
  const resMedian = sortedResids[Math.floor(n * 0.5)];
  const resQ3 = sortedResids[Math.floor(n * 0.75)];

  const coefficients: RegressionCoefficients[] = beta.map((val, idx) => ({
    name: names[idx],
    estimate: val,
    stdError: seBeta[idx],
    tStat: tStats[idx],
    pValue: pValues[idx],
    confidenceInterval: confidenceIntervals[idx],
  }));

  return {
    type: regressionType,
    coefficients,
    residuals: {
      min: resMin,
      q1: resQ1,
      median: resMedian,
      q3: resQ3,
      max: resMax,
      stdError: Math.sqrt(s2),
    },
    rSquared,
    adjRSquared,
    fStatistic,
    fPValue,
    dfResidual,
    dfModel,
  };
}

/**
 * Fit Logistic Regression using Iteratively Reweighted Least Squares (IRLS).
 * Handles binary classification y_i in {0, 1}.
 */
export function fitLogisticRegression(
  X: number[][],
  Y: number[],
  coefNames?: string[],
  alpha = 0.05,
  maxIter = 30,
  tol = 1e-6
): RegressionSummary {
  const n = X.length;
  const p = X[0].length;

  if (n !== Y.length || n <= p) {
    throw new Error(`Insufficient data points (${n}) compared to predictors (${p}) for Logistic Regression.`);
  }

  const names = coefNames || Array.from({ length: p }, (_, i) => `Beta${i}`);

  // Verify binary boundaries
  for (const val of Y) {
    if (val !== 0 && val !== 1) {
      throw new Error("Logistic regression response variable Y must contain only 0 and 1.");
    }
  }

  // Initialize coefficients beta to zero
  let beta: number[] = Array(p).fill(0);
  let converged = false;
  let iter = 0;
  let finalXtWXInv: number[][] = [];

  for (iter = 0; iter < maxIter; iter++) {
    // 1. Compute fitted probabilities p_i = sigmoid(X_i * beta)
    const pVec: number[] = [];
    const weights: number[] = []; // w_ii = p_i * (1 - p_i)
    const workingResid: number[] = []; // z_i = (y_i - p_i) / w_ii

    for (let i = 0; i < n; i++) {
      let eta = 0;
      for (let j = 0; j < p; j++) {
        eta += X[i][j] * beta[j];
      }
      const prob = 1.0 / (1.0 + Math.exp(-Math.max(-20, Math.min(20, eta)))); // clamp to avoid over/underflow
      pVec.push(prob);

      const w = Math.max(1e-8, prob * (1.0 - prob));
      weights.push(w);
      workingResid.push((Y[i] - prob) / w);
    }

    // 2. Formulate weighted least squares step:
    // (X^T * W * X) * dBeta = X^T * W * workingResid
    // First construct X^T * W * X
    const XtWX: number[][] = Array.from({ length: p }, () => Array(p).fill(0));
    for (let j = 0; j < p; j++) {
      for (let k = 0; k < p; k++) {
        let sum = 0;
        for (let i = 0; i < n; i++) {
          sum += X[i][j] * weights[i] * X[i][k];
        }
        XtWX[j][k] = sum;
      }
    }

    // Construct gradients X^T * (Y - p)
    const gradient: number[] = Array(p).fill(0);
    for (let j = 0; j < p; j++) {
      let sum = 0;
      for (let i = 0; i < n; i++) {
        sum += X[i][j] * (Y[i] - pVec[i]);
      }
      gradient[j] = sum;
    }

    // Invert XtWX to get update step and covariance matrix
    let dBeta: number[];
    try {
      const invXtWX = invert(XtWX);
      finalXtWXInv = invXtWX;
      // dBeta = (X^T * W * X)^-1 * (X^T * (Y - p))
      dBeta = Array(p).fill(0);
      for (let j = 0; j < p; j++) {
        let sum = 0;
        for (let k = 0; k < p; k++) {
          sum += invXtWX[j][k] * gradient[k];
        }
        dBeta[j] = sum;
      }
    } catch {
      throw new Error("Collinearity or singularity detected in logistic design matrix.");
    }

    // Update beta
    const nextBeta = beta.map((val, idx) => val + dBeta[idx]);

    // Check convergence
    let maxDiff = 0;
    for (let j = 0; j < p; j++) {
      maxDiff = Math.max(maxDiff, Math.abs(dBeta[j]));
    }

    beta = nextBeta;

    if (maxDiff < tol) {
      converged = true;
      break;
    }
  }

  // Calculate final diagnostics
  // Standard Errors of beta: diagonal of covariance matrix (X^T * W * X)^-1
  const seBeta: number[] = [];
  const zStats: number[] = [];
  const pValues: number[] = [];
  const confidenceIntervals: [number, number][] = [];

  const zCrit = stdNormalInvCDF(1 - alpha / 2);

  for (let j = 0; j < p; j++) {
    const varianceBetaJ = finalXtWXInv[j][j];
    const se = Math.sqrt(Math.max(0, varianceBetaJ));
    seBeta.push(se);

    const zVal = se > 0 ? beta[j] / se : 0;
    zStats.push(zVal);

    // Two-tailed Wald p-value (approximate Z test)
    const pVal = 2 * (1 - stdNormalCDF(Math.abs(zVal)));
    pValues.push(pVal);

    confidenceIntervals.push([beta[j] - zCrit * se, beta[j] + zCrit * se]);
  }

  // Wald p-values and summaries
  const coefficients: RegressionCoefficients[] = beta.map((val, idx) => ({
    name: names[idx],
    estimate: val,
    stdError: seBeta[idx],
    tStat: zStats[idx], // Wald Z represents same role
    pValue: pValues[idx],
    confidenceInterval: confidenceIntervals[idx],
  }));

  // Compiling residuals
  const residuals: number[] = [];
  let sumDeviance = 0; // Likelihood deviance residuals
  for (let i = 0; i < n; i++) {
    let eta = 0;
    for (let j = 0; j < p; j++) {
      eta += X[i][j] * beta[j];
    }
    const prob = 1.0 / (1.0 + Math.exp(-Math.max(-20, Math.min(20, eta))));
    const residY = Y[i] - prob;
    residuals.push(residY);

    // deviance residual contribution
    if (Y[i] === 1) {
      sumDeviance += -2 * Math.log(prob);
    } else {
      sumDeviance += -2 * Math.log(1 - prob);
    }
  }

  const sortedResids = [...residuals].sort((a, b) => a - b);
  const resMin = sortedResids[0];
  const resMax = sortedResids[n - 1];
  const resQ1 = sortedResids[Math.floor(n * 0.25)];
  const resMedian = sortedResids[Math.floor(n * 0.5)];
  const resQ3 = sortedResids[Math.floor(n * 0.75)];

  // pseudo R-squared (McFadden R2)
  // Compute null deviance (only intercept)
  let ySum = 0;
  for (let i = 0; i < n; i++) ySum += Y[i];
  const pNull = ySum / n;
  let nullDeviance = 0;
  for (let i = 0; i < n; i++) {
    if (Y[i] === 1) {
      nullDeviance += -2 * Math.log(pNull);
    } else {
      nullDeviance += -2 * Math.log(1 - pNull);
    }
  }

  const pseudoRSquared = nullDeviance > 0 ? 1 - sumDeviance / nullDeviance : 0;

  return {
    type: "logistic",
    coefficients,
    residuals: {
      min: resMin,
      q1: resQ1,
      median: resMedian,
      q3: resQ3,
      max: resMax,
      stdError: Math.sqrt(sumDeviance / (n - p)), // average scale of deviance
    },
    rSquared: pseudoRSquared, // we use McFadden's pseudo R2 here
    adjRSquared: pseudoRSquared, // same for simple representation
    dfResidual: n - p,
    dfModel: p - 1,
    converged,
    iterations: iter + 1,
  };
}
