#' Spreadsheet Integration Formula Wrappers
#'
#' @description
#' Capitalized formulas mapped directly to the core descriptive statistics engine.
#' Supports variadic arguments (`...`) to mirror spreadsheet structures which can pass
#' multiple cells, vectors, or multi-dimensional ranges.
#'
#' @export

# Handle workspace sourcing
tryCatch({
  source(file.path(dirname(sys.frame(1)$ofile), "descriptive_stats.R"))
}, error = function(e) {
  paths <- c("descriptive_stats.R", "statistics-engine/descriptive_stats.R")
  for(path in paths) {
    if(file.exists(path)) source(path)
  }
})

#' MEAN Formula
#' @description Calculates average of spreadsheet cells or vectors.
#' @param ... One or more cell references, ranges, lists, or discrete values.
#' @return The arithmetic mean.
#' @export
MEAN <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_mean(args, na.rm = TRUE)
}

#' MEDIAN Formula
#' @description Calculates the absolute middle value.
#' @param ... One or more cell references, ranges, lists, or discrete values.
#' @return The median.
#' @export
MEDIAN <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_median(args, na.rm = TRUE)
}

#' MODE Formula
#' @description Calculates the most common element value(s).
#' @param ... One or more cell references, ranges, lists, or discrete values.
#' @return High popularity value/list, or empty if uniformly flat.
#' @export
MODE <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_mode(args, na.rm = TRUE)
}

#' MINIMUM Formula
#' @description Calculates the lowest value on the cell scope.
#' @param ... One or more cell references, ranges, lists, or discrete values.
#' @return The lowest numeric observation.
#' @export
MINIMUM <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_min(args, na.rm = TRUE)
}

#' MAXIMUM Formula
#' @description Calculates the largest value on the cell scope.
#' @param ... One or more cell references, ranges, lists, or discrete values.
#' @return The largest numeric observation.
#' @export
MAXIMUM <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_max(args, na.rm = TRUE)
}

#' RANGE Formula
#' @description Calculates the span (Max - Min).
#' @param ... One or more cell references, ranges, lists, or discrete values.
#' @return Max - Min.
#' @export
RANGE <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_range(args, na.rm = TRUE)
}
