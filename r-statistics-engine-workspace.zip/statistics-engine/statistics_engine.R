#' Statistics Engine - Main Module
#'
#' @description
#' Orchestrates descriptive statistics functions and provides the central
#' master summary function `statistics_summary` for downstream integrations.
#'
#' @references
#' R Core Team (2026). R: A language and environment for statistical computing.

# Relative-aware module sourcing
tryCatch({
  source(file.path(dirname(sys.frame(1)$ofile), "validation.R"))
  source(file.path(dirname(sys.frame(1)$ofile), "descriptive_stats.R"))
}, error = function(e) {
  # Fallback source paths for safe command line executions
  paths <- c("validation.R", "descriptive_stats.R", 
             "statistics-engine/validation.R", "statistics-engine/descriptive_stats.R")
  for(path in paths) {
    if(file.exists(path)) source(path)
  }
})

#' Master Dataset Statistical Summary
#'
#' @description
#' Performs a unified analytical run on a collection of values, minimizing
#' memory overhead by avoiding sequential validations. Calculates descriptive
#' variables (location, dispersion, sizing) in a single high-speed pass.
#'
#' @param data Input numerical dataset (vector, data frame column, or cell values).
#' @param na.rm Logical. If TRUE, non-finite values (NA, NaN, Inf, -Inf) are cleaned first.
#' @return A structured named list containing count, sum, mean, median, mode, minimum, maximum, and range.
#' @export
statistics_summary <- function(data, na.rm = TRUE) {
  # Pre-validate and clean exactly once to ensure optimal O(N) execution paths
  clean_data <- validate_data(data, na.rm = na.rm)
  
  # Perform calculations sequentially using fast primitive elements on pre-cleaned data
  n_count   <- length(clean_data)
  acc_sum   <- sum(clean_data)
  avg_mean  <- acc_sum / n_count
  mid_med   <- stats::median(clean_data)
  
  # Calculate modes efficiently
  val_modes <- stat_mode(clean_data, na.rm = na.rm)
  
  # Compute limits
  lims      <- range(clean_data)
  val_min   <- lims[1]
  val_max   <- lims[2]
  rng_diff  <- val_max - val_min
  
  out <- list(
    count   = n_count,
    sum     = acc_sum,
    mean    = avg_mean,
    median  = mid_med,
    mode    = val_modes,
    minimum = val_min,
    maximum = val_max,
    range   = rng_diff
  )
  
  return(out)
}
