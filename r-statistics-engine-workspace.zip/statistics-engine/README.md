# R Statistics Core Engine

A fast, accurate, and memory-efficient mathematical calculation module written in R, designed to be embedded into spreadsheet software as a reusable backend component. This module implements descriptive statistical measures optimized for performance on large datasets exceeding **1,000,000 rows**.

---

## 📁 Project Structure

```text
statistics-engine/
│
├── statistics_engine.R       # Central orchestrator & master statistics_summary()
├── descriptive_stats.R       # Core mathematical formulas (Mean, Median, Mode, etc.)
├── validation.R              # Input sanitization, cleaning, and error routing
├── spreadsheet_wrappers.R    # Capitalized spreadsheet formulas (MEAN, MEDIAN, etc.)
├── tests/                    # Automated unit tests and assertion logic
│   ├── test_mean.R
│   ├── test_median.R
│   ├── test_mode.R
│   └── test_range.R
│
└── README.md                 # Detailed integration & technical reference
```

---

## 🧬 Core Statistical Functions

All core routines reside in `descriptive_stats.R`. They leverage highly optimized R internal vectorized computations written in C to minimize memory reallocations and avoid slow looping.

### 1. Mean
Arithmetic average of all values in the range.
$$\bar{x} = \frac{1}{n} \sum_{i=1}^{n} x_i$$
- **Function:** `stat_mean(data, na.rm = TRUE)`
- **Vectorization:** Leveraging $O(N)$ high-speed underlying C implementations of `sum()` and `length()`.

### 2. Median
The absolute middle value of the ordered dataset. For even sample sizes, it resolves to the average of the two middle elements.
- **Function:** `stat_median(data, na.rm = TRUE)`
- **Sorting Efficiency:** Uses quickselect partial sorting algorithm, executing in average linear time $O(N)$.

### 3. Mode
The most frequently occurring value(s) in a dataset. Supports single-mode, multi-modal, and no-mode scenarios.
- **Function:** `stat_mode(data, na.rm = TRUE)`
- **Performance:** Implements matching hashes via `match()` and `tabulate()` to retrieve frequency distributions in $O(N)$ rather than standard $O(N \log N)$ sorting. Returns `numeric(0)` if a flat, uniform distribution has no discernible modes.

### 4. Minimum & Maximum
Retrieves the lowest and highest observations.
- **Functions:** `stat_min(data, na.rm = TRUE)`, `stat_max(data, na.rm = TRUE)`

### 5. Range
The interval span between maximum and minimum value bounds.
$$\text{Range} = \text{Max} - \text{Min}$$
- **Function:** `stat_range(data, na.rm = TRUE)`

### 6. Count & Sum
Aggregates observation statistics.
- **Count Function:** `stat_count(data, na.rm = TRUE)` (calculates number of valid finite observations)
- **Sum Function:** `stat_sum(data, na.rm = TRUE)`

---

## 📊 Summary Function

The orchestrator `statistics_engine.R` implements a high-efficiency entry point that validates datasets exactly once and computes all statistical properties in a single sequential pass.

```R
library(statistics_engine) # Or direct relative sourcing

# Calculate unified summary stats
results <- statistics_summary(c(10, 20, 20, 30, 40, NA))

# Output Shape:
# list(
#   count = 5,
#   sum = 120,
#   mean = 24.0,
#   median = 20.0,
#   mode = c(20),
#   minimum = 10,
#   maximum = 40,
#   range = 30
# )
```

---

## ⚙️ Data Handling & Validation

To ensure clean calculations within spreadsheets, the engine uses `validation.R` to check and sanitize input before doing math:
* **Structural Coercion:** Dynamically handles numeric vectors, single-column data frames, multi-dimensional matrices, standard lists, and strings containing numeric representations.
* **Missing & Infinite Values:** Sanitizes `NA`, `NaN`, `Inf`, and `-Inf` correctly when `na.rm = TRUE`.
* **Descriptive Errors:** Intercepts completely empty datasets or text-based inputs, raising meaningful errors (e.g. `Error: Input must contain numeric values.`).

---

## 🧩 Spreadsheet Formula Integration

Compatible spreadsheet wrappers in `spreadsheet_wrappers.R` allow integration using capitalized, Excel-compatible formula syntax with support for variadic parameters (`...` references):

* `=MEAN(A1:A100)` $\rightarrow$ `MEAN(...)`
* `=MEDIAN(A1:A100)` $\rightarrow$ `MEDIAN(...)`
* `=MODE(A1:A100)` $\rightarrow$ `MODE(...)`
* `=MINIMUM(A1:A100)` $\rightarrow$ `MINIMUM(...)`
* `=MAXIMUM(A1:A100)` $\rightarrow$ `MAXIMUM(...)`
* `=RANGE(A1:A100)` $\rightarrow$ `RANGE(...)`

---

## 🚀 Performance & Vectorization

The statistics engine is built around high-throughput computing standards:
1. **Zero loops:** Replaces standard iterator controls with fast, element-wise primitives in R.
2. **Memory Preservation:** Keeps memory-copying operations to a minimum.
3. **Linear Time Algorithms:** Runs at $O(N)$ time complexity for mean, median, mode, and range, making it highly suitable for enterprise spreadsheets.
