# Test Suite: stat_mean
# Provides automated assertions on descriptive calculations.

# Source module cleanly
tryCatch({
  source(file.path("..", "statistics_engine.R"))
}, error = function(e) {
  # Direct folder fallback
  if (file.exists("statistics_engine.R")) {
    source("statistics_engine.R")
  } else if (file.exists("statistics-engine/statistics_engine.R")) {
    source("statistics-engine/statistics_engine.R")
  } else {
    source("../statistics_engine.R")
  }
})

cat("=======================================\n")
cat("Starting Mean Tests...\n")
cat("=======================================\n")

# Test 1: Simple Integer Series
input_set <- c(12, 18, 24, 30, 36)
expected  <- 24.0
actual    <- stat_mean(input_set)
stopifnot(abs(actual - expected) < 1e-9)
cat("[PASS] Case 1: Simple vector mean evaluates correctly to", actual, "\n")

# Test 2: Double Float Elements
input_double <- c(10.5, 20.3, 30.2, 40.0)
expected_dbl <- 25.25
actual_dbl   <- stat_mean(input_double)
stopifnot(abs(actual_dbl - expected_dbl) < 1e-9)
cat("[PASS] Case 2: Precision floats mean is accurate to", actual_dbl, "\n")

# Test 3: Handling NA/NaN values (na.rm = TRUE)
input_dirty <- c(10, NA, 20, NaN, 30)
expected_dry <- 20.0
actual_dry   <- stat_mean(input_dirty, na.rm = TRUE)
stopifnot(abs(actual_dry - expected_dry) < 1e-9)
cat("[PASS] Case 3: Missing/NaN elements filtered correctly under na.rm = TRUE\n")

# Test 4: Exception throwing for character inputs
err_thrown <- FALSE
tryCatch({
  stat_mean(c("one", "two", "three"))
}, error = function(e) {
  err_thrown <<- TRUE
  cat("[PASS] Case 4: Correctly handles non-numeric exceptions with message:", e$message, "\n")
})
if (!err_thrown) stop("Error: Non-numeric inputs should have thrown an error.")

# Test 5: Exception throwing for empty dataset
empty_err <- FALSE
tryCatch({
  stat_mean(numeric(0))
}, error = function(e) {
  empty_err <<- TRUE
  cat("[PASS] Case 5: Correctly throws clean exception with message:", e$message, "\n")
})
if (!empty_err) stop("Error: Empty inputs should have thrown an error.")

cat("=======================================\n")
cat("Status: All Mean Tests Finished Successfully!\n")
cat("=======================================\n\n")
