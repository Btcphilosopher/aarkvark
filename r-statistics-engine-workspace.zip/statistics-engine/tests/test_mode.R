# Test Suite: stat_mode
# Verification suite concerning discrete mode calculations.

tryCatch({
  source(file.path("..", "statistics_engine.R"))
}, error = function(e) {
  if (file.exists("statistics_engine.R")) {
    source("statistics_engine.R")
  } else if (file.exists("statistics-engine/statistics_engine.R")) {
    source("statistics-engine/statistics_engine.R")
  } else {
    source("../statistics_engine.R")
  }
})

cat("=======================================\n")
cat("Starting Mode Tests...\n")
cat("=======================================\n")

# Test 1: Single Mode Simple Array
single_mode_set <- c(10, 20, 20, 30, 40)
expected_single <- c(20)
actual_single   <- stat_mode(single_mode_set)
stopifnot(identical(actual_single, expected_single))
cat("[PASS] Case 1: Identifies single most frequent item correctly. Mode is", actual_single, "\n")

# Test 2: Bimodal Dataset (matches the user's c(4,4,5,6,6) example)
bimodal_set <- c(4, 4, 5, 6, 6)
expected_bi <- c(4, 6)
actual_bi   <- stat_mode(bimodal_set)
stopifnot(identical(actual_bi, expected_bi))
cat("[PASS] Case 2: Multi-modal values returned correctly as numeric vector: [", paste(actual_bi, collapse = ", "), "]\n")

# Test 3: No-mode distribution (all elements appear exactly once)
no_dup_set <- c(1, 2, 3, 4, 5)
expected_none <- numeric(0)
actual_none   <- stat_mode(no_dup_set)
stopifnot(identical(actual_none, expected_none))
cat("[PASS] Case 3: Returns clean numeric(0) for flat distributions with uniqueness.\n")

# Test 4: Uniform multi-frequency distribution (flat flat, every item appears twice)
uniform_flat_set <- c(7, 7, 8, 8, 9, 9)
expected_uni     <- numeric(0)
actual_uni       <- stat_mode(uniform_flat_set)
stopifnot(identical(actual_uni, expected_uni))
cat("[PASS] Case 4: Correctly returns empty numeric(0) for a perfect uniform multi-frequency distribution.\n")

# Test 5: mode calculation with NA filtering
dirty_mode_set <- c(9, 9, 10, NA, NaN, 10)
expected_dirty_mode <- c(9, 10)
actual_dirty_mode   <- stat_mode(dirty_mode_set, na.rm = TRUE)
stopifnot(identical(actual_dirty_mode, expected_dirty_mode))
cat("[PASS] Case 5: Correctly resolves dirty fields, returning sorted values: [", paste(actual_dirty_mode, collapse = ", "), "]\n")

cat("=======================================\n")
cat("Status: All Mode Tests Finished Successfully!\n")
cat("=======================================\n\n")
