# Test Suite: stat_median
# Dedicated verification module on middle order statistics.

tryCatch({
  source(file.path("..", "statistics_engine.R"))
}, error = function(e) {
  if (file.exists("statistics_engine.R")) {
    source("statistics_engine.R")
  } else if (file.exists("statistics-engine/statistics_engine.R")) {
    source("statistics-engine/statistics_engine.R")
  } else {
    source("../statistics_engine.R")
  }
})

cat("=======================================\n")
cat("Starting Median Tests...\n")
cat("=======================================\n")

# Test 1: Odd sample size (direct middle element)
odd_set <- c(5, 7, 1, 9, 3) # Ordered: 1, 3, 5, 7, 9
expected_odd <- 5.0
actual_odd   <- stat_median(odd_set)
stopifnot(abs(actual_odd - expected_odd) < 1e-9)
cat("[PASS] Case 1: Odd count datasets return direct midpoint:", actual_odd, "\n")

# Test 2: Even sample size (mean of two midpoints)
even_set <- c(10, 20, 30, 40) # Ordered: 10, 20, 30, 40. Midpoints: 20, 30. Mean: 25.
expected_even <- 25.0
actual_even   <- stat_median(even_set)
stopifnot(abs(actual_even - expected_even) < 1e-9)
cat("[PASS] Case 2: Even count datasets calculate mean of the two center items:", actual_even, "\n")

# Test 3: Unsorted decimals
decimal_set <- c(1.23, 5.67, 4.56, 2.34, 3.45) # Sorted: 1.23, 2.34, 3.45, 4.56, 5.67
expected_dec <- 3.45
actual_dec   <- stat_median(decimal_set)
stopifnot(abs(actual_dec - expected_dec) < 1e-9)
cat("[PASS] Case 3: Precision decimals are fully sorted and resolved to:", actual_dec, "\n")

# Test 4: dirty values filtering (na.rm = TRUE)
dirty_set <- c(NA, 100, NaN, 200, Inf, 300) # Excludes NA, NaN, Inf
expected_dirty <- 200.0
actual_dirty   <- stat_median(dirty_set, na.rm = TRUE)
stopifnot(abs(actual_dirty - expected_dirty) < 1e-9)
cat("[PASS] Case 4: Safely cleans missing/infinite nodes in median computation.\n")

# Test 5: Standard invalid types error
tryCatch({
  stat_median(c("abc", "def"))
  stop("Failed: Non-numeric lists must fail.")
}, error = function(e) {
  cat("[PASS] Case 5: Correctly throws clean exception for invalid text lists.\n")
})

cat("=======================================\n")
cat("Status: All Median Tests Finished Successfully!\n")
cat("=======================================\n\n")
