# Test Suite: stat_range
# Verification suite checking dispersion limits arithmetic.

tryCatch({
  source(file.path("..", "statistics_engine.R"))
}, error = function(e) {
  if (file.exists("statistics_engine.R")) {
    source("statistics_engine.R")
  } else if (file.exists("statistics-engine/statistics_engine.R")) {
    source("statistics-engine/statistics_engine.R")
  } else {
    source("../statistics_engine.R")
  }
})

cat("=======================================\n")
cat("Starting Range Tests...\n")
cat("=======================================\n")

# Test 1: Standard Numeric Vector
range_set_1 <- c(12.5, 4.0, 46.5, 23.0) # Max: 46.5, Min: 4.0. Diff = 42.5
expected_1  <- 42.5
actual_1    <- stat_range(range_set_1)
stopifnot(abs(actual_1 - expected_1) < 1e-9)
cat("[PASS] Case 1: Standard numeric series span correctly computed as", actual_1, "\n")

# Test 2: Decimals & Negative Values
negative_set <- c(-15.4, 30.6, -2.1, 0) # Max: 30.6, Min: -15.4. Diff = 30.6 - (-15.4) = 46.0
expected_neg <- 46.0
actual_neg   <- stat_range(negative_set)
stopifnot(abs(actual_neg - expected_neg) < 1e-9)
cat("[PASS] Case 2: Handing negative value bounds correctly resulting in", actual_neg, "\n")

# Test 3: Standard single value dataset (range should be exactly 0)
single_val_set <- c(99.9)
expected_single <- 0.0
actual_single   <- stat_range(single_val_set)
stopifnot(abs(actual_single - expected_single) < 1e-9)
cat("[PASS] Case 3: Single element contains a mathematical range of 0.0\n")

# Test 4: Check NA / NaN cleaning filter
dirty_range_set <- c(100, NA, 30, NaN, 20) # Max: 100, Min: 20. Diff = 80
expected_dirty   <- 80.0
actual_dirty     <- stat_range(dirty_range_set, na.rm = TRUE)
stopifnot(abs(actual_dirty - expected_dirty) < 1e-9)
cat("[PASS] Case 4: Excludes non-finite parameters with high reliability\n")

# Test 5: Verify incorrect input is caught
tryCatch({
  stat_range(c("five", "six"))
  stop("Failed: Non-numerics should fail range calculations")
}, error = function(e) {
  cat("[PASS] Case 5: Safely catches incorrect text structures.\n")
})

cat("=======================================\n")
cat("Status: All Range Tests Finished Successfully!\n")
cat("=======================================\n\n")
