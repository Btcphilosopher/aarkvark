#' Validate and Clean Dataset for Statistics Calculations
#'
#' @description
#' Standardizes various input types (vectors, data frames, matrices) into a
#' clean numeric vector. Detects non-numeric values, handling of empty structures,
#' and removes missing/null data if na.rm = TRUE.
#'
#' @param data A numeric vector, single-column data frame, matrix, or spreadsheet cell list.
#' @param na.rm Logical. If TRUE (default), removes NA, NaN, and Infinite values before evaluation.
#' @return A cleaned, non-empty numeric vector.
#' @export
validate_data <- function(data, na.rm = TRUE) {
  # 1. Null check
  if (is.null(data)) {
    stop("Error: Input is NULL. Data must be a numeric vector.")
  }

  # 2. Structural normalization: convert data frame columns or arrays to vector
  if (is.data.frame(data)) {
    if (ncol(data) == 1) {
      data <- data[[1]]
    } else if (ncol(data) == 0) {
      stop("Error: Provided data frame is empty (0 columns).")
    } else {
      # For multiple columns, we flatten into a single vector to behave like a multi-column spreadsheet cell range
      data <- unlist(data, use.names = FALSE)
    }
  }

  # If it is a list, flatten to vector
  if (is.list(data)) {
    data <- unlist(data, use.names = FALSE)
  }

  # If it's a matrix or array, flatten to 1D vector
  if (is.matrix(data) || is.array(data)) {
    data <- as.vector(data)
  }

  # 3. Type check: ensure numeric support (logical is converted to numeric automatically; strings are invalid)
  if (!is.numeric(data) && !is.logical(data)) {
    # If it is a character vector, check if we can safely convert to numeric without returning complete NAs
    if (is.character(data)) {
      # Attempt a safe parse
      suppressWarnings(parsed <- as.numeric(data))
      if (all(is.na(parsed)) && length(data) > 0) {
        stop("Error: Input must contain numeric values.")
      }
      data <- parsed
    } else {
      stop("Error: Input must contain numeric values.")
    }
  }

  # Ensure converted to logical/numeric vector of numeric type
  data <- as.numeric(data)

  # 4. Check early empty state
  if (length(data) == 0) {
    stop("Error: Empty dataset.")
  }

  # 5. Missing values / Not-a-Number / Infinites removal
  if (na.rm) {
    # Keep only finite values (excludes NA, NaN, Inf, -Inf)
    data <- data[is.finite(data)]
  } else {
    # If na.rm is FALSE, we check if there are any infinite terms or missing values.
    # In standardized R descriptive stats, if NAs are present and na.rm = FALSE,
    # computations should propagate NA. We allow them to pass, but if the whole sequence is NA:
    if (all(is.na(data))) {
      stop("Error: Dataset contains only NA/NaN values.")
    }
  }

  # 6. Final verification of post-cleaning length
  if (length(data) == 0) {
    stop("Error: Dataset is empty or contains only NA/NaN values after cleaning.")
  }

  return(data)
}
