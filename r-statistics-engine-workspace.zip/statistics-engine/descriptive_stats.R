#' High-Performance Mathematical Descriptive Statistics Engine
#'
#' @description
#' Provides vectorized, memory-optimized routines for descriptive statistics,
#' designed to operate efficiently on datasets of over 1,000,000 rows.
#'
#' @references
#' R Core Team (2026). R: A language and environment for statistical computing.

# Source validation interface
# Note: In a package or embedded script, standard practice is to source or import.
# For modular flexibility, we can safely invoke find/source or rely on load.
# We expect validation.R to be loaded already, or we can relative source it safely.
# If Rscript is run, we source it. Let's make it robust to being run from different working directories:
tryCatch({
  source(file.path(dirname(sys.frame(1)$ofile), "validation.R"))
}, error = function(e) {
  # Fallback logic if sys.frame is not accessible (e.g., interactive session or direct run)
  if (file.exists("validation.R")) {
    source("validation.R")
  } else if (file.exists("statistics-engine/validation.R")) {
    source("statistics-engine/validation.R")
  }
})

#' Arithmetic Mean
#'
#' @param data Input numerical dataset (vector, dataframe column, matrix).
#' @param na.rm Logical. Remove missing values (NA, NaN, Infinite).
#' @return Numeric. Arithmetic mean of the input.
#' @export
stat_mean <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  
  # Standardized vectorized sum/count is extremely fast in R internals (written in C)
  return(sum(clean_data) / length(clean_data))
}

#' Median (Middle value of sorted records)
#'
#' @param data Input numerical dataset.
#' @param na.rm Logical. Remove missing values.
#' @return Numeric. Median of the input, handles odd and even count cases.
#' @export
stat_median <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  
  # R's built-in median is optimized via partial sorting (O(N) with quickselect)
  return(stats::median(clean_data))
}

#' Mode (Most frequently occurring value)
#'
#' @param data Input numerical dataset.
#' @param na.rm Logical. Remove missing values.
#' @return Numeric vector. All values with maximum frequency, or numeric(0) if no mode exists.
#' @export
stat_mode <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  
  # O(N) integer frequency calculation based on hashing
  uniq_vals <- unique(clean_data)
  
  # For integer and real vectors, 'match' is vectorized and uses a hash table internally
  counts <- tabulate(match(clean_data, uniq_vals))
  max_count <- max(counts)
  
  # Check for "no-mode" scenarios:
  # 1. All elements occur exactly once (max_count = 1) and there's more than one distinct element
  if (max_count == 1 && length(clean_data) > 1) {
    return(numeric(0))
  }
  
  # 2. Perfect uniform distribution: all unique elements appear with the exact same frequency
  if (length(uniq_vals) > 1 && length(uniq_vals) == sum(counts == max_count)) {
    return(numeric(0))
  }
  
  modes <- uniq_vals[counts == max_count]
  return(sort(modes))
}

#' Minimum
#'
#' @param data Input numerical dataset.
#' @param na.rm Logical. Remove missing values.
#' @return Numeric. Minimum value.
#' @export
stat_min <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  return(min(clean_data))
}

#' Maximum
#'
#' @param data Input numerical dataset.
#' @param na.rm Logical. Remove missing values.
#' @return Numeric. Maximum value.
#' @export
stat_max <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  return(max(clean_data))
}

#' Range (Difference between Max and Min)
#'
#' @param data Input numerical dataset.
#' @param na.rm Logical. Remove missing values.
#' @return Numeric. Max - Min.
#' @export
stat_range <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  
  # Use micro-optimized min/max range calculations
  rng <- range(clean_data)
  return(rng[2] - rng[1])
}

#' Count (Returns number of valid numeric observations)
#'
#' @param data Input numerical dataset.
#' @param na.rm Logical. If TRUE, count excludes NA/NaN values.
#' @return Integer. Number of counted elements.
#' @export
stat_count <- function(data, na.rm = TRUE) {
  # Null check early to prevent crash
  if (is.null(data)) return(0L)
  
  # Avoid heavy coercions of validate_data for performance if we are just counting
  if (is.data.frame(data) || is.list(data)) {
    data <- unlist(data, use.names = FALSE)
  }
  
  if (na.rm) {
    return(sum(!is.na(data) & !is.nan(data) & is.finite(data)))
  } else {
    return(length(data))
  }
}

#' Sum
#'
#' @param data Input numerical dataset.
#' @param na.rm Logical. Remove missing values.
#' @return Numeric. Sum of overall elements.
#' @export
stat_sum <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  return(sum(clean_data))
}
