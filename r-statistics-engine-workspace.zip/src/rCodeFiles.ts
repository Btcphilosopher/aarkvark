import { RFile } from './types';

export const rCodeFiles: RFile[] = [
  {
    path: '/statistics-engine/descriptive_stats.R',
    filename: 'descriptive_stats.R',
    description: 'Vectorized core implementations of calculations (Mean, Median, Mode, etc.) using efficient R primitives.',
    content: `#' High-Performance Mathematical Descriptive Statistics Engine
#'
#' @description
#' Provides vectorized, memory-optimized routines for descriptive statistics,
#' designed to operate efficiently on datasets of over 1,000,000 rows.
#'
#' @references
#' R Core Team (2026). R: A language and environment for statistical computing.

tryCatch({
  source(file.path(dirname(sys.frame(1)$ofile), "validation.R"))
}, error = function(e) {
  if (file.exists("validation.R")) {
    source("validation.R")
  } else if (file.exists("statistics-engine/validation.R")) {
    source("statistics-engine/validation.R")
  }
})

#' Arithmetic Mean
#'
#' @param data Input numerical dataset (vector, dataframe column, matrix).
#' @param na.rm Logical. Remove missing values (NA, NaN, Infinite).
#' @return Numeric. Arithmetic mean of the input.
#' @export
stat_mean <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  
  return(sum(clean_data) / length(clean_data))
}

#' Median (Middle value of sorted records)
#'
#' @param data Input numerical dataset.
#' @param na.rm Logical. Remove missing values.
#' @return Numeric. Median of the input, handles odd and even count cases.
#' @export
stat_median <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  
  return(stats::median(clean_data))
}

#' Mode (Most frequently occurring value)
#'
#' @param data Input numerical dataset.
#' @param na.rm Logical. Remove missing values.
#' @return Numeric vector. All values with maximum frequency, or numeric(0) if no mode exists.
#' @export
stat_mode <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  
  uniq_vals <- unique(clean_data)
  counts <- tabulate(match(clean_data, uniq_vals))
  max_count <- max(counts)
  
  if (max_count == 1 && length(clean_data) > 1) {
    return(numeric(0))
  }
  
  if (length(uniq_vals) > 1 && length(uniq_vals) == sum(counts == max_count)) {
    return(numeric(0))
  }
  
  modes <- uniq_vals[counts == max_count]
  return(sort(modes))
}

#' Minimum
#' @export
stat_min <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  return(min(clean_data))
}

#' Maximum
#' @export
stat_max <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  return(max(clean_data))
}

#' Range (Difference between Max and Min)
#' @export
stat_range <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  
  rng <- range(clean_data)
  return(rng[2] - rng[1])
}

#' Count (Returns number of valid numeric observations)
#' @export
stat_count <- function(data, na.rm = TRUE) {
  if (is.null(data)) return(0L)
  
  if (is.data.frame(data) || is.list(data)) {
    data <- unlist(data, use.names = FALSE)
  }
  
  if (na.rm) {
    return(sum(!is.na(data) & !is.nan(data) & is.finite(data)))
  } else {
    return(length(data))
  }
}

#' Sum
#' @export
stat_sum <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  if (!na.rm && any(is.na(clean_data))) {
    return(NA_real_)
  }
  return(sum(clean_data))
}`
  },
  {
    path: '/statistics-engine/validation.R',
    filename: 'validation.R',
    description: 'Strict type validation, structural parsing of inputs, infinite checks, and error message routers.',
    content: `#' Validate and Clean Dataset for Statistics Calculations
#'
#' @description
#' Standardizes various input types (vectors, data frames, matrices) into a
#' clean numeric vector. Detects non-numeric values, handling of empty structures,
#' and removes missing/null data if na.rm = TRUE.
#'
#' @param data A numeric vector, single-column data frame, matrix, or spreadsheet cell list.
#' @param na.rm Logical. If TRUE (default), removes NA, NaN, and Infinite values before evaluation.
#' @return A cleaned, non-empty numeric vector.
#' @export
validate_data <- function(data, na.rm = TRUE) {
  if (is.null(data)) {
    stop("Error: Input is NULL. Data must be a numeric vector.")
  }

  if (is.data.frame(data)) {
    if (ncol(data) == 1) {
      data <- data[[1]]
    } else if (ncol(data) == 0) {
      stop("Error: Provided data frame is empty (0 columns).")
    } else {
      data <- unlist(data, use.names = FALSE)
    }
  }

  if (is.list(data)) {
    data <- unlist(data, use.names = FALSE)
  }

  if (is.matrix(data) || is.array(data)) {
    data <- as.vector(data)
  }

  if (!is.numeric(data) && !is.logical(data)) {
    if (is.character(data)) {
      suppressWarnings(parsed <- as.numeric(data))
      if (all(is.na(parsed)) && length(data) > 0) {
        stop("Error: Input must contain numeric values.")
      }
      data <- parsed
    } else {
      stop("Error: Input must contain numeric values.")
    }
  }

  data <- as.numeric(data)

  if (length(data) == 0) {
    stop("Error: Empty dataset.")
  }

  if (na.rm) {
    data <- data[is.finite(data)]
  } else {
    if (all(is.na(data))) {
      stop("Error: Dataset contains only NA/NaN values.")
    }
  }

  if (length(data) == 0) {
    stop("Error: Dataset is empty or contains only NA/NaN values after cleaning.")
  }

  return(data)
}`
  },
  {
    path: '/statistics-engine/statistics_engine.R',
    filename: 'statistics_engine.R',
    description: 'Core central orchestrator containing the high speed multi-metric single-pass calculation statistics_summary().',
    content: `#' Statistics Engine - Main Module
#'
#' @description
#' Orchestrates descriptive statistics functions and provides the central
#' master summary function \`statistics_summary\` for downstream integrations.
#'
#' @references
#' R Core Team (2026). R: A language and environment for statistical computing.

tryCatch({
  source(file.path(dirname(sys.frame(1)$ofile), "validation.R"))
  source(file.path(dirname(sys.frame(1)$ofile), "descriptive_stats.R"))
}, error = function(e) {
  paths <- c("validation.R", "descriptive_stats.R", 
             "statistics-engine/validation.R", "statistics-engine/descriptive_stats.R")
  for(path in paths) {
    if(file.exists(path)) source(path)
  }
})

#' Master Dataset Statistical Summary
#'
#' @description
#' Performs a unified analytical run on a collection of values, minimizing
#' memory overhead by avoiding sequential validations. Calculates descriptive
#' variables (location, dispersion, sizing) in a single high-speed pass.
#'
#' @param data Input numerical dataset (vector, data frame column, or cell values).
#' @param na.rm Logical. If TRUE, non-finite values (NA, NaN, Inf, -Inf) are cleaned first.
#' @return A structured named list containing count, sum, mean, median, mode, minimum, maximum, and range.
#' @export
statistics_summary <- function(data, na.rm = TRUE) {
  clean_data <- validate_data(data, na.rm = na.rm)
  
  n_count   <- length(clean_data)
  acc_sum   <- sum(clean_data)
  avg_mean  <- acc_sum / n_count
  mid_med   <- stats::median(clean_data)
  val_modes <- stat_mode(clean_data, na.rm = na.rm)
  
  lims      <- range(clean_data)
  val_min   <- lims[1]
  val_max   <- lims[2]
  rng_diff  <- val_max - val_min
  
  out <- list(
    count   = n_count,
    sum     = acc_sum,
    mean    = avg_mean,
    median  = mid_med,
    mode    = val_modes,
    minimum = val_min,
    maximum = val_max,
    range   = rng_diff
  )
  
  return(out)
}`
  },
  {
    path: '/statistics-engine/spreadsheet_wrappers.R',
    filename: 'spreadsheet_wrappers.R',
    description: 'Capitalized wrappers (MEAN, MEDIAN, MODE, etc.) matching spreadsheet formulas.',
    content: `#' Spreadsheet Integration Formula Wrappers
#'
#' @description
#' Capitalized formulas mapped directly to the core descriptive statistics engine.
#' Supports variadic arguments (\`...\`) to mirror spreadsheet structures which can pass
#' multiple cells, vectors, or multi-dimensional ranges.
#'
#' @export

tryCatch({
  source(file.path(dirname(sys.frame(1)$ofile), "descriptive_stats.R"))
}, error = function(e) {
  paths <- c("descriptive_stats.R", "statistics-engine/descriptive_stats.R")
  for(path in paths) {
    if(file.exists(path)) source(path)
  }
})

#' MEAN Formula
#' @export
MEAN <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_mean(args, na.rm = TRUE)
}

#' MEDIAN Formula
#' @export
MEDIAN <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_median(args, na.rm = TRUE)
}

#' MODE Formula
#' @export
MODE <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_mode(args, na.rm = TRUE)
}

#' MINIMUM Formula
#' @export
MINIMUM <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_min(args, na.rm = TRUE)
}

#' MAXIMUM Formula
#' @export
MAXIMUM <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_max(args, na.rm = TRUE)
}

#' RANGE Formula
#' @export
RANGE <- function(...) {
  args <- unlist(list(...), use.names = FALSE)
  stat_range(args, na.rm = TRUE)
}`
  },
  {
    path: '/statistics-engine/tests/test_mean.R',
    filename: 'test_mean.R',
    description: 'R assertions validating standard counts, float point accuracies, NA filters, and input error scenarios.',
    content: `# Test Suite: stat_mean
# Provides automated assertions on descriptive calculations.

tryCatch({
  source(file.path("..", "statistics_engine.R"))
}, error = function(e) {
  if (file.exists("statistics_engine.R")) {
    source("statistics_engine.R")
  } else if (file.exists("statistics-engine/statistics_engine.R")) {
    source("statistics-engine/statistics_engine.R")
  } else {
    source("../statistics_engine.R")
  }
})

cat("=======================================\\n")
cat("Starting Mean Tests...\\n")
cat("=======================================\\n")

# Test 1: Simple Integer Series
input_set <- c(12, 18, 24, 30, 36)
expected  <- 24.0
actual    <- stat_mean(input_set)
stopifnot(abs(actual - expected) < 1e-9)
cat("[PASS] Case 1: Simple vector mean evaluates correctly to", actual, "\\n")

# Test 2: Double Float Elements
input_double <- c(10.5, 20.3, 30.2, 40.0)
expected_dbl <- 25.25
actual_dbl   <- stat_mean(input_double)
stopifnot(abs(actual_dbl - expected_dbl) < 1e-9)
cat("[PASS] Case 2: Precision floats mean is accurate to", actual_dbl, "\\n")

# Test 3: Handling NA/NaN values (na.rm = TRUE)
input_dirty <- c(10, NA, 20, NaN, 30)
expected_dry <- 20.0
actual_dry   <- stat_mean(input_dirty, na.rm = TRUE)
stopifnot(abs(actual_dry - expected_dry) < 1e-9)
cat("[PASS] Case 3: Missing/NaN elements filtered correctly under na.rm = TRUE\\n")

# Test 4: Exception throwing for character inputs
err_thrown <- FALSE
tryCatch({
  stat_mean(c("one", "two", "three"))
}, error = function(e) {
  err_thrown <<- TRUE
  cat("[PASS] Case 4: Correctly handles non-numeric exceptions with message:", e$message, "\\n")
})
if (!err_thrown) stop("Error: Non-numeric inputs should have thrown an error.")

# Test 5: Exception throwing for empty dataset
empty_err <- FALSE
tryCatch({
  stat_mean(numeric(0))
}, error = function(e) {
  empty_err <<- TRUE
  cat("[PASS] Case 5: Correctly throws clean exception with message:", e$message, "\\n")
})
if (!empty_err) stop("Error: Empty inputs should have thrown an error.")

cat("=======================================\\n")
cat("Status: All Mean Tests Finished Successfully!\\n")
cat("=======================================\\n\\n")`
  },
  {
    path: '/statistics-engine/tests/test_median.R',
    filename: 'test_median.R',
    description: 'Unit assertions covering odd datasets, even datasets, sorting hierarchies, and invalid structures.',
    content: `# Test Suite: stat_median
# Dedicated verification module on middle order statistics.

tryCatch({
  source(file.path("..", "statistics_engine.R"))
}, error = function(e) {
  if (file.exists("statistics_engine.R")) {
    source("statistics_engine.R")
  } else if (file.exists("statistics-engine/statistics_engine.R")) {
    source("statistics-engine/statistics_engine.R")
  } else {
    source("../statistics_engine.R")
  }
})

cat("=======================================\\n")
cat("Starting Median Tests...\\n")
cat("=======================================\\n")

# Test 1: Odd sample size
odd_set <- c(5, 7, 1, 9, 3) # Ordered: 1, 3, 5, 7, 9
expected_odd <- 5.0
actual_odd   <- stat_median(odd_set)
stopifnot(abs(actual_odd - expected_odd) < 1e-9)
cat("[PASS] Case 1: Odd count datasets return direct midpoint:", actual_odd, "\\n")

# Test 2: Even sample size
even_set <- c(10, 20, 30, 40) # Ordered: 10, 20, 30, 40. Midpoints: 20, 30. Mean: 25.
expected_even <- 25.0
actual_even   <- stat_median(even_set)
stopifnot(abs(actual_even - expected_even) < 1e-9)
cat("[PASS] Case 2: Even count datasets calculate mean of the two center items:", actual_even, "\\n")

# Test 3: Unsorted decimals
decimal_set <- c(1.23, 5.67, 4.56, 2.34, 3.45) # Sorted: 1.23, 2.34, 3.45, 4.56, 5.67
expected_dec <- 3.45
actual_dec   <- stat_median(decimal_set)
stopifnot(abs(actual_dec - expected_dec) < 1e-9)
cat("[PASS] Case 3: Precision decimals are fully sorted and resolved to:", actual_dec, "\\n")

# Test 4: dirty values filtering
dirty_set <- c(NA, 100, NaN, 200, Inf, 300)
expected_dirty <- 200.0
actual_dirty   <- stat_median(dirty_set, na.rm = TRUE)
stopifnot(abs(actual_dirty - expected_dirty) < 1e-9)
cat("[PASS] Case 4: Safely cleans missing/infinite nodes in median computation.\\n")

# Test 5: Standard invalid types error
tryCatch({
  stat_median(c("abc", "def"))
  stop("Failed: Non-numeric lists must fail.")
}, error = function(e) {
  cat("[PASS] Case 5: Correctly throws clean exception for invalid text lists.\\n")
})

cat("=======================================\\n")
cat("Status: All Median Tests Finished Successfully!\\n")
cat("=======================================\\n\\n")`
  },
  {
    path: '/statistics-engine/tests/test_mode.R',
    filename: 'test_mode.R',
    description: 'Unit assertions validating single mode, bimodal datasets (4,4,5,6,6), and empty arrays for no mode.',
    content: `# Test Suite: stat_mode
# Verification suite concerning discrete mode calculations.

tryCatch({
  source(file.path("..", "statistics_engine.R"))
}, error = function(e) {
  if (file.exists("statistics_engine.R")) {
    source("statistics_engine.R")
  } else if (file.exists("statistics-engine/statistics_engine.R")) {
    source("statistics-engine/statistics_engine.R")
  } else {
    source("../statistics_engine.R")
  }
})

cat("=======================================\\n")
cat("Starting Mode Tests...\\n")
cat("=======================================\\n")

# Test 1: Single Mode Simple Array
single_mode_set <- c(10, 20, 20, 30, 40)
expected_single <- c(20)
actual_single   <- stat_mode(single_mode_set)
stopifnot(identical(actual_single, expected_single))
cat("[PASS] Case 1: Identifies single most frequent item correctly. Mode is", actual_single, "\\n")

# Test 2: Bimodal Dataset (matches standard double maximum frequency)
bimodal_set <- c(4, 4, 5, 6, 6)
expected_bi <- c(4, 6)
actual_bi   <- stat_mode(bimodal_set)
stopifnot(identical(actual_bi, expected_bi))
cat("[PASS] Case 2: Multi-modal values returned correctly as numeric vector: [", paste(actual_bi, collapse = ", "), "]\\n")

# Test 3: No-mode distribution
no_dup_set <- c(1, 2, 3, 4, 5)
expected_none <- numeric(0)
actual_none   <- stat_mode(no_dup_set)
stopifnot(identical(actual_none, expected_none))
cat("[PASS] Case 3: Returns clean numeric(0) for flat distributions with uniqueness.\\n")

# Test 4: Uniform multi-frequency distribution
uniform_flat_set <- c(7, 7, 8, 8, 9, 9)
expected_uni     <- numeric(0)
actual_uni       <- stat_mode(uniform_flat_set)
stopifnot(identical(actual_uni, expected_uni))
cat("[PASS] Case 4: Correctly returns empty numeric(0) for a perfect uniform multi-frequency distribution.\\n")

# Test 5: mode calculation with NA filtering
dirty_mode_set <- c(9, 9, 10, NA, NaN, 10)
expected_dirty_mode <- c(9, 10)
actual_dirty_mode   <- stat_mode(dirty_mode_set, na.rm = TRUE)
stopifnot(identical(actual_dirty_mode, expected_dirty_mode))
cat("[PASS] Case 5: Correctly resolves dirty fields, returning sorted values: [", paste(actual_dirty_mode, collapse = ", "), "]\\n")

cat("=======================================\\n")
cat("Status: All Mode Tests Finished Successfully!\\n")
cat("=======================================\\n\\n")`
  },
  {
    path: '/statistics-engine/tests/test_range.R',
    filename: 'test_range.R',
    description: 'Unit assertions on absolute boundaries, mixing bounds (negative to positive, decimals), and error reporting.',
    content: `# Test Suite: stat_range
# Verification suite checking dispersion limits arithmetic.

tryCatch({
  source(file.path("..", "statistics_engine.R"))
}, error = function(e) {
  if (file.exists("statistics_engine.R")) {
    source("statistics_engine.R")
  } else if (file.exists("statistics-engine/statistics_engine.R")) {
    source("statistics-engine/statistics_engine.R")
  } else {
    source("../statistics_engine.R")
  }
})

cat("=======================================\\n")
cat("Starting Range Tests...\\n")
cat("=======================================\\n")

# Test 1: Standard Numeric Vector
range_set_1 <- c(12.5, 4.0, 46.5, 23.0) # Max: 46.5, Min: 4.0. Diff = 42.5
expected_1  <- 42.5
actual_1    <- stat_range(range_set_1)
stopifnot(abs(actual_1 - expected_1) < 1e-9)
cat("[PASS] Case 1: Standard numeric series span correctly computed as", actual_1, "\\n")

# Test 2: Decimals & Negative Values
negative_set <- c(-15.4, 30.6, -2.1, 0) # Max: 30.6, Min: -15.4. Diff = 46.0
expected_neg <- 46.0
actual_neg   <- stat_range(negative_set)
stopifnot(abs(actual_neg - expected_neg) < 1e-9)
cat("[PASS] Case 2: Handing negative value bounds correctly resulting in", actual_neg, "\\n")

# Test 3: Standard single value dataset
single_val_set <- c(99.9)
expected_single <- 0.0
actual_single   <- stat_range(single_val_set)
stopifnot(abs(actual_single - expected_single) < 1e-9)
cat("[PASS] Case 3: Single element contains a mathematical range of 0.0\\n")

# Test 4: Check NA / NaN cleaning filter
dirty_range_set <- c(100, NA, 30, NaN, 20)
expected_dirty   <- 80.0
actual_dirty     <- stat_range(dirty_range_set, na.rm = TRUE)
stopifnot(abs(actual_dirty - expected_dirty) < 1e-9)
cat("[PASS] Case 4: Excludes non-finite parameters with high reliability\\n")

# Test 5: Verify incorrect input is caught
tryCatch({
  stat_range(c("five", "six"))
  stop("Failed: Non-numerics should fail")
}, error = function(e) {
  cat("[PASS] Case 5: Safely catches incorrect text structures.\\n")
})

cat("=======================================\\n")
cat("Status: All Range Tests Finished Successfully!\\n")
cat("=======================================\\n\\n")`
  },
  {
    path: '/statistics-engine/README.md',
    filename: 'README.md',
    description: 'Technical project documentation summarizing parameters, installation workflows, and computational complexities.',
    content: `# R Statistics Core Engine

A fast, accurate, and memory-efficient mathematical calculation module written in R, designed to be embedded into spreadsheet software as a reusable backend component. This module implements descriptive statistical measures optimized for performance on large datasets exceeding **1,000,000 rows**.

---

## 📁 Project Structure

\`\`\`text
statistics-engine/
├── statistics_engine.R       # Central orchestrator & master statistics_summary()
├── descriptive_stats.R       # Core mathematical formulas (Mean, Median, Mode, etc.)
├── validation.R              # Input sanitization, cleaning, and error routing
├── spreadsheet_wrappers.R    # Capitalized spreadsheet formulas (MEAN, MEDIAN, etc.)
├── tests/                    # Automated unit tests and assertion logic
│   ├── test_mean.R
│   ├── test_median.R
│   ├── test_mode.R
│   └── test_range.R
└── README.md                 # Detailed integration & technical reference
\`\`\`

---

## 🧬 Core Statistical Functions

All core routines reside in \`descriptive_stats.R\`. They leverage highly optimized R internal vectorized computations written in C to minimize memory reallocations and avoid slow looping.

### 1. Mean
Arithmetic average of all values in the range.
\\\\[ \\\\bar{x} = \\\\frac{1}{n} \\\\sum_{i=1}^{n} x_i \\\\]

### 2. Median
The absolute middle value of the ordered dataset. Handles odd and even counters with precision.

### 3. Mode
The most frequently occurring value(s). Handles bimodal, multimodal, and uniform distributions (no-mode).

### 4. Minimum & Maximum / Range
Dispersion characteristics. Range is the span Max - Min.
`
  }
];
