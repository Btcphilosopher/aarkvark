/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { GridData, FormulaResult } from './types';
import { SpreadsheetGrid } from './components/SpreadsheetGrid';
import { BenchmarkPanel } from './components/BenchmarkPanel';
import { CodeExplorer } from './components/CodeExplorer';
import { Calculator, ShieldAlert, Cpu, Sparkles, BookOpen, Terminal, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [gridData, setGridData] = useState<GridData>({});
  const [activeFormula, setActiveFormula] = useState<string>('=SUMMARY(A1:A5)');
  const [formulaResult, setFormulaResult] = useState<FormulaResult | null>(null);

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] antialiased font-sans flex flex-col">
      
      {/* Prime Header Block */}
      <header className="bg-white border-b border-[#141414] py-4 px-6 shrink-0" id="app_header">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Logo & title context */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#141414] text-white flex items-center justify-center shrink-0 border border-[#141414]">
              <span className="font-serif font-black text-xl italic tracking-tighter">R</span>
            </div>
            <div>
              <h1 className="text-md font-bold text-[#141414] tracking-tight flex items-center gap-2 font-serif italic">
                R Statistics Engine Workspace
                <span className="text-[9px] uppercase tracking-widest font-bold text-white bg-[#141414] px-1.5 py-0.5 font-mono select-none">
                  Core Module v1.4
                </span>
              </h1>
              <p className="text-[11px] text-[#141414]/65 font-mono">
                A tested, high-performance mathematical statistics calculation and evaluation backend module.
              </p>
            </div>
          </div>

          {/* Quick status specs & Meta from Design specs */}
          <div className="flex flex-wrap items-center gap-6 text-[11px] font-mono">
            <div className="hidden sm:flex gap-6 border-r border-[#141414]/15 pr-6">
              <div className="flex flex-col">
                <span className="text-[9px] uppercase opacity-50 font-bold">Precision</span>
                <span className="font-semibold tracking-tight text-[#141414]">Double-Float (64-bit)</span>
              </div>
              <div className="flex flex-col">
                <span className="text-[9px] uppercase opacity-50 font-bold">Vectorization</span>
                <span className="font-semibold tracking-tight text-[#141414]">Native C++ (BLAS)</span>
              </div>
              <div className="flex flex-col">
                <span className="text-[9px] uppercase opacity-50 font-bold">Na Handle</span>
                <span className="font-semibold tracking-tight text-[#141414]">na.rm = TRUE</span>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-[#141414]/5 px-3 py-1.5 border border-[#141414]/20">
              <span className="w-2 h-2 rounded-full bg-green-600"></span>
              <span className="font-bold text-[10px] uppercase">Engine Status: Ready</span>
            </div>
          </div>
          
        </div>
      </header>

      {/* Main Single-Screen Bento Cockpit */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-6 lg:p-8 space-y-6" id="app_main">
        
        {/* Core Layout Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          
          {/* Left section split (Grid Workspace + Benchmarks) - 7 columns */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            
            {/* Cell Range evaluator table wrapper */}
            <div className="flex-1">
              <SpreadsheetGrid 
                gridData={gridData}
                setGridData={setGridData}
                activeFormula={activeFormula}
                setActiveFormula={setActiveFormula}
                formulaResult={formulaResult}
                setFormulaResult={setFormulaResult}
              />
            </div>
            
            {/* O(N) Benchmark timing calculator */}
            <div>
              <BenchmarkPanel />
            </div>

          </div>

          {/* Right section split (R Code modules + test terminal assertions) - 5 columns */}
          <div className="lg:col-span-5 flex flex-col h-full">
            <div className="flex-1 min-h-[500px]">
              <CodeExplorer />
            </div>
          </div>

        </div>

      </main>

      {/* Modern, light minimal footer */}
      <footer className="bg-white border-t border-[#141414] py-4 px-6 text-center text-xs text-[#141414]/60 font-mono tracking-wide mt-auto select-none" id="app_footer">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-[10px]">
          <span>
            R Version 4.2.1 (2022-06-23) -- "Funny-looking Kid" | module: statistics-engine-backend-v1
          </span>
          <div className="flex items-center gap-4 font-mono font-medium text-[#141414]/80">
            <span className="hover:underline cursor-pointer">Module Specifications</span>
            <span className="opacity-40">|</span>
            <span className="hover:underline cursor-pointer">IEEE-754 Compliant Arithmetic</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
