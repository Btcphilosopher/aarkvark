/**
 * Types and Contracts for the R Statistics Engine Workspace
 */

export interface SpreadsheetCell {
  row: number; // 1-indexed (1 to 10)
  col: string; // "A" to "E"
  value: string; // Raw input (can be numbers, empty, dirty items)
  parsedValue: number | null; // Coerced numeric equivalent (or null if blank/invalid)
}

export type GridData = Record<string, SpreadsheetCell>; // Key format e.g., "A1"

export interface FormulaResult {
  formula: string; // The parsed formula typed e.g. "=MEAN(A1:A5)"
  success: boolean;
  value: number | number[] | null; // Multi-mode returns array
  errorMsg?: string;
  sourceCells?: string[]; // Cells involved in the evaluation
  summaryObj?: Record<string, number | number[] | null>; // For `=SUMMARY(...)`
}

export interface BenchmarkDistribution {
  id: 'uniform' | 'normal' | 'bimodal' | 'dirty';
  name: string;
  description: string;
}

export interface BenchmarkResult {
  datasetSize: number;
  distributionType: string;
  times: {
    mean: number; // ms
    median: number; // ms
    mode: number; // ms
    range: number; // ms
    summary: number; // ms
  };
}

export interface RFile {
  path: string;
  filename: string;
  description: string;
  content: string;
}

export interface TestLog {
  timestamp: string;
  type: 'info' | 'pass' | 'error' | 'header';
  message: string;
}
