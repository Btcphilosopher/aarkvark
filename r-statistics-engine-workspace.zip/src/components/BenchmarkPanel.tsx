import React, { useState } from 'react';
import { Play, Cpu, Sparkles, Sliders, Layers, BarChart, Info } from 'lucide-react';
import { scorePerformance } from '../statsEngineSim';

interface BenchmarkData {
  times: {
    mean: number;
    median: number;
    mode: number;
    range: number;
    summary: number;
  };
  results: {
    mean: number;
    median: number;
    mode: number[];
    range: number;
    count: number;
  };
}

export const BenchmarkPanel: React.FC = () => {
  const [size, setSize] = useState<number>(100000); // Default 100,000
  const [distType, setDistType] = useState<'uniform' | 'normal' | 'bimodal' | 'dirty'>('normal');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [perfData, setPerfData] = useState<BenchmarkData | null>(null);

  const sizes = [
    { label: '10K', value: 10000 },
    { label: '100K', value: 100000 },
    { label: '500K', value: 500000 },
    { label: '1 Million', value: 1000000 }
  ];

  const distributions = [
    { id: 'uniform', name: 'Uniform [0, 100]', desc: 'Flat random distribution' },
    { id: 'normal', name: 'Gaussian Normal', desc: 'Bell curve centered at 50, Stdv 15' },
    { id: 'bimodal', name: 'Bimodal Peaks', desc: 'Dual-clusters (centers 25 & 75)' },
    { id: 'dirty', name: 'Dirty (15% NAs)', desc: 'Tests performance under null-strips' }
  ] as const;

  const handleBenchmarkLaunch = () => {
    setIsRunning(true);
    // Use an immediate timeout to allow UI rendering thread to update spinner
    setTimeout(() => {
      try {
        const results = scorePerformance(size, distType);
        setPerfData(results);
      } catch (e) {
        console.error(e);
      } finally {
        setIsRunning(false);
      }
    }, 100);
  };

  // Find max time to scale chart relative heights beautifully
  const getMaxTime = () => {
    if (!perfData) return 1;
    const { mean, median, mode, range, summary } = perfData.times;
    return Math.max(mean, median, mode, range, summary, 1);
  };

  const getPercent = (timeVal: number) => {
    const max = getMaxTime();
    return Math.max(4, Math.min(100, (timeVal / max) * 100));
  };

  return (
    <div className="bg-white border border-[#141414] p-5 flex flex-col h-full rounded-none" id="benchmark_panel">
      {/* Panel Headers */}
      <div className="pb-4 mb-4 border-b border-[#141414]/15">
        <h2 className="text-md font-bold text-[#141414] tracking-tight flex items-center gap-2 font-serif italic">
          <Cpu className="w-5 h-5 text-[#141414]" />
          Vectorised Performance Benchmarks
        </h2>
        <p className="text-[11px] text-[#141414]/65 mt-0.5 font-mono">
          Verify memory-safe operations in R by scaling dataset rows from <strong>10,000 to 1,000,000+ elements</strong>.
        </p>
      </div>

      {/* Control Layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
        {/* Size Slider */}
        <div className="bg-[#f8f8f7] p-3 border border-[#141414] rounded-none">
          <label className="text-[10px] font-mono font-bold uppercase text-[#141414]/70 block mb-2 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-[#141414]/55" />
            Dataset Sizing Rows (N)
          </label>
          <div className="grid grid-cols-4 gap-1.5">
            {sizes.map(sz => (
              <button
                key={sz.value}
                onClick={() => setSize(sz.value)}
                className={`py-1.5 text-xs font-mono font-bold rounded-none border transition duration-150 ${
                  size === sz.value
                    ? 'bg-[#141414] text-white border-[#141414]'
                    : 'bg-white hover:bg-neutral-150 text-[#141414] border-[#141414]/30'
                } cursor-pointer`}
              >
                {sz.label}
              </button>
            ))}
          </div>
          <div className="mt-2.5 text-right">
            <span className="text-[10px] bg-[#141414] text-white font-mono font-bold px-2 py-0.5 rounded-none border border-[#141414]">
              N = {size.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Data Distribution selection */}
        <div className="bg-[#f8f8f7] p-3 border border-[#141414] flex flex-col justify-between rounded-none">
          <div>
            <label className="text-[10px] font-mono font-bold uppercase text-[#141414]/70 block mb-1.5 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#141414]/55" />
              Statistical Probability Distribution
            </label>
            <select
              value={distType}
              onChange={(e) => setDistType(e.target.value as any)}
              className="w-full bg-white border border-[#141414] px-2.5 py-1 text-xs text-[#141414] font-mono rounded-none focus:outline-none focus:bg-[#f8f8f7] cursor-pointer"
            >
              {distributions.map(d => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>
          <p className="text-[10px] text-[#141414]/65 font-mono mt-2 leading-normal">
            {distributions.find(d => d.id === distType)?.desc}
          </p>
        </div>
      </div>

      {/* Launcher Button */}
      <button
        onClick={handleBenchmarkLaunch}
        disabled={isRunning}
        className={`w-full py-2.5 px-4 text-xs font-serif italic text-white rounded-none transition duration-150 shadow-none flex items-center justify-center gap-2 cursor-pointer ${
          isRunning
            ? 'bg-neutral-500 cursor-not-allowed border border-neutral-600'
            : 'bg-[#141414] hover:bg-neutral-800 border border-[#141414]'
        }`}
      >
        {isRunning ? (
          <>
            <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <span className="font-mono">Allocating & Benchmarking O(N) Vectors...</span>
          </>
        ) : (
          <>
            <Play className="w-4 h-4 fill-current text-white" />
            <span>Launch Statistical Benchmarking Run</span>
          </>
        )}
      </button>

      {/* Benchmarking Charts and statistics outputs */}
      <div className="mt-5 flex-1 flex flex-col justify-between">
        {perfData ? (
          <div className="space-y-5">
            {/* Chart Grid */}
            <div>
              <span className="text-[10px] text-[#141414]/50 font-mono font-bold tracking-widest uppercase block mb-3 flex items-center gap-1">
                <BarChart className="w-3.5 h-3.5 text-[#141414]/50" />
                Execution Cost (lower is faster)
              </span>
              <div className="space-y-2.5">
                {[
                  { name: 'RANGE', label: 'stat_range()', time: perfData.times.range, color: 'bg-blue-800', desc: 'Min/Max endpoints [O(N)]' },
                  { name: 'MEAN', label: 'stat_mean()', time: perfData.times.mean, color: 'bg-indigo-900', desc: 'Arithmetic average [O(N)]' },
                  { name: 'MEDIAN', label: 'stat_median()', time: perfData.times.median, color: 'bg-[#141414]', desc: 'Sort & select [O(N log N)]' },
                  { name: 'MODE', label: 'stat_mode()', time: perfData.times.mode, color: 'bg-zinc-700', desc: 'Hash frequency scan [O(N)]' },
                  { name: 'SUMMARY', label: 'statistics_summary()', time: perfData.times.summary, color: 'bg-neutral-600', desc: 'Single-pass master list [Optimized]' }
                ].map((item) => (
                  <div key={item.name} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div className="font-mono text-[11px] font-bold text-[#141414]">
                        {item.label} <span className="font-sans font-normal text-[10px] text-[#141414]/60">({item.desc})</span>
                      </div>
                      <div className="font-mono text-[11px] font-bold text-[#141414]">
                        {item.time >= 1 ? `${item.time.toFixed(2)} ms` : `${(item.time * 1050).toFixed(0)} μs`}
                      </div>
                    </div>
                    <div className="w-full bg-[#f8f8f7] border border-[#141414]/15 h-2.5 rounded-none">
                      <div 
                        className={`h-full rounded-none transition-all duration-700 ${item.color}`}
                        style={{ width: `${getPercent(item.time)}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Calculations outputs */}
            <div className="bg-[#f8f8f7] border border-[#141414] p-3.5 rounded-none">
              <span className="text-[10px] text-[#141414]/50 font-mono font-bold tracking-widest uppercase block mb-2.5">
                Algebraic Outputs for Row Set
              </span>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-white p-2 border border-[#141414] rounded-none">
                  <span className="text-[9px] text-[#141414]/50 block font-mono font-bold uppercase tracking-wider">Mean Average</span>
                  <span className="text-xs text-[#141414] font-bold font-mono mt-0.5 block truncate">
                    {perfData.results.mean.toFixed(4)}
                  </span>
                </div>
                <div className="bg-white p-2 border border-[#141414] rounded-none">
                  <span className="text-[9px] text-[#141414]/50 block font-mono font-bold uppercase tracking-wider">Median Order</span>
                  <span className="text-xs text-[#141414] font-bold font-mono mt-0.5 block truncate">
                    {perfData.results.median.toFixed(4)}
                  </span>
                </div>
                <div className="bg-white p-2 border border-[#141414] rounded-none">
                  <span className="text-[9px] text-[#141414]/50 block font-mono font-bold uppercase tracking-wider">Modes (Rounded)</span>
                  <span className="text-xs text-[#141414] font-bold font-mono mt-0.5 block truncate" title={perfData.results.mode.join(', ')}>
                    {perfData.results.mode.length === 0 ? 'numeric(0)' : perfData.results.mode.slice(0,2).join(', ') + (perfData.results.mode.length > 2 ? '...' : '')}
                  </span>
                </div>
                <div className="bg-white p-2 border border-[#141414] rounded-none">
                  <span className="text-[9px] text-[#141414]/50 block font-mono font-bold uppercase tracking-wider">Interval Range</span>
                  <span className="text-xs text-[#141414] font-bold font-mono mt-0.5 block truncate">
                    {perfData.results.range.toFixed(4)}
                  </span>
                </div>
              </div>
              <div className="mt-2.5 text-center">
                <span className="text-[10px] text-[#141414]/60 font-mono uppercase tracking-wide">
                  Total valid rows parsed: <strong className="text-blue-800 font-bold">{perfData.results.count.toLocaleString()}</strong> rows (excluding NAs).
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="border border-dashed border-[#141414]/40 rounded-none p-10 text-center flex flex-col items-center justify-center space-y-2.5 h-full min-h-[220px]">
            <CPUBackgroundGrid />
            <span className="text-xs text-[#141414] font-mono mt-2 font-bold uppercase tracking-widest">Ready to benchmark calculations...</span>
            <p className="text-[11px] text-[#141414]/60 max-w-sm font-mono">
              Press the benchmarking button to stream massive vectors (up to 1,000,000 values) through our O(N) descriptive calculations, simulating high-throughput conditions.
            </p>
          </div>
        )}

        {/* Technical complexity note footer */}
        <div className="mt-4 bg-[#f8f8f7] border border-[#141414] p-3 flex gap-2 rounded-none">
          <Info className="w-4 h-4 text-[#141414] shrink-0 mt-0.5" />
          <p className="text-[10px] text-[#141414] font-mono leading-normal">
            <strong>Memory footprint:</strong> R calculations are performed natively in vectorized C-code. 
            Memory overhead is kept at $O(1)$ additional allocations by referencing references directly, ensuring the workspace operates efficiently under enterprise constraints.
          </p>
        </div>
      </div>
    </div>
  );
};

// Decorative vector
const CPUBackgroundGrid: React.FC = () => (
  <div className="relative">
    <div className="w-10 h-10 bg-white flex items-center justify-center border border-[#141414] text-[#141414]">
      <Cpu className="w-5 h-5 text-[#141414]" />
    </div>
  </div>
);
