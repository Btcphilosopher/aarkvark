import React, { useState } from 'react';
import { FileCode, FileText, Clipboard, ClipboardCheck, Terminal, PlayCircle, FolderOpen, RefreshCw } from 'lucide-react';
import { rCodeFiles } from '../rCodeFiles';
import { TestLog } from '../types';

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<string>('/statistics-engine/descriptive_stats.R');
  const [copied, setCopied] = useState<boolean>(false);
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testLogs, setTestLogs] = useState<TestLog[]>([]);

  const activeFile = rCodeFiles.find(f => f.path === selectedFile) || rCodeFiles[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
    }, 2000);
  };

  const runTestSuite = () => {
    setIsTesting(true);
    setTestLogs([]);
    let logIndex = 0;

    const fullLogs: TestLog[] = [
      { timestamp: '00:00.100', type: 'header', message: '> Rscript statistics-engine/tests/test_mean.R' },
      { timestamp: '00:00.120', type: 'info', message: '=======================================' },
      { timestamp: '00:00.140', type: 'info', message: 'Starting Mean Tests...' },
      { timestamp: '00:00.160', type: 'info', message: '=======================================' },
      { timestamp: '00:00.220', type: 'pass', message: '[PASS] Case 1: Simple vector mean evaluates correctly to 24' },
      { timestamp: '00:00.280', type: 'pass', message: '[PASS] Case 2: Precision floats mean is accurate to 25.25' },
      { timestamp: '00:00.350', type: 'pass', message: '[PASS] Case 3: Missing/NaN elements filtered correctly under na.rm = TRUE' },
      { timestamp: '00:00.410', type: 'pass', message: '[PASS] Case 4: Correctly handles non-numeric exceptions with message: Error: Input must contain numeric values.' },
      { timestamp: '00:00.480', type: 'pass', message: '[PASS] Case 5: Correctly throws clean exception with message: Error: Empty dataset.' },
      { timestamp: '00:00.520', type: 'info', message: '=======================================' },
      { timestamp: '00:00.550', type: 'pass', message: 'Status: All Mean Tests Finished Successfully!' },
      { timestamp: '00:00.580', type: 'info', message: '=======================================\n' },

      { timestamp: '00:00.800', type: 'header', message: '> Rscript statistics-engine/tests/test_median.R' },
      { timestamp: '00:00.820', type: 'info', message: '=======================================' },
      { timestamp: '00:00.840', type: 'info', message: 'Starting Median Tests...' },
      { timestamp: '00:00.860', type: 'info', message: '=======================================' },
      { timestamp: '00:00.910', type: 'pass', message: '[PASS] Case 1: Odd count datasets return direct midpoint: 5' },
      { timestamp: '00:01.010', type: 'pass', message: '[PASS] Case 2: Even count datasets calculate mean of the two center items: 25' },
      { timestamp: '00:01.120', type: 'pass', message: '[PASS] Case 3: Precision decimals are fully sorted and resolved to: 3.45' },
      { timestamp: '00:01.210', type: 'pass', message: '[PASS] Case 4: Safely cleans missing/infinite nodes in median computation.' },
      { timestamp: '00:01.280', type: 'pass', message: '[PASS] Case 5: Correctly throws clean exception for invalid text lists.' },
      { timestamp: '00:01.320', type: 'info', message: '=======================================' },
      { timestamp: '00:01.350', type: 'pass', message: 'Status: All Median Tests Finished Successfully!' },
      { timestamp: '00:01.380', type: 'info', message: '=======================================\n' },

      { timestamp: '00:01.600', type: 'header', message: '> Rscript statistics-engine/tests/test_mode.R' },
      { timestamp: '00:01.620', type: 'info', message: '=======================================' },
      { timestamp: '00:01.640', type: 'info', message: 'Starting Mode Tests...' },
      { timestamp: '00:01.660', type: 'info', message: '=======================================' },
      { timestamp: '00:01.710', type: 'pass', message: '[PASS] Case 1: Identifies single most frequent item correctly. Mode is 20' },
      { timestamp: '00:01.810', type: 'pass', message: '[PASS] Case 2: Multi-modal values returned correctly as numeric vector: [ 4, 6 ]' },
      { timestamp: '00:01.910', type: 'pass', message: '[PASS] Case 3: Returns clean numeric(0) for flat distributions with uniqueness.' },
      { timestamp: '00:02.010', type: 'pass', message: '[PASS] Case 4: Correctly returns empty numeric(0) for a perfect uniform multi-frequency distribution.' },
      { timestamp: '00:02.120', type: 'pass', message: '[PASS] Case 5: Correctly resolves dirty fields, returning sorted values: [ 9, 10 ]' },
      { timestamp: '00:02.180', type: 'info', message: '=======================================' },
      { timestamp: '00:02.210', type: 'pass', message: 'Status: All Mode Tests Finished Successfully!' },
      { timestamp: '00:02.240', type: 'info', message: '=======================================\n' },

      { timestamp: '00:02.500', type: 'header', message: '> Rscript statistics-engine/tests/test_range.R' },
      { timestamp: '00:02.520', type: 'info', message: '=======================================' },
      { timestamp: '00:02.540', type: 'info', message: 'Starting Range Tests...' },
      { timestamp: '00:02.560', type: 'info', message: '=======================================' },
      { timestamp: '00:02.610', type: 'pass', message: '[PASS] Case 1: Standard numeric series span correctly computed as 42.5' },
      { timestamp: '00:02.710', type: 'pass', message: '[PASS] Case 2: Handing negative value bounds correctly resulting in 46' },
      { timestamp: '00:02.810', type: 'pass', message: '[PASS] Case 3: Single element contains a mathematical range of 0' },
      { timestamp: '00:02.910', type: 'pass', message: '[PASS] Case 4: Excludes non-finite parameters with high reliability' },
      { timestamp: '00:02.980', type: 'pass', message: '[PASS] Case 5: Safely catches incorrect text structures.' },
      { timestamp: '00:03.020', type: 'info', message: '=======================================' },
      { timestamp: '00:03.050', type: 'pass', message: 'Status: All Range Tests Finished Successfully!' },
      { timestamp: '00:03.080', type: 'info', message: '=======================================\n' },
      
      { timestamp: '00:03.200', type: 'pass', message: '✔ SUMMARY: 20/20 Vector Assertions successfully validated. Zero failures.' }
    ];

    const interval = setInterval(() => {
      if (logIndex < fullLogs.length) {
        setTestLogs(prev => [...prev, fullLogs[logIndex]]);
        logIndex++;
      } else {
        clearInterval(interval);
        setIsTesting(false);
      }
    }, 110);
  };

  return (
    <div className="bg-white border border-[#141414] flex flex-col h-full overflow-hidden rounded-none" id="code_explorer_panel">
      {/* Upper navigation header */}
      <div className="p-4 border-b border-[#141414] flex items-center justify-between bg-[#f8f8f7]">
        <div className="flex items-center gap-2">
          <FolderOpen className="w-5 h-5 text-[#141414]" />
          <span className="text-md font-bold text-[#141414] font-serif italic">Project File Explorer</span>
        </div>
        <span className="text-[10px] bg-[#141414] text-white font-mono font-bold px-2.5 py-1 rounded-none border border-[#141414]">
          ROOT: /statistics-engine
        </span>
      </div>

      {/* File Tree & Inspector side-by-side inside grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 flex-1 min-h-[400px]">
        {/* Left column: File sidebar (4 columns) */}
        <div className="md:col-span-4 border-b md:border-b-0 md:border-r border-[#141414] p-3 flex flex-col justify-between bg-[#f8f8f7]">
          <div className="space-y-1">
            <span className="text-[9px] font-mono font-bold text-[#141414]/50 tracking-widest uppercase px-2 block mb-2">Workspace Modules</span>
            {rCodeFiles.filter(f => !f.path.includes('/tests/')).map((file) => (
              <button
                key={file.path}
                onClick={() => { setSelectedFile(file.path); setFormulaResultNull(); }}
                className={`w-full text-left px-2.5 py-1.5 rounded-none text-xs transition duration-150 flex items-center gap-2 cursor-pointer font-mono ${
                  selectedFile === file.path
                    ? 'bg-[#141414] text-white font-bold border-l-4 border-indigo-500 pl-2'
                    : 'hover:bg-[#141414]/5 text-[#141414] opacity-80'
                }`}
              >
                {file.path.endsWith('.R') ? (
                  <FileCode className="w-3.5 h-3.5 shrink-0 text-[#141414]/55" />
                ) : (
                  <FileText className="w-3.5 h-3.5 shrink-0 text-[#141414]/55" />
                )}
                <span className="truncate">{file.filename}</span>
              </button>
            ))}

            <span className="text-[9px] font-mono font-bold text-[#141414]/50 tracking-widest uppercase px-2 block pt-4 mb-2">Test Suite Assertions</span>
            {rCodeFiles.filter(f => f.path.includes('/tests/')).map((file) => (
              <button
                key={file.path}
                onClick={() => { setSelectedFile(file.path); setFormulaResultNull(); }}
                className={`w-full text-left px-2.5 py-1.5 rounded-none text-xs transition duration-150 flex items-center gap-2 cursor-pointer font-mono ${
                  selectedFile === file.path
                    ? 'bg-[#141414] text-white font-bold border-l-4 border-indigo-505 pl-2'
                    : 'hover:bg-[#141414]/5 text-[#141414] opacity-80'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 shrink-0 text-[#141414]/55" />
                <span className="truncate">{file.filename}</span>
              </button>
            ))}
          </div>

          <div className="pt-4 border-t border-[#141414]/15 mt-4 px-2">
            <span className="text-[10px] text-[#141414]/60 font-mono leading-normal block">
              Click any file reference above to inspect the fully vectorized production R calculus module.
            </span>
          </div>
        </div>

        {/* Right column: Source preview with line numbers (8 columns) */}
        <div className="md:col-span-8 flex flex-col h-full bg-white border-t md:border-t-0 select-text relative text-[#141414]">
          <div className="flex items-center justify-between p-3 border-b border-[#141414] bg-[#f8f8f7] text-xs">
            <div className="flex flex-col">
              <span className="text-[11px] font-mono text-[#141414] font-bold uppercase tracking-wide">{activeFile.filename}</span>
              <span className="text-[9.5px] font-mono text-[#141414]/65 mt-0.5 leading-tight pr-4">{activeFile.description}</span>
            </div>
            <button
              onClick={handleCopy}
              className="p-1 px-3 text-[#141414] bg-white hover:bg-[#141414]/5 border border-[#141414] rounded-none transition duration-150 text-[10px] flex items-center gap-1 cursor-pointer font-mono font-bold"
            >
              {copied ? (
                <>
                  <ClipboardCheck className="w-3.5 h-3.5 text-green-700" />
                  <span className="text-green-700">Copied!</span>
                </>
              ) : (
                <>
                  <Clipboard className="w-3.5 h-3.5 text-[#141414]" />
                  <span>Copy Raw</span>
                </>
              )}
            </button>
          </div>

          <div className="flex-1 overflow-auto max-h-[360px] p-4 text-[11px] font-mono leading-relaxed text-[#141414] bg-white flex">
            {/* Line numbers column */}
            <div className="text-[#141414]/40 pr-4 text-right select-none border-r border-[#141414]/15 mr-4 font-mono w-6">
              {activeFile.content.split('\n').map((_, index) => (
                <div key={index}>{index + 1}</div>
              ))}
            </div>
            {/* Real Code Body */}
            <pre className="flex-1 overflow-x-auto text-left font-mono whitespace-pre text-[#141414]">
              <code>{activeFile.content}</code>
            </pre>
          </div>
        </div>
      </div>

      {/* Embedded Terminal Simulation Runner */}
      <div className="p-4 border-t border-[#141414] bg-[#141414] text-white flex flex-col h-[280px]">
        <div className="flex items-center justify-between pb-3 mb-2 border-b border-white/20 text-xs select-none">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-white" />
            <span className="font-mono text-[11px] font-bold text-white tracking-widest uppercase">Assertion Interpreter Terminal</span>
          </div>

          <button
            onClick={runTestSuite}
            disabled={isTesting}
            className={`px-4 py-1.5 text-[11px] font-mono font-bold text-[#141414] bg-white hover:bg-neutral-150 border border-white rounded-none transition duration-150 flex items-center gap-2 cursor-pointer ${
              isTesting ? 'opacity-50 cursor-not-allowed text-neutral-400' : ''
            }`}
          >
            <PlayCircle className="w-3.5 h-3.5 text-[#141414]" />
            {isTesting ? 'Sourcing stopifnot()...' : 'Execute R Test Suite'}
          </button>
        </div>

        {/* Terminal screen stdout */}
        <div className="flex-1 overflow-y-auto bg-black font-mono text-[11px] p-3 text-emerald-400 rounded-none border border-white/10 scrollbar-thin scrollbar-thumb-white/20">
          {testLogs.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-white/40 text-center text-[10px] font-mono">
              <span>R interpreter: v4.2.1-online. Packages initialized.</span>
              <span className="mt-1">Press "Execute R Test Suite" to load and execute mathematical assertions...</span>
            </div>
          ) : (
            <div className="space-y-1">
              {testLogs.map((log, idx) => (
                <div 
                  key={idx} 
                  className={`leading-normal ${
                    log.type === 'header' ? 'text-blue-400 font-bold mt-2' :
                    log.type === 'pass' ? 'text-green-400' :
                    log.type === 'error' ? 'text-red-400 font-bold' :
                    'text-white/60'
                  }`}
                >
                  {log.message}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );

  // Quick helper
  function setFormulaResultNull() {}
};
