import React, { useState, useEffect } from 'react';
import { GridData, SpreadsheetCell, FormulaResult } from '../types';
import { Plus, BarChart3, HelpCircle, FileText, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';
import { 
  statMean, 
  statMedian, 
  statMode, 
  statMin, 
  statMax, 
  statRange, 
  statCount, 
  statSum, 
  statisticsSummary 
} from '../statsEngineSim';

interface SpreadsheetGridProps {
  gridData: GridData;
  setGridData: React.Dispatch<React.SetStateAction<GridData>>;
  activeFormula: string;
  setActiveFormula: (f: string) => void;
  formulaResult: FormulaResult | null;
  setFormulaResult: (res: FormulaResult | null) => void;
}

const PRESETS = {
  fibonacci: {
    name: 'Fibonacci Sequence',
    desc: 'Loads standard integers [1, 1, 2, 3, 5, 8, 13, 21, 34, 55] into Col A',
    cells: {
      A1: '1', A2: '1', A3: '2', A4: '3', A5: '5',
      A6: '8', A7: '13', A8: '21', A9: '34', A10: '55'
    } as Record<string, string>
  },
  bimodal: {
    name: 'Bimodal Clusters',
    desc: 'Loads standard duplicate mode set c(4,4,5,6,6) and clusters in Col B',
    cells: {
      B1: '4', B2: '4', B3: '5', B4: '6', B5: '6',
      B6: '12', B7: '12', B8: '15', B9: '18', B10: '18'
    } as Record<string, string>
  },
  dirty: {
    name: 'Dirty Sheet (NA / logicals)',
    desc: 'Loads NA, logicals (TRUE/FALSE), blank strings, and text characters to test validation rules',
    cells: {
      C1: '10.5', C2: 'NA', C3: '30.2', C4: 'TRUE', C5: 'NaN',
      C6: 'apple', C7: '40.0', C8: '', C9: 'FALSE', C10: 'Inf'
    } as Record<string, string>
  },
  positiveNegative: {
    name: 'Real Range (Dispersion)',
    desc: 'Incorporate decimal and negative bounds (-15.4 to 30.6) inside Col D',
    cells: {
      D1: '-15.4', D2: '30.6', D3: '-2.1', D4: '0', D5: '12.4',
      D6: '-5.0', D7: '18.1', D8: '-10.2', D9: '25.0', D10: '3.3'
    } as Record<string, string>
  }
};

export const SpreadsheetGrid: React.FC<SpreadsheetGridProps> = ({
  gridData,
  setGridData,
  activeFormula,
  setActiveFormula,
  formulaResult,
  setFormulaResult
}) => {
  const [editingCell, setEditingCell] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState<string>('');
  const [selectionStart, setSelectionStart] = useState<string | null>(null);
  const [selectionEnd, setSelectionEnd] = useState<string | null>(null);

  const cols = ['A', 'B', 'C', 'D', 'E'];
  const rows = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  // Initialize sheet cells if empty
  useEffect(() => {
    if (Object.keys(gridData).length === 0) {
      const initial: GridData = {};
      cols.forEach(c => {
        rows.forEach(r => {
          const key = `${c}${r}`;
          // Default start data values
          let val = '';
          if (c === 'A' && r <= 5) val = String(r * 10); // A1:A5 -> 10,20,30,40,50
          if (c === 'B' && r <= 5) {
            // mode elements
            const mv = [4, 4, 5, 6, 6];
            val = String(mv[r - 1]);
          }
          initial[key] = {
            row: r,
            col: c,
            value: val,
            parsedValue: val !== '' ? Number(val) : null
          };
        });
      });
      setGridData(initial);
    }
  }, []);

  const handleCellClick = (key: string) => {
    setEditingCell(key);
    setEditingValue(gridData[key]?.value || '');
  };

  const handleCellBlur = (key: string) => {
    setEditingCell(null);
    const parsed = editingValue.trim() === '' ? null : Number(editingValue);
    setGridData(prev => ({
      ...prev,
      [key]: {
        ...prev[key],
        value: editingValue,
        parsedValue: isNaN(parsed as number) ? null : parsed
      }
    }));
  };

  const handleCellKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, key: string) => {
    if (e.key === 'Enter') {
      handleCellBlur(key);
    } else if (e.key === 'Escape') {
      setEditingCell(null);
    }
  };

  const applyPreset = (presetKey: keyof typeof PRESETS) => {
    const preset = PRESETS[presetKey];
    setGridData(prev => {
      const next = { ...prev };
      Object.keys(preset.cells).forEach(cellKey => {
        if (next[cellKey]) {
          const rawVal = preset.cells[cellKey];
          const num = Number(rawVal);
          next[cellKey] = {
            ...next[cellKey],
            value: rawVal,
            parsedValue: isNaN(num) || rawVal.trim() === '' ? null : num
          };
        }
      });
      return next;
    });
    // Set a quick default formula matching the preset
    const colName = presetKey === 'fibonacci' ? 'A' : presetKey === 'bimodal' ? 'B' : presetKey === 'dirty' ? 'C' : 'D';
    if (presetKey === 'dirty') {
      setActiveFormula(`=MEAN(${colName}1:${colName}10)`);
    } else if (presetKey === 'bimodal') {
      setActiveFormula(`=MODE(${colName}1:${colName}5)`);
    } else if (presetKey === 'positiveNegative') {
      setActiveFormula(`=RANGE(${colName}1:${colName}10)`);
    } else {
      setActiveFormula(`=SUMMARY(${colName}1:${colName}10)`);
    }
    setFormulaResult(null);
  };

  const clearGrid = () => {
    setGridData(prev => {
      const next = { ...prev };
      Object.keys(next).forEach(key => {
        next[key] = {
          ...next[key],
          value: '',
          parsedValue: null
        };
      });
      return next;
    });
    setFormulaResult(null);
  };

  // Parses coordinates e.g., "A1:B5" to array of cell values
  const getCellRangeValues = (rangeStr: string): { values: any[]; keys: string[] } => {
    const parts = rangeStr.toUpperCase().trim().split(':');
    if (parts.length === 0 || parts[0] === '') {
      return { values: [], keys: [] };
    }

    if (parts.length === 1) {
      // Single cell
      const cellKey = parts[0];
      const cell = gridData[cellKey];
      return { 
        values: [cell ? (cell.value === 'TRUE' ? true : cell.value === 'FALSE' ? false : cell.value) : null], 
        keys: [cellKey] 
      };
    }

    const start = parts[0];
    const end = parts[1];

    const startCol = start.charCodeAt(0);
    const startRow = parseInt(start.substring(1), 10);
    const endCol = end.charCodeAt(0);
    const endRow = parseInt(end.substring(1), 10);

    if (isNaN(startRow) || isNaN(endRow)) {
      throw new Error("Invalid spreadsheet row index inside cell range.");
    }

    const colMin = Math.min(startCol, endCol);
    const colMax = Math.max(startCol, endCol);
    const rowMin = Math.min(startRow, endRow);
    const rowMax = Math.max(startRow, endRow);

    const gatheredValues: any[] = [];
    const gatheredKeys: string[] = [];

    for (let c = colMin; c <= colMax; c++) {
      const colChar = String.fromCharCode(c);
      for (let r = rowMin; r <= rowMax; r++) {
        const key = `${colChar}${r}`;
        const cell = gridData[key];
        if (cell) {
          // Pass logic truthy-falsy strings as logical representations to mirror R's logic check
          if (cell.value === 'TRUE') {
            gatheredValues.push(true);
          } else if (cell.value === 'FALSE') {
            gatheredValues.push(false);
          } else if (cell.value.trim() === '') {
            gatheredValues.push(null);
          } else {
            gatheredValues.push(cell.value);
          }
          gatheredKeys.push(key);
        }
      }
    }

    return { values: gatheredValues, keys: gatheredKeys };
  };

  const handleEvaluate = () => {
    const query = activeFormula.trim();
    if (!query.startsWith('=')) {
      setFormulaResult({
        formula: query,
        success: false,
        value: null,
        errorMsg: "Spreadsheet formulas must start with '=' (e.g. =MEAN(A1:A5))"
      });
      return;
    }

    const formulaMatch = query.match(/^=([A-Z]{3,10})\(([^)]+)\)$/i);
    if (!formulaMatch) {
      setFormulaResult({
        formula: query,
        success: false,
        value: null,
        errorMsg: "Invalid spreadsheet formula syntax. Supported style: =MEAN(A1:A10) or =SUMMARY(A1:E10)"
      });
      return;
    }

    const funcName = formulaMatch[1].toUpperCase();
    const rangeParam = formulaMatch[2];

    try {
      const { values: rawData, keys: sourceKeys } = getCellRangeValues(rangeParam);
      
      let evaluatedResult: number | number[] | null = null;
      let summaryObj: Record<string, number | number[] | null> | undefined = undefined;

      // Handle optional argument configuration (emulating na.rm parameter logic)
      // Spreadsheet wrappers of our R module internally default na.rm = TRUE.
      // We will follow the standard wrapper specifications.
      switch (funcName) {
        case 'MEAN':
          evaluatedResult = statMean(rawData, true);
          break;
        case 'MEDIAN':
          evaluatedResult = statMedian(rawData, true);
          break;
        case 'MODE':
          evaluatedResult = statMode(rawData, true);
          break;
        case 'MINIMUM':
          evaluatedResult = statMin(rawData, true);
          break;
        case 'MAXIMUM':
          evaluatedResult = statMax(rawData, true);
          break;
        case 'RANGE':
          evaluatedResult = statRange(rawData, true);
          break;
        case 'SUM':
          evaluatedResult = statSum(rawData, true);
          break;
        case 'COUNT':
          evaluatedResult = statCount(rawData, true);
          break;
        case 'SUMMARY':
          const s = statisticsSummary(rawData, true);
          summaryObj = {
            count: s.count,
            sum: s.sum,
            mean: s.mean,
            median: s.median,
            mode: s.mode,
            minimum: s.minimum,
            maximum: s.maximum,
            range: s.range
          };
          break;
        default:
          throw new Error(`Unsupported formula function '${funcName}'. Available: MEAN, MEDIAN, MODE, MINIMUM, MAXIMUM, RANGE, SUM, COUNT, SUMMARY.`);
      }

      setFormulaResult({
        formula: query,
        success: true,
        value: evaluatedResult,
        sourceCells: sourceKeys,
        summaryObj: summaryObj
      });
    } catch (e: any) {
      setFormulaResult({
        formula: query,
        success: false,
        value: null,
        errorMsg: e.message || 'Validation error calculating descriptive parameters.'
      });
    }
  };

  const selectFormula = (fn: string) => {
    setActiveFormula(`=${fn}(A1:A5)`);
    setFormulaResult(null);
  };

  return (
    <div className="bg-white border border-[#141414] p-5 flex flex-col h-full rounded-none" id="grid_calculator">
      {/* Header and description tags */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 mb-4 border-b border-[#141414]/15 gap-3">
        <div>
          <h2 className="text-md font-bold text-[#141414] tracking-tight flex items-center gap-2 font-serif italic">
            <BarChart3 className="w-5 h-5 text-[#141414]" />
            Spreadsheet Range Playground
          </h2>
          <p className="text-[11px] text-[#141414]/65 mt-0.5 font-mono">
            Demonstrates <strong>spreadsheet_wrappers.R</strong> formula computations on real-time cell evaluations.
          </p>
        </div>
        
        {/* Presets and clean layout buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/50 mr-1">Load Preset:</span>
          <button 
            onClick={() => applyPreset('fibonacci')}
            className="px-2 py-1 text-[11px] font-mono font-bold bg-white hover:bg-[#141414]/5 border border-[#141414] text-[#141414] rounded-none transition duration-150 cursor-pointer"
            title="Fibonacci digits in A1:A10"
          >
            A: Fibonacci
          </button>
          <button 
            onClick={() => applyPreset('bimodal')}
            className="px-2 py-1 text-[11px] font-mono font-bold bg-white hover:bg-[#141414]/5 border border-[#141414] text-[#141414] rounded-none transition duration-150 cursor-pointer"
            title="Bimodal series in B1:B10"
          >
            B: Bimodal
          </button>
          <button 
            onClick={() => applyPreset('dirty')}
            className="px-2 py-1 text-[11px] font-mono font-bold bg-white hover:bg-[#141414]/5 border border-[#141414] text-[#141414] rounded-none transition duration-150 cursor-pointer"
            title="Dirty entries (NA, NaNs) in C1:C10"
          >
            C: Dirty Rules
          </button>
          <button 
            onClick={() => applyPreset('positiveNegative')}
            className="px-2 py-1 text-[11px] font-mono font-bold bg-white hover:bg-[#141414]/5 border border-[#141414] text-[#141414] rounded-none transition duration-150 cursor-pointer"
            title="Positives and Negatives in D1:D10"
          >
            D: Range Min/Max
          </button>
          <button 
            onClick={clearGrid}
            className="px-2.5 py-1 text-[11px] font-mono font-bold text-[#141414] bg-white hover:bg-[#141414] hover:text-white border border-[#141414] rounded-none transition duration-150 cursor-pointer"
            title="Clear worksheet"
          >
            Clear All
          </button>
        </div>
      </div>

      {/* Formula inputs and trigger controls */}
      <div className="bg-[#f8f8f7] p-3.5 mb-4 border border-[#141414] flex flex-col md:flex-row items-center gap-3 rounded-none">
        <div className="font-mono text-xs font-semibold text-[#141414]/50 select-none hidden md:block">
          fx |
        </div>
        <div className="relative flex-1 w-full">
          <input 
            type="text" 
            value={activeFormula}
            onChange={(e) => setActiveFormula(e.target.value)}
            placeholder="Type standard formulas e.g., =MEAN(A1:A5) or =SUMMARY(B1:B10)"
            className="w-full bg-white border border-[#141414] px-3 py-1.5 text-xs text-[#141414] font-mono focus:outline-none focus:bg-[#f8f8f7] rounded-none"
            onKeyDown={(e) => e.key === 'Enter' && handleEvaluate()}
          />
        </div>
        <button 
          onClick={handleEvaluate}
          className="w-full md:w-auto px-6 py-1.5 text-xs font-serif font-bold italic text-white bg-[#141414] hover:bg-neutral-800 rounded-none transition duration-150 cursor-pointer flex items-center justify-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5" />
          Evaluate Formula
        </button>
      </div>

      {/* Helper Formulas panel */}
      <div className="mb-4 flex flex-wrap gap-1.5 items-center">
        <span className="text-[10px] font-mono uppercase tracking-widest text-[#141414]/50 mr-2">Quick Formulas:</span>
        {['MEAN', 'MEDIAN', 'MODE', 'MINIMUM', 'MAXIMUM', 'RANGE', 'SUMMARY'].map(fn => (
          <button
            key={fn}
            onClick={() => selectFormula(fn)}
            className="font-mono text-[10px] uppercase font-bold tracking-widest text-[#141414] hover:text-white bg-[#141414]/5 hover:bg-[#141414] border border-[#141414]/30 px-2 py-1 rounded-none transition duration-150 cursor-pointer"
          >
            {fn}
          </button>
        ))}
      </div>

      {/* Grid workspace table */}
      <div className="flex-1 overflow-x-auto min-h-[300px] border border-[#141414] bg-white rounded-none">
        <table className="w-full border-collapse text-left text-xs font-mono table-fixed min-w-[500px]">
          <thead>
            <tr className="bg-[#f8f8f7] divide-x divide-[#141414] border-b border-[#141414] text-[#141414]">
              <th className="w-12 text-center py-2 font-mono font-bold select-none text-[10px] bg-[#f8f8f7]">#</th>
              {cols.map(c => (
                <th key={c} className="text-center py-2 font-mono font-bold select-none tracking-wide text-[#141414]">
                  {c}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[#141414] border-b border-[#141414]">
            {rows.map(r => (
              <tr key={r} className="divide-x divide-[#141414] hover:bg-[#141414]/5 bg-white">
                <td className="text-center py-1.5 bg-[#f8f8f7] text-[10.5px] font-mono text-[#141414]/70 select-none font-bold border-r border-[#141414]">
                  {r}
                </td>
                {cols.map(c => {
                  const key = `${c}${r}`;
                  const cell = gridData[key];
                  const isEditing = editingCell === key;
                  const isHighlighted = formulaResult?.sourceCells?.includes(key);

                  return (
                    <td 
                      key={c} 
                      onClick={() => handleCellClick(key)}
                      className={`p-0 cursor-text transition-colors duration-150 relative ${
                        isHighlighted ? 'bg-blue-50 border-2 border-blue-800' : ''
                      }`}
                    >
                      {isEditing ? (
                        <input
                           type="text"
                           value={editingValue}
                           onChange={(e) => setEditingValue(e.target.value)}
                           onBlur={() => handleCellBlur(key)}
                           onKeyDown={(e) => handleCellKeyDown(e, key)}
                           className="w-full h-full px-2 py-1 outline-none text-xs bg-white border border-[#141414] font-mono text-[#141414] rounded-none focus:ring-1 focus:ring-[#141414]"
                           autoFocus
                        />
                      ) : (
                        <div className="px-2.5 py-1.5 truncate font-mono text-xs text-[#141414] flex justify-between items-center group min-h-[30px]">
                          <span>{cell?.value}</span>
                          {/* Indicator for numeric parses under the hood */}
                          {cell?.parsedValue !== null && cell?.value !== '' && (
                            <span className="text-[8px] text-[#141414]/40 font-mono tracking-tight select-none">
                              num
                            </span>
                          )}
                          {cell?.value === 'NA' || cell?.value === 'NaN' || cell?.value === 'Inf' ? (
                            <span className="text-[8.5px] text-red-600 bg-red-50 border border-red-500/20 font-bold uppercase px-1 rounded-none select-none">
                              R-NA
                            </span>
                          ) : null}
                          {cell?.value === 'TRUE' || cell?.value === 'FALSE' ? (
                            <span className="text-[8.5px] text-emerald-700 bg-emerald-50 border border-green-600/20 font-bold uppercase px-1 rounded-none select-none">
                              BOOL
                            </span>
                          ) : null}
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Formula Output Terminal */}
      <div className="mt-4 bg-[#141414] text-white p-5 border border-[#141414] rounded-none">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-white/20 text-white/50 text-xs font-mono">
          <span>Formula Engine Terminal</span>
          <span className="text-[10px] tracking-wider text-white/45">Spreadsheet-to-R Coercion Module</span>
        </div>

        {formulaResult ? (
          <div>
            {formulaResult.success ? (
              <div className="space-y-3 font-mono text-xs">
                <div className="flex items-center gap-1.5 text-green-400">
                  <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
                  <span>Calculation Successful: <code>{formulaResult.formula}</code></span>
                </div>

                {formulaResult.summaryObj ? (
                  <div className="grid grid-cols-2 md:grid-cols-4 bg-white text-[#141414] p-4 border border-[#141414] gap-y-2.5 gap-x-4 rounded-none">
                    {Object.entries(formulaResult.summaryObj).map(([key, val]) => (
                      <div key={key} className="flex flex-col border-b border-[#141414]/10 pb-1">
                        <span className="text-[#141414]/50 text-[9px] uppercase font-mono font-bold tracking-widest">{key}</span>
                        <span className="text-[#141414] text-xs font-bold mt-0.5">
                          {Array.isArray(val) ? (
                            val.length === 0 ? 'numeric(0)' : `[${val.join(', ')}]`
                          ) : typeof val === 'number' ? (
                            val % 1 === 0 ? val : val.toFixed(4)
                          ) : String(val)}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-baseline gap-2.5 bg-white text-[#141414] p-4 border border-[#141414] rounded-none">
                    <span className="text-[#141414]/50 uppercase tracking-widest text-[9px] font-bold">Evaluated Value:</span>
                    <span className="text-blue-800 font-bold text-sm font-mono">
                      {Array.isArray(formulaResult.value) ? (
                        formulaResult.value.length === 0 ? 'numeric(0)' : `c(${formulaResult.value.join(', ')})`
                      ) : typeof formulaResult.value === 'number' ? (
                        formulaResult.value % 1 === 0 ? formulaResult.value : formulaResult.value.toFixed(4)
                      ) : formulaResult.value === null ? (
                        'NULL'
                      ) : String(formulaResult.value)}
                    </span>
                  </div>
                )}

                <div className="text-[10px] text-white/60">
                  <span>Source cells matched: </span>
                  <span className="text-white">[{formulaResult.sourceCells?.join(', ')}]</span> | Valid Observations: <span className="text-blue-400 font-bold">{formulaResult.sourceCells?.filter(k => gridData[k]?.value.trim() !== '' && gridData[k]?.value !== 'NA' && gridData[k]?.value !== 'NaN').length}</span>
                </div>
              </div>
            ) : (
              <div className="font-mono text-xs space-y-2.5">
                <div className="flex items-center gap-1.5 text-red-400">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span>Evaluation Error:</span>
                </div>
                <div className="p-3 bg-red-50 text-red-700 rounded-none border border-red-500 text-[11px]">
                  {formulaResult.errorMsg}
                </div>
                <p className="text-[10px] text-white/50 leading-normal">
                  R statistics core raises exceptions for non-numeric arrays, mismatched sizing or empty ranges. Correct cell values above or adjust the bounds.
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-6 text-white/40 font-mono text-[11px]">
            Enter a formula above or click cell preset parameters to calculate statistics descriptive structures...
          </div>
        )}
      </div>
    </div>
  );
};
