#!/usr/bin/env python3
"""
Document → Spreadsheet Engine
══════════════════════════════════════════════════════════════════════════════
Production-quality Python engine that ingests technical documents (PDF, DOCX,
TXT, or raw text) and converts them into structured, spreadsheet-ready pandas
DataFrames with CSV / XLSX export.

Architecture:
  1. DocumentLoader      – file ingestion (PDF, DOCX, TXT, raw)
  2. TextNormaliser      – whitespace cleaning, encoding fixes, header removal
  3. ChunkingEngine      – semantic text segmentation with section tracking
  4. SchemaInference     – automatic schema discovery (+ LLM hook stub)
  5. ExtractionEngine    – multi-strategy structured data extraction
  6. NormalisationLayer  – unit standardisation, type coercion, null handling
  7. TableBuilder        – pandas DataFrame construction & deduplication
  8. ExportLayer         – CSV / XLSX output
  9. DocumentToSpreadsheetEngine – end-to-end orchestrator
"""

from __future__ import annotations

import csv
import hashlib
import json
import logging
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

import pandas as pd

# ─── Optional Backend Imports ─────────────────────────────────────────────────

PDF_BACKEND: Optional[str] = None
try:
    import pdfplumber          # type: ignore
    PDF_BACKEND = "pdfplumber"
except ImportError:
    try:
        import fitz            # type: ignore  # PyMuPDF
        PDF_BACKEND = "pymupdf"
    except ImportError:
        pass

DOCX_AVAILABLE = False
try:
    from docx import Document as _DocxDocument   # type: ignore
    DOCX_AVAILABLE = True
except ImportError:
    pass

XLSX_AVAILABLE = False
try:
    import openpyxl            # type: ignore  # noqa: F401
    XLSX_AVAILABLE = True
except ImportError:
    pass

# ─── Logger ───────────────────────────────────────────────────────────────────

def _build_logger(name: str = "doc2sheet", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        _h = logging.StreamHandler(sys.stdout)
        _h.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)-8s] %(name)s → %(message)s",
            datefmt="%H:%M:%S",
        ))
        logger.addHandler(_h)
    logger.setLevel(level)
    return logger

log = _build_logger()

# ─── Data Structures ──────────────────────────────────────────────────────────

@dataclass
class DocumentChunk:
    """A semantically meaningful segment of a document."""
    index: int
    text: str
    section: str = ""
    source: str = ""
    page: Optional[int] = None
    confidence: float = 1.0


@dataclass
class SchemaField:
    """A single inferred schema column."""
    name: str
    dtype: str = "text"          # text | numeric | date | boolean | unit
    description: str = ""
    required: bool = False
    unit: str = ""


@dataclass
class ExtractionRecord:
    """A single extracted row mapped to schema fields."""
    data: dict[str, Any] = field(default_factory=dict)
    source_chunk: int = -1
    confidence: float = 1.0


@dataclass
class ExtractionResult:
    """Full extraction output for a document."""
    schema: list[SchemaField]
    records: list[ExtractionRecord]
    warnings: list[str] = field(default_factory=list)

# ─── 1. Document Loader ───────────────────────────────────────────────────────

class DocumentLoader:
    """
    Loads documents from PDF, DOCX, TXT files or raw text strings.

    Returns (raw_text, metadata_dict).
    """

    SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".txt", ".md", ".rst", ".csv"}

    def load(self, source: str) -> tuple[str, dict[str, Any]]:
        if not source:
            raise ValueError("Source must be a non-empty string (file path or raw text).")

        path = Path(source)
        if path.exists() and path.is_file():
            suffix = path.suffix.lower()
            log.info("Loading file: %s  [%s]", path.name, suffix or "no-ext")
            if suffix == ".pdf":
                return self._load_pdf(path)
            if suffix == ".docx":
                return self._load_docx(path)
            if suffix in (".txt", ".md", ".rst", ".csv"):
                return self._load_txt(path)
            # Unknown extension – try as text
            log.warning("Unknown extension '%s'; attempting plain-text load.", suffix)
            return self._load_txt(path)

        # No file found → treat as raw text
        log.info("Source is raw text (%d chars).", len(source))
        return source, {"source": "raw_text", "chars": len(source)}

    # ── PDF ──────────────────────────────────────────────────────────────────
    def _load_pdf(self, path: Path) -> tuple[str, dict[str, Any]]:
        if PDF_BACKEND is None:
            raise ImportError(
                "No PDF backend found. Install one:\n"
                "  pip install pdfplumber\n"
                "  pip install pymupdf"
            )
        pages: list[str] = []
        meta: dict[str, Any] = {"source": str(path), "backend": PDF_BACKEND, "pages": 0}

        if PDF_BACKEND == "pdfplumber":
            with pdfplumber.open(path) as pdf:
                meta["pages"] = len(pdf.pages)
                for i, page in enumerate(pdf.pages, 1):
                    text = page.extract_text() or ""
                    for tbl in (page.extract_tables() or []):
                        text += "\n" + self._table_rows_to_text(tbl)
                    if text.strip():
                        pages.append(f"[PAGE {i}]\n{text}")
        else:
            doc = fitz.open(str(path))
            meta["pages"] = len(doc)
            for i, page in enumerate(doc, 1):
                text = page.get_text("text")
                if text.strip():
                    pages.append(f"[PAGE {i}]\n{text}")
            doc.close()

        log.info("PDF: %d pages loaded.", meta["pages"])
        return "\n\n".join(pages), meta

    # ── DOCX ─────────────────────────────────────────────────────────────────
    def _load_docx(self, path: Path) -> tuple[str, dict[str, Any]]:
        if not DOCX_AVAILABLE:
            raise ImportError("python-docx not installed.  pip install python-docx")
        doc = _DocxDocument(str(path))
        parts: list[str] = []

        for para in doc.paragraphs:
            if not para.text.strip():
                continue
            style_name = para.style.name if para.style else ""
            prefix = "## " if "Heading" in style_name else ""
            parts.append(prefix + para.text.strip())

        for tbl in doc.tables:
            rows = [[cell.text.strip() for cell in row.cells] for row in tbl.rows]
            parts.append(self._table_rows_to_text(rows))

        meta = {
            "source": str(path),
            "paragraphs": len(doc.paragraphs),
            "tables": len(doc.tables),
        }
        log.info("DOCX: %d paragraphs, %d tables.", meta["paragraphs"], meta["tables"])
        return "\n".join(parts), meta

    # ── TXT ──────────────────────────────────────────────────────────────────
    def _load_txt(self, path: Path) -> tuple[str, dict[str, Any]]:
        for enc in ("utf-8", "utf-8-sig", "latin-1"):
            try:
                text = path.read_text(encoding=enc)
                meta = {"source": str(path), "encoding": enc, "chars": len(text)}
                log.info("TXT: %d chars loaded (enc=%s).", len(text), enc)
                return text, meta
            except UnicodeDecodeError:
                continue
        raise ValueError(f"Cannot decode '{path}' with any supported encoding.")

    # ── Helpers ──────────────────────────────────────────────────────────────
    @staticmethod
    def _table_rows_to_text(rows: list) -> str:
        if not rows:
            return ""
        out: list[str] = []
        for row in rows:
            if row is None:
                continue
            cells = [str(c).strip() if c is not None else "" for c in row]
            out.append(" | ".join(cells))
        return "\n".join(out)

# ─── 2. Text Normaliser ───────────────────────────────────────────────────────

class TextNormaliser:
    """
    Cleans raw extracted text:
      - Unicode normalisation (NFKC)
      - Smart-quote / dash / bullet-glyph substitution
      - Noise-line removal (page numbers, footers, dividers)
      - Broken-line repair (PDF line-wrap artefacts)
      - Whitespace collapse
    """

    _NOISE_PATTERNS: list[str] = [
        r"^Page\s+\d+\s+of\s+\d+$",
        r"^\d+\s+of\s+\d+$",
        r"^©\s*\d{4}.*$",
        r"^Confidential.*$",
        r"^Proprietary.*$",
        r"^\s*\d+\s*$",
        r"^-{5,}$",
        r"^={5,}$",
        r"^\*{5,}$",
        r"^\[PAGE \d+\]$",
        r"^_{5,}$",
    ]
    _NOISE_RES = [re.compile(p, re.IGNORECASE) for p in _NOISE_PATTERNS]

    _GLYPH_MAP: dict[str, str] = {
        "\u2018": "'", "\u2019": "'",
        "\u201c": '"', "\u201d": '"',
        "\u2013": "-", "\u2014": "--",
        "\u00a0": " ",
        "\uf0b7": "-",   # Word bullet artefact
        "\u00b7": "-",
        "\u2022": "-",   # •
        "\u25ba": "-",   # ►
        "\u25cf": "-",   # ●
    }

    def normalise(self, raw: str) -> str:
        text = unicodedata.normalize("NFKC", raw)
        text = self._fix_glyphs(text)
        text = self._remove_noise_lines(text)
        text = self._repair_broken_lines(text)
        text = self._collapse_whitespace(text)
        log.debug("Normaliser: %d → %d chars", len(raw), len(text))
        return text

    def _fix_glyphs(self, text: str) -> str:
        for src, dst in self._GLYPH_MAP.items():
            text = text.replace(src, dst)
        return text

    def _remove_noise_lines(self, text: str) -> str:
        cleaned: list[str] = []
        for line in text.splitlines():
            stripped = line.strip()
            if not any(rx.fullmatch(stripped) for rx in self._NOISE_RES):
                cleaned.append(line)
        return "\n".join(cleaned)

    def _repair_broken_lines(self, text: str) -> str:
        # Join lines that end without sentence-terminating punctuation when the
        # next line starts with a lowercase letter (common PDF extraction artefact).
        return re.sub(r"([a-z,;])(\n)([a-z])", r"\1 \3", text)

    def _collapse_whitespace(self, text: str) -> str:
        text = re.sub(r"\n{3,}", "\n\n", text)
        lines = [l.rstrip() for l in text.splitlines()]
        return "\n".join(lines).strip()

# ─── 3. Chunking Engine ───────────────────────────────────────────────────────

class ChunkingEngine:
    """
    Splits normalised text into semantically meaningful DocumentChunks.

    Strategies applied (in order):
      1. Section header detection → resets section context
      2. Paragraph splitting on blank lines
      3. Word-budget merging to avoid micro-chunks
    """

    _SECTION_PATTERNS: list[re.Pattern] = [
        re.compile(r"^#{1,4}\s+(.+)$"),                   # ## Markdown header
        re.compile(r"^\d+(?:\.\d+)*\s+([A-Z].{2,})$"),   # 1.2 Numbered section
        re.compile(r"^([A-Z][A-Z0-9 ]{4,}):?\s*$"),      # ALL-CAPS header
    ]

    def __init__(self, max_chunk_words: int = 300, overlap_lines: int = 1) -> None:
        self.max_chunk_words = max_chunk_words
        self.overlap_lines = overlap_lines

    def chunk(self, text: str, source: str = "") -> list[DocumentChunk]:
        paras = self._split_paragraphs(text)
        chunks = self._merge_paragraphs(paras, source)
        log.info("Chunking: %d paragraphs → %d chunks", len(paras), len(chunks))
        return chunks

    def _split_paragraphs(self, text: str) -> list[dict[str, str]]:
        paras: list[dict[str, str]] = []
        current_section = "Preamble"
        buffer: list[str] = []

        for line in text.splitlines():
            stripped = line.strip()
            matched_section: Optional[str] = None

            for rx in self._SECTION_PATTERNS:
                m = rx.fullmatch(stripped)
                if m:
                    matched_section = (m.group(1).strip()
                                       if m.lastindex and m.group(1)
                                       else stripped)
                    break

            if matched_section is not None:
                if buffer:
                    paras.append({"text": "\n".join(buffer).strip(),
                                  "section": current_section})
                    buffer = []
                current_section = matched_section
                continue

            if stripped == "":
                if buffer:
                    paras.append({"text": "\n".join(buffer).strip(),
                                  "section": current_section})
                    buffer = []
            else:
                buffer.append(line)

        if buffer:
            paras.append({"text": "\n".join(buffer).strip(),
                          "section": current_section})

        return [p for p in paras if p["text"]]

    def _merge_paragraphs(
        self, paras: list[dict[str, str]], source: str
    ) -> list[DocumentChunk]:
        chunks: list[DocumentChunk] = []
        buf_lines: list[str] = []
        buf_section = ""
        buf_words = 0
        idx = 0

        for para in paras:
            words = len(para["text"].split())
            # Flush if budget exceeded
            if buf_words + words > self.max_chunk_words and buf_lines:
                chunks.append(DocumentChunk(
                    index=idx,
                    text="\n".join(buf_lines),
                    section=buf_section,
                    source=source,
                ))
                idx += 1
                # Carry-over overlap
                buf_lines = buf_lines[-self.overlap_lines:] if self.overlap_lines else []
                buf_words = sum(len(l.split()) for l in buf_lines)

            buf_lines.append(para["text"])
            buf_section = para["section"]
            buf_words += words

        if buf_lines:
            chunks.append(DocumentChunk(
                index=idx,
                text="\n".join(buf_lines),
                section=buf_section,
                source=source,
            ))
        return chunks

# ─── 4. Schema Inference Module ───────────────────────────────────────────────

class SchemaInference:
    """
    Infers a tabular schema from document chunks.

    Heuristic pipeline:
      - Scan for key:value patterns across all chunks
      - Detect pipe-separated table headers
      - Count key frequencies to determine required vs optional fields
      - Classify dtype from sampled values
      - Provide LLM hook (stub) for advanced inference
    """

    _KV_RE = re.compile(
        r"^([A-Za-z][A-Za-z0-9 _/().-]{1,60})\s*[:\-=]\s*(.{1,500})$",
        re.MULTILINE,
    )

    _DTYPE_PATTERNS: dict[str, list[str]] = {
        "date": [
            r"\b\d{4}[-/]\d{2}[-/]\d{2}\b",
            r"\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{4}\b",
        ],
        "numeric": [r"^\s*[-+]?\d+(?:[.,]\d+)?\s*$"],
        "boolean": [r"^(?:yes|no|true|false|enabled|disabled|on|off|pass(?:ing)?|fail(?:ing)?)$"],
        "unit": [
            r"[-+]?\d+(?:\.\d+)?\s*(?:ms|us|ns|s|GB|MB|KB|TB|%|kg|g|m|km|Hz|MHz|GHz|rpm|°C|°F|W|V|A)"
        ],
    }

    _CANONICAL: dict[str, str] = {
        "name": "name", "title": "name", "label": "name",
        "id": "id", "identifier": "id", "uuid": "id",
        "description": "description", "desc": "description", "summary": "description",
        "version": "version", "ver": "version", "release": "version",
        "date": "date", "timestamp": "date", "created": "date",
        "updated": "date", "modified": "date",
        "type": "type", "kind": "type",
        "category": "category", "class": "category",
        "status": "status", "state": "status",
        "value": "value", "result": "value", "output": "value", "score": "value",
        "unit": "unit",
        "count": "count", "total": "total", "quantity": "count",
        "percentage": "percentage", "percent": "percentage",
        "error": "error", "error_rate": "error_rate",
        "notes": "notes", "note": "notes", "comment": "notes", "remarks": "notes",
        "author": "author", "owner": "owner",
        "source": "source", "origin": "source",
        "endpoint": "endpoint", "url": "endpoint", "path": "endpoint",
        "method": "method", "verb": "method",
        "latency": "latency", "response_time": "latency",
        "throughput": "throughput", "rps": "throughput", "qps": "throughput",
        "size": "size", "payload": "payload_size", "payload_size": "payload_size",
        "cpu": "cpu", "ram": "ram", "memory": "ram",
        "storage": "storage", "disk": "storage",
        "os": "os", "operating_system": "os",
        "kernel": "kernel",
        "network": "network",
    }

    def infer(self, chunks: list[DocumentChunk]) -> list[SchemaField]:
        log.info("Schema inference: scanning %d chunks ...", len(chunks))

        key_freq: Counter[str] = Counter()
        key_samples: dict[str, list[str]] = defaultdict(list)

        for chunk in chunks:
            for m in self._KV_RE.finditer(chunk.text):
                norm = self._norm_key(m.group(1))
                key_freq[norm] += 1
                if len(key_samples[norm]) < 10:
                    key_samples[norm].append(m.group(2).strip())

        # Bonus weight for pipe-table headers (structural, reliable)
        for header in self._detect_table_headers(chunks):
            norm = self._norm_key(header)
            key_freq[norm] += 3

        if not key_freq:
            log.warning("No structured keys detected; using generic schema fallback.")
            return self._generic_schema()

        schema: list[SchemaField] = []
        seen: set[str] = set()

        for key, freq in key_freq.most_common():
            if key in seen or not key:
                continue
            seen.add(key)
            samples = key_samples.get(key, [])
            dtype = self._infer_dtype(samples)
            unit = self._infer_unit(samples)
            schema.append(SchemaField(
                name=key,
                dtype=dtype,
                unit=unit,
                description=f"Extracted field  ({freq} occurrence{'s' if freq>1 else ''})",
                required=freq >= 2,
            ))

        log.info("Schema: %d fields inferred.", len(schema))
        return schema

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _norm_key(self, raw: str) -> str:
        key = raw.lower().strip()
        key = re.sub(r"[\s\-/]+", "_", key)
        key = re.sub(r"[^a-z0-9_]", "", key)
        key = key.strip("_")
        return self._CANONICAL.get(key, key)

    def _detect_table_headers(self, chunks: list[DocumentChunk]) -> list[str]:
        headers: list[str] = []
        for chunk in chunks:
            for line in chunk.text.splitlines():
                parts = [c.strip() for c in line.split("|") if c.strip()]
                if len(parts) >= 2 and all(
                    p and not re.fullmatch(r"[-:\s]+", p) for p in parts
                ):
                    # Heuristic: most cells are label-like (not pure numbers)
                    label_count = sum(
                        1 for p in parts if not re.fullmatch(r"[\d.,\s]+", p)
                    )
                    if label_count >= len(parts) * 0.6:
                        headers.extend(parts)
                        break   # Only grab first table-header per chunk
        return headers

    def _infer_dtype(self, samples: list[str]) -> str:
        scores: Counter[str] = Counter()
        for val in samples:
            v = val.strip().lower()
            for dtype, patterns in self._DTYPE_PATTERNS.items():
                if any(re.search(p, v, re.IGNORECASE) for p in patterns):
                    scores[dtype] += 1
        return scores.most_common(1)[0][0] if scores else "text"

    def _infer_unit(self, samples: list[str]) -> str:
        rx = re.compile(
            r"[-+]?\d+(?:\.\d+)?\s*(ms|us|ns|s|GB|MB|KB|TB|%|kg|g|m|km|Hz|MHz|GHz|rpm|°C|°F|W|V|A)",
            re.IGNORECASE,
        )
        counter: Counter[str] = Counter()
        for val in samples:
            m = rx.search(val)
            if m:
                counter[m.group(1)] += 1
        return counter.most_common(1)[0][0] if counter else ""

    def _generic_schema(self) -> list[SchemaField]:
        return [
            SchemaField("id",      "text",  "Record identifier",    required=True),
            SchemaField("section", "text",  "Document section"),
            SchemaField("key",     "text",  "Field name",           required=True),
            SchemaField("value",   "text",  "Field value",          required=True),
            SchemaField("notes",   "text",  "Contextual notes"),
        ]

    def print_schema(self, schema: list[SchemaField]) -> None:
        width = 62
        print("\n" + "═" * width)
        print("  INFERRED SCHEMA")
        print("═" * width)
        for i, f in enumerate(schema, 1):
            badge  = "  *req*" if f.required else ""
            unit   = f"  [{f.unit}]" if f.unit else ""
            print(f"  {i:3}. {f.name:<28} {f.dtype:<10}{unit}{badge}")
            if f.description:
                print(f"       └─ {f.description}")
        print("═" * width)

    # ── LLM Hook Stub ────────────────────────────────────────────────────────

    def infer_with_llm(
        self,
        chunks: list[DocumentChunk],
        llm_callable: Optional[Callable[[str], str]] = None,
    ) -> list[SchemaField]:
        """
        LLM-assisted schema inference.

        Parameters
        ----------
        chunks : list[DocumentChunk]
            Document chunks produced by ChunkingEngine.
        llm_callable : Callable[[str], str], optional
            A function that accepts a prompt string and returns a JSON string
            of the form::

                [
                  {"name": "col_name", "dtype": "text|numeric|date|boolean|unit",
                   "description": "Human-readable description"},
                  ...
                ]

        If no callable is supplied, falls back to heuristic inference.

        Example
        -------
        >>> import openai
        >>> def my_llm(prompt):
        ...     r = openai.chat.completions.create(
        ...         model="gpt-4o",
        ...         messages=[{"role": "user", "content": prompt}],
        ...     )
        ...     return r.choices[0].message.content
        >>> schema = inferrer.infer_with_llm(chunks, llm_callable=my_llm)
        """
        if llm_callable is None:
            log.info("LLM hook: no callable provided; using heuristic inference.")
            return self.infer(chunks)

        sample = "\n\n".join(c.text[:300] for c in chunks[:6])
        prompt = (
            "You are a schema analyst. Given the document excerpt below, "
            "return ONLY a JSON array of column definitions. Each element must have: "
            '"name" (snake_case), "dtype" (text|numeric|date|boolean|unit), '
            '"description" (brief). No markdown, no preamble.\n\n'
            f"DOCUMENT EXCERPT:\n{sample}\n\nJSON:"
        )

        try:
            raw_response = llm_callable(prompt)
            clean = re.sub(r"```(?:json)?|```", "", raw_response).strip()
            parsed: list[dict] = json.loads(clean)
            schema = [
                SchemaField(
                    name=self._norm_key(f.get("name", "")),
                    dtype=f.get("dtype", "text"),
                    description=f.get("description", ""),
                )
                for f in parsed
                if isinstance(f, dict) and f.get("name")
            ]
            log.info("LLM schema: %d fields", len(schema))
            return schema if schema else self.infer(chunks)
        except Exception as exc:
            log.error("LLM schema failed (%s); falling back to heuristics.", exc)
            return self.infer(chunks)

# ─── 5. Information Extraction Engine ─────────────────────────────────────────

class ExtractionEngine:
    """
    Multi-strategy structured data extractor.

    Strategies (evaluated per chunk):
      1. Key-Value pairs  — handles single-entity and multi-entity blocks
      2. Pipe-table rows  — handles Markdown / ASCII tables
      3. Bullet / list items — fallback for list-heavy content
      4. Generic KV pairs  — last-resort for generic schema
    """

    _KV_RE = re.compile(
        r"^([A-Za-z][A-Za-z0-9 _/().-]{1,60})\s*[:\-=]\s*(.{1,500})$",
        re.MULTILINE,
    )
    _BULLET_RE    = re.compile(r"^[\s]*[-•*►▪▸◦]\s+(.+)$", re.MULTILINE)
    _NUMBERED_RE  = re.compile(r"^[\s]*\d+[.)]\s+(.+)$", re.MULTILINE)
    _DIVIDER_RE   = re.compile(r"^[\s|:-]{3,}$")

    def extract(
        self,
        chunks: list[DocumentChunk],
        schema: list[SchemaField],
    ) -> list[ExtractionRecord]:
        col_names = [f.name for f in schema]
        schema_map = {f.name: f for f in schema}
        is_generic = col_names == ["id", "section", "key", "value", "notes"]

        records: list[ExtractionRecord] = []
        for chunk in chunks:
            chunk_recs = self._extract_chunk(chunk, col_names, schema_map, is_generic)
            records.extend(chunk_recs)

        log.info("Extraction: %d records from %d chunks", len(records), len(chunks))
        return records

    # ── Per-chunk dispatch ────────────────────────────────────────────────────

    def _extract_chunk(
        self,
        chunk: DocumentChunk,
        col_names: list[str],
        schema_map: dict[str, SchemaField],
        is_generic: bool,
    ) -> list[ExtractionRecord]:
        records: list[ExtractionRecord] = []

        # Strategy 1 – KV pairs (primary)
        kv = self._extract_kv(chunk, col_names)
        records.extend(kv)

        # Strategy 2 – pipe-table rows
        tbl = self._extract_table_rows(chunk, col_names)
        records.extend(tbl)

        # Strategy 3 – list items (only when strategies 1 & 2 found nothing)
        if not kv and not tbl:
            records.extend(self._extract_list_items(chunk, col_names))

        # Strategy 4 – generic pivot fallback
        if not records and is_generic:
            records.extend(self._generic_kv_extract(chunk))

        return records

    # ── Strategy 1: Key-Value ─────────────────────────────────────────────────

    def _extract_kv(
        self, chunk: DocumentChunk, col_names: list[str]
    ) -> list[ExtractionRecord]:
        pairs: list[tuple[str, str]] = []
        for m in self._KV_RE.finditer(chunk.text):
            raw_key = m.group(1).strip()
            raw_val = m.group(2).strip()
            norm    = self._map_key(raw_key, col_names)
            pairs.append((norm or self._slugify(raw_key), raw_val))

        if not pairs:
            return []

        # Detect repeated keys → multiple entities inside this chunk
        key_counts: Counter[str] = Counter(k for k, _ in pairs)
        repeating   = {k for k, n in key_counts.items() if n > 1}

        if not repeating:
            # Single entity
            return [ExtractionRecord(
                data={"section": chunk.section, **dict(pairs)},
                source_chunk=chunk.index,
                confidence=0.90,
            )]

        # Multi-entity: split on the first key that repeats
        primary = next(k for k, _ in pairs if k in repeating)
        records: list[ExtractionRecord] = []
        current: dict[str, Any] = {"section": chunk.section}

        for key, val in pairs:
            if key == primary and primary in current:
                # Flush current entity, start new one
                if any(v is not None for k, v in current.items() if k != "section"):
                    records.append(ExtractionRecord(
                        data=dict(current),
                        source_chunk=chunk.index,
                        confidence=0.85,
                    ))
                current = {"section": chunk.section, primary: val}
            else:
                current[key] = val

        if current:
            records.append(ExtractionRecord(
                data=dict(current),
                source_chunk=chunk.index,
                confidence=0.85,
            ))
        return records

    # ── Strategy 2: Pipe table rows ───────────────────────────────────────────

    def _extract_table_rows(
        self, chunk: DocumentChunk, col_names: list[str]
    ) -> list[ExtractionRecord]:
        pipe_lines = [
            l for l in chunk.text.splitlines()
            if "|" in l and len(l.split("|")) >= 3
        ]
        if len(pipe_lines) < 2:
            return []

        # First non-divider line = header
        header_line = next(
            (l for l in pipe_lines if not self._DIVIDER_RE.match(l.strip())), None
        )
        if header_line is None:
            return []

        raw_headers = [c.strip() for c in header_line.split("|") if c.strip()]
        header_map: dict[str, str] = {
            h: (self._map_key(h, col_names) or self._slugify(h))
            for h in raw_headers
        }

        records: list[ExtractionRecord] = []
        data_lines = [
            l for l in pipe_lines
            if l.strip() != header_line.strip()
            and not self._DIVIDER_RE.match(l.strip())
        ]

        for line in data_lines:
            cells = [c.strip() for c in line.split("|")]
            cells = [c for c in cells]            # keep empties for alignment
            # Re-filter leading/trailing empty from split artefacts
            if cells and cells[0] == "":
                cells = cells[1:]
            if cells and cells[-1] == "":
                cells = cells[:-1]
            if len(cells) != len(raw_headers):
                continue                          # column mismatch – skip row
            row: dict[str, Any] = {"section": chunk.section}
            for hdr, cell in zip(raw_headers, cells):
                row[header_map[hdr]] = cell.strip() if cell.strip() else None
            records.append(ExtractionRecord(
                data=row, source_chunk=chunk.index, confidence=0.88,
            ))
        return records

    # ── Strategy 3: Bullet / numbered lists ───────────────────────────────────

    def _extract_list_items(
        self, chunk: DocumentChunk, col_names: list[str]
    ) -> list[ExtractionRecord]:
        records: list[ExtractionRecord] = []
        items = (
            self._BULLET_RE.findall(chunk.text)
            + self._NUMBERED_RE.findall(chunk.text)
        )
        for item in items:
            item = item.strip()
            if not item:
                continue
            # Try "label: value" pattern inside the list item
            kv_m = re.match(r"^([^:\-]{2,50})[:\-]\s*(.+)$", item)
            if kv_m:
                key = self._map_key(kv_m.group(1).strip(), col_names)
                val = kv_m.group(2).strip()
                records.append(ExtractionRecord(
                    data={"section": chunk.section, (key or "value"): val},
                    source_chunk=chunk.index,
                    confidence=0.72,
                ))
            else:
                records.append(ExtractionRecord(
                    data={"section": chunk.section, "value": item},
                    source_chunk=chunk.index,
                    confidence=0.60,
                ))
        return records

    # ── Strategy 4: Generic pivot ─────────────────────────────────────────────

    def _generic_kv_extract(self, chunk: DocumentChunk) -> list[ExtractionRecord]:
        records: list[ExtractionRecord] = []
        for m in self._KV_RE.finditer(chunk.text):
            raw_key = m.group(1).strip()
            raw_val = m.group(2).strip()
            records.append(ExtractionRecord(
                data={
                    "id":      self._make_id(chunk.index, raw_key),
                    "section": chunk.section,
                    "key":     raw_key,
                    "value":   raw_val,
                    "notes":   "",
                },
                source_chunk=chunk.index,
                confidence=0.80,
            ))
        return records

    # ── Utilities ─────────────────────────────────────────────────────────────

    @staticmethod
    def _slugify(text: str) -> str:
        t = text.lower().strip()
        t = re.sub(r"[\s\-/]+", "_", t)
        t = re.sub(r"[^a-z0-9_]", "", t)
        return t.strip("_")

    def _map_key(self, raw: str, col_names: list[str]) -> Optional[str]:
        """Fuzzy-match raw key string to nearest schema column name."""
        slug = self._slugify(raw)
        if not slug:
            return None
        # 1. Exact
        if slug in col_names:
            return slug
        # 2. Substring (slug contained in col or vice-versa)
        for col in col_names:
            if slug in col or col in slug:
                return col
        # 3. Token overlap
        slug_toks = set(slug.split("_"))
        best_col, best = None, 0
        for col in col_names:
            col_toks = set(col.split("_"))
            score = len(slug_toks & col_toks)
            if score > best:
                best, best_col = score, col
        return best_col if best >= 1 else None

    @staticmethod
    def _make_id(chunk_idx: int, key: str) -> str:
        return hashlib.md5(f"{chunk_idx}:{key}".encode()).hexdigest()[:8]

# ─── 6. Normalisation Layer ───────────────────────────────────────────────────

class NormalisationLayer:
    """
    Post-extraction value standardisation:
      - Null / missing value detection
      - Numeric coercion (K/M/B suffix, currency symbols)
      - Boolean coercion
      - Unit string normalisation
      - String whitespace cleanup
    """

    _UNIT_ALIASES: dict[str, str] = {
        "milliseconds": "ms", "millisecond": "ms",
        "microseconds": "us", "microsecond": "us",
        "nanoseconds": "ns", "nanosecond": "ns",
        "seconds": "s", "second": "s",
        "kilobytes": "KB", "megabytes": "MB",
        "gigabytes": "GB", "terabytes": "TB",
        "kilohertz": "KHz", "megahertz": "MHz", "gigahertz": "GHz",
        "percent": "%", "percentage": "%",
        "kilograms": "kg", "kilogram": "kg", "grams": "g",
        "metres": "m", "meters": "m",
        "kilometres": "km", "kilometers": "km",
        "degrees celsius": "°C", "celsius": "°C",
        "degrees fahrenheit": "°F", "fahrenheit": "°F",
    }

    _NULL_MARKERS: frozenset[str] = frozenset({
        "n/a", "na", "none", "null", "nil", "-", "--", "---",
        "tbd", "tbc", "n.a.", "", "unknown", "not available",
        "not applicable", "?",
    })

    def normalise(
        self,
        records: list[ExtractionRecord],
        schema: list[SchemaField],
    ) -> list[ExtractionRecord]:
        schema_map = {f.name: f for f in schema}
        normalised: list[ExtractionRecord] = []

        for rec in records:
            new_data: dict[str, Any] = {}
            for col, val in rec.data.items():
                new_data[col] = self._normalise_value(val, schema_map.get(col))
            normalised.append(ExtractionRecord(
                data=new_data,
                source_chunk=rec.source_chunk,
                confidence=rec.confidence,
            ))
        return normalised

    def _normalise_value(self, val: Any, field: Optional[SchemaField]) -> Any:
        if val is None:
            return None
        val_s = str(val).strip()
        if val_s.lower() in self._NULL_MARKERS:
            return None

        if field is None:
            return self._clean_str(val_s)

        if field.dtype == "numeric":
            return self._to_numeric(val_s)
        if field.dtype == "boolean":
            return self._to_bool(val_s)
        if field.dtype == "unit":
            return self._normalise_unit(val_s)
        if field.dtype == "date":
            return val_s          # Return as-is; full parsing is locale-dependent
        return self._clean_str(val_s)

    def _to_numeric(self, val: str) -> Any:
        clean = re.sub(r"[,\$£€¥₹]", "", val)
        multipliers = {"k": 1_000, "m": 1_000_000, "b": 1_000_000_000}
        m = re.match(r"^([-+]?\d+(?:\.\d+)?)([kmbKMB])?$", clean.strip())
        if m:
            num = float(m.group(1))
            suf = (m.group(2) or "").lower()
            return num * multipliers.get(suf, 1.0)
        # Strip trailing unit labels and retry
        stripped = re.sub(
            r"\s+(?:ms|us|ns|s|GB|MB|KB|TB|%|kg|g|m|km|Hz|MHz|GHz|rpm|°C|°F|W|V|A"
            r"|requests/s|req/s|rps|qps)$",
            "",
            clean.strip(),
            flags=re.IGNORECASE,
        )
        try:
            return float(stripped)
        except ValueError:
            return val            # Return original string if unparseable

    def _to_bool(self, val: str) -> Any:
        v = val.strip().lower()
        if v in ("yes", "true", "enabled", "on", "1", "pass", "passing"):
            return True
        if v in ("no", "false", "disabled", "off", "0", "fail", "failing"):
            return False
        return val

    def _normalise_unit(self, val: str) -> str:
        low = val.lower()
        for alias, canonical in self._UNIT_ALIASES.items():
            low = low.replace(alias, canonical)
        return low

    @staticmethod
    def _clean_str(val: str) -> str:
        val = re.sub(r"\s+", " ", val).strip()
        val = val.strip("\"'")
        return val

# ─── 7. Table Builder ─────────────────────────────────────────────────────────

class TableBuilder:
    """
    Converts ExtractionRecord list into a pandas DataFrame.

    Steps:
      1. Align all rows to a unified column set (schema first, extras appended)
      2. Drop all-null columns
      3. Deduplicate exact rows; if generic schema, also dedup on key+value
      4. Sort by section for readability
    """

    def build(
        self,
        records: list[ExtractionRecord],
        schema: list[SchemaField],
    ) -> pd.DataFrame:
        if not records:
            log.warning("No records to build DataFrame from.")
            return pd.DataFrame(columns=[f.name for f in schema])

        schema_cols = [f.name for f in schema]
        extra_cols = [
            k for rec in records for k in rec.data
            if k not in schema_cols
        ]
        all_cols = schema_cols + list(dict.fromkeys(extra_cols))

        rows = [
            {col: rec.data.get(col) for col in all_cols}
            for rec in records
        ]
        df = pd.DataFrame(rows, columns=all_cols)

        # Drop completely empty columns
        df = df.dropna(axis=1, how="all")

        # Deduplication
        before = len(df)
        df = self._deduplicate(df)
        after = len(df)
        if before != after:
            log.info("Deduplication: %d → %d rows removed.", before - after, before)

        # Sort
        if "section" in df.columns:
            df = df.sort_values("section", na_position="last")
        df = df.reset_index(drop=True)

        log.info("DataFrame built: %d rows × %d columns", len(df), len(df.columns))
        return df

    @staticmethod
    def _deduplicate(df: pd.DataFrame) -> pd.DataFrame:
        df = df.drop_duplicates()
        if "key" in df.columns and "value" in df.columns:
            df = df.drop_duplicates(subset=["key", "value"], keep="first")
        return df

# ─── 8. Export Layer ──────────────────────────────────────────────────────────

class ExportLayer:
    """Exports a DataFrame to CSV and / or XLSX."""

    def to_csv(self, df: pd.DataFrame, path: str) -> str:
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(out, index=False, quoting=csv.QUOTE_NONNUMERIC)
        log.info("CSV  → %s  (%d rows)", out, len(df))
        return str(out)

    def to_xlsx(
        self,
        df: pd.DataFrame,
        path: str,
        sheet_name: str = "Extracted Data",
    ) -> str:
        if not XLSX_AVAILABLE:
            raise ImportError(
                "openpyxl is required for XLSX export.  pip install openpyxl"
            )
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)

        with pd.ExcelWriter(out, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
            ws = writer.sheets[sheet_name]
            # Auto-size columns
            for col_cells in ws.columns:
                max_w = max(
                    len(str(c.value)) if c.value is not None else 0
                    for c in col_cells
                )
                ws.column_dimensions[col_cells[0].column_letter].width = min(max_w + 4, 60)

        log.info("XLSX → %s  (%d rows)", out, len(df))
        return str(out)

    def to_both(self, df: pd.DataFrame, base_path: str) -> dict[str, str]:
        """Export to CSV (always) and XLSX (if openpyxl is available)."""
        out: dict[str, str] = {}
        out["csv"] = self.to_csv(df, base_path + ".csv")
        if XLSX_AVAILABLE:
            out["xlsx"] = self.to_xlsx(df, base_path + ".xlsx")
        else:
            log.warning("XLSX export skipped (openpyxl not installed).")
        return out

# ─── Orchestrator ─────────────────────────────────────────────────────────────

class DocumentToSpreadsheetEngine:
    """
    End-to-end orchestrator that wires all eight pipeline stages together.

    Quick-start
    -----------
    >>> engine = DocumentToSpreadsheetEngine()
    >>> df = engine.process("my_report.pdf")          # or raw text string
    >>> engine.export(df, "output/my_report")
    """

    def __init__(
        self,
        max_chunk_words: int = 300,
        log_level: int = logging.INFO,
    ) -> None:
        global log
        log = _build_logger(level=log_level)

        self.loader          = DocumentLoader()
        self.normaliser      = TextNormaliser()
        self.chunker         = ChunkingEngine(max_chunk_words=max_chunk_words)
        self.schema_inferrer = SchemaInference()
        self.extractor       = ExtractionEngine()
        self.normalisation   = NormalisationLayer()
        self.builder         = TableBuilder()
        self.exporter        = ExportLayer()

    def process(
        self,
        source: str,
        schema: Optional[list[SchemaField]] = None,
        print_schema: bool = True,
        llm_callable: Optional[Callable[[str], str]] = None,
    ) -> pd.DataFrame:
        """
        Full pipeline: source → DataFrame.

        Parameters
        ----------
        source : str
            File path (.pdf / .docx / .txt) OR raw text string.
        schema : list[SchemaField], optional
            Supply a pre-defined schema to skip automatic inference.
        print_schema : bool
            Pretty-print the (inferred) schema to stdout.
        llm_callable : Callable[[str], str], optional
            Hook for LLM-assisted schema inference.  See SchemaInference.infer_with_llm.

        Returns
        -------
        pd.DataFrame
        """
        # ── 1. Load ──────────────────────────────────────────────────────────
        raw_text, meta = self.loader.load(source)

        # ── 2. Normalise ─────────────────────────────────────────────────────
        clean_text = self.normaliser.normalise(raw_text)

        # ── 3. Chunk ─────────────────────────────────────────────────────────
        src_name = str(meta.get("source", "input"))
        chunks   = self.chunker.chunk(clean_text, source=src_name)

        if not chunks:
            log.error("Chunking produced zero chunks.  Check document content.")
            return pd.DataFrame()

        # ── 4. Schema ────────────────────────────────────────────────────────
        if schema is None:
            schema = (
                self.schema_inferrer.infer_with_llm(chunks, llm_callable)
                if llm_callable
                else self.schema_inferrer.infer(chunks)
            )

        if print_schema:
            self.schema_inferrer.print_schema(schema)

        # ── 5. Extract ───────────────────────────────────────────────────────
        records = self.extractor.extract(chunks, schema)

        if not records:
            log.warning(
                "Extraction yielded 0 records.  "
                "Document may be unstructured or schema may not match content."
            )

        # ── 6. Normalise values ──────────────────────────────────────────────
        records = self.normalisation.normalise(records, schema)

        # ── 7. Build DataFrame ───────────────────────────────────────────────
        df = self.builder.build(records, schema)

        return df

    def export(self, df: pd.DataFrame, base_path: str) -> dict[str, str]:
        """Export DataFrame to CSV (and XLSX if openpyxl is installed)."""
        return self.exporter.to_both(df, base_path)

# ─── Built-in Sample Document ─────────────────────────────────────────────────

_SAMPLE_DOCUMENT = """\
API PERFORMANCE BENCHMARK REPORT
=================================
Version: 2.4.1
Date: 2024-11-15
Author: Systems Engineering Team
Status: Final

## 1. Executive Summary

This report documents performance benchmarks for the Aureom.AI API Gateway
v2.4.1 under sustained production-equivalent load conditions. All measurements
were collected on an isolated staging cluster over 30-minute windows.

## 2. Endpoint Benchmarks

Endpoint: /api/v2/infer
Method: POST
Latency (p50): 42 ms
Latency (p95): 187 ms
Latency (p99): 412 ms
Throughput: 8500 requests/s
Error Rate: 0.12%
Payload Size: 512 KB
Status: Passing

Endpoint: /api/v2/embed
Method: POST
Latency (p50): 18 ms
Latency (p95): 89 ms
Latency (p99): 201 ms
Throughput: 14200 requests/s
Error Rate: 0.04%
Payload Size: 128 KB
Status: Passing

Endpoint: /api/v2/search
Method: GET
Latency (p50): 6 ms
Latency (p95): 31 ms
Latency (p99): 78 ms
Throughput: 22000 requests/s
Error Rate: 0.01%
Payload Size: 8 KB
Status: Passing

Endpoint: /api/v2/classify
Method: POST
Latency (p50): 95 ms
Latency (p95): 380 ms
Latency (p99): 740 ms
Throughput: 3200 requests/s
Error Rate: 0.31%
Payload Size: 2048 KB
Status: Warning

## 3. Infrastructure Specifications

CPU: 64-core AMD EPYC 9654
RAM: 512 GB DDR5
Storage: 8 TB NVMe (RAID-10)
Network: 100 Gbps
OS: Ubuntu 22.04 LTS
Kernel: 6.5.0-generic

## 4. Comparative Summary Table

| Endpoint         | p50 (ms) | p99 (ms) | RPS   | Error % | Status  |
|------------------|----------|----------|-------|---------|---------|
| /api/v2/infer    | 42       | 412      | 8500  | 0.12    | Passing |
| /api/v2/embed    | 18       | 201      | 14200 | 0.04    | Passing |
| /api/v2/search   | 6        | 78       | 22000 | 0.01    | Passing |
| /api/v2/classify | 95       | 740      | 3200  | 0.31    | Warning |

## 5. Test Methodology Notes

- Load generator: k6 v0.46.0
- Metrics backend: InfluxDB 2.7
- Warmup period: 2 minutes excluded from results
- Concurrency model: 500 virtual users, constant-rate arrival
- Data integrity: All responses validated against JSON schema v2.4 spec
"""

# ─── main() ───────────────────────────────────────────────────────────────────

def main() -> None:
    SEP = "═" * 66

    # Resolve source: CLI arg > built-in sample
    source: str
    if len(sys.argv) > 1:
        candidate = sys.argv[1]
        if Path(candidate).exists():
            source = candidate
            log.info("Using file: %s", candidate)
        else:
            log.warning("'%s' not found; falling back to built-in sample.", candidate)
            source = _SAMPLE_DOCUMENT
    else:
        log.info("No file path supplied; using built-in sample document.")
        source = _SAMPLE_DOCUMENT

    print(f"\n{SEP}")
    print("  DOCUMENT → SPREADSHEET ENGINE")
    print(SEP)

    # ── Run pipeline ──────────────────────────────────────────────────────────
    engine = DocumentToSpreadsheetEngine(max_chunk_words=400, log_level=logging.INFO)
    df = engine.process(source, print_schema=True)

    # ── Preview ───────────────────────────────────────────────────────────────
    print(f"\n{SEP}")
    print("  EXTRACTED DATA PREVIEW")
    print(SEP)
    if df.empty:
        print("  [No data extracted]")
    else:
        with pd.option_context(
            "display.max_columns", None,
            "display.width",       140,
            "display.max_colwidth", 28,
            "display.max_rows",    50,
        ):
            print(df.to_string(index=True))
        print(f"\n  Shape : {df.shape[0]} rows × {df.shape[1]} columns")
        print(f"  Columns: {list(df.columns)}")

    # ── Export ────────────────────────────────────────────────────────────────
    if not df.empty:
        print(f"\n{SEP}")
        print("  EXPORTS")
        print(SEP)
        output_base = "output/extracted_data"
        exports = engine.export(df, output_base)
        for fmt, path in exports.items():
            print(f"  {fmt.upper():<6} → {path}")

    print(f"\n{SEP}\n")


if __name__ == "__main__":
    main()
