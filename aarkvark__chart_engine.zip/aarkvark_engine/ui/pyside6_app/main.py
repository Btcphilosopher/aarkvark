"""Module 3 — PySide6 UI layer (default, per spec).

UI RULES (enforced by construction here, not just by convention):
  - UI MUST NOT contain business logic: every panel below only reads from / sends
    commands to `aarkvark_charts` objects (Chart, Worksheet, Workbook). No chart math,
    no layout math, no color math lives in this file.
  - UI MUST NOT perform calculations: even a "recalculate" button just calls
    `worksheet.recalculate()`.
  - Rust handles rendering output: every chart preview pixel comes from
    `chart.render_rgba()`, which calls straight into the compiled Rust extension. This
    file never draws a chart itself — it only displays the RGBA buffer Rust produced.

This is real, complete PySide6 code. It is NOT executed/screenshotted in the sandbox this
was built in (no GPU/display, and PySide6's wheel is large enough that downloading it
just to prove a window opens wasn't a good use of that environment's time budget) — but
the code paths (loading a chart, converting Rust's RGBA buffer to a QImage, wiring panel
signals to API calls) are straightforward PySide6/numpy with no novel risk surface the
way the Rust renderer had. Run `pip install PySide6` then `python main.py` in any
environment with a display to use it.
"""
from __future__ import annotations

import sys
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDoubleSpinBox, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QPushButton, QSplitter,
    QTabWidget, QTextEdit, QVBoxLayout, QWidget,
)

sys.path.insert(0, "../../python")  # dev convenience; real installs use the package normally
from aarkvark_charts import (
    Axis, AxisPosition, Chart, ChartType, Legend, LegendPosition, Series, Workbook,
    ANGLO_FUTURIST,
)

ANGLO_FUTURIST_QSS = """
QWidget { background-color: #0A0A0C; color: #E8E6E1; font-family: 'DM Mono', monospace; }
QMainWindow { background-color: #0A0A0C; }
QLabel#PanelTitle { font-family: 'Bebas Neue'; font-size: 14px; color: #00E5FF; letter-spacing: 1px; }
QPushButton {
    background-color: #1A1A1F; color: #C9A84C; border: 1px solid #4A4A52;
    padding: 6px 14px; border-radius: 2px;
}
QPushButton:hover { background-color: #23232A; border-color: #C9A84C; }
QListWidget, QComboBox, QTextEdit, QDoubleSpinBox, QLineEdit {
    background-color: #111114; border: 1px solid #23232A; color: #E8E6E1;
}
QSplitter::handle { background-color: #23232A; }
QTabWidget::pane { border: 1px solid #23232A; }
QTabBar::tab { background: #111114; color: #8A8A92; padding: 6px 12px; }
QTabBar::tab:selected { color: #C9A84C; border-bottom: 2px solid #C9A84C; }
"""


def chart_to_qpixmap(chart: Chart) -> QPixmap:
    """The ONLY rendering-adjacent line in the whole UI layer: take the RGBA buffer Rust
    already produced and wrap it in a QImage. No pixels are computed here."""
    rgba = chart.render_rgba()  # (H, W, 4) uint8, from chart_raster via PyO3
    h, w, _ = rgba.shape
    qimg = QImage(rgba.tobytes(), w, h, w * 4, QImage.Format_RGBA8888)
    return QPixmap.fromImage(qimg)


class ChartPreviewPanel(QWidget):
    """Chart Preview panel."""

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        title = QLabel("CHART PREVIEW")
        title.setObjectName("PanelTitle")
        self.image_label = QLabel("No chart selected")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumSize(640, 400)
        layout.addWidget(title)
        layout.addWidget(self.image_label, 1)

    def show_chart(self, chart: Optional[Chart]):
        if chart is None:
            self.image_label.setText("No chart selected")
            self.image_label.setPixmap(QPixmap())
            return
        try:
            pixmap = chart_to_qpixmap(chart)
            self.image_label.setPixmap(
                pixmap.scaled(self.image_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            )
        except Exception as e:  # surfaces e.g. UnimplementedChartTypeError cleanly in the UI
            self.image_label.setText(f"Render error:\n{e}")


class PropertiesInspectorPanel(QWidget):
    """Properties Inspector — title + chart type. Sends commands (attribute writes) to
    the Chart object; never computes anything."""

    changed = Signal()

    def __init__(self):
        super().__init__()
        self._chart: Optional[Chart] = None
        layout = QVBoxLayout(self)
        title = QLabel("PROPERTIES")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)

        form = QFormLayout()
        self.title_edit = QLineEdit()
        self.title_edit.textChanged.connect(self._on_title_changed)
        self.chart_type_combo = QComboBox()
        self.chart_type_combo.addItems([t.value for t in ChartType])
        self.chart_type_combo.currentTextChanged.connect(self._on_type_changed)
        form.addRow("Title", self.title_edit)
        form.addRow("Chart type", self.chart_type_combo)
        layout.addLayout(form)
        layout.addStretch(1)

    def set_chart(self, chart: Optional[Chart]):
        self._chart = chart
        if chart:
            self.title_edit.blockSignals(True)
            self.chart_type_combo.blockSignals(True)
            self.title_edit.setText(chart.title)
            self.chart_type_combo.setCurrentText(chart.chart_type.value)
            self.title_edit.blockSignals(False)
            self.chart_type_combo.blockSignals(False)

    def _on_title_changed(self, text: str):
        if self._chart:
            self._chart.title = text
            self.changed.emit()

    def _on_type_changed(self, text: str):
        if self._chart:
            self._chart.chart_type = ChartType(text)
            self.changed.emit()


class AxisEditorPanel(QWidget):
    """Axis Editor — min/max/title for the x and y axes."""

    changed = Signal()

    def __init__(self):
        super().__init__()
        self._chart: Optional[Chart] = None
        layout = QVBoxLayout(self)
        title = QLabel("AXIS EDITOR")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)

        form = QFormLayout()
        self.x_title = QLineEdit()
        self.y_title = QLineEdit()
        self.x_title.textChanged.connect(self._on_change)
        self.y_title.textChanged.connect(self._on_change)
        form.addRow("X axis title", self.x_title)
        form.addRow("Y axis title", self.y_title)
        layout.addLayout(form)
        layout.addStretch(1)

    def set_chart(self, chart: Optional[Chart]):
        self._chart = chart
        if chart:
            self.x_title.blockSignals(True)
            self.y_title.blockSignals(True)
            self.x_title.setText(chart.x_axis.title)
            self.y_title.setText(chart.y_axis.title)
            self.x_title.blockSignals(False)
            self.y_title.blockSignals(False)

    def _on_change(self):
        if self._chart:
            self._chart.x_axis.title = self.x_title.text()
            self._chart.y_axis.title = self.y_title.text()
            self.changed.emit()


class LegendEditorPanel(QWidget):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self._chart: Optional[Chart] = None
        layout = QVBoxLayout(self)
        title = QLabel("LEGEND")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)
        self.position_combo = QComboBox()
        self.position_combo.addItems([p.value for p in LegendPosition])
        self.position_combo.currentTextChanged.connect(self._on_change)
        layout.addWidget(self.position_combo)
        layout.addStretch(1)

    def set_chart(self, chart: Optional[Chart]):
        self._chart = chart
        if chart:
            self.position_combo.blockSignals(True)
            self.position_combo.setCurrentText(chart.legend.position.value)
            self.position_combo.blockSignals(False)

    def _on_change(self, text: str):
        if self._chart:
            self._chart.legend.position = LegendPosition(text)
            self.changed.emit()


class SeriesManagerPanel(QWidget):
    """Series Manager — list series in the current chart; toggle visibility."""

    changed = Signal()

    def __init__(self):
        super().__init__()
        self._chart: Optional[Chart] = None
        layout = QVBoxLayout(self)
        title = QLabel("SERIES")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)
        self.list_widget = QListWidget()
        self.list_widget.itemChanged.connect(self._on_item_changed)
        layout.addWidget(self.list_widget, 1)

    def set_chart(self, chart: Optional[Chart]):
        self._chart = chart
        self.list_widget.blockSignals(True)
        self.list_widget.clear()
        if chart:
            for s in chart.series:
                item = QListWidgetItem(f"{s.name}  ({len(s.data)} pts)")
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Checked if s.visible else Qt.Unchecked)
                item.setData(Qt.UserRole, s.id)
                self.list_widget.addItem(item)
        self.list_widget.blockSignals(False)

    def _on_item_changed(self, item: QListWidgetItem):
        if not self._chart:
            return
        sid = item.data(Qt.UserRole)
        for s in self._chart.series:
            if s.id == sid:
                s.visible = item.checkState() == Qt.Checked
        self.changed.emit()


class DataSourcePanel(QWidget):
    """Data Source Panel — pick a worksheet range to bind."""

    def __init__(self, workbook: Workbook):
        super().__init__()
        self.workbook = workbook
        layout = QVBoxLayout(self)
        title = QLabel("DATA SOURCE")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)
        form = QFormLayout()
        self.sheet_combo = QComboBox()
        self.sheet_combo.addItems(list(workbook.worksheets.keys()))
        self.x_range_edit = QLineEdit("A1:A10")
        self.y_range_edit = QLineEdit("B1:B10")
        form.addRow("Worksheet", self.sheet_combo)
        form.addRow("X range", self.x_range_edit)
        form.addRow("Y range", self.y_range_edit)
        layout.addLayout(form)
        layout.addStretch(1)

    def build_chart(self, chart_type: ChartType, title: str) -> Chart:
        ws = self.workbook.worksheet(self.sheet_combo.currentText())
        return ws.chart(type=chart_type.value, x=self.x_range_edit.text(), y=self.y_range_edit.text(), title=title)


class ThemeManagerPanel(QWidget):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self._chart: Optional[Chart] = None
        layout = QVBoxLayout(self)
        title = QLabel("THEME")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)
        self.theme_combo = QComboBox()
        from aarkvark_charts import THEMES
        self.theme_combo.addItems(list(THEMES.keys()))
        self.theme_combo.currentTextChanged.connect(self._on_change)
        layout.addWidget(self.theme_combo)
        layout.addStretch(1)

    def set_chart(self, chart: Optional[Chart]):
        self._chart = chart
        if chart:
            self.theme_combo.blockSignals(True)
            self.theme_combo.setCurrentText(chart.theme.name)
            self.theme_combo.blockSignals(False)

    def _on_change(self, name: str):
        if self._chart:
            from aarkvark_charts import THEMES
            self._chart.theme = THEMES[name]
            self.changed.emit()


class AnimationEditorPanel(QWidget):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self._chart: Optional[Chart] = None
        layout = QVBoxLayout(self)
        title = QLabel("ANIMATION")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)
        form = QFormLayout()
        self.progress_spin = QDoubleSpinBox()
        self.progress_spin.setRange(0.0, 1.0)
        self.progress_spin.setSingleStep(0.05)
        self.progress_spin.valueChanged.connect(self._on_change)
        form.addRow("Progress", self.progress_spin)
        layout.addLayout(form)
        layout.addStretch(1)

    def set_chart(self, chart: Optional[Chart]):
        self._chart = chart
        if chart:
            self.progress_spin.blockSignals(True)
            self.progress_spin.setValue(chart.animation_progress)
            self.progress_spin.blockSignals(False)

    def _on_change(self, value: float):
        if self._chart:
            self._chart.animation_progress = value
            self.changed.emit()


class AnnotationToolsPanel(QWidget):
    """Annotation Tools — add a horizontal-line annotation at a given y value."""

    changed = Signal()

    def __init__(self):
        super().__init__()
        self._chart: Optional[Chart] = None
        layout = QVBoxLayout(self)
        title = QLabel("ANNOTATIONS")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)
        form = QFormLayout()
        self.y_value_spin = QDoubleSpinBox()
        self.y_value_spin.setRange(-1e9, 1e9)
        self.text_edit = QLineEdit("Target")
        form.addRow("Y value", self.y_value_spin)
        form.addRow("Label", self.text_edit)
        add_btn = QPushButton("Add horizontal line")
        add_btn.clicked.connect(self._on_add)
        layout.addLayout(form)
        layout.addWidget(add_btn)
        layout.addStretch(1)

    def set_chart(self, chart: Optional[Chart]):
        self._chart = chart

    def _on_add(self):
        if self._chart:
            from aarkvark_charts import Annotation
            import uuid
            self._chart.add_annotation(
                Annotation.horizontal_line(f"ann-{uuid.uuid4().hex[:6]}", self.y_value_spin.value(),
                                            text=self.text_edit.text())
            )
            self.changed.emit()


class DashboardBuilderPanel(QWidget):
    """Dashboard Builder — placeholder list of charts that could be dragged onto a grid.
    Drag-and-drop wiring itself (QListWidget internal-move + a QGraphicsGridLayout drop
    target) is the natural next increment; the data model it would write into already
    exists in `aarkvark_charts.dashboard.Dashboard`."""

    def __init__(self, workbook: Workbook):
        super().__init__()
        self.workbook = workbook
        layout = QVBoxLayout(self)
        title = QLabel("DASHBOARD BUILDER")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)
        self.chart_list = QListWidget()
        layout.addWidget(QLabel("Charts in workbook:"))
        layout.addWidget(self.chart_list, 1)
        export_btn = QPushButton("Export dashboard HTML…")
        export_btn.clicked.connect(self._export)
        layout.addWidget(export_btn)

    def refresh(self):
        self.chart_list.clear()
        for cid, chart in self.workbook.charts.items():
            self.chart_list.addItem(f"{chart.title or cid}")

    def _export(self):
        from aarkvark_charts import Dashboard
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(self, "Export Dashboard", "dashboard.html", "HTML (*.html)")
        if not path:
            return
        dash = Dashboard(title=self.workbook.name)
        col = 1
        for chart in self.workbook.charts.values():
            dash.add_chart(chart, row=1 + (col - 1) // 12, col=((col - 1) % 12) + 1, col_span=4)
            col += 4
        dash.export_html(path)


class MainWindow(QMainWindow):
    def __init__(self, workbook: Workbook):
        super().__init__()
        self.workbook = workbook
        self.setWindowTitle("Aarkvark Charts")
        self.resize(1440, 900)

        self.preview = ChartPreviewPanel()
        self.properties = PropertiesInspectorPanel()
        self.axis_editor = AxisEditorPanel()
        self.legend_editor = LegendEditorPanel()
        self.series_manager = SeriesManagerPanel()
        self.data_source = DataSourcePanel(workbook)
        self.theme_manager = ThemeManagerPanel()
        self.animation_editor = AnimationEditorPanel()
        self.annotation_tools = AnnotationToolsPanel()
        self.dashboard_builder = DashboardBuilderPanel(workbook)

        for panel in (self.properties, self.axis_editor, self.legend_editor,
                      self.series_manager, self.theme_manager, self.animation_editor,
                      self.annotation_tools):
            panel.changed.connect(self._refresh_preview)

        right_tabs = QTabWidget()
        right_tabs.addTab(self.properties, "Properties")
        right_tabs.addTab(self.axis_editor, "Axes")
        right_tabs.addTab(self.legend_editor, "Legend")
        right_tabs.addTab(self.series_manager, "Series")
        right_tabs.addTab(self.theme_manager, "Theme")
        right_tabs.addTab(self.animation_editor, "Animation")
        right_tabs.addTab(self.annotation_tools, "Annotations")
        right_tabs.addTab(self.data_source, "Data Source")
        right_tabs.addTab(self.dashboard_builder, "Dashboard")

        new_chart_btn = QPushButton("Build chart from data source")
        new_chart_btn.clicked.connect(self._new_chart)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(new_chart_btn)
        left_layout.addWidget(self.preview, 1)

        splitter = QSplitter()
        splitter.addWidget(left)
        splitter.addWidget(right_tabs)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        self.setCentralWidget(splitter)

        self._current_chart: Optional[Chart] = None

    def _new_chart(self):
        chart = self.data_source.build_chart(ChartType.LINE, title="New Chart")
        self.workbook.add_chart(chart)
        self._current_chart = chart
        self.properties.set_chart(chart)
        self.axis_editor.set_chart(chart)
        self.legend_editor.set_chart(chart)
        self.series_manager.set_chart(chart)
        self.theme_manager.set_chart(chart)
        self.animation_editor.set_chart(chart)
        self.annotation_tools.set_chart(chart)
        self.dashboard_builder.refresh()
        self._refresh_preview()

    def _refresh_preview(self):
        self.preview.show_chart(self._current_chart)


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(ANGLO_FUTURIST_QSS)

    workbook = Workbook("Demo Workbook")
    ws = workbook.add_worksheet("Sheet1")
    import numpy as np
    x = np.arange(10, dtype=float)
    y = x ** 1.6
    ws.set_range("A1", x)
    ws.set_range("B1", y)

    window = MainWindow(workbook)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
