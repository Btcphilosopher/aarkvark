import numpy as np
import pytest

from aarkvark_charts.chart import Chart, UnimplementedChartTypeError
from aarkvark_charts.model import ChartType, Series, Axis, Legend, Annotation, AnnotationKind
from aarkvark_charts.theme import ANGLO_FUTURIST


def make_chart(chart_type=ChartType.LINE):
    c = Chart(chart_type=chart_type, title="Test")
    c.add_series(Series.from_xy("s1", "Series 1", [0, 1, 2, 3], [1, 4, 2, 8]))
    return c


@pytest.mark.parametrize("chart_type", [
    ChartType.LINE, ChartType.AREA, ChartType.BAR, ChartType.COLUMN,
    ChartType.SCATTER, ChartType.HISTOGRAM,
])
def test_implemented_chart_types_render(chart_type):
    c = make_chart(chart_type)
    png = c.render_png()
    assert png[:8] == b"\x89PNG\r\n\x1a\n"
    assert len(png) > 50


def test_pie_donut_render():
    for chart_type in (ChartType.PIE, ChartType.DONUT):
        c = Chart(chart_type=chart_type, title="Slices")
        c.add_series(Series.from_values("s1", "vals", [30, 50, 20], labels=["A", "B", "C"]))
        png = c.render_png()
        assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_bubble_chart_with_sizes():
    c = Chart(chart_type=ChartType.BUBBLE, title="Bubbles")
    c.add_series(Series.from_xy("s1", "b", [0, 1, 2], [1, 2, 3], size=[5, 15, 25]))
    png = c.render_png()
    assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_unimplemented_chart_type_raises_clean_error():
    c = make_chart(ChartType.SANKEY)
    with pytest.raises(UnimplementedChartTypeError):
        c.render_png()


def test_render_rgba_shape_matches_viewport():
    c = make_chart().with_size(400, 300)
    arr = c.render_rgba()
    assert arr.shape == (300, 400, 4)
    assert arr.dtype.name == "uint8"


def test_geometry_json_roundtrips():
    import json
    c = make_chart()
    geo = json.loads(c.geometry_json())
    assert "primitives" in geo
    assert geo["width_px"] == c.width_px


def test_validate_does_not_raise_for_good_chart():
    make_chart().validate()


def test_validate_raises_for_empty_series():
    c = Chart(chart_type=ChartType.LINE)
    c.add_series(Series(id="s1", name="empty", data=[]))
    with pytest.raises(Exception):
        c.validate()


def test_multi_series_with_secondary_axis():
    c = Chart(chart_type=ChartType.LINE, title="Dual axis")
    c.add_series(Series.from_xy("s1", "Revenue", [0, 1, 2], [10, 20, 30]))
    s2 = Series.from_xy("s2", "Margin %", [0, 1, 2], [0.2, 0.25, 0.22])
    s2.y_axis = s2.y_axis.SECONDARY
    c.add_series(s2)
    png = c.render_png()
    assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_annotations_render():
    c = make_chart()
    c.add_annotation(Annotation.horizontal_line("target", y=5.0, text="Target"))
    png = c.render_png()
    assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_animation_progress_frame():
    c = make_chart()
    frame = c.at_animation_progress(0.5)
    assert frame.animation_progress == 0.5
    assert c.animation_progress == 1.0  # original untouched
    png = frame.render_png()
    assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_custom_theme_applied():
    from aarkvark_charts.theme import LIGHT
    c = make_chart().with_theme(LIGHT)
    assert c.theme.name == "light"
    png = c.render_png()
    assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_zero_copy_line_chart_from_arrays():
    from aarkvark_charts.chart import line_chart_from_arrays
    x = np.linspace(0, 10, 5000)
    y = np.sin(x)
    png = line_chart_from_arrays("Zero copy", "sine", x, y)
    assert png[:8] == b"\x89PNG\r\n\x1a\n"
