import os
import numpy as np
import pandas as pd
import pytest

from aarkvark_charts.chart import Chart
from aarkvark_charts.model import ChartType, Series
from aarkvark_charts.dashboard import Dashboard, GridPosition, TableWidget, TextWidget
from aarkvark_charts.data_connector import DataConnector
from aarkvark_charts.schema_inference import infer_schema, suggest_chart, ColumnKind
from aarkvark_charts import export
from aarkvark_charts.plugin import HookRegistry, ComponentRegistry
from aarkvark_charts.workbook import Workbook


def _sample_chart():
    c = Chart(chart_type=ChartType.LINE, title="Sample")
    c.add_series(Series.from_xy("s1", "s", [0, 1, 2], [1, 2, 3]))
    return c


def test_dashboard_html_export(tmp_path):
    dash = Dashboard(title="Test Dashboard")
    dash.add_chart(_sample_chart(), row=1, col=1, col_span=6)
    dash.add_kpi("Revenue", "$1.2M", row=1, col=7, delta="+12%", delta_positive=True)
    df = pd.DataFrame({"name": ["a", "b"], "value": [1, 2]})
    dash.add_widget(TableWidget(df, GridPosition(2, 1, 1, 6), title="Table"))
    dash.add_widget(TextWidget("Some commentary.", GridPosition(2, 7, 1, 6), heading="Notes"))

    out = tmp_path / "dash.html"
    dash.export_html(str(out))
    content = out.read_text()
    assert "Test Dashboard" in content
    assert "data:image/png;base64," in content
    assert "Revenue" in content
    assert "<table" in content


def test_data_connector_pubsub():
    df = pd.DataFrame({"x": [1, 2, 3]})
    conn = DataConnector.from_dataframe(df)
    received = []
    conn.subscribe(lambda d: received.append(len(d)))
    conn.push_update(pd.DataFrame({"x": [1, 2]}))
    assert received == [2]
    conn.append_rows(pd.DataFrame({"x": [9]}))
    assert received == [2, 3]


def test_schema_inference_classifies_columns():
    df = pd.DataFrame({
        "id": [f"id-{i}" for i in range(100)],
        "category": np.random.choice(["A", "B", "C"], size=100),
        "value": np.random.randn(100),
        "is_active": np.random.choice([True, False], size=100),
    })
    report = infer_schema(df)
    assert report.row_count == 100
    assert report.column("category").kind == ColumnKind.CATEGORICAL
    assert report.column("value").kind == ColumnKind.NUMERIC_CONTINUOUS
    assert report.column("is_active").kind == ColumnKind.BOOLEAN
    assert report.column("id").kind == ColumnKind.IDENTIFIER


def test_suggest_chart_builds_renderable_chart():
    df = pd.DataFrame({"category": ["A", "B", "C", "D"], "revenue": [10, 30, 20, 45]})
    chart = suggest_chart(df, x_col="category", y_col="revenue")
    png = chart.render_png()
    assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_export_svg_pdf_json(tmp_path):
    c = _sample_chart()
    svg = export.to_svg(c, str(tmp_path / "c.svg"))
    assert svg.startswith("<svg")
    assert "<polyline" in svg
    export.to_pdf(c, str(tmp_path / "c.pdf"))
    assert os.path.getsize(tmp_path / "c.pdf") > 100
    j = export.to_json(c, str(tmp_path / "c.json"))
    assert '"chart_type"' in j


def test_plugin_hook_registry_chains_transformations():
    hooks = HookRegistry()

    @hooks.register("before_render")
    def add_suffix(chart):
        chart.title = chart.title + " [v1]"
        return chart

    @hooks.register("before_render")
    def add_suffix2(chart):
        chart.title = chart.title + " [v2]"
        return chart

    c = _sample_chart()
    result = hooks.call("before_render", c)
    assert result.title == "Sample [v1] [v2]"


def test_plugin_component_registry():
    reg = ComponentRegistry("preprocessor")

    @reg.register("double")
    def double(x):
        return x * 2

    assert reg.get("double")(21) == 42
    assert "double" in reg.list()
    with pytest.raises(KeyError):
        reg.get("missing")


def test_workbook_save_load_roundtrip(tmp_path):
    wb = Workbook("MyBook")
    ws = wb.add_worksheet("Sheet1")
    ws["A1"] = 5.0
    ws["A2"] = "=A1*2"
    path = str(tmp_path / "wb.json")
    wb.save_json(path)
    wb2 = Workbook.load_json(path)
    assert wb2.worksheet("Sheet1")["A2"] == 10.0
