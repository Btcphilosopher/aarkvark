import numpy as np
import pandas as pd
import pytest

from aarkvark_charts.worksheet import Worksheet, CircularReferenceError, FormulaError, parse_cell_ref, parse_range, col_letters_to_index, col_index_to_letters


def test_col_letter_roundtrip():
    for letters in ["A", "Z", "AA", "AZ", "BA", "ZZ", "AAA"]:
        idx = col_letters_to_index(letters)
        assert col_index_to_letters(idx) == letters


def test_parse_cell_ref():
    assert parse_cell_ref("A1") == (0, 0)
    assert parse_cell_ref("B3") == (2, 1)
    assert parse_cell_ref("AA10") == (9, 26)


def test_literal_values():
    ws = Worksheet("s")
    ws["A1"] = 5.0
    ws["A2"] = "hello"
    assert ws["A1"] == 5.0
    assert ws["A2"] == "hello"


def test_simple_arithmetic_formula():
    ws = Worksheet("s")
    ws["A1"] = 2.0
    ws["A2"] = 3.0
    ws["A3"] = "=A1+A2*2"
    assert ws["A3"] == 8.0


def test_parentheses_and_precedence():
    ws = Worksheet("s")
    ws["A1"] = "=(2+3)*4"
    assert ws["A1"] == 20.0
    ws["A2"] = "=2+3*4"
    assert ws["A2"] == 14.0


def test_unary_minus():
    ws = Worksheet("s")
    ws["A1"] = 5.0
    ws["A2"] = "=-A1+10"
    assert ws["A2"] == 5.0


def test_sum_average_min_max_count():
    ws = Worksheet("s")
    for i in range(5):
        ws[f"A{i+1}"] = float(i + 1)  # 1..5
    ws["B1"] = "=SUM(A1:A5)"
    ws["B2"] = "=AVERAGE(A1:A5)"
    ws["B3"] = "=MIN(A1:A5)"
    ws["B4"] = "=MAX(A1:A5)"
    ws["B5"] = "=COUNT(A1:A5)"
    assert ws["B1"] == 15.0
    assert ws["B2"] == 3.0
    assert ws["B3"] == 1.0
    assert ws["B4"] == 5.0
    assert ws["B5"] == 5.0


def test_chained_formula_dependencies():
    ws = Worksheet("s")
    ws["A1"] = 1.0
    ws["A2"] = "=A1+1"
    ws["A3"] = "=A2+1"
    ws["A4"] = "=A3+1"
    assert ws["A4"] == 4.0


def test_circular_reference_raises():
    ws = Worksheet("s")
    ws["A1"] = "=B1+1"
    ws["B1"] = "=A1+1"
    with pytest.raises(CircularReferenceError):
        ws.recalculate()


def test_self_reference_raises():
    ws = Worksheet("s")
    ws["A1"] = "=A1+1"
    with pytest.raises(CircularReferenceError):
        ws.recalculate()


def test_division_by_zero_raises():
    ws = Worksheet("s")
    ws["A1"] = "=1/0"
    with pytest.raises(FormulaError):
        ws.recalculate()


def test_range_resolution():
    ws = Worksheet("s")
    ws.set_range("A1", np.array([1.0, 2.0, 3.0, 4.0]))
    result = ws.range("A1:A4")
    np.testing.assert_array_equal(result, [1.0, 2.0, 3.0, 4.0])


def test_dataframe_roundtrip():
    df = pd.DataFrame({"x": [1, 2, 3], "y": [10, 20, 30]})
    ws = Worksheet.from_dataframe("data", df)
    out = ws.to_dataframe("A1:B4")
    assert list(out.columns) == ["x", "y"]
    assert out["y"].tolist() == [10.0, 20.0, 30.0]


def test_recalculation_after_update():
    ws = Worksheet("s")
    ws["A1"] = 10.0
    ws["B1"] = "=A1*2"
    assert ws["B1"] == 20.0
    ws["A1"] = 50.0
    assert ws["B1"] == 100.0


def test_worksheet_chart_spec_example():
    ws = Worksheet("s")
    ws.set_range("A1", np.arange(10, dtype=float))
    ws.set_range("B1", (np.arange(10, dtype=float)) ** 2)
    chart = ws.chart(type="scatter", x="A1:A10", y="B1:B10", title="Population Growth")
    assert chart.title == "Population Growth"
    assert len(chart.series) == 1
    assert len(chart.series[0].data) == 10
