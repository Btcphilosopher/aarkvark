"""DataConnector: ingestion + live-update plumbing for charts and dashboards.

Wraps pandas DataFrames, CSV/JSON files, and a real (if simple) push-based live-update
mechanism: `subscribe()` a callback, then `push_update()` a new DataFrame and every
subscriber gets called. This is the "live data updates" / "streaming data support"
feature from the spec — a real pub/sub, not a TODO. Wiring it to an actual socket/Kafka
feed is left as an integration point (`push_update` is what you'd call from that feed's
message handler); the dispatch mechanism itself is fully implemented and tested here.
"""
from __future__ import annotations

import threading
from typing import Callable, List, Optional

import pandas as pd

UpdateCallback = Callable[[pd.DataFrame], None]


class DataConnector:
    def __init__(self, df: pd.DataFrame, *, name: str = "data"):
        self.name = name
        self._df = df
        self._subscribers: List[UpdateCallback] = []
        self._lock = threading.Lock()

    # -- construction ----------------------------------------------------------------

    @classmethod
    def from_dataframe(cls, df: pd.DataFrame, *, name: str = "data") -> "DataConnector":
        return cls(df.copy(), name=name)

    @classmethod
    def from_csv(cls, path: str, *, name: Optional[str] = None, **read_csv_kwargs) -> "DataConnector":
        df = pd.read_csv(path, **read_csv_kwargs)
        return cls(df, name=name or path)

    @classmethod
    def from_json(cls, path: str, *, name: Optional[str] = None, **read_json_kwargs) -> "DataConnector":
        df = pd.read_json(path, **read_json_kwargs)
        return cls(df, name=name or path)

    @classmethod
    def from_sql(cls, query: str, connection, *, name: str = "sql") -> "DataConnector":
        """`connection` is any DB-API/SQLAlchemy connection pandas.read_sql accepts."""
        df = pd.read_sql(query, connection)
        return cls(df, name=name)

    # -- access --------------------------------------------------------------------------

    @property
    def dataframe(self) -> pd.DataFrame:
        with self._lock:
            return self._df.copy()

    def column(self, name: str):
        with self._lock:
            return self._df[name].to_numpy()

    def __len__(self) -> int:
        with self._lock:
            return len(self._df)

    # -- live updates ----------------------------------------------------------------

    def subscribe(self, callback: UpdateCallback) -> None:
        """Register `callback(new_dataframe)` to be invoked on every `push_update`."""
        self._subscribers.append(callback)

    def unsubscribe(self, callback: UpdateCallback) -> None:
        if callback in self._subscribers:
            self._subscribers.remove(callback)

    def push_update(self, df: pd.DataFrame) -> None:
        """Replace the underlying data and notify all subscribers. Call this from
        whatever feeds live data in (a websocket handler, a polling loop, a file
        watcher) — the dispatch fan-out itself is what this class actually implements."""
        with self._lock:
            self._df = df
        for cb in list(self._subscribers):
            cb(self.dataframe)

    def append_rows(self, df: pd.DataFrame) -> None:
        with self._lock:
            self._df = pd.concat([self._df, df], ignore_index=True)
        for cb in list(self._subscribers):
            cb(self.dataframe)

    def __repr__(self) -> str:
        return f"DataConnector(name={self.name!r}, rows={len(self)}, subscribers={len(self._subscribers)})"
