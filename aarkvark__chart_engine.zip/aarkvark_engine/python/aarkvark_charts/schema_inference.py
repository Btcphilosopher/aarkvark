"""AI-assisted schema inference: the spec's "AI-assisted schema inference" feature.

This is a heuristic/statistical implementation — dtype + cardinality + distribution-shape
analysis driving chart-type suggestions — documented honestly as such rather than
overclaiming an actual model call. `suggest_chart_for_columns` is the integration point
where a real LLM call (e.g. via the Anthropic API, given a column sample + the user's
intent) would slot in to replace or augment the heuristics; the heuristic path works
standalone with zero network dependency, which matters for a charting library that has to
work offline/air-gapped.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

import numpy as np
import pandas as pd

from .model import ChartType


class ColumnKind(str, Enum):
    NUMERIC_CONTINUOUS = "numeric_continuous"
    NUMERIC_DISCRETE = "numeric_discrete"
    CATEGORICAL = "categorical"
    DATETIME = "datetime"
    BOOLEAN = "boolean"
    TEXT = "text"
    IDENTIFIER = "identifier"  # high-cardinality, likely an ID/key column


@dataclass
class ColumnProfile:
    name: str
    kind: ColumnKind
    dtype: str
    cardinality: int
    null_fraction: float
    sample: list = field(default_factory=list)


@dataclass
class SchemaReport:
    row_count: int
    columns: List[ColumnProfile]

    def column(self, name: str) -> ColumnProfile:
        for c in self.columns:
            if c.name == name:
                return c
        raise KeyError(name)

    def columns_of_kind(self, kind: ColumnKind) -> List[ColumnProfile]:
        return [c for c in self.columns if c.kind == kind]


def _classify_column(name: str, s: pd.Series, n_rows: int) -> ColumnProfile:
    null_frac = float(s.isna().mean()) if n_rows else 0.0
    non_null = s.dropna()
    cardinality = int(non_null.nunique())

    if pd.api.types.is_bool_dtype(s):
        kind = ColumnKind.BOOLEAN
    elif pd.api.types.is_datetime64_any_dtype(s):
        kind = ColumnKind.DATETIME
    elif pd.api.types.is_numeric_dtype(s):
        # Discrete vs continuous: integers with low cardinality relative to row count
        # read as discrete/categorical-ish (e.g. a 1-5 rating column); everything else
        # continuous.
        if pd.api.types.is_integer_dtype(s) and n_rows and cardinality <= max(20, n_rows * 0.05):
            kind = ColumnKind.NUMERIC_DISCRETE
        else:
            kind = ColumnKind.NUMERIC_CONTINUOUS
    else:
        # Try datetime coercion before falling back to text/categorical — a common case
        # is a date column read in as object dtype from CSV.
        try:
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                coerced = pd.to_datetime(non_null.iloc[: min(50, len(non_null))], errors="raise")
            kind = ColumnKind.DATETIME
        except Exception:
            if n_rows and cardinality >= n_rows * 0.9 and cardinality > 20:
                kind = ColumnKind.IDENTIFIER
            elif n_rows and cardinality <= max(50, n_rows * 0.2):
                kind = ColumnKind.CATEGORICAL
            else:
                kind = ColumnKind.TEXT

    sample = non_null.head(5).tolist()
    return ColumnProfile(
        name=name, kind=kind, dtype=str(s.dtype), cardinality=cardinality,
        null_fraction=null_frac, sample=sample,
    )


def infer_schema(df: pd.DataFrame) -> SchemaReport:
    n_rows = len(df)
    columns = [_classify_column(col, df[col], n_rows) for col in df.columns]
    return SchemaReport(row_count=n_rows, columns=columns)


def suggest_chart_type(x_kind: ColumnKind, y_kind: ColumnKind) -> ChartType:
    """Heuristic chart-type suggestion for an (x, y) column-kind pairing — the core
    "given this data shape, what chart works" rule table."""
    numeric = {ColumnKind.NUMERIC_CONTINUOUS, ColumnKind.NUMERIC_DISCRETE}
    if x_kind == ColumnKind.DATETIME and y_kind in numeric:
        return ChartType.LINE
    if x_kind in numeric and y_kind in numeric:
        return ChartType.SCATTER
    if x_kind == ColumnKind.CATEGORICAL and y_kind in numeric:
        return ChartType.BAR
    if x_kind in numeric and y_kind == ColumnKind.CATEGORICAL:
        return ChartType.BAR
    if x_kind == ColumnKind.CATEGORICAL and y_kind == ColumnKind.CATEGORICAL:
        return ChartType.HEATMAP
    return ChartType.SCATTER


def suggest_chart(
    df: pd.DataFrame,
    x_col: Optional[str] = None,
    y_col: Optional[str] = None,
    *,
    title: Optional[str] = None,
):
    """Infer the schema, pick sensible x/y columns if not given, pick a chart type, and
    return a ready-to-render `Chart`. This is the one-call "AI-assisted" path: hand it a
    DataFrame, get a chart back."""
    from .chart import Chart
    from .model import Series

    report = infer_schema(df)
    numeric_cols = report.columns_of_kind(ColumnKind.NUMERIC_CONTINUOUS) + report.columns_of_kind(
        ColumnKind.NUMERIC_DISCRETE
    )
    datetime_cols = report.columns_of_kind(ColumnKind.DATETIME)
    categorical_cols = report.columns_of_kind(ColumnKind.CATEGORICAL)

    if y_col is None:
        if not numeric_cols:
            raise ValueError("suggest_chart needs at least one numeric column to use as y")
        y_col = numeric_cols[0].name

    if x_col is None:
        if datetime_cols:
            x_col = datetime_cols[0].name
        elif categorical_cols:
            x_col = categorical_cols[0].name
        elif len(numeric_cols) >= 2:
            x_col = next((c.name for c in numeric_cols if c.name != y_col), numeric_cols[0].name)
        else:
            # Fall back to row index as x.
            x_col = None

    x_kind = report.column(x_col).kind if x_col else ColumnKind.NUMERIC_DISCRETE
    y_kind = report.column(y_col).kind
    chart_type = suggest_chart_type(x_kind, y_kind)

    y_vals = pd.to_numeric(df[y_col], errors="coerce").to_numpy(dtype=float)
    if x_col is None:
        x_vals = np.arange(len(df), dtype=float)
        x_label = "index"
    elif x_kind == ColumnKind.DATETIME:
        dt = pd.to_datetime(df[x_col])
        x_vals = (dt.astype("int64") // 10**9).to_numpy(dtype=float)  # unix seconds
        x_label = x_col
    elif x_kind == ColumnKind.CATEGORICAL:
        categories = pd.Categorical(df[x_col])
        x_vals = categories.codes.astype(float)
        x_label = x_col
    else:
        x_vals = pd.to_numeric(df[x_col], errors="coerce").to_numpy(dtype=float)
        x_label = x_col

    mask = ~(np.isnan(x_vals) | np.isnan(y_vals))
    series = Series.from_xy("series-0", y_col, x_vals[mask], y_vals[mask])
    chart = Chart(chart_type=chart_type, title=title or f"{y_col} by {x_label}").add_series(series)
    chart.x_axis.title = x_label
    chart.y_axis.title = y_col
    if x_kind == ColumnKind.CATEGORICAL:
        chart.x_axis.category_labels = list(pd.Categorical(df[x_col]).categories)
    return chart
