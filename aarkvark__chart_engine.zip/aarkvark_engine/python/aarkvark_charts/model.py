"""Python-side mirror of chart_core's data model: Series, Axis, Legend, Annotation.

These are the REQUIRED COMPONENTS from the spec (Workbook/Worksheet live in their own
modules). Every `to_dict()` here produces exactly the JSON shape `Chart::from_json` on the
Rust side expects — see rust/chart_core/src/model.rs for the authoritative schema.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Sequence, Tuple, Union

import numpy as np

from .theme import Color


class ChartType(str, Enum):
    LINE = "line"
    AREA = "area"
    SPLINE = "spline"
    BAR = "bar"
    COLUMN = "column"
    STACKED_BAR = "stacked_bar"
    STACKED_COLUMN = "stacked_column"
    SCATTER = "scatter"
    BUBBLE = "bubble"
    PIE = "pie"
    DONUT = "donut"
    HISTOGRAM = "histogram"
    HEATMAP = "heatmap"
    CANDLESTICK = "candlestick"
    OHLC = "ohlc"
    RADAR = "radar"
    POLAR = "polar"
    TREEMAP = "treemap"
    SUNBURST = "sunburst"
    SANKEY = "sankey"
    NETWORK = "network"
    GANTT = "gantt"
    TIMELINE = "timeline"
    SURFACE_3D = "surface3_d"  # matches serde's snake_case of `Surface3D`


# Chart types with a real Rust-side geometry implementation today. Anything else
# round-trips through the model/JSON fine but `chart.render_png()` raises a clear
# `UnimplementedChartType` error instead of silently producing nothing.
IMPLEMENTED_CHART_TYPES = {
    ChartType.LINE, ChartType.AREA, ChartType.SPLINE, ChartType.BAR, ChartType.COLUMN,
    ChartType.SCATTER, ChartType.BUBBLE, ChartType.HISTOGRAM, ChartType.PIE, ChartType.DONUT,
}


class ScaleType(str, Enum):
    LINEAR = "linear"
    LOGARITHMIC = "logarithmic"
    CATEGORY = "category"
    TIME = "time"


class AxisPosition(str, Enum):
    BOTTOM = "bottom"
    TOP = "top"
    LEFT = "left"
    RIGHT = "right"


class LegendPosition(str, Enum):
    TOP = "top"
    BOTTOM = "bottom"
    LEFT = "left"
    RIGHT = "right"
    NONE = "none"


class AnnotationKind(str, Enum):
    TEXT = "text"
    HORIZONTAL_LINE = "horizontal_line"
    VERTICAL_LINE = "vertical_line"
    RECT = "rect"


class YAxisRef(str, Enum):
    PRIMARY = "primary"
    SECONDARY = "secondary"


@dataclass
class DataPoint:
    x: float
    y: float
    size: Optional[float] = None
    label: Optional[str] = None

    def to_dict(self) -> dict:
        d = {"x": float(self.x), "y": float(self.y)}
        if self.size is not None:
            d["size"] = float(self.size)
        if self.label is not None:
            d["label"] = self.label
        return d


ArrayLike = Union[Sequence[float], np.ndarray]


@dataclass
class Series:
    id: str
    name: str
    data: List[DataPoint] = field(default_factory=list)
    color: Optional[Color] = None
    y_axis: YAxisRef = YAxisRef.PRIMARY
    visible: bool = True

    @classmethod
    def from_xy(
        cls,
        id: str,
        name: str,
        x: ArrayLike,
        y: ArrayLike,
        *,
        size: Optional[ArrayLike] = None,
        labels: Optional[Sequence[str]] = None,
        color: Optional[Color] = None,
    ) -> "Series":
        x_arr = np.asarray(x, dtype=float)
        y_arr = np.asarray(y, dtype=float)
        if x_arr.shape != y_arr.shape:
            raise ValueError(f"x/y length mismatch: x={x_arr.shape} y={y_arr.shape}")
        sizes = np.asarray(size, dtype=float) if size is not None else None
        points = []
        for i in range(len(x_arr)):
            points.append(
                DataPoint(
                    x=float(x_arr[i]),
                    y=float(y_arr[i]),
                    size=float(sizes[i]) if sizes is not None else None,
                    label=labels[i] if labels is not None else None,
                )
            )
        return cls(id=id, name=name, data=points, color=color)

    @classmethod
    def from_values(cls, id: str, name: str, values: ArrayLike, *, labels: Optional[Sequence[str]] = None,
                     color: Optional[Color] = None) -> "Series":
        """Build a series from a single 1D array, using the index as x. This is what
        pie/donut slices and bar categories typically want."""
        arr = np.asarray(values, dtype=float)
        return cls.from_xy(id, name, np.arange(len(arr)), arr, labels=labels, color=color)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "data": [p.to_dict() for p in self.data],
            "color": self.color.to_dict() if self.color else None,
            "y_axis": self.y_axis.value,
            "visible": self.visible,
        }


@dataclass
class Axis:
    title: str = ""
    scale: ScaleType = ScaleType.LINEAR
    position: AxisPosition = AxisPosition.BOTTOM
    min: Optional[float] = None
    max: Optional[float] = None
    grid_visible: bool = True
    tick_count: int = 6
    category_labels: Optional[List[str]] = None

    def with_range(self, lo: float, hi: float) -> "Axis":
        self.min, self.max = float(lo), float(hi)
        return self

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "scale": self.scale.value,
            "position": self.position.value,
            "min": self.min,
            "max": self.max,
            "grid_visible": self.grid_visible,
            "tick_count": self.tick_count,
            "category_labels": self.category_labels,
        }


@dataclass
class Legend:
    visible: bool = True
    position: LegendPosition = LegendPosition.BOTTOM

    def to_dict(self) -> dict:
        return {"visible": self.visible, "position": self.position.value}


@dataclass
class Annotation:
    id: str
    kind: AnnotationKind
    x: float
    y: float
    text: str = ""
    color: Color = field(default_factory=lambda: Color.from_hex("#9A2E2E"))
    x2: Optional[float] = None
    y2: Optional[float] = None

    @classmethod
    def horizontal_line(cls, id: str, y: float, text: str = "", color: Optional[Color] = None) -> "Annotation":
        return cls(id=id, kind=AnnotationKind.HORIZONTAL_LINE, x=0.0, y=y, text=text,
                    color=color or Color.from_hex("#9A2E2E"))

    @classmethod
    def vertical_line(cls, id: str, x: float, text: str = "", color: Optional[Color] = None) -> "Annotation":
        return cls(id=id, kind=AnnotationKind.VERTICAL_LINE, x=x, y=0.0, text=text,
                    color=color or Color.from_hex("#9A2E2E"))

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "kind": self.kind.value,
            "x": float(self.x),
            "y": float(self.y),
            "x2": self.x2,
            "y2": self.y2,
            "text": self.text,
            "color": self.color.to_dict(),
        }
