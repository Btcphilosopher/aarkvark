"""Chart: the main user-facing chart object.

`sheet.chart(type="scatter", x="A1:A1000", y="B1:B1000", title=...)` (the API-design-goal
example from the spec) is implemented on `Worksheet`; this module is the `Chart` object
that call returns. Python owns chart *definition*; it MUST NOT implement rendering — every
render call here is delegated to the compiled Rust extension via `_native`.
"""
from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from . import _native
from .model import (
    Annotation, Axis, AxisPosition, ChartType, IMPLEMENTED_CHART_TYPES, Legend, Series,
)
from .theme import ANGLO_FUTURIST, Theme


class UnimplementedChartTypeError(RuntimeError):
    """Raised when a chart type is modeled but has no Rust-side geometry implementation
    yet (see `chart_core::ChartType::is_implemented`). Listed explicitly rather than
    letting a generic Rust panic/error surface, since "which chart types actually render"
    is exactly the kind of thing a caller needs a clean answer to."""


@dataclass
class Chart:
    chart_type: ChartType
    id: str = field(default_factory=lambda: f"chart-{uuid.uuid4().hex[:10]}")
    title: str = ""
    series: List[Series] = field(default_factory=list)
    x_axis: Axis = field(default_factory=lambda: Axis(position=AxisPosition.BOTTOM))
    y_axis: Axis = field(default_factory=lambda: Axis(position=AxisPosition.LEFT))
    secondary_y_axis: Optional[Axis] = None
    legend: Legend = field(default_factory=Legend)
    theme: Theme = field(default_factory=lambda: ANGLO_FUTURIST)
    annotations: List[Annotation] = field(default_factory=list)
    width_px: float = 1024.0
    height_px: float = 640.0
    # viewport overrides; None means "auto-fit to data" (computed Rust-side)
    x_min: Optional[float] = None
    x_max: Optional[float] = None
    y_min: Optional[float] = None
    y_max: Optional[float] = None
    animation_progress: float = 1.0

    # -- fluent builder methods -------------------------------------------------------

    def add_series(self, series: Series) -> "Chart":
        self.series.append(series)
        return self

    def add_annotation(self, annotation: Annotation) -> "Chart":
        self.annotations.append(annotation)
        return self

    def with_theme(self, theme: Theme) -> "Chart":
        self.theme = theme
        return self

    def with_size(self, width_px: float, height_px: float) -> "Chart":
        self.width_px, self.height_px = width_px, height_px
        return self

    def with_viewport(self, x_min: float, x_max: float, y_min: float, y_max: float) -> "Chart":
        self.x_min, self.x_max, self.y_min, self.y_max = x_min, x_max, y_min, y_max
        return self

    def at_animation_progress(self, progress: float) -> "Chart":
        """Return a shallow copy of this chart frozen at a given animation progress
        (0.0..1.0), for building enter-transition frame sequences."""
        import copy
        c = copy.copy(self)
        c.animation_progress = max(0.0, min(1.0, progress))
        return c

    # -- serialization ------------------------------------------------------------------

    def _viewport_dict(self) -> dict:
        if self.x_min is None or self.x_max is None or self.y_min is None or self.y_max is None:
            x_lo, x_hi, y_lo, y_hi = self._auto_viewport()
        else:
            x_lo, x_hi, y_lo, y_hi = self.x_min, self.x_max, self.y_min, self.y_max
        return {
            "x_min": x_lo, "x_max": x_hi, "y_min": y_lo, "y_max": y_hi,
            "width_px": self.width_px, "height_px": self.height_px,
        }

    def _auto_viewport(self):
        xs, ys = [], []
        for s in self.series:
            for p in s.data:
                xs.append(p.x)
                ys.append(p.y)
        if not xs:
            return (0.0, 1.0, 0.0, 1.0)
        x_lo, x_hi = min(xs), max(xs)
        y_lo, y_hi = min(ys), max(ys)
        if x_hi - x_lo < 1e-9:
            x_lo, x_hi = x_lo - 0.5, x_hi + 0.5
        if y_hi - y_lo < 1e-9:
            y_lo, y_hi = y_lo - 0.5, y_hi + 0.5
        pad = (y_hi - y_lo) * 0.1
        return (x_lo, x_hi, y_lo - pad, y_hi + pad)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "chart_type": self.chart_type.value,
            "series": [s.to_dict() for s in self.series],
            "x_axis": self.x_axis.to_dict(),
            "y_axis": self.y_axis.to_dict(),
            "secondary_y_axis": self.secondary_y_axis.to_dict() if self.secondary_y_axis else None,
            "legend": self.legend.to_dict(),
            "theme": self.theme.to_dict(),
            "annotations": [a.to_dict() for a in self.annotations],
            "viewport": self._viewport_dict(),
            "interaction": {"hovered_point": None, "selected_points": [], "brush": None},
            "animation": {"progress": self.animation_progress, "easing": "ease_out_cubic"},
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    # -- rendering (delegates to Rust) -------------------------------------------------

    def _check_implemented(self):
        if self.chart_type not in IMPLEMENTED_CHART_TYPES:
            raise UnimplementedChartTypeError(
                f"chart_type={self.chart_type.value!r} is modeled but has no Rust geometry "
                f"implementation yet. Implemented types: "
                f"{sorted(t.value for t in IMPLEMENTED_CHART_TYPES)}"
            )

    def render_png(self, path: Optional[str] = None) -> bytes:
        """Rasterize via the Rust engine and return PNG bytes (optionally also writing
        to `path`)."""
        self._check_implemented()
        native = _native.require_native()
        png_bytes = bytes(native.render_chart_png(self.to_json()))
        if path:
            with open(path, "wb") as f:
                f.write(png_bytes)
        return png_bytes

    def render_rgba(self) -> np.ndarray:
        """Rasterize via Rust and return an (H, W, 4) uint8 numpy array — useful for
        handing straight to a Qt QImage or matplotlib-free inline display."""
        self._check_implemented()
        native = _native.require_native()
        w, h, buf = native.render_chart_rgba(self.to_json())
        arr = np.frombuffer(bytes(buf), dtype=np.uint8)
        return arr.reshape((h, w, 4))

    def geometry_json(self) -> str:
        """The flattened, renderer-agnostic primitive list Rust actually drew, as JSON.
        Used by `export.to_svg` and for debugging/inspection."""
        self._check_implemented()
        native = _native.require_native()
        return native.chart_geometry_json(self.to_json())

    def validate(self) -> None:
        """Raise a clean exception if this chart can't be rendered, without actually
        rasterizing it."""
        self._check_implemented()
        native = _native.require_native()
        native.validate_chart(self.to_json())


def line_chart_from_arrays(
    title: str,
    series_name: str,
    x: np.ndarray,
    y: np.ndarray,
    *,
    width_px: float = 1024.0,
    height_px: float = 640.0,
    x_title: str = "",
    y_title: str = "",
) -> bytes:
    """Direct zero-copy path for very large series (the 1,000,000+ datapoint case): skips
    building a `Chart`/JSON round trip entirely and hands the numpy buffers straight to
    Rust. Returns PNG bytes. For anything under ~100k points, `Chart(...).render_png()` is
    simpler and the JSON overhead is negligible."""
    native = _native.require_native()
    x_arr = np.ascontiguousarray(x, dtype=np.float64)
    y_arr = np.ascontiguousarray(y, dtype=np.float64)
    return bytes(native.render_line_series_png(
        title, series_name, x_arr, y_arr, width_px, height_px, x_title, y_title
    ))
