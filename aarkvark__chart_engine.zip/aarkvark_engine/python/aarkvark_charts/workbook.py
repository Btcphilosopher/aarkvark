"""Workbook: top-level container tying worksheets, charts, and dashboards together —
the Excel-like entry point. `Workbook` doesn't render anything itself; it's bookkeeping
plus save/load of the whole project as JSON (cell values + formulas + chart definitions +
dashboard layouts, NOT the rendered pixels — those are always regenerated from source)."""
from __future__ import annotations

import json
from typing import Dict, List, Optional

from .chart import Chart
from .worksheet import Worksheet


class Workbook:
    def __init__(self, name: str = "Workbook"):
        self.name = name
        self.worksheets: Dict[str, Worksheet] = {}
        self.charts: Dict[str, Chart] = {}
        self.dashboards: Dict[str, "Dashboard"] = {}

    def add_worksheet(self, name: str) -> Worksheet:
        if name in self.worksheets:
            raise ValueError(f"worksheet {name!r} already exists")
        ws = Worksheet(name)
        self.worksheets[name] = ws
        return ws

    def worksheet(self, name: str) -> Worksheet:
        return self.worksheets[name]

    def add_chart(self, chart: Chart) -> Chart:
        self.charts[chart.id] = chart
        return chart

    def add_dashboard(self, dashboard: "Dashboard") -> "Dashboard":
        self.dashboards[dashboard.id] = dashboard
        return dashboard

    # -- persistence ---------------------------------------------------------------------

    def to_dict(self) -> dict:
        sheets = {}
        for name, ws in self.worksheets.items():
            ws._recalculate_if_dirty()
            sheets[name] = {
                "values": {k: v for k, v in ws._values.items() if k not in ws._formulas},
                "formulas": ws._formulas,
            }
        return {
            "name": self.name,
            "worksheets": sheets,
            "charts": {cid: c.to_dict() for cid, c in self.charts.items()},
        }

    def save_json(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load_json(cls, path: str) -> "Workbook":
        with open(path) as f:
            data = json.load(f)
        wb = cls(name=data.get("name", "Workbook"))
        for sheet_name, sheet_data in data.get("worksheets", {}).items():
            ws = wb.add_worksheet(sheet_name)
            for ref, value in sheet_data.get("values", {}).items():
                ws[ref] = value
            for ref, formula in sheet_data.get("formulas", {}).items():
                ws[ref] = f"={formula}"
        # Note: chart objects are intentionally not reconstructed from raw dicts here —
        # `Chart` is a live, renderable object tied to the theme/model classes, not just
        # data. Round-tripping full Chart objects is a documented next increment; for now
        # save_json/load_json round-trips the worksheets (the part with real state).
        return wb

    def __repr__(self) -> str:
        return f"Workbook(name={self.name!r}, worksheets={list(self.worksheets)}, charts={len(self.charts)})"
