"""Theme + Color: Python-side mirror of chart_core::model::{Color, Theme}.

Field names and the JSON shape here must match the Rust serde model exactly — this is
the contract the PyO3 bridge deserializes against.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import List


@dataclass(frozen=True)
class Color:
    r: int
    g: int
    b: int
    a: int = 255

    @classmethod
    def from_hex(cls, hex_str: str) -> "Color":
        h = hex_str.lstrip("#")
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        a = int(h[6:8], 16) if len(h) >= 8 else 255
        return cls(r, g, b, a)

    def to_hex(self) -> str:
        return f"#{self.r:02X}{self.g:02X}{self.b:02X}" + (f"{self.a:02X}" if self.a != 255 else "")

    def to_dict(self) -> dict:
        return {"r": self.r, "g": self.g, "b": self.b, "a": self.a}


@dataclass
class Theme:
    name: str
    background: Color
    foreground: Color
    grid_color: Color
    axis_color: Color
    palette: List[Color] = field(default_factory=list)
    font_family: str = "Bebas Neue"
    data_font_family: str = "DM Mono"

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "background": self.background.to_dict(),
            "foreground": self.foreground.to_dict(),
            "grid_color": self.grid_color.to_dict(),
            "axis_color": self.axis_color.to_dict(),
            "palette": [c.to_dict() for c in self.palette],
            "font_family": self.font_family,
            "data_font_family": self.data_font_family,
        }


# Tom's standing Anglo-futurist palette: near-black + gold + electric cyan.
ANGLO_FUTURIST = Theme(
    name="anglo-futurist",
    background=Color.from_hex("#0A0A0C"),
    foreground=Color.from_hex("#E8E6E1"),
    grid_color=Color.from_hex("#23232A"),
    axis_color=Color.from_hex("#4A4A52"),
    palette=[
        Color.from_hex("#C9A84C"),  # gold
        Color.from_hex("#00E5FF"),  # electric cyan
        Color.from_hex("#E8E6E1"),  # off-white
        Color.from_hex("#8C6E2F"),  # dark gold
        Color.from_hex("#0095A8"),  # dark cyan
        Color.from_hex("#9A2E2E"),  # signal red
    ],
    font_family="Bebas Neue",
    data_font_family="DM Mono",
)

# A light theme included for completeness — dashboards exported for print/PDF often want
# a white background, even on a project that otherwise lives in the dark palette.
LIGHT = Theme(
    name="light",
    background=Color.from_hex("#FFFFFF"),
    foreground=Color.from_hex("#1A1A1A"),
    grid_color=Color.from_hex("#E5E5E5"),
    axis_color=Color.from_hex("#9A9A9A"),
    palette=[
        Color.from_hex("#0F62FE"),
        Color.from_hex("#C9A84C"),
        Color.from_hex("#24A148"),
        Color.from_hex("#DA1E28"),
        Color.from_hex("#8A3FFC"),
    ],
    font_family="Helvetica",
    data_font_family="Menlo",
)

THEMES = {"anglo-futurist": ANGLO_FUTURIST, "light": LIGHT}
