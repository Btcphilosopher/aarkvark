"""aarkvark_charts: Python-first spreadsheet + chart + dashboard API.

    sheet.chart(type="scatter", x="A1:A1000", y="B1:B1000", title="Population Growth")

Python owns spreadsheet logic, chart definitions, dashboard composition, AI-assisted
schema inference, and the plugin layer. Rendering is delegated to the compiled Rust
extension (`aarkvark_native`, built from `rust/chart_pyo3`) — this package contains no
rasterization or GPU code of its own.
"""
from .chart import Chart, UnimplementedChartTypeError, line_chart_from_arrays
from .dashboard import (
    ChartWidget, Dashboard, EmbeddedWebViewWidget, FilterWidget, GridPosition,
    KpiCardWidget, MapWidget, TableWidget, TextWidget, Widget,
)
from .data_connector import DataConnector
from .model import (
    Annotation, AnnotationKind, Axis, AxisPosition, ChartType, DataPoint,
    IMPLEMENTED_CHART_TYPES, Legend, LegendPosition, ScaleType, Series, YAxisRef,
)
from .schema_inference import ColumnKind, ColumnProfile, SchemaReport, infer_schema, suggest_chart
from .theme import ANGLO_FUTURIST, Color, LIGHT, THEMES, Theme
from .workbook import Workbook
from .worksheet import Worksheet, CircularReferenceError, FormulaError
from . import export
from . import plugin

__version__ = "0.1.0"

__all__ = [
    "Chart", "UnimplementedChartTypeError", "line_chart_from_arrays",
    "Dashboard", "Widget", "ChartWidget", "KpiCardWidget", "TableWidget", "TextWidget",
    "MapWidget", "EmbeddedWebViewWidget", "FilterWidget", "GridPosition",
    "DataConnector",
    "Series", "DataPoint", "Axis", "Legend", "Annotation", "ChartType", "ScaleType",
    "AxisPosition", "LegendPosition", "AnnotationKind", "YAxisRef", "IMPLEMENTED_CHART_TYPES",
    "infer_schema", "suggest_chart", "SchemaReport", "ColumnProfile", "ColumnKind",
    "Theme", "Color", "ANGLO_FUTURIST", "LIGHT", "THEMES",
    "Workbook", "Worksheet", "CircularReferenceError", "FormulaError",
    "export", "plugin",
]
