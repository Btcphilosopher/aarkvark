"""Export: the spec's "Export (PNG, SVG, PDF, JSON)" feature, all four real.

PNG and JSON come straight from the Rust engine (`chart.render_png()` /
`chart.geometry_json()`). SVG is generated *here*, in Python, by walking the same flat
`Geometry` JSON the rasterizer consumes and emitting matching SVG elements — this is the
payoff of keeping geometry renderer-agnostic: a second, independent backend (vector SVG
instead of CPU-rasterized PNG) falls out of the architecture almost for free, with zero
chance of the two backends disagreeing on layout since they share the exact same input.
PDF wraps the rendered PNG via `img2pdf` (lossless, no re-encode) into a single-page PDF.
"""
from __future__ import annotations

import json
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .chart import Chart


def _color_to_svg(c: dict) -> str:
    return f"#{c['r']:02x}{c['g']:02x}{c['b']:02x}"


def _color_opacity(c: dict) -> float:
    return round(c.get("a", 255) / 255.0, 4)


def _points_attr(points) -> str:
    return " ".join(f"{x:.2f},{y:.2f}" for x, y in points)


def _escape_xml(s: str) -> str:
    return (
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace('"', "&quot;").replace("'", "&apos;")
    )


_ANCHOR_TO_SVG = {"start": "start", "middle": "middle", "end": "end"}


def geometry_to_svg(geometry_json: str) -> str:
    """Convert a `chart.geometry_json()` payload to a standalone SVG document."""
    geo = json.loads(geometry_json)
    width = geo["width_px"]
    height = geo["height_px"]
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:.0f}" height="{height:.0f}" '
        f'viewBox="0 0 {width:.0f} {height:.0f}">'
    ]

    for prim in geo["primitives"]:
        kind = prim["kind"]
        if kind == "rect":
            color = prim["color"]
            parts.append(
                f'<rect x="{prim["x"]:.2f}" y="{prim["y"]:.2f}" width="{prim["w"]:.2f}" '
                f'height="{prim["h"]:.2f}" fill="{_color_to_svg(color)}" '
                f'fill-opacity="{_color_opacity(color)}" />'
            )
        elif kind == "circle":
            color = prim["color"]
            parts.append(
                f'<circle cx="{prim["cx"]:.2f}" cy="{prim["cy"]:.2f}" r="{prim["r"]:.2f}" '
                f'fill="{_color_to_svg(color)}" fill-opacity="{_color_opacity(color)}" />'
            )
        elif kind == "filled_polygon":
            color = prim["color"]
            parts.append(
                f'<polygon points="{_points_attr(prim["points"])}" fill="{_color_to_svg(color)}" '
                f'fill-opacity="{_color_opacity(color)}" />'
            )
        elif kind == "polyline":
            color = prim["color"]
            parts.append(
                f'<polyline points="{_points_attr(prim["points"])}" fill="none" '
                f'stroke="{_color_to_svg(color)}" stroke-opacity="{_color_opacity(color)}" '
                f'stroke-width="{prim["width"]:.2f}" stroke-linecap="round" stroke-linejoin="round" />'
            )
        elif kind == "text":
            color = prim["color"]
            anchor = _ANCHOR_TO_SVG.get(prim["anchor"], "start")
            parts.append(
                f'<text x="{prim["x"]:.2f}" y="{prim["y"]:.2f}" font-size="{prim["size"]:.1f}" '
                f'font-family="DM Mono, monospace" text-anchor="{anchor}" '
                f'dominant-baseline="middle" fill="{_color_to_svg(color)}" '
                f'fill-opacity="{_color_opacity(color)}">{_escape_xml(prim["text"])}</text>'
            )
        # "group" never appears here — chart_core's geometry builder fully flattens
        # the scene graph before this JSON is produced.

    parts.append("</svg>")
    return "\n".join(parts)


def to_svg(chart: "Chart", path: Optional[str] = None) -> str:
    svg = geometry_to_svg(chart.geometry_json())
    if path:
        with open(path, "w") as f:
            f.write(svg)
    return svg


def to_pdf(chart: "Chart", path: str) -> None:
    """Single-page PDF wrapping the rasterized PNG. Uses `img2pdf` (pure-Python, no
    re-encoding/quality loss — it embeds the PNG bytes directly as a PDF image XObject)."""
    import img2pdf
    png_bytes = chart.render_png()
    with open(path, "wb") as f:
        f.write(img2pdf.convert(png_bytes))


def to_json(chart: "Chart", path: Optional[str] = None) -> str:
    """Export the chart's *definition* (not pixels) as JSON — round-trippable via
    `Chart.from_json`-equivalent on the Rust side, or just for inspection/diffing."""
    j = chart.to_json()
    if path:
        with open(path, "w") as f:
            f.write(j)
    return j
