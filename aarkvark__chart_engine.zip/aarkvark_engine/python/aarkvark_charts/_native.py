"""
Thin loader for the compiled Rust extension (`aarkvark_native`, built from
`rust/chart_pyo3` via maturin). Every rendering call in this package goes through here so
there is exactly one place that knows whether the native engine is present.

MUST NOT implement rendering logic in Python — per the architecture spec, this module's
only job is to import the compiled extension and give a clear, actionable error if it
hasn't been built yet (rather than a cryptic ImportError surfacing from deep inside
chart.py).
"""
from __future__ import annotations

_IMPORT_ERROR: Exception | None = None

try:
    import aarkvark_native as native  # type: ignore
except ImportError as exc:  # pragma: no cover - exercised only when the extension is missing
    native = None  # type: ignore
    _IMPORT_ERROR = exc


def require_native():
    """Return the loaded native module or raise a clear, actionable error."""
    if native is None:
        raise RuntimeError(
            "The aarkvark_native Rust extension is not built/importable. "
            "From rust/chart_pyo3, run: maturin develop --release "
            "(or `maturin build --release` + pip install the wheel). "
            f"Original import error: {_IMPORT_ERROR}"
        )
    return native


def is_available() -> bool:
    return native is not None
