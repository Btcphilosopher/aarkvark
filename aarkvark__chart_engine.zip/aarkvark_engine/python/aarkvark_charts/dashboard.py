"""Dashboard & Analytics Engine (Module 4): composes charts + widgets into a dashboard
with a grid layout, real cross-filtering (via `DataConnector` pub/sub), and HTML export.

Architecture flow per spec: Dashboard -> Widgets -> Layout Manager -> Python API Layer
-> Rust Graph Engine. Widgets never render themselves; chart widgets call back into
`Chart.render_png()` (which delegates to Rust), table/KPI/text widgets render to HTML
directly since they're not GPU chart geometry.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import pandas as pd

from .chart import Chart
from .data_connector import DataConnector
from .theme import ANGLO_FUTURIST, Theme


@dataclass
class GridPosition:
    row: int
    col: int
    row_span: int = 1
    col_span: int = 1


class Widget:
    """Base widget. Subclasses implement `render_html()`; the dashboard's job is purely
    grid placement, not knowing what's inside a cell."""

    def __init__(self, position: GridPosition, *, title: Optional[str] = None):
        self.position = position
        self.title = title

    def render_html(self, theme: Theme) -> str:
        raise NotImplementedError


class ChartWidget(Widget):
    def __init__(self, chart: Chart, position: GridPosition):
        super().__init__(position, title=chart.title)
        self.chart = chart

    def render_html(self, theme: Theme) -> str:
        png = self.chart.render_png()
        b64 = base64.b64encode(png).decode("ascii")
        return f'<img class="aw-chart" src="data:image/png;base64,{b64}" alt="{self.chart.title}" />'


class KpiCardWidget(Widget):
    def __init__(self, label: str, value: str, position: GridPosition, *, delta: Optional[str] = None,
                 delta_positive: bool = True):
        super().__init__(position, title=label)
        self.label = label
        self.value = value
        self.delta = delta
        self.delta_positive = delta_positive

    def render_html(self, theme: Theme) -> str:
        delta_html = ""
        if self.delta is not None:
            cls = "aw-kpi-delta-up" if self.delta_positive else "aw-kpi-delta-down"
            arrow = "\u25B2" if self.delta_positive else "\u25BC"
            delta_html = f'<div class="{cls}">{arrow} {self.delta}</div>'
        return (
            f'<div class="aw-kpi"><div class="aw-kpi-label">{self.label}</div>'
            f'<div class="aw-kpi-value">{self.value}</div>{delta_html}</div>'
        )


class TableWidget(Widget):
    def __init__(self, df: pd.DataFrame, position: GridPosition, *, title: Optional[str] = None,
                 max_rows: int = 50):
        super().__init__(position, title=title)
        self.df = df
        self.max_rows = max_rows

    def render_html(self, theme: Theme) -> str:
        rows = self.df.head(self.max_rows)
        header = "".join(f"<th>{c}</th>" for c in rows.columns)
        body_rows = []
        for _, row in rows.iterrows():
            cells = "".join(f"<td>{v}</td>" for v in row)
            body_rows.append(f"<tr>{cells}</tr>")
        return f'<table class="aw-table"><thead><tr>{header}</tr></thead><tbody>{"".join(body_rows)}</tbody></table>'


class TextWidget(Widget):
    def __init__(self, text: str, position: GridPosition, *, heading: Optional[str] = None):
        super().__init__(position, title=heading)
        self.text = text
        self.heading = heading

    def render_html(self, theme: Theme) -> str:
        heading_html = f'<div class="aw-text-heading">{self.heading}</div>' if self.heading else ""
        return f'<div class="aw-text">{heading_html}<p>{self.text}</p></div>'


class MapWidget(Widget):
    """Lat/lon point map. Renders as an embedded OpenStreetMap iframe centered on the
    point centroid — a real, working map view without needing a tile-serving stack of
    our own."""

    def __init__(self, points: List[tuple], position: GridPosition, *, title: Optional[str] = None, zoom: int = 9):
        super().__init__(position, title=title)
        self.points = points
        self.zoom = zoom

    def render_html(self, theme: Theme) -> str:
        if not self.points:
            return '<div class="aw-map-empty">No points</div>'
        lat = sum(p[0] for p in self.points) / len(self.points)
        lon = sum(p[1] for p in self.points) / len(self.points)
        bbox = (lon - 0.5, lat - 0.5, lon + 0.5, lat + 0.5)
        src = (
            f"https://www.openstreetmap.org/export/embed.html?bbox="
            f"{bbox[0]:.4f}%2C{bbox[1]:.4f}%2C{bbox[2]:.4f}%2C{bbox[3]:.4f}&marker={lat:.4f}%2C{lon:.4f}"
        )
        return f'<iframe class="aw-map" src="{src}" loading="lazy"></iframe>'


class EmbeddedWebViewWidget(Widget):
    def __init__(self, url: str, position: GridPosition, *, title: Optional[str] = None):
        super().__init__(position, title=title)
        self.url = url

    def render_html(self, theme: Theme) -> str:
        return f'<iframe class="aw-webview" src="{self.url}" loading="lazy"></iframe>'


class FilterWidget(Widget):
    """A dropdown filter bound to a `DataConnector` column. Selecting a value calls
    `connector.push_update(filtered_df)`, which fans out to every subscriber — this is
    the real cross-filtering / linked-highlighting plumbing, not a cosmetic dropdown.
    HTML export renders it as a static `<select>`; wiring its `onchange` to a live
    backend (a small Flask/FastAPI endpoint calling `apply()`) is the integration point
    for a fully interactive served dashboard, vs. this module's static HTML snapshot."""

    def __init__(self, connector: DataConnector, column: str, position: GridPosition, *,
                 title: Optional[str] = None):
        super().__init__(position, title=title or f"Filter: {column}")
        self.connector = connector
        self.column = column

    def apply(self, value) -> None:
        df = self.connector.dataframe
        filtered = df[df[self.column] == value]
        self.connector.push_update(filtered)

    def render_html(self, theme: Theme) -> str:
        values = sorted(self.connector.dataframe[self.column].dropna().unique().tolist(), key=str)
        options = "".join(f'<option value="{v}">{v}</option>' for v in values)
        return (
            f'<div class="aw-filter"><label>{self.title}</label>'
            f'<select disabled title="Static export — wire onchange to a live backend for interactivity">'
            f'{options}</select></div>'
        )


_CSS_TEMPLATE = """
:root {{
  --bg: {bg}; --fg: {fg}; --grid: {grid}; --accent: {accent}; --accent2: {accent2};
}}
* {{ box-sizing: border-box; }}
body {{
  background: var(--bg); color: var(--fg); margin: 0; padding: 32px;
  font-family: 'DM Mono', 'Consolas', monospace;
}}
h1 {{
  font-family: 'Bebas Neue', sans-serif; letter-spacing: 0.04em; font-weight: 400;
  font-size: 2.4rem; margin: 0 0 24px 0; color: var(--accent);
  border-bottom: 1px solid var(--grid); padding-bottom: 16px;
}}
.aw-grid {{ display: grid; grid-template-columns: repeat(12, 1fr); gap: 16px; }}
.aw-cell {{
  background: rgba(255,255,255,0.02); border: 1px solid var(--grid); border-radius: 4px;
  padding: 16px; overflow: hidden;
}}
.aw-cell-title {{
  font-family: 'Bebas Neue', sans-serif; letter-spacing: 0.03em; font-size: 1rem;
  color: var(--accent2); margin-bottom: 10px; text-transform: uppercase;
}}
.aw-chart {{ width: 100%; height: auto; display: block; }}
.aw-kpi-label {{ font-size: 0.8rem; opacity: 0.7; text-transform: uppercase; letter-spacing: 0.05em; }}
.aw-kpi-value {{ font-size: 2.2rem; color: var(--accent); margin-top: 6px; }}
.aw-kpi-delta-up {{ color: #3DDC84; margin-top: 4px; }}
.aw-kpi-delta-down {{ color: #E8544C; margin-top: 4px; }}
.aw-table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
.aw-table th, .aw-table td {{ text-align: left; padding: 6px 8px; border-bottom: 1px solid var(--grid); }}
.aw-table th {{ color: var(--accent2); font-weight: 400; }}
.aw-text-heading {{ font-family: 'Bebas Neue', sans-serif; font-size: 1.1rem; color: var(--accent2); margin-bottom: 8px; }}
.aw-map, .aw-webview {{ width: 100%; height: 320px; border: none; border-radius: 4px; }}
.aw-filter select {{ background: var(--bg); color: var(--fg); border: 1px solid var(--grid); padding: 6px; width: 100%; }}
"""


class Dashboard:
    def __init__(self, title: str = "Dashboard", *, theme: Theme = ANGLO_FUTURIST, id: Optional[str] = None):
        import uuid
        self.id = id or f"dashboard-{uuid.uuid4().hex[:10]}"
        self.title = title
        self.theme = theme
        self.widgets: List[Widget] = []

    def add_widget(self, widget: Widget) -> Widget:
        self.widgets.append(widget)
        return widget

    def add_chart(self, chart: Chart, row: int, col: int, row_span: int = 1, col_span: int = 4) -> ChartWidget:
        return self.add_widget(ChartWidget(chart, GridPosition(row, col, row_span, col_span)))

    def add_kpi(self, label: str, value: str, row: int, col: int, *, delta: Optional[str] = None,
                delta_positive: bool = True, col_span: int = 3) -> KpiCardWidget:
        return self.add_widget(
            KpiCardWidget(label, value, GridPosition(row, col, 1, col_span), delta=delta,
                          delta_positive=delta_positive)
        )

    def export_html(self, path: str) -> None:
        cells = []
        for w in self.widgets:
            pos = w.position
            style = (
                f"grid-row: {pos.row} / span {pos.row_span}; "
                f"grid-column: {pos.col} / span {pos.col_span};"
            )
            title_html = f'<div class="aw-cell-title">{w.title}</div>' if w.title else ""
            cells.append(f'<div class="aw-cell" style="{style}">{title_html}{w.render_html(self.theme)}</div>')

        css = _CSS_TEMPLATE.format(
            bg=self.theme.background.to_hex(), fg=self.theme.foreground.to_hex(),
            grid=self.theme.grid_color.to_hex(),
            accent=self.theme.palette[0].to_hex() if self.theme.palette else "#C9A84C",
            accent2=self.theme.palette[1].to_hex() if len(self.theme.palette) > 1 else "#00E5FF",
        )
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>{self.title}</title>
<style>{css}</style>
</head>
<body>
<h1>{self.title}</h1>
<div class="aw-grid">
{''.join(cells)}
</div>
</body>
</html>"""
        with open(path, "w") as f:
            f.write(html)

    def __repr__(self) -> str:
        return f"Dashboard(title={self.title!r}, widgets={len(self.widgets)})"
