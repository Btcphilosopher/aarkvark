"""Worksheet: the spreadsheet half of the API.

A real, working reactive cell engine — values, formulas (`=A1+B1*2`, `=SUM(A1:A10)`,
range references for charting), a dependency graph, and Kahn's-algorithm topological
recalculation, in the spirit of Tom's existing Aarkvark Cell Engine. This is what lets
`sheet.chart(x="A1:A1000", y="B1:B1000", ...)` from the spec's API-design-goal example
actually work: `"A1:A1000"` is parsed here and resolved to a numpy array of cell values.

Formula grammar (recursive-descent, operator precedence: `* /` then `+ -`, unary `-`,
parentheses, cell refs `A1`, ranges `A1:A10` only valid as function arguments):

    expr   := term (('+' | '-') term)*
    term   := factor (('*' | '/') factor)*
    factor := NUMBER | CELLREF | '(' expr ')' | '-' factor | FUNC '(' args ')'
    FUNC   := SUM | AVERAGE | MIN | MAX | COUNT
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Union

import numpy as np
import pandas as pd

_CELL_RE = re.compile(r"^([A-Z]+)(\d+)$")
_RANGE_RE = re.compile(r"^([A-Z]+\d+):([A-Z]+\d+)$")


def col_letters_to_index(letters: str) -> int:
    """A -> 0, B -> 1, ..., Z -> 25, AA -> 26, ..."""
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - ord("A") + 1)
    return n - 1


def col_index_to_letters(index: int) -> str:
    index += 1
    letters = ""
    while index > 0:
        index, rem = divmod(index - 1, 26)
        letters = chr(rem + ord("A")) + letters
    return letters


def parse_cell_ref(ref: str) -> tuple[int, int]:
    """'B3' -> (row=2, col=1), 0-indexed."""
    m = _CELL_RE.match(ref.strip().upper())
    if not m:
        raise ValueError(f"invalid cell reference: {ref!r}")
    col = col_letters_to_index(m.group(1))
    row = int(m.group(2)) - 1
    return row, col


def cell_ref(row: int, col: int) -> str:
    return f"{col_index_to_letters(col)}{row + 1}"


def parse_range(ref: str) -> tuple[tuple[int, int], tuple[int, int]]:
    """'A1:A1000' -> ((row0,col0),(row1,col1)), 0-indexed, inclusive."""
    m = _RANGE_RE.match(ref.strip().upper())
    if not m:
        raise ValueError(f"invalid range reference: {ref!r}")
    return parse_cell_ref(m.group(1)), parse_cell_ref(m.group(2))


class CircularReferenceError(RuntimeError):
    pass


class FormulaError(RuntimeError):
    pass


# ---------------------------------------------------------------------------------------
# Recursive-descent formula parser / evaluator
# ---------------------------------------------------------------------------------------

_TOKEN_RE = re.compile(
    r"""
    \s*(?:
        (?P<NUMBER>\d+\.\d+|\d+)
      | (?P<RANGE>[A-Z]+\d+:[A-Z]+\d+)
      | (?P<CELL>[A-Z]+\d+)
      | (?P<FUNC>SUM|AVERAGE|AVG|MIN|MAX|COUNT)(?=\()
      | (?P<LPAREN>\()
      | (?P<RPAREN>\))
      | (?P<COMMA>,)
      | (?P<PLUS>\+)
      | (?P<MINUS>-)
      | (?P<STAR>\*)
      | (?P<SLASH>/)
    )
    """,
    re.VERBOSE,
)


@dataclass
class _Token:
    kind: str
    value: str


def _tokenize(formula: str) -> List[_Token]:
    pos = 0
    tokens: List[_Token] = []
    s = formula.upper().replace(" ", "")
    # re-tokenize with whitespace stripped already; regex above tolerates \s* anyway
    text = formula.upper()
    i = 0
    while i < len(text):
        m = _TOKEN_RE.match(text, i)
        if not m or m.end() == i:
            if text[i].isspace():
                i += 1
                continue
            raise FormulaError(f"unexpected character {text[i]!r} in formula: {formula!r}")
        kind = m.lastgroup
        value = m.group(kind)
        tokens.append(_Token(kind, value))
        i = m.end()
    return tokens


class _Parser:
    """Parses a tokenized formula into a callable evaluator closure. References to other
    cells are resolved lazily through `resolve_cell`/`resolve_range`, which is what lets
    the worksheet detect dependencies (by recording every ref touched during a dry pass)
    before doing the real evaluation pass in topological order."""

    def __init__(self, tokens: List[_Token], resolve_cell, resolve_range):
        self.tokens = tokens
        self.pos = 0
        self.resolve_cell = resolve_cell
        self.resolve_range = resolve_range

    def _peek(self) -> Optional[_Token]:
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def _advance(self) -> _Token:
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def parse(self) -> float:
        value = self._expr()
        if self.pos != len(self.tokens):
            raise FormulaError(f"unexpected trailing tokens at position {self.pos}")
        return value

    def _expr(self) -> float:
        value = self._term()
        while self._peek() and self._peek().kind in ("PLUS", "MINUS"):
            op = self._advance().kind
            rhs = self._term()
            value = value + rhs if op == "PLUS" else value - rhs
        return value

    def _term(self) -> float:
        value = self._factor()
        while self._peek() and self._peek().kind in ("STAR", "SLASH"):
            op = self._advance().kind
            rhs = self._factor()
            if op == "SLASH":
                if rhs == 0:
                    raise FormulaError("division by zero")
                value = value / rhs
            else:
                value = value * rhs
        return value

    def _factor(self) -> float:
        tok = self._peek()
        if tok is None:
            raise FormulaError("unexpected end of formula")
        if tok.kind == "MINUS":
            self._advance()
            return -self._factor()
        if tok.kind == "NUMBER":
            self._advance()
            return float(tok.value)
        if tok.kind == "CELL":
            self._advance()
            return self.resolve_cell(tok.value)
        if tok.kind == "LPAREN":
            self._advance()
            value = self._expr()
            if not self._peek() or self._peek().kind != "RPAREN":
                raise FormulaError("missing closing parenthesis")
            self._advance()
            return value
        if tok.kind == "FUNC":
            return self._function_call()
        raise FormulaError(f"unexpected token {tok.kind} ({tok.value!r})")

    def _function_call(self) -> float:
        func = self._advance().value
        if not self._peek() or self._peek().kind != "LPAREN":
            raise FormulaError(f"expected '(' after {func}")
        self._advance()
        values: List[float] = []
        if self._peek() and self._peek().kind == "RANGE":
            values.extend(self.resolve_range(self._advance().value))
        else:
            values.append(self._expr())
        while self._peek() and self._peek().kind == "COMMA":
            self._advance()
            if self._peek() and self._peek().kind == "RANGE":
                values.extend(self.resolve_range(self._advance().value))
            else:
                values.append(self._expr())
        if not self._peek() or self._peek().kind != "RPAREN":
            raise FormulaError(f"missing closing parenthesis for {func}")
        self._advance()

        if func == "SUM":
            return float(sum(values))
        if func in ("AVERAGE", "AVG"):
            return float(sum(values) / len(values)) if values else 0.0
        if func == "MIN":
            return float(min(values)) if values else 0.0
        if func == "MAX":
            return float(max(values)) if values else 0.0
        if func == "COUNT":
            return float(len(values))
        raise FormulaError(f"unknown function {func}")


def _extract_refs(tokens: List[_Token]) -> tuple[Set[str], Set[str]]:
    """Returns (cell_refs, range_refs) touched by a formula's tokens — used to build the
    dependency graph without actually evaluating anything."""
    cells, ranges = set(), set()
    for t in tokens:
        if t.kind == "CELL":
            cells.add(t.value)
        elif t.kind == "RANGE":
            ranges.add(t.value)
    return cells, ranges


class Worksheet:
    """A single sheet of cells. Supports literal numbers/strings and `=`-prefixed
    formulas with cell refs, ranges, arithmetic, and SUM/AVERAGE/MIN/MAX/COUNT. Charts
    reference ranges by A1-notation string (`"A1:A1000"`), matching the spec's API-design
    example directly."""

    def __init__(self, name: str):
        self.name = name
        self._values: Dict[str, Union[float, str]] = {}
        self._formulas: Dict[str, str] = {}
        self._dirty = True

    # -- cell access ---------------------------------------------------------------------

    def __setitem__(self, ref: str, value: Union[float, str]) -> None:
        ref = ref.strip().upper()
        parse_cell_ref(ref)  # validates
        if isinstance(value, str) and value.startswith("="):
            self._formulas[ref] = value[1:]
            self._values.pop(ref, None)
        else:
            self._values[ref] = value
            self._formulas.pop(ref, None)
        self._dirty = True

    def __getitem__(self, ref: str) -> Union[float, str]:
        ref = ref.strip().upper()
        self._recalculate_if_dirty()
        if ref in self._values:
            return self._values[ref]
        raise KeyError(f"cell {ref} is empty")

    def set_range(self, top_left: str, values) -> None:
        """Bulk-write a 1D or 2D array of values starting at `top_left` (e.g. loading a
        DataFrame column into a column of cells)."""
        row0, col0 = parse_cell_ref(top_left)
        arr = np.asarray(values)
        if arr.ndim == 1:
            for i, v in enumerate(arr):
                self[cell_ref(row0 + i, col0)] = float(v) if not isinstance(v, str) else v
        elif arr.ndim == 2:
            for i in range(arr.shape[0]):
                for j in range(arr.shape[1]):
                    v = arr[i, j]
                    self[cell_ref(row0 + i, col0 + j)] = float(v) if not isinstance(v, str) else v
        else:
            raise ValueError("set_range only supports 1D or 2D arrays")

    def range(self, ref: str) -> np.ndarray:
        """Resolve an A1-notation range (e.g. `"A1:A1000"`) to a numpy array of its
        current values, recalculating formulas first if needed. This is what
        `Worksheet.chart(x="A1:A1000", ...)` calls internally."""
        self._recalculate_if_dirty()
        (r0, c0), (r1, c1) = parse_range(ref)
        rows = []
        for r in range(min(r0, r1), max(r0, r1) + 1):
            row_vals = []
            for c in range(min(c0, c1), max(c0, c1) + 1):
                cr = cell_ref(r, c)
                row_vals.append(self._values.get(cr, 0.0) if cr not in self._formulas else self._values.get(cr, 0.0))
            rows.append(row_vals)
        arr = np.array(rows, dtype=float)
        # Collapse to 1D when it's a single row or single column, which is the common
        # case for chart binding.
        if arr.shape[0] == 1:
            return arr[0]
        if arr.shape[1] == 1:
            return arr[:, 0]
        return arr

    def chart(
        self,
        type: str,
        x: str,
        y: str,
        title: str = "",
        *,
        name: Optional[str] = None,
        labels: Optional[str] = None,
    ):
        """The API-design-goal example from the spec, implemented directly:

            sheet.chart(type="scatter", x="A1:A1000", y="B1:B1000", title="Population Growth")

        `x`/`y` are A1-notation ranges resolved against this worksheet's current values
        (formulas recalculated first if dirty). Returns a `Chart` ready to
        `.render_png()`."""
        from .chart import Chart  # local import: chart.py doesn't need to import worksheet.py
        from .model import ChartType, Series

        x_vals = self.range(x)
        y_vals = self.range(y)
        label_vals = None
        if labels:
            label_vals = [str(v) for v in self.range(labels)]

        series = Series.from_xy(name or "series-0", name or f"{x} vs {y}", x_vals, y_vals, labels=label_vals)
        return Chart(chart_type=ChartType(type), title=title).add_series(series)



    @classmethod
    def from_dataframe(cls, name: str, df: pd.DataFrame, *, start_cell: str = "A1",
                        include_header: bool = True) -> "Worksheet":
        ws = cls(name)
        row0, col0 = parse_cell_ref(start_cell)
        if include_header:
            for j, col_name in enumerate(df.columns):
                ws[cell_ref(row0, col0 + j)] = str(col_name)
            row0 += 1
        for i in range(len(df)):
            for j, col_name in enumerate(df.columns):
                v = df.iloc[i, j]
                ws[cell_ref(row0 + i, col0 + j)] = float(v) if pd.api.types.is_number(v) else str(v)
        return ws

    def to_dataframe(self, range_ref: str, *, header: bool = True) -> pd.DataFrame:
        self._recalculate_if_dirty()
        (r0, c0), (r1, c1) = parse_range(range_ref)
        rows = []
        start_r = min(r0, r1)
        if header:
            start_r += 1
            columns = [self._values.get(cell_ref(min(r0, r1), c), "") for c in range(min(c0, c1), max(c0, c1) + 1)]
        else:
            columns = [col_index_to_letters(c) for c in range(min(c0, c1), max(c0, c1) + 1)]
        for r in range(start_r, max(r0, r1) + 1):
            rows.append([self._values.get(cell_ref(r, c), None) for c in range(min(c0, c1), max(c0, c1) + 1)])
        return pd.DataFrame(rows, columns=columns)

    # -- recalculation (Kahn's algorithm topological sort) ----------------------------

    def _recalculate_if_dirty(self) -> None:
        if not self._dirty:
            return
        self.recalculate()

    def recalculate(self) -> None:
        """Re-evaluate every formula cell in dependency order. Raises
        `CircularReferenceError` if the dependency graph has a cycle."""
        tokenized: Dict[str, List[_Token]] = {ref: _tokenize(f) for ref, f in self._formulas.items()}
        deps: Dict[str, Set[str]] = {}
        for ref, tokens in tokenized.items():
            cells, ranges = _extract_refs(tokens)
            cell_deps = set(cells)
            for rng in ranges:
                (r0, c0), (r1, c1) = parse_range(rng)
                for r in range(min(r0, r1), max(r0, r1) + 1):
                    for c in range(min(c0, c1), max(c0, c1) + 1):
                        cell_deps.add(cell_ref(r, c))
            deps[ref] = cell_deps

        # Kahn's algorithm: in-degree = number of unresolved formula dependencies.
        formula_refs = set(self._formulas.keys())
        in_degree = {ref: len(deps[ref] & formula_refs) for ref in formula_refs}
        # Edges point from a dependency to its dependents.
        dependents: Dict[str, Set[str]] = {ref: set() for ref in formula_refs}
        for ref, dep_set in deps.items():
            for d in dep_set & formula_refs:
                dependents[d].add(ref)

        queue = [ref for ref, deg in in_degree.items() if deg == 0]
        order: List[str] = []
        while queue:
            ref = queue.pop()
            order.append(ref)
            for dependent in dependents[ref]:
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        if len(order) != len(formula_refs):
            unresolved = formula_refs - set(order)
            raise CircularReferenceError(f"circular reference involving: {sorted(unresolved)}")

        for ref in order:
            value = self._evaluate_formula(ref, tokenized[ref])
            self._values[ref] = value

        self._dirty = False

    def _evaluate_formula(self, ref: str, tokens: List[_Token]) -> float:
        def resolve_cell(cell: str) -> float:
            if cell == ref:
                raise CircularReferenceError(f"{ref} references itself")
            v = self._values.get(cell, 0.0)
            return float(v) if not isinstance(v, str) else 0.0

        def resolve_range(rng: str) -> List[float]:
            (r0, c0), (r1, c1) = parse_range(rng)
            out = []
            for r in range(min(r0, r1), max(r0, r1) + 1):
                for c in range(min(c0, c1), max(c0, c1) + 1):
                    v = self._values.get(cell_ref(r, c), 0.0)
                    out.append(float(v) if not isinstance(v, str) else 0.0)
            return out

        try:
            return _Parser(tokens, resolve_cell, resolve_range).parse()
        except FormulaError as e:
            raise FormulaError(f"error evaluating {ref}: {e}") from e

    def __repr__(self) -> str:
        return f"Worksheet(name={self.name!r}, cells={len(self._values) + len(self._formulas)})"
