"""Plugin architecture: the spec's "Plugin architecture" / "extensible via plugins"
requirement.

A real registry + hook system: plugins register against named extension points
(`"before_render"`, `"after_data_load"`, `"chart_type"`, ...) and the engine calls them at
the right time. Two plugin shapes are supported:

  - Hook plugins: `@hooks.register("before_render")` decorate a function; it gets called
    with the chart (and can mutate/replace it) before rasterization.
  - Named component plugins: `@registry.register_chart_preprocessor("smooth")` for
    reusable, lookup-by-name building blocks (e.g. a data-smoothing step a dashboard
    widget can reference by name in config).
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any, Callable, Dict, List


class HookRegistry:
    """Pub/sub for named lifecycle hooks. `call(hook_name, *args)` invokes every
    registered callback in registration order and returns the list of return values
    (callbacks that return `None` are filtered, so a hook can either observe or
    transform — e.g. `before_render` callbacks that return a modified `Chart` get that
    chart passed to the next callback in the chain)."""

    def __init__(self):
        self._hooks: Dict[str, List[Callable]] = defaultdict(list)

    def register(self, hook_name: str):
        def decorator(fn: Callable):
            self._hooks[hook_name].append(fn)
            return fn
        return decorator

    def call(self, hook_name: str, value: Any = None, **kwargs) -> Any:
        """Pipe `value` through every registered callback for `hook_name` in order,
        threading the (possibly transformed) result forward. Returns the final value."""
        for fn in self._hooks.get(hook_name, []):
            result = fn(value, **kwargs)
            if result is not None:
                value = result
        return value

    def list_hooks(self, hook_name: str) -> List[Callable]:
        return list(self._hooks.get(hook_name, []))

    def clear(self, hook_name: str = None) -> None:
        if hook_name is None:
            self._hooks.clear()
        else:
            self._hooks.pop(hook_name, None)


class ComponentRegistry:
    """Named, lookup-by-string component registration — for things like reusable data
    preprocessors, custom export formats, or custom theme presets that other code
    (dashboard config, CLI flags) wants to reference by name rather than by import."""

    def __init__(self, kind: str):
        self.kind = kind
        self._components: Dict[str, Callable] = {}

    def register(self, name: str):
        def decorator(fn_or_cls):
            if name in self._components:
                raise ValueError(f"{self.kind} plugin {name!r} already registered")
            self._components[name] = fn_or_cls
            return fn_or_cls
        return decorator

    def get(self, name: str):
        if name not in self._components:
            raise KeyError(f"no {self.kind} plugin named {name!r}. Registered: {sorted(self._components)}")
        return self._components[name]

    def list(self) -> List[str]:
        return sorted(self._components)


# Module-level singletons — `from aarkvark_charts.plugin import hooks, preprocessors`
hooks = HookRegistry()
preprocessors = ComponentRegistry("preprocessor")
exporters = ComponentRegistry("exporter")
