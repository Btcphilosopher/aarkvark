# Example renders

Generated during this build, kept here as proof-of-output rather than just a claim:

- `demo_line.png`, `demo_bar.png`, `demo_donut.png` — output of `rust/chart_raster/examples/demo.rs`
- `spec_example_chart.png` — output of the spec's exact API example:
  `sheet.chart(type="scatter", x="A1:A1000", y="B1:B1000", title="Population Growth")`
- `native_1m.png` — the 1,000,000-point zero-copy-numpy stress test (0.63s render)
- `pyside_ui_screenshot.png` — the PySide6 desktop UI, captured offscreen, with a live
  Rust-rendered chart embedded in a real window

Run `cargo run -p chart_raster --example demo` from `rust/` to regenerate the first three.
