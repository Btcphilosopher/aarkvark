use chart_core::{Annotation, AnnotationKind, ChartBuilder, ChartType, Color, DataPoint, Series, ViewportState};
use chart_raster::render_chart_to_png;
use std::fs;

fn main() {
    // Line chart
    let series = Series::new(
        "revenue",
        "Revenue",
        vec![
            DataPoint::new(0.0, 120.0),
            DataPoint::new(1.0, 180.0),
            DataPoint::new(2.0, 150.0),
            DataPoint::new(3.0, 240.0),
            DataPoint::new(4.0, 310.0),
            DataPoint::new(5.0, 275.0),
            DataPoint::new(6.0, 340.0),
        ],
    );
    let series2 = Series::new(
        "costs",
        "Costs",
        vec![
            DataPoint::new(0.0, 80.0),
            DataPoint::new(1.0, 95.0),
            DataPoint::new(2.0, 110.0),
            DataPoint::new(3.0, 130.0),
            DataPoint::new(4.0, 140.0),
            DataPoint::new(5.0, 155.0),
            DataPoint::new(6.0, 160.0),
        ],
    );
    let chart = ChartBuilder::new("demo-line", ChartType::Line)
        .title("Dynasty Elite — Weekly Revenue vs Costs")
        .add_series(series)
        .add_series(series2)
        .add_annotation(Annotation {
            id: "target".into(),
            kind: AnnotationKind::HorizontalLine,
            x: 0.0,
            y: 300.0,
            x2: None,
            y2: None,
            text: "Target".into(),
            color: Color::from_hex("#9A2E2E").unwrap(),
        })
        .viewport(ViewportState::new(0.0, 6.0, 0.0, 400.0, 900.0, 560.0))
        .build();
    let png = render_chart_to_png(&chart).expect("render");
    fs::write("/home/claude/demo_line.png", png).unwrap();

    // Bar chart
    let bars = Series::new(
        "matches",
        "Wins",
        vec![
            DataPoint::new(0.0, 14.0),
            DataPoint::new(1.0, 22.0),
            DataPoint::new(2.0, 9.0),
            DataPoint::new(3.0, 31.0),
            DataPoint::new(4.0, 18.0),
        ],
    );
    let bar_chart = ChartBuilder::new("demo-bar", ChartType::Bar)
        .title("Season Wins by Roster Tier")
        .add_series(bars)
        .viewport(ViewportState::new(-0.5, 4.5, 0.0, 35.0, 800.0, 500.0))
        .build();
    let png2 = render_chart_to_png(&bar_chart).expect("render");
    fs::write("/home/claude/demo_bar.png", png2).unwrap();

    // Donut chart
    let slices = Series::new(
        "alloc",
        "Allocation",
        vec![
            DataPoint::new(0.0, 42.0).with_label("Offense"),
            DataPoint::new(0.0, 31.0).with_label("Defense"),
            DataPoint::new(0.0, 18.0).with_label("Scouting"),
            DataPoint::new(0.0, 9.0).with_label("Medical"),
        ],
    );
    let donut = ChartBuilder::new("demo-donut", ChartType::Donut)
        .title("Cap Space Allocation")
        .add_series(slices)
        .viewport(ViewportState::new(0.0, 1.0, 0.0, 1.0, 700.0, 600.0))
        .build();
    let png3 = render_chart_to_png(&donut).expect("render");
    fs::write("/home/claude/demo_donut.png", png3).unwrap();

    println!("wrote demo_line.png, demo_bar.png, demo_donut.png");
}
