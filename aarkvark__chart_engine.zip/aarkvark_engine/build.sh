#!/usr/bin/env bash
# One-shot build script: Rust workspace -> PyO3 extension -> Python package install.
# Run from the repo root.
set -euo pipefail

echo "==> Building Rust workspace (release)"
cd rust
cargo build --workspace --release
cargo test --workspace

echo "==> Building + installing the PyO3 extension into the active venv"
cd chart_pyo3
if [ -z "${VIRTUAL_ENV:-}" ]; then
  echo "No active virtualenv detected. Create one first:"
  echo "  python3 -m venv .venv && source .venv/bin/activate"
  exit 1
fi
pip install -q maturin numpy
maturin develop --release
cd ../..

echo "==> Installing the Python package (editable) + dependencies"
cd python
pip install -q -e .
pip install -q pytest
python -m pytest tests/ -q
cd ..

echo "==> Done. Try:"
echo "    python3 -c \"from aarkvark_charts import Chart, ChartType, Series; c=Chart(chart_type=ChartType.LINE,title='Hello').add_series(Series.from_xy('s','s',[0,1,2],[1,4,2])); c.render_png('hello.png')\""
