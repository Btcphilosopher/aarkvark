//! Real text rendering. Rather than hand-rolling glyph bitmaps (easy to get subtly wrong)
//! this uses `embedded-graphics`'s built-in monospace ASCII fonts: full glyph coverage,
//! MIT/Apache licensed, no font file to bundle. We implement `DrawTarget` for our `Canvas`
//! so glyph pixels land directly in the same RGBA buffer everything else draws into.

use chart_core::{Color, TextAnchor};
use embedded_graphics::{
    geometry::{OriginDimensions, Point, Size},
    mono_font::{ascii, MonoFont, MonoTextStyle},
    pixelcolor::{Rgb888, RgbColor},
    text::{Baseline, Text},
    Drawable, Pixel,
};

use crate::canvas::Canvas;

struct CanvasTarget<'a> {
    canvas: &'a mut Canvas,
}

impl<'a> embedded_graphics::draw_target::DrawTarget for CanvasTarget<'a> {
    type Color = Rgb888;
    type Error = core::convert::Infallible;

    fn draw_iter<I>(&mut self, pixels: I) -> Result<(), Self::Error>
    where
        I: IntoIterator<Item = Pixel<Self::Color>>,
    {
        for Pixel(point, color) in pixels {
            self.canvas.set_px(
                point.x,
                point.y,
                Color::rgb(color.r(), color.g(), color.b()),
            );
        }
        Ok(())
    }
}

impl<'a> OriginDimensions for CanvasTarget<'a> {
    fn size(&self) -> Size {
        Size::new(self.canvas.width, self.canvas.height)
    }
}

fn font_for_size(size: f32) -> &'static MonoFont<'static> {
    if size <= 9.0 {
        &ascii::FONT_5X8
    } else if size <= 11.0 {
        &ascii::FONT_6X10
    } else if size <= 14.0 {
        &ascii::FONT_8X13
    } else if size <= 17.0 {
        &ascii::FONT_9X15
    } else {
        &ascii::FONT_10X20
    }
}

/// Draw `text` at `(x, y)` with the given color/size/anchor. `x` is the anchor point per
/// `TextAnchor` (Start = left edge, Middle = horizontally centered, End = right edge); `y`
/// is the text's vertical center.
pub fn draw_text(canvas: &mut Canvas, x: f32, y: f32, text: &str, color: Color, size: f32, anchor: TextAnchor) {
    if text.is_empty() {
        return;
    }
    let font = font_for_size(size);
    let char_w = font.character_size.width as f32;
    let text_w = char_w * text.chars().count() as f32;

    let origin_x = match anchor {
        TextAnchor::Start => x,
        TextAnchor::Middle => x - text_w / 2.0,
        TextAnchor::End => x - text_w,
    };

    let style = MonoTextStyle::new(font, Rgb888::new(color.r, color.g, color.b));
    let mut target = CanvasTarget { canvas };
    let _ = Text::with_baseline(
        text,
        Point::new(origin_x.round() as i32, y.round() as i32),
        style,
        Baseline::Middle,
    )
    .draw(&mut target);
}
