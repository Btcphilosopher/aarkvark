//! CPU software rasterizer: the working "GPU Renderer (wgpu) -> Frame Output" stage of
//! the pipeline, implemented on the CPU so it runs anywhere with no GPU/display required.
//! It consumes the exact same `chart_core::Geometry` a wgpu vertex-buffer builder would,
//! so swapping in a real GPU backend later doesn't touch anything upstream.

pub mod canvas;
pub mod text;

use canvas::Canvas;
use chart_core::{build_geometry, Chart, ChartResult, Geometry, Primitive};
use std::io::Cursor;

#[derive(Debug, thiserror::Error)]
pub enum RasterError {
    #[error(transparent)]
    Chart(#[from] chart_core::ChartError),
    #[error("PNG encode error: {0}")]
    Encode(#[from] image::ImageError),
}

pub type RasterResult<T> = Result<T, RasterError>;

/// Walk a flattened `Geometry` and paint every primitive onto a fresh `Canvas`.
pub fn render_geometry_to_canvas(geo: &Geometry) -> Canvas {
    let mut canvas = Canvas::new(geo.width_px.round() as u32, geo.height_px.round() as u32, geo.background);
    for prim in &geo.primitives {
        match prim {
            Primitive::Rect { x, y, w, h, color } => canvas.fill_rect(*x, *y, *w, *h, *color),
            Primitive::Circle { cx, cy, r, color } => canvas.fill_circle(*cx, *cy, *r, *color),
            Primitive::FilledPolygon { points, color } => canvas.fill_polygon(points, *color),
            Primitive::Polyline { points, color, width } => canvas.draw_polyline(points, *width, *color),
            Primitive::Text { x, y, text, color, size, anchor } => {
                text::draw_text(&mut canvas, *x, *y, text, *color, *size, *anchor)
            }
            Primitive::Group { .. } => {
                debug_assert!(false, "geometry builder should have fully flattened the scene graph");
            }
        }
    }
    canvas
}

/// Build geometry for `chart` and rasterize straight to RGBA8 bytes (row-major, no
/// padding) plus dimensions. This is the function the PyO3 bridge calls when the caller
/// wants raw pixels (e.g. to hand to numpy) instead of an encoded image file.
pub fn render_chart_to_rgba(chart: &Chart) -> ChartResult<(u32, u32, Vec<u8>)> {
    let geo = build_geometry(chart)?;
    let canvas = render_geometry_to_canvas(&geo);
    let (w, h) = (canvas.width, canvas.height);
    Ok((w, h, canvas.buf.into_raw()))
}

/// Build geometry for `chart` and rasterize to encoded PNG bytes.
pub fn render_chart_to_png(chart: &Chart) -> RasterResult<Vec<u8>> {
    let geo = build_geometry(chart)?;
    let canvas = render_geometry_to_canvas(&geo);
    let mut bytes: Vec<u8> = Vec::new();
    let dyn_img = image::DynamicImage::ImageRgba8(canvas.buf);
    dyn_img.write_to(&mut Cursor::new(&mut bytes), image::ImageFormat::Png)?;
    Ok(bytes)
}

#[cfg(test)]
mod tests {
    use super::*;
    use chart_core::{ChartBuilder, ChartType, DataPoint, Series};

    fn sample_chart() -> Chart {
        let series = Series::new(
            "revenue",
            "Revenue",
            vec![
                DataPoint::new(0.0, 12.0),
                DataPoint::new(1.0, 28.0),
                DataPoint::new(2.0, 19.0),
                DataPoint::new(3.0, 44.0),
                DataPoint::new(4.0, 31.0),
            ],
        );
        ChartBuilder::new("c1", ChartType::Line)
            .title("Quarterly Revenue")
            .add_series(series)
            .viewport(chart_core::ViewportState::new(0.0, 4.0, 0.0, 50.0, 640.0, 400.0))
            .build()
    }

    #[test]
    fn renders_nonempty_png() {
        let chart = sample_chart();
        let png = render_chart_to_png(&chart).expect("render should succeed");
        assert!(png.len() > 100);
        // PNG magic bytes
        assert_eq!(&png[0..8], &[0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
    }

    #[test]
    fn rgba_buffer_has_expected_dimensions() {
        let chart = sample_chart();
        let (w, h, buf) = render_chart_to_rgba(&chart).expect("render should succeed");
        assert_eq!(w, 640);
        assert_eq!(h, 400);
        assert_eq!(buf.len(), (w * h * 4) as usize);
    }

    #[test]
    fn background_color_is_painted() {
        let chart = sample_chart();
        let (_, _, buf) = render_chart_to_rgba(&chart).expect("render should succeed");
        // Top-left corner pixel should match the theme background (no geometry drawn there).
        assert_eq!(&buf[0..3], &[0x0A, 0x0A, 0x0C]);
    }

    #[test]
    fn bar_chart_draws_visible_pixels_above_baseline() {
        let series = Series::new("s", "S", vec![DataPoint::new(0.0, 10.0), DataPoint::new(1.0, 5.0)]);
        let chart = ChartBuilder::new("c", ChartType::Bar).add_series(series).build();
        let (w, h, buf) = render_chart_to_rgba(&chart).expect("render should succeed");
        // Somewhere in the canvas a non-background pixel should exist (a bar was drawn).
        let bg = [0x0Au8, 0x0A, 0x0C];
        let mut found_non_bg = false;
        for px in buf.chunks(4) {
            if px[0..3] != bg {
                found_non_bg = true;
                break;
            }
        }
        assert!(found_non_bg, "expected at least one non-background pixel ({w}x{h} canvas)");
    }
}
