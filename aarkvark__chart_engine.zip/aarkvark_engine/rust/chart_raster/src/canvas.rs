//! A plain RGBA pixel canvas with the handful of fill primitives the rasterizer needs:
//! rects, antialiasing-free filled circles, scanline-filled polygons, and thick lines
//! (drawn as filled quads so they share the polygon fill rather than needing a separate
//! Bresenham path). Every primitive alpha-blends onto the existing buffer.

use chart_core::Color;
use image::{Rgba, RgbaImage};

pub struct Canvas {
    pub width: u32,
    pub height: u32,
    pub buf: RgbaImage,
}

fn to_rgba(c: Color) -> Rgba<u8> {
    Rgba([c.r, c.g, c.b, c.a])
}

fn alpha_blend(bg: Rgba<u8>, fg: Color) -> Rgba<u8> {
    if fg.a == 255 {
        return Rgba([fg.r, fg.g, fg.b, 255]);
    }
    let a = fg.a as f32 / 255.0;
    let r = (fg.r as f32 * a + bg[0] as f32 * (1.0 - a)).round() as u8;
    let g = (fg.g as f32 * a + bg[1] as f32 * (1.0 - a)).round() as u8;
    let b = (fg.b as f32 * a + bg[2] as f32 * (1.0 - a)).round() as u8;
    Rgba([r, g, b, 255])
}

impl Canvas {
    pub fn new(width: u32, height: u32, background: Color) -> Self {
        let mut buf = RgbaImage::new(width.max(1), height.max(1));
        let bg = to_rgba(background);
        for px in buf.pixels_mut() {
            *px = bg;
        }
        Self { width: width.max(1), height: height.max(1), buf }
    }

    #[inline]
    pub fn set_px(&mut self, x: i32, y: i32, color: Color) {
        if x < 0 || y < 0 || x as u32 >= self.width || y as u32 >= self.height || color.a == 0 {
            return;
        }
        let existing = *self.buf.get_pixel(x as u32, y as u32);
        self.buf.put_pixel(x as u32, y as u32, alpha_blend(existing, color));
    }

    pub fn fill_rect(&mut self, x: f32, y: f32, w: f32, h: f32, color: Color) {
        let x0 = x.floor().max(0.0) as i32;
        let y0 = y.floor().max(0.0) as i32;
        let x1 = (x + w).ceil().min(self.width as f32) as i32;
        let y1 = (y + h).ceil().min(self.height as f32) as i32;
        for py in y0..y1 {
            for px in x0..x1 {
                self.set_px(px, py, color);
            }
        }
    }

    pub fn fill_circle(&mut self, cx: f32, cy: f32, r: f32, color: Color) {
        if r <= 0.0 {
            return;
        }
        let x0 = (cx - r).floor().max(0.0) as i32;
        let x1 = (cx + r).ceil().min(self.width as f32) as i32;
        let y0 = (cy - r).floor().max(0.0) as i32;
        let y1 = (cy + r).ceil().min(self.height as f32) as i32;
        let r2 = r * r;
        for py in y0..y1 {
            for px in x0..x1 {
                let dx = px as f32 + 0.5 - cx;
                let dy = py as f32 + 0.5 - cy;
                if dx * dx + dy * dy <= r2 {
                    self.set_px(px, py, color);
                }
            }
        }
    }

    /// Even-odd scanline fill. Used both for actual filled-polygon primitives (area
    /// charts, pie wedges) and as the rasterization strategy for thick lines.
    pub fn fill_polygon(&mut self, points: &[(f32, f32)], color: Color) {
        if points.len() < 3 {
            return;
        }
        let min_y = points.iter().map(|p| p.1).fold(f32::INFINITY, f32::min).floor().max(0.0) as i32;
        let max_y = points
            .iter()
            .map(|p| p.1)
            .fold(f32::NEG_INFINITY, f32::max)
            .ceil()
            .min(self.height as f32) as i32;
        let n = points.len();

        for y in min_y..max_y {
            let yf = y as f32 + 0.5;
            let mut xs: Vec<f32> = Vec::new();
            for i in 0..n {
                let (x0, y0) = points[i];
                let (x1, y1) = points[(i + 1) % n];
                if (y0 <= yf && y1 > yf) || (y1 <= yf && y0 > yf) {
                    let t = (yf - y0) / (y1 - y0);
                    xs.push(x0 + t * (x1 - x0));
                }
            }
            xs.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let mut i = 0;
            while i + 1 < xs.len() {
                let x_start = xs[i].round().max(0.0) as i32;
                let x_end = xs[i + 1].round().min(self.width as f32) as i32;
                for x in x_start..x_end {
                    self.set_px(x, y, color);
                }
                i += 2;
            }
        }
    }

    /// A single thick line segment, drawn as a filled quad along the segment direction
    /// plus round joins (small filled circles) at each endpoint so segment chains in a
    /// polyline don't show gaps at the joints.
    pub fn draw_thick_line(&mut self, p0: (f32, f32), p1: (f32, f32), width: f32, color: Color) {
        let dx = p1.0 - p0.0;
        let dy = p1.1 - p0.1;
        let len = (dx * dx + dy * dy).sqrt();
        if len < 1e-6 {
            self.fill_circle(p0.0, p0.1, width / 2.0, color);
            return;
        }
        let hw = width / 2.0;
        let nx = -dy / len * hw;
        let ny = dx / len * hw;
        let quad = [
            (p0.0 + nx, p0.1 + ny),
            (p1.0 + nx, p1.1 + ny),
            (p1.0 - nx, p1.1 - ny),
            (p0.0 - nx, p0.1 - ny),
        ];
        self.fill_polygon(&quad, color);
        self.fill_circle(p0.0, p0.1, hw, color);
        self.fill_circle(p1.0, p1.1, hw, color);
    }

    pub fn draw_polyline(&mut self, points: &[(f32, f32)], width: f32, color: Color) {
        for w in points.windows(2) {
            self.draw_thick_line(w[0], w[1], width, color);
        }
    }
}
