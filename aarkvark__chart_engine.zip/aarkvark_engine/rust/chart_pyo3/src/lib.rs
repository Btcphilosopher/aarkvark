//! PyO3 bindings: the only point where Python and Rust actually meet.
//!
//! Two ingestion paths, deliberately:
//!  - `render_chart_png` / `render_chart_rgba` / `chart_geometry_json` take a JSON-encoded
//!    `Chart` (built on the Python side from Workbook/Worksheet/Chart objects). Simple,
//!    flexible, handles every chart type/theme/annotation option — but pays a
//!    serialize/deserialize cost, fine for chart *configuration* which is small.
//!  - `render_line_series_png` takes the bulk numeric series data as numpy arrays via
//!    `PyReadonlyArray1`, which hands Rust a direct view into the numpy buffer with no
//!    copy. This is the path that matters for the "1,000,000+ datapoints" target: large
//!    series never get serialized to JSON and back.

use chart_core::{
    Axis, AxisPosition, Chart, ChartBuilder, ChartType, DataPoint, Series, ViewportState,
};
use numpy::PyReadonlyArray1;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyBytes;

fn chart_from_json(json: &str) -> PyResult<Chart> {
    Chart::from_json(json).map_err(|e| PyValueError::new_err(format!("invalid chart JSON: {e}")))
}

fn raster_err_to_py(e: chart_raster::RasterError) -> PyErr {
    PyValueError::new_err(e.to_string())
}

fn chart_err_to_py(e: chart_core::ChartError) -> PyErr {
    PyValueError::new_err(e.to_string())
}

/// Render a `Chart` (passed as JSON, as produced by `chart.to_json()` on the Python side)
/// to PNG bytes.
#[pyfunction]
fn render_chart_png<'py>(py: Python<'py>, chart_json: &str) -> PyResult<&'py PyBytes> {
    let chart = chart_from_json(chart_json)?;
    let png = chart_raster::render_chart_to_png(&chart).map_err(raster_err_to_py)?;
    Ok(PyBytes::new(py, &png))
}

/// Render a `Chart` (JSON) straight to a raw RGBA8 buffer: `(width, height, bytes)`.
/// The Python side wraps `bytes` with `np.frombuffer(...).reshape(h, w, 4)` — no PNG
/// encode/decode round trip when the caller just wants pixels (e.g. for a Qt QImage).
#[pyfunction]
fn render_chart_rgba<'py>(py: Python<'py>, chart_json: &str) -> PyResult<(u32, u32, &'py PyBytes)> {
    let chart = chart_from_json(chart_json)?;
    let (w, h, buf) = chart_raster::render_chart_to_rgba(&chart).map_err(chart_err_to_py)?;
    Ok((w, h, PyBytes::new(py, &buf)))
}

/// Validate a `Chart` (JSON) is renderable without actually rasterizing it — used by the
/// Python API to give a clean exception immediately on `sheet.chart(...)` rather than
/// only failing later at export/display time.
#[pyfunction]
fn validate_chart(chart_json: &str) -> PyResult<()> {
    let chart = chart_from_json(chart_json)?;
    chart_core::build_geometry(&chart).map_err(chart_err_to_py)?;
    Ok(())
}

/// Build the chart's geometry (every drawn primitive, in pixel space, draw order) and
/// return it as JSON — the "Export ... JSON" path.
#[pyfunction]
fn chart_geometry_json(chart_json: &str) -> PyResult<String> {
    let chart = chart_from_json(chart_json)?;
    chart_core::geometry_to_json(&chart).map_err(chart_err_to_py)
}

/// Zero-copy line-chart render: `x`/`y` are numpy float64 arrays read directly from their
/// underlying buffer (no Python-side `tolist()`, no JSON serialization of the data). Chart
/// chrome (title, axis titles, canvas size) comes in as plain scalars since that's tiny.
/// This is the function the Python API calls for `sheet.chart(type="line", x=..., y=...)`
/// on large series.
#[pyfunction]
#[pyo3(signature = (title, series_name, x, y, width_px=1024.0, height_px=640.0, x_title="".to_string(), y_title="".to_string()))]
fn render_line_series_png<'py>(
    py: Python<'py>,
    title: &str,
    series_name: &str,
    x: PyReadonlyArray1<f64>,
    y: PyReadonlyArray1<f64>,
    width_px: f64,
    height_px: f64,
    x_title: String,
    y_title: String,
) -> PyResult<&'py PyBytes> {
    let x_slice = x.as_slice().map_err(|_| PyValueError::new_err("x array must be contiguous"))?;
    let y_slice = y.as_slice().map_err(|_| PyValueError::new_err("y array must be contiguous"))?;
    if x_slice.len() != y_slice.len() {
        return Err(PyValueError::new_err(format!(
            "x and y length mismatch: x={} y={}",
            x_slice.len(),
            y_slice.len()
        )));
    }
    if x_slice.is_empty() {
        return Err(PyValueError::new_err("x/y arrays must not be empty"));
    }

    // The one copy that's unavoidable: chart_core::DataPoint pairs (x, y) per element, so
    // building the Vec<DataPoint> does have to walk the numpy buffers once. What's avoided
    // is the JSON round trip — for a million points that's the difference that matters.
    let data: Vec<DataPoint> = x_slice
        .iter()
        .zip(y_slice.iter())
        .map(|(&xv, &yv)| DataPoint::new(xv, yv))
        .collect();

    let series = Series::new("series-0", series_name, data);
    let x_min = x_slice.iter().cloned().fold(f64::INFINITY, f64::min);
    let x_max = x_slice.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    let y_min = y_slice.iter().cloned().fold(f64::INFINITY, f64::min);
    let y_max = y_slice.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    let y_pad = ((y_max - y_min) * 0.1).max(1e-9);

    let chart: Chart = ChartBuilder::new("zero-copy-line", ChartType::Line)
        .title(title)
        .add_series(series)
        .x_axis(Axis::new(x_title, AxisPosition::Bottom))
        .y_axis(Axis::new(y_title, AxisPosition::Left))
        .viewport(ViewportState::new(x_min, x_max, y_min - y_pad, y_max + y_pad, width_px, height_px))
        .build();

    let png = chart_raster::render_chart_to_png(&chart).map_err(raster_err_to_py)?;
    Ok(PyBytes::new(py, &png))
}

#[pyfunction]
fn native_version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

#[pymodule]
fn aarkvark_native(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(render_chart_png, m)?)?;
    m.add_function(wrap_pyfunction!(render_chart_rgba, m)?)?;
    m.add_function(wrap_pyfunction!(validate_chart, m)?)?;
    m.add_function(wrap_pyfunction!(chart_geometry_json, m)?)?;
    m.add_function(wrap_pyfunction!(render_line_series_png, m)?)?;
    m.add_function(wrap_pyfunction!(native_version, m)?)?;
    Ok(())
}
