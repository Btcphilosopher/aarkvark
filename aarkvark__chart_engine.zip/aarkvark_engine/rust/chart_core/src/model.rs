//! Immutable, serializable chart model.
//!
//! Every type here is plain data (Clone + Serialize + Deserialize). Charts are built via
//! `ChartBuilder` and, once built, are immutable: any "mutation" (pan, zoom, hover, select)
//! returns a *new* `Chart` value with the relevant state swapped out. This makes charts safe
//! to hand across the PyO3 boundary, cache, diff, and replay without aliasing bugs.

use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------------------------
// Color / Theme
// ---------------------------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Color {
    pub r: u8,
    pub g: u8,
    pub b: u8,
    pub a: u8,
}

impl Color {
    pub const fn rgb(r: u8, g: u8, b: u8) -> Self {
        Self { r, g, b, a: 255 }
    }

    pub const fn rgba(r: u8, g: u8, b: u8, a: u8) -> Self {
        Self { r, g, b, a }
    }

    /// Parse a `#RRGGBB` or `#RRGGBBAA` hex string.
    pub fn from_hex(hex: &str) -> Option<Self> {
        let h = hex.trim_start_matches('#');
        let r = u8::from_str_radix(h.get(0..2)?, 16).ok()?;
        let g = u8::from_str_radix(h.get(2..4)?, 16).ok()?;
        let b = u8::from_str_radix(h.get(4..6)?, 16).ok()?;
        let a = if h.len() >= 8 {
            u8::from_str_radix(h.get(6..8)?, 16).ok()?
        } else {
            255
        };
        Some(Self { r, g, b, a })
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Theme {
    pub name: String,
    pub background: Color,
    pub foreground: Color,
    pub grid_color: Color,
    pub axis_color: Color,
    pub palette: Vec<Color>,
    pub font_family: String,
    pub data_font_family: String,
}

impl Default for Theme {
    /// Tom's Anglo-futurist theme: near-black background, gold + electric cyan accents.
    fn default() -> Self {
        Self {
            name: "anglo-futurist".to_string(),
            background: Color::from_hex("#0A0A0C").unwrap(),
            foreground: Color::from_hex("#E8E6E1").unwrap(),
            grid_color: Color::from_hex("#23232A").unwrap(),
            axis_color: Color::from_hex("#4A4A52").unwrap(),
            palette: vec![
                Color::from_hex("#C9A84C").unwrap(), // gold
                Color::from_hex("#00E5FF").unwrap(), // electric cyan
                Color::from_hex("#E8E6E1").unwrap(), // off-white
                Color::from_hex("#8C6E2F").unwrap(), // dark gold
                Color::from_hex("#0095A8").unwrap(), // dark cyan
                Color::from_hex("#9A2E2E").unwrap(), // signal red
            ],
            font_family: "Bebas Neue".to_string(),
            data_font_family: "DM Mono".to_string(),
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Chart type
// ---------------------------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ChartType {
    Line,
    Area,
    Spline,
    Bar,
    Column,
    StackedBar,
    StackedColumn,
    Scatter,
    Bubble,
    Pie,
    Donut,
    Histogram,
    Heatmap,
    Candlestick,
    Ohlc,
    Radar,
    Polar,
    Treemap,
    Sunburst,
    Sankey,
    Network,
    Gantt,
    Timeline,
    Surface3D,
}

impl ChartType {
    /// Chart types with a real, working layout + geometry implementation in this build.
    /// Everything else is modeled (you can construct and serialize it) but geometry
    /// generation returns `ChartError::UnimplementedChartType` rather than faking output.
    pub fn is_implemented(self) -> bool {
        matches!(
            self,
            ChartType::Line
                | ChartType::Area
                | ChartType::Spline
                | ChartType::Bar
                | ChartType::Column
                | ChartType::Scatter
                | ChartType::Bubble
                | ChartType::Histogram
                | ChartType::Pie
                | ChartType::Donut
        )
    }

    pub fn is_cartesian(self) -> bool {
        matches!(
            self,
            ChartType::Line
                | ChartType::Area
                | ChartType::Spline
                | ChartType::Bar
                | ChartType::Column
                | ChartType::StackedBar
                | ChartType::StackedColumn
                | ChartType::Scatter
                | ChartType::Bubble
                | ChartType::Histogram
                | ChartType::Heatmap
                | ChartType::Candlestick
                | ChartType::Ohlc
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Data points / series
// ---------------------------------------------------------------------------------------------

/// A single data point. `size` and `label` are optional and only consumed by chart types
/// that use them (bubble uses `size`, pie/donut use `label` + `y` as the slice value).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DataPoint {
    pub x: f64,
    pub y: f64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub size: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub label: Option<String>,
}

impl DataPoint {
    pub fn new(x: f64, y: f64) -> Self {
        Self { x, y, size: None, label: None }
    }

    pub fn with_size(mut self, size: f64) -> Self {
        self.size = Some(size);
        self
    }

    pub fn with_label(mut self, label: impl Into<String>) -> Self {
        self.label = Some(label.into());
        self
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum YAxisRef {
    Primary,
    Secondary,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Series {
    pub id: String,
    pub name: String,
    pub data: Vec<DataPoint>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub color: Option<Color>,
    pub y_axis: YAxisRef,
    pub visible: bool,
}

impl Series {
    pub fn new(id: impl Into<String>, name: impl Into<String>, data: Vec<DataPoint>) -> Self {
        Self {
            id: id.into(),
            name: name.into(),
            data,
            color: None,
            y_axis: YAxisRef::Primary,
            visible: true,
        }
    }

    pub fn with_color(mut self, color: Color) -> Self {
        self.color = Some(color);
        self
    }

    pub fn on_secondary_axis(mut self) -> Self {
        self.y_axis = YAxisRef::Secondary;
        self
    }

    pub fn x_range(&self) -> Option<(f64, f64)> {
        if self.data.is_empty() {
            return None;
        }
        let mut lo = f64::INFINITY;
        let mut hi = f64::NEG_INFINITY;
        for p in &self.data {
            lo = lo.min(p.x);
            hi = hi.max(p.x);
        }
        Some((lo, hi))
    }

    pub fn y_range(&self) -> Option<(f64, f64)> {
        if self.data.is_empty() {
            return None;
        }
        let mut lo = f64::INFINITY;
        let mut hi = f64::NEG_INFINITY;
        for p in &self.data {
            lo = lo.min(p.y);
            hi = hi.max(p.y);
        }
        Some((lo, hi))
    }
}

// ---------------------------------------------------------------------------------------------
// Axes / legend / grid / annotations
// ---------------------------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ScaleType {
    Linear,
    Logarithmic,
    Category,
    Time,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AxisPosition {
    Bottom,
    Top,
    Left,
    Right,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Axis {
    pub title: String,
    pub scale: ScaleType,
    pub position: AxisPosition,
    /// Explicit min/max. `None` means "auto-fit to data" at layout time.
    pub min: Option<f64>,
    pub max: Option<f64>,
    pub grid_visible: bool,
    pub tick_count: usize,
    pub category_labels: Option<Vec<String>>,
}

impl Axis {
    pub fn new(title: impl Into<String>, position: AxisPosition) -> Self {
        Self {
            title: title.into(),
            scale: ScaleType::Linear,
            position,
            min: None,
            max: None,
            grid_visible: true,
            tick_count: 6,
            category_labels: None,
        }
    }

    pub fn with_range(mut self, min: f64, max: f64) -> Self {
        self.min = Some(min);
        self.max = Some(max);
        self
    }

    pub fn with_scale(mut self, scale: ScaleType) -> Self {
        self.scale = scale;
        self
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LegendPosition {
    Top,
    Bottom,
    Left,
    Right,
    None,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Legend {
    pub visible: bool,
    pub position: LegendPosition,
}

impl Default for Legend {
    fn default() -> Self {
        Self { visible: true, position: LegendPosition::Bottom }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AnnotationKind {
    Text,
    HorizontalLine,
    VerticalLine,
    Rect,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Annotation {
    pub id: String,
    pub kind: AnnotationKind,
    pub x: f64,
    pub y: f64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub x2: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub y2: Option<f64>,
    pub text: String,
    pub color: Color,
}

// ---------------------------------------------------------------------------------------------
// Viewport / interaction / animation state
// ---------------------------------------------------------------------------------------------

/// The visible data-space window plus the pixel-space canvas it maps onto. Pan/zoom mutate
/// this and *only* this — the underlying `Chart` data never changes from interaction.
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct ViewportState {
    pub x_min: f64,
    pub x_max: f64,
    pub y_min: f64,
    pub y_max: f64,
    pub width_px: f64,
    pub height_px: f64,
}

impl ViewportState {
    pub fn new(x_min: f64, x_max: f64, y_min: f64, y_max: f64, width_px: f64, height_px: f64) -> Self {
        Self { x_min, x_max, y_min, y_max, width_px, height_px }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Default)]
pub struct InteractionState {
    /// (series_id, point_index)
    pub hovered_point: Option<(String, usize)>,
    pub selected_points: Vec<(String, usize)>,
    /// Brush selection rectangle in data space: (x0, y0, x1, y1)
    pub brush: Option<(f64, f64, f64, f64)>,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Easing {
    Linear,
    EaseInOut,
    EaseOutCubic,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct AnimationState {
    /// 0.0 (start) ..= 1.0 (complete)
    pub progress: f64,
    pub easing: Easing,
}

impl Default for AnimationState {
    fn default() -> Self {
        Self { progress: 1.0, easing: Easing::EaseOutCubic }
    }
}

// ---------------------------------------------------------------------------------------------
// Chart
// ---------------------------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Chart {
    pub id: String,
    pub title: String,
    pub chart_type: ChartType,
    pub series: Vec<Series>,
    pub x_axis: Axis,
    pub y_axis: Axis,
    pub secondary_y_axis: Option<Axis>,
    pub legend: Legend,
    pub theme: Theme,
    pub annotations: Vec<Annotation>,
    pub viewport: ViewportState,
    pub interaction: InteractionState,
    pub animation: AnimationState,
}

impl Chart {
    /// Returns a new chart with the viewport replaced (used for pan/zoom). The chart's
    /// data and styling are untouched — this is the immutable-update pattern used
    /// throughout: state transitions produce new values rather than mutating in place.
    pub fn with_viewport(&self, viewport: ViewportState) -> Self {
        let mut next = self.clone();
        next.viewport = viewport;
        next
    }

    pub fn with_interaction(&self, interaction: InteractionState) -> Self {
        let mut next = self.clone();
        next.interaction = interaction;
        next
    }

    pub fn with_animation_progress(&self, progress: f64) -> Self {
        let mut next = self.clone();
        next.animation.progress = progress.clamp(0.0, 1.0);
        next
    }

    pub fn to_json(&self) -> crate::error::ChartResult<String> {
        Ok(serde_json::to_string(self)?)
    }

    pub fn from_json(s: &str) -> crate::error::ChartResult<Self> {
        Ok(serde_json::from_str(s)?)
    }
}

/// Builder for `Chart`. Charts are immutable once built; this is the only mutable
/// construction path.
pub struct ChartBuilder {
    id: String,
    title: String,
    chart_type: ChartType,
    series: Vec<Series>,
    x_axis: Axis,
    y_axis: Axis,
    secondary_y_axis: Option<Axis>,
    legend: Legend,
    theme: Theme,
    annotations: Vec<Annotation>,
    viewport: Option<ViewportState>,
}

impl ChartBuilder {
    pub fn new(id: impl Into<String>, chart_type: ChartType) -> Self {
        Self {
            id: id.into(),
            title: String::new(),
            chart_type,
            series: Vec::new(),
            x_axis: Axis::new("", AxisPosition::Bottom),
            y_axis: Axis::new("", AxisPosition::Left),
            secondary_y_axis: None,
            legend: Legend::default(),
            theme: Theme::default(),
            annotations: Vec::new(),
            viewport: None,
        }
    }

    pub fn title(mut self, title: impl Into<String>) -> Self {
        self.title = title.into();
        self
    }

    pub fn add_series(mut self, series: Series) -> Self {
        self.series.push(series);
        self
    }

    pub fn x_axis(mut self, axis: Axis) -> Self {
        self.x_axis = axis;
        self
    }

    pub fn y_axis(mut self, axis: Axis) -> Self {
        self.y_axis = axis;
        self
    }

    pub fn secondary_y_axis(mut self, axis: Axis) -> Self {
        self.secondary_y_axis = Some(axis);
        self
    }

    pub fn legend(mut self, legend: Legend) -> Self {
        self.legend = legend;
        self
    }

    pub fn theme(mut self, theme: Theme) -> Self {
        self.theme = theme;
        self
    }

    pub fn add_annotation(mut self, annotation: Annotation) -> Self {
        self.annotations.push(annotation);
        self
    }

    pub fn viewport(mut self, viewport: ViewportState) -> Self {
        self.viewport = Some(viewport);
        self
    }

    pub fn build(self) -> Chart {
        let viewport = self.viewport.unwrap_or_else(|| {
            // Auto-fit viewport from series data, defaulting to a unit window if there's
            // no data yet so the chart is still constructible (e.g. live-data charts that
            // start empty and stream in points).
            let mut x_min = f64::INFINITY;
            let mut x_max = f64::NEG_INFINITY;
            let mut y_min = f64::INFINITY;
            let mut y_max = f64::NEG_INFINITY;
            for s in &self.series {
                if let Some((lo, hi)) = s.x_range() {
                    x_min = x_min.min(lo);
                    x_max = x_max.max(hi);
                }
                if let Some((lo, hi)) = s.y_range() {
                    y_min = y_min.min(lo);
                    y_max = y_max.max(hi);
                }
            }
            if !x_min.is_finite() || !x_max.is_finite() || (x_max - x_min).abs() < f64::EPSILON {
                x_min = 0.0;
                x_max = 1.0;
            }
            if !y_min.is_finite() || !y_max.is_finite() || (y_max - y_min).abs() < f64::EPSILON {
                y_min = 0.0;
                y_max = 1.0;
            }
            // Pad y range 10% so points don't sit flush against the plot edge.
            let pad = (y_max - y_min) * 0.1;
            ViewportState::new(x_min, x_max, y_min - pad, y_max + pad, 1024.0, 640.0)
        });

        Chart {
            id: self.id,
            title: self.title,
            chart_type: self.chart_type,
            series: self.series,
            x_axis: self.x_axis,
            y_axis: self.y_axis,
            secondary_y_axis: self.secondary_y_axis,
            legend: self.legend,
            theme: self.theme,
            annotations: self.annotations,
            viewport,
            interaction: InteractionState::default(),
            animation: AnimationState::default(),
        }
    }
}
