//! Scene graph: a tree of drawable nodes built from a `Chart` + its `Layout`.
//!
//! Grouping nodes (background, grid, series, legend, annotations) gives later stages
//! (hit-testing, per-group transforms, partial re-render on interaction) a structure to
//! walk instead of a flat soup of primitives. The geometry builder flattens this tree into
//! renderer-agnostic `Primitive`s.

use crate::layout::Layout;
use crate::model::{
    AnnotationKind, Chart, ChartType, Color, LegendPosition, YAxisRef,
};

#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize)]
#[serde(rename_all = "snake_case")]
pub enum TextAnchor {
    Start,
    Middle,
    End,
}

#[derive(Debug, Clone, PartialEq, serde::Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum SceneNode {
    Group { label: &'static str, children: Vec<SceneNode> },
    Polyline { points: Vec<(f32, f32)>, color: Color, width: f32 },
    FilledPolygon { points: Vec<(f32, f32)>, color: Color },
    Rect { x: f32, y: f32, w: f32, h: f32, color: Color },
    Circle { cx: f32, cy: f32, r: f32, color: Color },
    Text { x: f32, y: f32, text: String, color: Color, size: f32, anchor: TextAnchor },
}

fn group(label: &'static str, children: Vec<SceneNode>) -> SceneNode {
    SceneNode::Group { label, children }
}

fn background_node(chart: &Chart, layout: &Layout) -> SceneNode {
    SceneNode::Rect {
        x: 0.0,
        y: 0.0,
        w: layout.viewport.width_px as f32,
        h: layout.viewport.height_px as f32,
        color: chart.theme.background,
    }
}

fn grid_node(chart: &Chart, layout: &Layout) -> SceneNode {
    let mut lines = Vec::new();
    if chart.x_axis.grid_visible {
        for tick in &layout.x_ticks {
            let px = layout.map_x(tick.value) as f32;
            lines.push(SceneNode::Polyline {
                points: vec![(px, layout.plot_y0 as f32), (px, layout.plot_y1 as f32)],
                color: chart.theme.grid_color,
                width: 1.0,
            });
        }
    }
    if chart.y_axis.grid_visible {
        for tick in &layout.y_ticks {
            let py = layout.map_y(tick.value) as f32;
            lines.push(SceneNode::Polyline {
                points: vec![(layout.plot_x0 as f32, py), (layout.plot_x1 as f32, py)],
                color: chart.theme.grid_color,
                width: 1.0,
            });
        }
    }
    group("grid", lines)
}

fn axes_node(chart: &Chart, layout: &Layout) -> SceneNode {
    let mut children = vec![
        SceneNode::Polyline {
            points: vec![
                (layout.plot_x0 as f32, layout.plot_y1 as f32),
                (layout.plot_x1 as f32, layout.plot_y1 as f32),
            ],
            color: chart.theme.axis_color,
            width: 1.5,
        },
        SceneNode::Polyline {
            points: vec![
                (layout.plot_x0 as f32, layout.plot_y0 as f32),
                (layout.plot_x0 as f32, layout.plot_y1 as f32),
            ],
            color: chart.theme.axis_color,
            width: 1.5,
        },
    ];

    for tick in &layout.x_ticks {
        let px = layout.map_x(tick.value) as f32;
        children.push(SceneNode::Text {
            x: px,
            y: layout.plot_y1 as f32 + 18.0,
            text: tick.label.clone(),
            color: chart.theme.foreground,
            size: 11.0,
            anchor: TextAnchor::Middle,
        });
    }
    for tick in &layout.y_ticks {
        let py = layout.map_y(tick.value) as f32;
        children.push(SceneNode::Text {
            x: layout.plot_x0 as f32 - 10.0,
            y: py,
            text: tick.label.clone(),
            color: chart.theme.foreground,
            size: 11.0,
            anchor: TextAnchor::End,
        });
    }

    if !chart.x_axis.title.is_empty() {
        children.push(SceneNode::Text {
            x: ((layout.plot_x0 + layout.plot_x1) / 2.0) as f32,
            y: layout.viewport.height_px as f32 - 8.0,
            text: chart.x_axis.title.clone(),
            color: chart.theme.foreground,
            size: 13.0,
            anchor: TextAnchor::Middle,
        });
    }

    group("axes", children)
}

fn title_node(chart: &Chart, layout: &Layout) -> SceneNode {
    if chart.title.is_empty() {
        return group("title", vec![]);
    }
    group(
        "title",
        vec![SceneNode::Text {
            x: (layout.viewport.width_px / 2.0) as f32,
            y: 28.0,
            text: chart.title.clone(),
            color: chart.theme.foreground,
            size: 20.0,
            anchor: TextAnchor::Middle,
        }],
    )
}

fn series_color(chart: &Chart, index: usize, override_color: Option<Color>) -> Color {
    override_color.unwrap_or_else(|| {
        let palette = &chart.theme.palette;
        palette[index % palette.len().max(1)]
    })
}

fn cartesian_series_nodes(chart: &Chart, layout: &Layout) -> SceneNode {
    let mut groups = Vec::new();
    // Animation progress scales how far along each series is drawn / grown, giving the
    // renderer a single knob to drive enter/update transitions.
    let progress = chart.animation.progress.clamp(0.0, 1.0);

    for (i, series) in chart.series.iter().enumerate() {
        if !series.visible || series.data.is_empty() {
            continue;
        }
        let color = series_color(chart, i, series.color);
        let n_visible = ((series.data.len() as f64) * progress).ceil() as usize;
        let visible_data = &series.data[..n_visible.min(series.data.len())];

        let mapped: Vec<(f32, f32)> = visible_data
            .iter()
            .map(|p| (layout.map_x(p.x) as f32, layout.map_y(p.y) as f32))
            .collect();

        let baseline_y = layout.map_y(layout.viewport.y_min.max(0.0).min(layout.viewport.y_max)) as f32;

        let mut nodes = Vec::new();
        match chart.chart_type {
            ChartType::Line | ChartType::Spline => {
                if mapped.len() >= 2 {
                    nodes.push(SceneNode::Polyline { points: mapped.clone(), color, width: 2.5 });
                }
                for p in &mapped {
                    nodes.push(SceneNode::Circle { cx: p.0, cy: p.1, r: 3.0, color });
                }
            }
            ChartType::Area => {
                if mapped.len() >= 2 {
                    let mut poly = mapped.clone();
                    poly.push((mapped.last().unwrap().0, baseline_y));
                    poly.push((mapped.first().unwrap().0, baseline_y));
                    let fill = Color::rgba(color.r, color.g, color.b, 90);
                    nodes.push(SceneNode::FilledPolygon { points: poly, color: fill });
                    nodes.push(SceneNode::Polyline { points: mapped.clone(), color, width: 2.0 });
                }
            }
            ChartType::Bar | ChartType::Column | ChartType::Histogram => {
                let n = visible_data.len().max(1);
                let bar_w = (layout.plot_width() as f32 / (series.data.len().max(1)) as f32) * 0.7;
                for (j, p) in mapped.iter().enumerate() {
                    let x = p.0 - bar_w / 2.0;
                    let y = p.1.min(baseline_y);
                    let h = (p.1 - baseline_y).abs();
                    nodes.push(SceneNode::Rect { x, y, w: bar_w, h, color });
                    let _ = (j, n);
                }
            }
            ChartType::Scatter => {
                for p in &mapped {
                    nodes.push(SceneNode::Circle { cx: p.0, cy: p.1, r: 4.0, color });
                }
            }
            ChartType::Bubble => {
                for (p, dp) in mapped.iter().zip(visible_data.iter()) {
                    let r = (dp.size.unwrap_or(5.0) as f32).clamp(2.0, 60.0);
                    let fill = Color::rgba(color.r, color.g, color.b, 160);
                    nodes.push(SceneNode::Circle { cx: p.0, cy: p.1, r, color: fill });
                }
            }
            _ => {} // unimplemented cartesian types are rejected earlier in build_geometry
        }

        // Hover/selection highlight ring.
        for (idx, p) in mapped.iter().enumerate() {
            let is_hovered = chart.interaction.hovered_point.as_ref()
                == Some(&(series.id.clone(), idx));
            let is_selected = chart
                .interaction
                .selected_points
                .iter()
                .any(|(sid, sidx)| sid == &series.id && *sidx == idx);
            if is_hovered || is_selected {
                nodes.push(SceneNode::Circle {
                    cx: p.0,
                    cy: p.1,
                    r: 7.0,
                    color: chart.theme.palette.get(1).copied().unwrap_or(color),
                });
            }
        }

        let label = if series.y_axis == YAxisRef::Secondary { "series-secondary" } else { "series" };
        groups.push(group(label, nodes));
    }
    group("series", groups)
}

fn pie_series_nodes(chart: &Chart, layout: &Layout) -> SceneNode {
    let cx = ((layout.plot_x0 + layout.plot_x1) / 2.0) as f32;
    let cy = ((layout.plot_y0 + layout.plot_y1) / 2.0) as f32;
    let r = (layout.plot_width().min(layout.plot_height()) as f32 / 2.0) * 0.85;
    let inner_r = if chart.chart_type == ChartType::Donut { r * 0.55 } else { 0.0 };

    let mut nodes = Vec::new();
    if let Some(series) = chart.series.first() {
        let total: f64 = series.data.iter().map(|p| p.y.max(0.0)).sum();
        if total <= 0.0 {
            return group("pie", nodes);
        }
        let progress = chart.animation.progress.clamp(0.0, 1.0);
        let mut start_angle = -std::f64::consts::FRAC_PI_2; // 12 o'clock
        for (i, p) in series.data.iter().enumerate() {
            let frac = (p.y.max(0.0) / total) * progress;
            let sweep = frac * std::f64::consts::TAU;
            let end_angle = start_angle + sweep;
            let color = series_color(chart, i, series.color);
            nodes.push(wedge_polygon(cx, cy, r, inner_r, start_angle as f32, end_angle as f32, color));
            start_angle = end_angle;
        }
    }
    group("pie", nodes)
}

fn wedge_polygon(cx: f32, cy: f32, r: f32, inner_r: f32, a0: f32, a1: f32, color: Color) -> SceneNode {
    const SEGMENTS_PER_RAD: f32 = 24.0;
    let n = (((a1 - a0).abs() * SEGMENTS_PER_RAD).ceil() as usize).max(2);
    let mut points = Vec::with_capacity(n * 2 + 2);
    for i in 0..=n {
        let t = a0 + (a1 - a0) * (i as f32 / n as f32);
        points.push((cx + r * t.cos(), cy + r * t.sin()));
    }
    if inner_r > 0.0 {
        for i in (0..=n).rev() {
            let t = a0 + (a1 - a0) * (i as f32 / n as f32);
            points.push((cx + inner_r * t.cos(), cy + inner_r * t.sin()));
        }
    } else {
        points.push((cx, cy));
    }
    SceneNode::FilledPolygon { points, color }
}

fn legend_node(chart: &Chart, layout: &Layout) -> SceneNode {
    if !chart.legend.visible || chart.legend.position == LegendPosition::None {
        return group("legend", vec![]);
    }
    let names: Vec<(usize, String, Option<Color>)> = if chart.chart_type == ChartType::Pie
        || chart.chart_type == ChartType::Donut
    {
        chart
            .series
            .first()
            .map(|s| {
                s.data
                    .iter()
                    .enumerate()
                    .map(|(i, p)| (i, p.label.clone().unwrap_or_else(|| format!("Slice {i}")), None))
                    .collect()
            })
            .unwrap_or_default()
    } else {
        chart
            .series
            .iter()
            .enumerate()
            .map(|(i, s)| (i, s.name.clone(), s.color))
            .collect()
    };

    let mut nodes = Vec::new();
    let swatch = 10.0_f32;
    let row_h = 20.0_f32;
    let start_y = layout.plot_y1 as f32 + 36.0;
    for (row, (i, name, override_color)) in names.iter().enumerate() {
        let color = series_color(chart, *i, *override_color);
        let x = layout.plot_x0 as f32 + (row as f32 % 4.0) * 180.0;
        let y = start_y + (row as f32 / 4.0).floor() * row_h;
        nodes.push(SceneNode::Rect { x, y: y - swatch, w: swatch, h: swatch, color });
        nodes.push(SceneNode::Text {
            x: x + swatch + 6.0,
            y,
            text: name.clone(),
            color: chart.theme.foreground,
            size: 11.0,
            anchor: TextAnchor::Start,
        });
    }
    group("legend", nodes)
}

fn annotations_node(chart: &Chart, layout: &Layout) -> SceneNode {
    let mut nodes = Vec::new();
    for a in &chart.annotations {
        match a.kind {
            AnnotationKind::HorizontalLine => {
                let y = layout.map_y(a.y) as f32;
                nodes.push(SceneNode::Polyline {
                    points: vec![(layout.plot_x0 as f32, y), (layout.plot_x1 as f32, y)],
                    color: a.color,
                    width: 1.5,
                });
            }
            AnnotationKind::VerticalLine => {
                let x = layout.map_x(a.x) as f32;
                nodes.push(SceneNode::Polyline {
                    points: vec![(x, layout.plot_y0 as f32), (x, layout.plot_y1 as f32)],
                    color: a.color,
                    width: 1.5,
                });
            }
            AnnotationKind::Rect => {
                let (x0, y0) = (layout.map_x(a.x) as f32, layout.map_y(a.y) as f32);
                let (x1, y1) = (
                    layout.map_x(a.x2.unwrap_or(a.x)) as f32,
                    layout.map_y(a.y2.unwrap_or(a.y)) as f32,
                );
                nodes.push(SceneNode::Rect {
                    x: x0.min(x1),
                    y: y0.min(y1),
                    w: (x1 - x0).abs(),
                    h: (y1 - y0).abs(),
                    color: Color::rgba(a.color.r, a.color.g, a.color.b, 60),
                });
            }
            AnnotationKind::Text => {}
        }
        if !a.text.is_empty() {
            nodes.push(SceneNode::Text {
                x: layout.map_x(a.x) as f32,
                y: layout.map_y(a.y) as f32 - 8.0,
                text: a.text.clone(),
                color: a.color,
                size: 11.0,
                anchor: TextAnchor::Start,
            });
        }
    }
    group("annotations", nodes)
}

/// Build the full scene graph for a chart at its current layout/interaction/animation state.
pub fn build_scene(chart: &Chart, layout: &Layout) -> SceneNode {
    let is_radial = matches!(chart.chart_type, ChartType::Pie | ChartType::Donut);
    let series = if is_radial {
        pie_series_nodes(chart, layout)
    } else {
        cartesian_series_nodes(chart, layout)
    };

    let mut children = vec![background_node(chart, layout)];
    if !is_radial {
        children.push(grid_node(chart, layout));
    }
    children.push(series);
    if !is_radial {
        children.push(axes_node(chart, layout));
    }
    children.push(title_node(chart, layout));
    children.push(legend_node(chart, layout));
    children.push(annotations_node(chart, layout));

    group("root", children)
}
