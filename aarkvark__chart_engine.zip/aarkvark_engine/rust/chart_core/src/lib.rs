//! `chart_core`: the immutable chart model, layout engine, scene graph, and geometry
//! builder. Renderer-agnostic on purpose — `chart_raster` (CPU) and any future wgpu
//! backend both consume the same `Geometry` produced here.

pub mod error;
pub mod geometry;
pub mod layout;
pub mod model;
pub mod scene;

pub use error::{ChartError, ChartResult};
pub use geometry::{build_geometry, build_geometry_with_margins, geometry_to_json, Geometry, Primitive};
pub use layout::{compute_layout, Layout, Margins, Tick};
pub use model::*;
pub use scene::{SceneNode, TextAnchor};
