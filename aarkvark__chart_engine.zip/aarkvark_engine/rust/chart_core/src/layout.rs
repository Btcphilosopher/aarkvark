//! Layout engine: turns a `Chart` + its `ViewportState` into pixel-space coordinates.
//!
//! This is pure data-in/data-out — no rendering, no GPU, no I/O. The same `Layout` value
//! is what both the CPU rasterizer (`chart_raster`) and, eventually, the wgpu renderer
//! consume, so the math only has to be right once.

use crate::model::{Axis, Chart, ScaleType, ViewportState};

/// Pixel-space margins reserved for axis titles, tick labels, and the legend.
#[derive(Debug, Clone, Copy)]
pub struct Margins {
    pub top: f64,
    pub right: f64,
    pub bottom: f64,
    pub left: f64,
}

impl Default for Margins {
    fn default() -> Self {
        Self { top: 56.0, right: 32.0, bottom: 64.0, left: 72.0 }
    }
}

/// A computed tick: position in data space + the label to draw.
#[derive(Debug, Clone, PartialEq, serde::Serialize)]
pub struct Tick {
    pub value: f64,
    pub label: String,
}

/// The plot area in pixel space, plus the data <-> pixel mapping functions for both axes.
#[derive(Debug, Clone, serde::Serialize)]
pub struct Layout {
    pub plot_x0: f64,
    pub plot_y0: f64,
    pub plot_x1: f64,
    pub plot_y1: f64,
    pub x_ticks: Vec<Tick>,
    pub y_ticks: Vec<Tick>,
    pub viewport: ViewportState,
}

impl Layout {
    /// Map a data-space x to a pixel-space x within the plot area.
    pub fn map_x(&self, x: f64) -> f64 {
        let t = (x - self.viewport.x_min) / (self.viewport.x_max - self.viewport.x_min);
        self.plot_x0 + t * (self.plot_x1 - self.plot_x0)
    }

    /// Map a data-space y to a pixel-space y within the plot area. Pixel-space y grows
    /// downward (image convention), so this is inverted relative to `map_x`.
    pub fn map_y(&self, y: f64) -> f64 {
        let t = (y - self.viewport.y_min) / (self.viewport.y_max - self.viewport.y_min);
        self.plot_y1 - t * (self.plot_y1 - self.plot_y0)
    }

    pub fn plot_width(&self) -> f64 {
        self.plot_x1 - self.plot_x0
    }

    pub fn plot_height(&self) -> f64 {
        self.plot_y1 - self.plot_y0
    }
}

/// "Nice number" tick generation (Heckbert's algorithm): produces human-friendly tick
/// spacing (1, 2, 5, 10, 20, 50...) rather than raw `range / count` fractions.
pub fn nice_ticks(min: f64, max: f64, target_count: usize) -> Vec<f64> {
    if !min.is_finite() || !max.is_finite() || max <= min || target_count == 0 {
        return vec![min];
    }
    let range = nice_number(max - min, false);
    let spacing = nice_number(range / (target_count.max(1) as f64 - 1.0).max(1.0), true);
    let nice_min = (min / spacing).floor() * spacing;
    let nice_max = (max / spacing).ceil() * spacing;

    let mut ticks = Vec::new();
    let mut v = nice_min;
    // Guard against pathological float spacing producing runaway loops.
    let max_iters = (target_count + 4) * 4;
    let mut i = 0;
    while v <= nice_max + spacing * 0.5 && i < max_iters {
        ticks.push(round_to_precision(v, spacing));
        v += spacing;
        i += 1;
    }
    ticks
}

fn nice_number(range: f64, round: bool) -> f64 {
    if range <= 0.0 {
        return 1.0;
    }
    let exponent = range.log10().floor();
    let fraction = range / 10f64.powf(exponent);
    let nice_fraction = if round {
        if fraction < 1.5 {
            1.0
        } else if fraction < 3.0 {
            2.0
        } else if fraction < 7.0 {
            5.0
        } else {
            10.0
        }
    } else if fraction <= 1.0 {
        1.0
    } else if fraction <= 2.0 {
        2.0
    } else if fraction <= 5.0 {
        5.0
    } else {
        10.0
    };
    nice_fraction * 10f64.powf(exponent)
}

fn round_to_precision(v: f64, spacing: f64) -> f64 {
    // Snap away tiny float noise (e.g. 0.30000000000000004) introduced by repeated addition.
    let decimals = (-spacing.log10()).ceil().max(0.0) as i32 + 2;
    let factor = 10f64.powi(decimals);
    (v * factor).round() / factor
}

fn format_tick_label(value: f64) -> String {
    if value.abs() >= 1000.0 || (value.fract() == 0.0 && value.abs() < 1e15) {
        format!("{:.0}", value)
    } else {
        let s = format!("{:.4}", value);
        s.trim_end_matches('0').trim_end_matches('.').to_string()
    }
}

fn compute_ticks(axis: &Axis, data_min: f64, data_max: f64) -> Vec<Tick> {
    let min = axis.min.unwrap_or(data_min);
    let max = axis.max.unwrap_or(data_max);

    if let Some(labels) = &axis.category_labels {
        return labels
            .iter()
            .enumerate()
            .map(|(i, l)| Tick { value: i as f64, label: l.clone() })
            .collect();
    }

    match axis.scale {
        ScaleType::Logarithmic => {
            let lo = min.max(f64::MIN_POSITIVE).log10().floor();
            let hi = max.max(f64::MIN_POSITIVE).log10().ceil();
            let mut ticks = Vec::new();
            let mut e = lo as i32;
            while (e as f64) <= hi {
                let v = 10f64.powi(e);
                ticks.push(Tick { value: v, label: format_tick_label(v) });
                e += 1;
            }
            ticks
        }
        _ => nice_ticks(min, max, axis.tick_count)
            .into_iter()
            .map(|v| Tick { value: v, label: format_tick_label(v) })
            .collect(),
    }
}

/// Compute the full layout for a chart: plot-area rectangle (after reserving margins for
/// axis labels) plus tick sets for both axes.
pub fn compute_layout(chart: &Chart, margins: Margins) -> Layout {
    let vp = chart.viewport;

    let plot_x0 = margins.left;
    let plot_y0 = margins.top;
    let plot_x1 = (vp.width_px - margins.right).max(plot_x0 + 1.0);
    let plot_y1 = (vp.height_px - margins.bottom).max(plot_y0 + 1.0);

    let x_ticks = compute_ticks(&chart.x_axis, vp.x_min, vp.x_max);
    let y_ticks = compute_ticks(&chart.y_axis, vp.y_min, vp.y_max);

    Layout { plot_x0, plot_y0, plot_x1, plot_y1, x_ticks, y_ticks, viewport: vp }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn nice_ticks_covers_range() {
        let ticks = nice_ticks(0.0, 97.0, 6);
        assert!(ticks.first().unwrap() <= &0.0);
        assert!(ticks.last().unwrap() >= &97.0);
        // Spacing should be uniform.
        let spacing = ticks[1] - ticks[0];
        for w in ticks.windows(2) {
            assert!((w[1] - w[0] - spacing).abs() < 1e-6);
        }
    }

    #[test]
    fn map_x_endpoints() {
        let layout = Layout {
            plot_x0: 10.0,
            plot_y0: 10.0,
            plot_x1: 110.0,
            plot_y1: 210.0,
            x_ticks: vec![],
            y_ticks: vec![],
            viewport: ViewportState::new(0.0, 100.0, 0.0, 100.0, 800.0, 600.0),
        };
        assert!((layout.map_x(0.0) - 10.0).abs() < 1e-9);
        assert!((layout.map_x(100.0) - 110.0).abs() < 1e-9);
    }

    #[test]
    fn map_y_is_inverted() {
        let layout = Layout {
            plot_x0: 0.0,
            plot_y0: 0.0,
            plot_x1: 100.0,
            plot_y1: 100.0,
            x_ticks: vec![],
            y_ticks: vec![],
            viewport: ViewportState::new(0.0, 1.0, 0.0, 1.0, 800.0, 600.0),
        };
        // y=0 (bottom of data) maps to plot_y1 (bottom of pixel area); y=1 maps to plot_y0 (top).
        assert!((layout.map_y(0.0) - 100.0).abs() < 1e-9);
        assert!((layout.map_y(1.0) - 0.0).abs() < 1e-9);
    }
}
