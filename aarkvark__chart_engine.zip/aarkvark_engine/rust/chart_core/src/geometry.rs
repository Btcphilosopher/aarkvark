//! Geometry builder: the last renderer-agnostic stage in the pipeline.
//!
//! `Chart -> Layout -> SceneGraph -> Geometry -> GPU Renderer`. This module owns the
//! `SceneGraph -> Geometry` step: it walks the scene tree depth-first and flattens it into
//! a draw-ordered list of primitives. Anything downstream — the CPU rasterizer in
//! `chart_raster` today, a wgpu vertex-buffer builder tomorrow — consumes the same
//! `Geometry` value and never needs to know about the tree structure that produced it.

use crate::error::{ChartError, ChartResult};
use crate::layout::{compute_layout, Layout, Margins};
use crate::model::{Chart, Color};
use crate::scene::{build_scene, SceneNode};

/// A single drawable primitive in pixel space. This is intentionally a closed, flat set —
/// any renderer backend can match on it exhaustively without needing scene-graph context.
pub type Primitive = SceneNode;

#[derive(Debug, Clone, serde::Serialize)]
pub struct Geometry {
    pub primitives: Vec<Primitive>,
    pub width_px: f32,
    pub height_px: f32,
    pub background: Color,
    pub layout: Layout,
}

fn flatten(node: SceneNode, out: &mut Vec<Primitive>) {
    match node {
        SceneNode::Group { children, .. } => {
            for child in children {
                flatten(child, out);
            }
        }
        leaf => out.push(leaf),
    }
}

/// Validate a chart is renderable: non-empty, known chart type with a real geometry
/// implementation, sane viewport. Returns the specific `ChartError` rather than panicking
/// so the Python layer can surface a clean exception instead of crashing the process.
fn validate(chart: &Chart) -> ChartResult<()> {
    if !chart.chart_type.is_implemented() {
        return Err(ChartError::UnimplementedChartType(chart.chart_type));
    }
    if chart.series.is_empty() {
        return Err(ChartError::NoSeries);
    }
    for s in &chart.series {
        if s.visible && s.data.is_empty() {
            return Err(ChartError::EmptySeries(s.id.clone()));
        }
    }
    let vp = chart.viewport;
    if vp.width_px <= 0.0 || vp.height_px <= 0.0 {
        return Err(ChartError::InvalidViewport { width: vp.width_px, height: vp.height_px });
    }
    if vp.x_max <= vp.x_min || vp.y_max <= vp.y_min {
        return Err(ChartError::InvalidAxisRange {
            min: vp.x_min.min(vp.y_min),
            max: vp.x_max.max(vp.y_max),
        });
    }
    Ok(())
}

/// Build the full, flat, renderer-agnostic geometry for a chart at its current state
/// (viewport, interaction, animation progress). This is the single function the PyO3
/// bridge and the raster backend both call.
pub fn build_geometry(chart: &Chart) -> ChartResult<Geometry> {
    build_geometry_with_margins(chart, Margins::default())
}

/// Build geometry and serialize it to JSON — the "Export ... JSON" path: a renderer-
/// agnostic dump of exactly what got drawn (every primitive, in draw order, in pixel
/// space) that another tool (e.g. a JS canvas/SVG renderer) could replay without
/// reimplementing the layout math.
pub fn geometry_to_json(chart: &Chart) -> ChartResult<String> {
    let geo = build_geometry(chart)?;
    Ok(serde_json::to_string(&geo)?)
}

pub fn build_geometry_with_margins(chart: &Chart, margins: Margins) -> ChartResult<Geometry> {
    validate(chart)?;
    let layout = compute_layout(chart, margins);
    let scene = build_scene(chart, &layout);
    let mut primitives = Vec::new();
    flatten(scene, &mut primitives);

    Ok(Geometry {
        primitives,
        width_px: chart.viewport.width_px as f32,
        height_px: chart.viewport.height_px as f32,
        background: chart.theme.background,
        layout,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::{ChartBuilder, ChartType, DataPoint, Series};

    fn sample_chart(chart_type: ChartType) -> Chart {
        let series = Series::new(
            "s1",
            "Revenue",
            vec![
                DataPoint::new(0.0, 10.0),
                DataPoint::new(1.0, 25.0),
                DataPoint::new(2.0, 17.0),
                DataPoint::new(3.0, 40.0),
            ],
        );
        ChartBuilder::new("c1", chart_type).title("Test Chart").add_series(series).build()
    }

    #[test]
    fn line_chart_produces_polyline_and_markers() {
        let chart = sample_chart(ChartType::Line);
        let geo = build_geometry(&chart).expect("should build");
        let has_polyline = geo.primitives.iter().any(|p| matches!(p, Primitive::Polyline { .. }));
        let circle_count =
            geo.primitives.iter().filter(|p| matches!(p, Primitive::Circle { .. })).count();
        assert!(has_polyline);
        assert_eq!(circle_count, 4);
    }

    #[test]
    fn bar_chart_produces_one_rect_per_point_plus_background() {
        let chart = sample_chart(ChartType::Bar);
        let geo = build_geometry(&chart).expect("should build");
        let rect_count = geo.primitives.iter().filter(|p| matches!(p, Primitive::Rect { .. })).count();
        // 4 data bars + background rect + 1 legend swatch (single series).
        assert_eq!(rect_count, 6);
    }

    #[test]
    fn unimplemented_chart_type_errors_cleanly() {
        let chart = sample_chart(ChartType::Sankey);
        let err = build_geometry(&chart).unwrap_err();
        assert!(matches!(err, ChartError::UnimplementedChartType(ChartType::Sankey)));
    }

    #[test]
    fn empty_series_errors_cleanly() {
        let series = Series::new("s1", "Empty", vec![]);
        let chart = ChartBuilder::new("c1", ChartType::Line).add_series(series).build();
        let err = build_geometry(&chart).unwrap_err();
        assert!(matches!(err, ChartError::EmptySeries(_)));
    }

    #[test]
    fn pie_chart_produces_one_wedge_per_slice() {
        let series = Series::new(
            "s1",
            "Share",
            vec![
                DataPoint::new(0.0, 30.0).with_label("A"),
                DataPoint::new(0.0, 70.0).with_label("B"),
            ],
        );
        let chart = ChartBuilder::new("c1", ChartType::Pie).add_series(series).build();
        let geo = build_geometry(&chart).expect("should build");
        let polygon_count =
            geo.primitives.iter().filter(|p| matches!(p, Primitive::FilledPolygon { .. })).count();
        assert_eq!(polygon_count, 2);
    }

    #[test]
    fn animation_progress_zero_hides_points() {
        let chart = sample_chart(ChartType::Line).with_animation_progress(0.0);
        let geo = build_geometry(&chart).expect("should build");
        let circle_count =
            geo.primitives.iter().filter(|p| matches!(p, Primitive::Circle { .. })).count();
        assert_eq!(circle_count, 0);
    }
}
