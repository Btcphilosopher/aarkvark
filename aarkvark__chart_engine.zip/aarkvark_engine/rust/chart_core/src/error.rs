use thiserror::Error;

#[derive(Debug, Error)]
pub enum ChartError {
    #[error("series '{0}' has no data points")]
    EmptySeries(String),

    #[error("series '{series}' x/y length mismatch: x={x_len} y={y_len}")]
    SeriesLengthMismatch {
        series: String,
        x_len: usize,
        y_len: usize,
    },

    #[error("chart type {0:?} is modeled but geometry generation is not yet implemented")]
    UnimplementedChartType(crate::model::ChartType),

    #[error("invalid axis range: min={min} max={max} (min must be < max)")]
    InvalidAxisRange { min: f64, max: f64 },

    #[error("viewport has zero or negative dimension: width={width} height={height}")]
    InvalidViewport { width: f64, height: f64 },

    #[error("serialization error: {0}")]
    Serde(#[from] serde_json::Error),

    #[error("no series in chart")]
    NoSeries,
}

pub type ChartResult<T> = Result<T, ChartError>;
