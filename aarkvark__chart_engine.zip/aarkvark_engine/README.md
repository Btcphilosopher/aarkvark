# Aarkvark Engine

A Python-first spreadsheet + chart + dashboard system with a Rust rendering core, built
against the four-module architecture spec (Python API / Rust Graph Engine / UI Layer /
Dashboard & Analytics Engine).

This README is deliberately specific about **what's real and working vs. what's scaffolded**.
Everything marked "real" is compiled, tested, and was visually verified during this build
(screenshots of actual rendered output, not descriptions of intended output).

```
sheet.chart(type="scatter", x="A1:A1000", y="B1:B1000", title="Population Growth")
```
That exact line from the spec works, end to end, today.

## What's real

- **Rust workspace** (`rust/`): `chart_core` (immutable/serializable chart model, layout
  engine with proper "nice number" tick generation, scene graph, geometry builder) +
  `chart_raster` (CPU rasterizer — real antialiased-via-polygon-fill lines, scanline
  polygon fill for area/pie, a real bitmap-font text renderer via `embedded-graphics`,
  PNG encoding) + `chart_pyo3` (PyO3 bindings, built as the `aarkvark_native` extension).
  **13 unit tests, 0 warnings, clean release build.**
- **10 chart types fully implemented and rendering**: line, area, spline, bar, column,
  scatter, bubble, histogram, pie, donut. Each one was rendered to a real PNG and visually
  inspected during this build, not just unit-tested for non-crashing.
- **Zero-copy numpy ingestion**: `render_line_series_png(x: PyReadonlyArray1<f64>, ...)`
  reads numpy buffers directly with no JSON/list round trip. Benchmarked at **1,000,000
  points rendered in 0.63s** end-to-end (Python call → Rust → PNG bytes back).
- **Python package** (`python/aarkvark_charts/`): `Workbook`, `Worksheet` (with a real
  recursive-descent formula engine — `=SUM(A1:A10)`, cell refs, arithmetic, Kahn's-algorithm
  dependency resolution, cycle detection), `Chart`, `Series`, `Axis`, `Legend`, `Theme`,
  `Annotation`, `Dashboard`, `DataConnector` (real pub/sub for live updates), a plugin
  system (hook registry + named component registry), and heuristic "AI-assisted" schema
  inference (`suggest_chart(df)` → a ready-to-render `Chart`, no LLM call, documented as
  such). **41 pytest tests, all passing.**
- **All four export formats work**: PNG and JSON come from Rust directly; SVG is generated
  in Python by walking the same flattened `Geometry` JSON the rasterizer consumes (so the
  vector and raster outputs are guaranteed to agree on layout — this is the actual payoff
  of keeping geometry renderer-agnostic); PDF wraps the PNG via `img2pdf` (no re-encode).
- **PySide6 UI** (`ui/pyside6_app/main.py`): all ten panels from the spec (Chart Preview,
  Properties Inspector, Axis Editor, Legend Editor, Series Manager, Theme Manager,
  Animation Editor, Annotation Tools, Data Source Panel, Dashboard Builder). This was
  **smoke-tested and screenshotted running offscreen** in this sandbox — a real window,
  with a real Rust-rendered chart embedded via `QImage` from the RGBA buffer, theme
  switching and property editing wired to live API calls, not mockups.
- **Dashboard HTML export**: real grid-layout HTML/CSS (standard CSS Grid — verified the
  underlying markup is correct; the one screenshot tool available in this sandbox,
  `wkhtmltoimage`, uses an old QtWebKit engine that doesn't support CSS Grid, so its
  screenshot shows the widgets stacked — any real browser renders the grid as designed).

## What's scaffolded, not faked

Being upfront about this matters more than claiming completeness that isn't real:

- **9 chart types are modeled but not yet rendered**: stacked bar/column, heatmap,
  candlestick/OHLC, radar/polar, treemap/sunburst, sankey, network, gantt/timeline,
  3D surface. Calling `.render_png()` on one of these raises a clean
  `UnimplementedChartTypeError` rather than crashing or silently drawing nothing — see
  `ChartType.is_implemented()` in `rust/chart_core/src/model.rs`. Adding one is "write a
  `match` arm in `scene.rs`'s geometry-generation function," not a redesign.
- **No wgpu/GPU path.** The spec calls for a wgpu-based GPU renderer hitting 120 FPS at
  1M+ points. This sandbox has no GPU or display, so building *and verifying* that path
  wasn't honest to attempt here. What exists instead is a genuinely fast CPU rasterizer
  (the 1M-point/0.63s number above) sitting behind the exact same `Geometry` interface a
  wgpu vertex-buffer builder would consume — swapping it in later doesn't touch
  `chart_core` at all, just adds a sibling to `chart_raster`.
- **Kotlin UI**: skipped per spec ("only used if... otherwise not required") — nothing
  in this build needed it.
- **Dashboard Builder drag-and-drop**: the panel exists and lists/exports charts; actual
  drag-and-drop grid placement (vs. the current auto-flow placement) is noted as a
  follow-up in the panel's docstring.
- **`Workbook.load_json`** round-trips worksheets (values + formulas) but not full `Chart`
  objects yet — re-binding a saved chart definition to live `Chart`/`Theme` objects is a
  small, well-scoped follow-up.
- Text rendering covers ASCII only (an em dash in a title renders as `?` — a real
  limitation of the bitmap font, not a crash).

## Layout

```
rust/
  chart_core/     Chart model, layout engine, scene graph, geometry builder (no I/O, no rendering)
  chart_raster/   CPU rasterizer: Geometry -> RGBA/PNG. Real text via embedded-graphics.
  chart_pyo3/     PyO3 bindings -> builds as `aarkvark_native`
python/
  aarkvark_charts/
    worksheet.py        Cell engine: formulas, ranges, dependency graph
    workbook.py          Workbook container, save/load
    model.py               Series/Axis/Legend/Annotation + enums (mirrors Rust model)
    theme.py                 Color/Theme, incl. ANGLO_FUTURIST default
    chart.py                   Chart object; all rendering delegates to _native
    data_connector.py            DataFrame/CSV/SQL ingestion + live-update pub/sub
    schema_inference.py            Heuristic "AI-assisted" column typing + chart suggestion
    dashboard.py                     Widgets, grid layout, HTML export
    plugin.py                          Hook + component registries
    export.py                           PNG/SVG/PDF/JSON export
  tests/            41 pytest tests across all of the above
ui/
  pyside6_app/main.py   10-panel desktop UI; rendering-free by construction
build.sh            One-shot: cargo build+test -> maturin develop -> pip install -> pytest
```

## Building

```bash
python3 -m venv .venv && source .venv/bin/activate
./build.sh
```

This builds the Rust workspace in release mode, runs the Rust test suite, builds the
PyO3 extension into your venv via `maturin develop --release`, installs the Python
package, and runs the Python test suite. Tested on Ubuntu 24.04 / rustc 1.75 / Python
3.12; should work on any platform maturin supports.

For the desktop UI: `pip install PySide6` then `python ui/pyside6_app/main.py`.

## Quick example

```python
import numpy as np
from aarkvark_charts import Workbook, ANGLO_FUTURIST

wb = Workbook("Dynasty Elite")
ws = wb.add_worksheet("Season")
ws.set_range("A1", np.arange(20, dtype=float))
ws.set_range("B1", np.cumsum(np.random.choice([0, 1], 20, p=[0.4, 0.6])))
ws["C1"] = "=SUM(B1:B20)"  # real formula evaluation

chart = ws.chart(type="line", x="A1:A20", y="B1:B20", title="Cumulative Wins")
chart.render_png("wins.png")          # Rust-rendered PNG, Anglo-futurist theme by default
chart.render_rgba()                    # (H, W, 4) uint8 numpy array, e.g. for a Qt QImage

from aarkvark_charts import export
export.to_svg(chart, "wins.svg")       # vector export, same geometry as the PNG
export.to_pdf(chart, "wins.pdf")
```
