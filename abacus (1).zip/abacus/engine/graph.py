"""
engine/graph.py — Dependency graph management.
Tracks which cells depend on which, enabling reactive propagation.
"""
from __future__ import annotations
from collections import defaultdict, deque
from typing import Callable, Iterator


CellKey = tuple[str, int, int]   # (sheet, row, col)


class DependencyGraph:
    """
    Directed graph: edge  A → B  means  B depends on A.
    Upstream  (A's consumers): self._fwd[A]  = {B, C, …}
    Downstream (B's producers): self._bwd[B] = {A, …}
    """

    def __init__(self):
        self._fwd: dict[CellKey, set[CellKey]] = defaultdict(set)
        self._bwd: dict[CellKey, set[CellKey]] = defaultdict(set)

    # ── mutation ──────────────────────────────────────────────────────────────
    def set_dependencies(self, dependent: CellKey, sources: set[CellKey]):
        """Replace all upstream edges for `dependent`."""
        # remove old edges
        for old_src in list(self._bwd.get(dependent, [])):
            self._fwd[old_src].discard(dependent)
        self._bwd[dependent] = set(sources)
        for src in sources:
            self._fwd[src].add(dependent)

    def remove_cell(self, key: CellKey):
        """Remove all edges for a cell (clearing its formula)."""
        self.set_dependencies(key, set())
        # also remove as a source
        for dep in list(self._fwd.get(key, [])):
            self._bwd[dep].discard(key)
        self._fwd.pop(key, None)

    # ── query ─────────────────────────────────────────────────────────────────
    def upstream(self, key: CellKey) -> set[CellKey]:
        """Cells that key depends on."""
        return self._bwd.get(key, set())

    def downstream(self, key: CellKey) -> set[CellKey]:
        """Cells that depend on key."""
        return self._fwd.get(key, set())

    def all_edges(self) -> list[tuple[CellKey, CellKey]]:
        """Return all (source, dependent) edges."""
        edges = []
        for src, deps in self._fwd.items():
            for dep in deps:
                edges.append((src, dep))
        return edges

    # ── topological propagation ───────────────────────────────────────────────
    def propagation_order(self, dirty: set[CellKey]) -> list[CellKey]:
        """
        Return cells reachable from `dirty`, in topological (evaluation) order.
        Raises CycleError if a cycle is detected.
        """
        # BFS to find all affected cells
        affected = set(dirty)
        queue = deque(dirty)
        while queue:
            cell = queue.popleft()
            for dep in self._fwd.get(cell, []):
                if dep not in affected:
                    affected.add(dep)
                    queue.append(dep)

        # Kahn's algorithm for topological sort over the subgraph
        in_degree: dict[CellKey, int] = {}
        for cell in affected:
            in_degree[cell] = sum(
                1 for src in self._bwd.get(cell, []) if src in affected
            )

        ready = deque(c for c in affected if in_degree[c] == 0)
        order: list[CellKey] = []
        while ready:
            cell = ready.popleft()
            order.append(cell)
            for dep in self._fwd.get(cell, []):
                if dep in in_degree:
                    in_degree[dep] -= 1
                    if in_degree[dep] == 0:
                        ready.append(dep)

        if len(order) != len(affected):
            raise CycleError("Circular reference detected")

        return order

    # ── sheet-level helpers ───────────────────────────────────────────────────
    def cells_on_sheet(self, sheet: str) -> set[CellKey]:
        all_keys: set[CellKey] = set()
        for k in list(self._fwd) + list(self._bwd):
            if k[0] == sheet:
                all_keys.add(k)
        return all_keys

    def rename_sheet(self, old: str, new: str):
        def rk(k: CellKey) -> CellKey:
            return (new, k[1], k[2]) if k[0] == old else k

        new_fwd: dict[CellKey, set[CellKey]] = defaultdict(set)
        new_bwd: dict[CellKey, set[CellKey]] = defaultdict(set)
        for src, deps in self._fwd.items():
            new_fwd[rk(src)] = {rk(d) for d in deps}
        for dep, srcs in self._bwd.items():
            new_bwd[rk(dep)] = {rk(s) for s in srcs}
        self._fwd = new_fwd
        self._bwd = new_bwd


class CycleError(Exception):
    pass
