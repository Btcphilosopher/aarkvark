"""
Abacus — Hypermodern Spreadsheet
Configuration & Constants
"""

APP_NAME    = "Abacus"
APP_VERSION = "1.0.0"
FILE_EXT    = ".abacus"

# ── Palette ──────────────────────────────────────────────────────────────────
COLORS = {
    "bg_deep":      "#0A0C0F",
    "bg_surface":   "#0F1215",
    "bg_panel":     "#13171C",
    "bg_elevated":  "#1A1F27",
    "bg_hover":     "#1E2530",
    "bg_selected":  "#1C2A3A",
    "bg_header":    "#111418",

    "border":       "#1E2530",
    "border_light": "#2A3344",
    "border_accent":"#2E4060",

    "text_primary":   "#E8EDF3",
    "text_secondary": "#8A9BB0",
    "text_muted":     "#4A5A6A",
    "text_accent":    "#4A9EFF",
    "text_gold":      "#C8A84B",
    "text_green":     "#3DD68C",
    "text_red":       "#FF5C5C",
    "text_cyan":      "#29C4D8",

    "accent_blue":    "#1A6EFF",
    "accent_blue_dim":"#0F3A8A",
    "accent_gold":    "#C8A84B",
    "accent_gold_dim":"#6A5020",
    "accent_cyan":    "#29C4D8",

    "cell_formula":  "#1A3A2A",
    "cell_selected": "#1A2A3A",
    "cell_error":    "#2A1A1A",
    "cell_computed": "#1A1F2A",

    "graph_node":    "#1A2A3A",
    "graph_edge":    "#2A4A6A",
    "graph_node_sel":"#2A4A6A",
}

# ── Typography ────────────────────────────────────────────────────────────────
FONT_MONO   = "JetBrains Mono, Consolas, Courier New"
FONT_UI     = "Inter, Segoe UI, Arial"
FONT_SIZE   = 11

# ── Grid defaults ─────────────────────────────────────────────────────────────
DEFAULT_COL_WIDTH  = 100
DEFAULT_ROW_HEIGHT = 24
HEADER_HEIGHT      = 24
HEADER_WIDTH       = 48
MAX_COLS           = 52    # A–AZ
MAX_ROWS           = 1000

# ── AI ────────────────────────────────────────────────────────────────────────
AI_MODEL   = "claude-sonnet-4-20250514"
AI_MAX_TOK = 1024
