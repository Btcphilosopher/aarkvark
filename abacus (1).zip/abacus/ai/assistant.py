"""
ai/assistant.py — AI assistant panel.
Connects to Anthropic API for natural-language spreadsheet assistance.
"""
from __future__ import annotations
import json
import threading
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextEdit,
    QLineEdit, QPushButton, QLabel, QScrollArea,
    QFrame, QSizePolicy
)
from PySide6.QtCore    import Qt, Signal, QObject, QTimer
from PySide6.QtGui     import QFont, QColor, QTextCharFormat, QTextCursor

from config          import COLORS as C, FONT_UI, FONT_MONO, FONT_SIZE, AI_MODEL, AI_MAX_TOK
from engine.workbook import Workbook
from engine.cells    import CellType, col_to_letter


class _APIWorker(QObject):
    finished = Signal(str)
    error    = Signal(str)

    def __init__(self, prompt: str, context: str):
        super().__init__()
        self.prompt  = prompt
        self.context = context

    def run(self):
        try:
            import urllib.request
            payload = json.dumps({
                "model": AI_MODEL,
                "max_tokens": AI_MAX_TOK,
                "system": (
                    "You are Abacus AI — an intelligent spreadsheet assistant integrated into "
                    "Abacus, a hypermodern spreadsheet application. You help users with:\n"
                    "- Writing and explaining formulas (use = prefix)\n"
                    "- Analysing data patterns and anomalies\n"
                    "- Forecasting and projections\n"
                    "- Suggesting optimisations\n"
                    "- Answering questions about the spreadsheet data\n\n"
                    "Keep responses concise and actionable. When suggesting formulas, "
                    "always show the exact formula the user should type."
                ),
                "messages": [
                    {"role": "user", "content": f"Spreadsheet context:\n{self.context}\n\nUser: {self.prompt}"}
                ]
            }).encode()

            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "anthropic-version": "2023-06-01",
                    "x-api-key": ""   # handled by proxy
                },
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.load(resp)
                text = data["content"][0]["text"]
                self.finished.emit(text)
        except Exception as e:
            self.error.emit(str(e))


class AIPanel(QWidget):
    """Right-side AI assistant panel."""

    apply_formula = Signal(str)  # formula string to apply to selected cell

    def __init__(self, workbook: Workbook, parent=None):
        super().__init__(parent)
        self.wb = workbook
        self.setObjectName("ai_panel")
        self.setMinimumWidth(280)
        self.setMaximumWidth(420)

        self._history: list[dict] = []  # {role, content}
        self._current_sheet = workbook.active_sheet_name()
        self._selected_cell = (0, 0)

        self._build_ui()

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Header
        header = QWidget()
        header.setFixedHeight(40)
        header.setStyleSheet(f"background:{C['bg_panel']}; border-bottom:1px solid {C['border']};")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(12, 0, 12, 0)
        title = QLabel("⬡  ABACUS AI")
        title.setObjectName("title_label")
        hl.addWidget(title)
        hl.addStretch()
        self._status = QLabel("●")
        self._status.setStyleSheet(f"color:{C['text_muted']}; font-size:10px;")
        hl.addWidget(self._status)
        layout.addWidget(header)

        # Suggestions bar
        sug_bar = QWidget()
        sug_bar.setStyleSheet(f"background:{C['bg_elevated']}; border-bottom:1px solid {C['border']};")
        sl = QHBoxLayout(sug_bar)
        sl.setContentsMargins(8, 4, 8, 4)
        sl.setSpacing(4)
        suggestions = [
            "Forecast next quarter",
            "Find anomalies",
            "Summarise data",
            "Explain formula",
        ]
        for sug in suggestions:
            btn = QPushButton(sug)
            btn.setFixedHeight(22)
            btn.setStyleSheet(
                f"QPushButton{{background:{C['bg_panel']};color:{C['text_muted']};"
                f"border:1px solid {C['border']};border-radius:3px;"
                f"font-size:9px;padding:0 6px;}}"
                f"QPushButton:hover{{color:{C['text_accent']};border-color:{C['border_accent']};}}"
            )
            btn.clicked.connect(lambda _, s=sug: self._send_query(s))
            sl.addWidget(btn)
        sl.addStretch()
        layout.addWidget(sug_bar)

        # Chat output
        self._output = QTextEdit()
        self._output.setObjectName("ai_output")
        self._output.setReadOnly(True)
        layout.addWidget(self._output, 1)

        # Input area
        bottom = QWidget()
        bottom.setStyleSheet(f"background:{C['bg_panel']}; border-top:1px solid {C['border']};")
        bl = QVBoxLayout(bottom)
        bl.setContentsMargins(8, 8, 8, 8)
        bl.setSpacing(6)

        self._input = QLineEdit()
        self._input.setObjectName("ai_input")
        self._input.setPlaceholderText("Ask about your data…")
        self._input.returnPressed.connect(self._on_send)
        bl.addWidget(self._input)

        send_row = QHBoxLayout()
        send_row.setSpacing(6)
        self._send_btn = QPushButton("Send")
        self._send_btn.setObjectName("primary_btn")
        self._send_btn.clicked.connect(self._on_send)
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self._clear_chat)
        send_row.addStretch()
        send_row.addWidget(clear_btn)
        send_row.addWidget(self._send_btn)
        bl.addLayout(send_row)
        layout.addWidget(bottom)

        self._append_message(
            "assistant",
            "Hello — I'm your Abacus AI assistant.\n\n"
            "I can help you write formulas, analyse data, forecast trends, "
            "and explain calculations.\n\n"
            "Select a range or type a question to get started."
        )

    # ── public ────────────────────────────────────────────────────────────────
    def set_context(self, sheet: str, row: int, col: int):
        self._current_sheet = sheet
        self._selected_cell = (row, col)

    # ── internals ─────────────────────────────────────────────────────────────
    def _build_context(self) -> str:
        sheet = self.wb.sheets.get(self._current_sheet)
        if not sheet:
            return "Empty workbook."
        r, c = self._selected_cell
        cell = sheet.cells.get((r, c))
        selected_info = ""
        if cell:
            selected_info = (f"Selected cell: {col_to_letter(c)}{r+1} "
                             f"= {cell.raw!r} → {cell.display_value()!r}\n")

        # Summarise non-empty cells
        summary_lines = [selected_info, f"Sheet: {self._current_sheet}", "Data:"]
        count = 0
        for (row2, col2), cell2 in sorted(sheet.cells.items()):
            if cell2.cell_type != CellType.EMPTY and count < 40:
                addr = f"{col_to_letter(col2)}{row2+1}"
                summary_lines.append(f"  {addr}: {cell2.raw!r} → {cell2.display_value()}")
                count += 1
        if count == 40:
            summary_lines.append("  … (truncated)")

        return "\n".join(summary_lines)

    def _on_send(self):
        text = self._input.text().strip()
        if not text:
            return
        self._input.clear()
        self._send_query(text)

    def _send_query(self, text: str):
        self._append_message("user", text)
        self._set_busy(True)

        ctx    = self._build_context()
        worker = _APIWorker(text, ctx)
        worker.finished.connect(self._on_response)
        worker.error.connect(self._on_error)

        thread = threading.Thread(target=worker.run, daemon=True)
        thread.start()
        self._worker = worker  # keep reference

    def _on_response(self, text: str):
        self._set_busy(False)
        self._append_message("assistant", text)

        # Check if the response contains a formula suggestion
        import re
        formulas = re.findall(r'`(=[^`]+)`', text)
        if formulas:
            self.apply_formula.emit(formulas[0])

    def _on_error(self, err: str):
        self._set_busy(False)
        self._append_message("error", f"API error: {err}\n\n"
                             "Make sure the Anthropic API is accessible.")

    def _append_message(self, role: str, text: str):
        cursor = self._output.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)

        fmt = QTextCharFormat()
        if role == "user":
            fmt.setForeground(QColor(C["text_accent"]))
            prefix = "▸ You\n"
        elif role == "assistant":
            fmt.setForeground(QColor(C["text_primary"]))
            prefix = "⬡ Abacus AI\n"
        else:
            fmt.setForeground(QColor(C["text_red"]))
            prefix = "⚠ Error\n"

        # separator
        sep_fmt = QTextCharFormat()
        sep_fmt.setForeground(QColor(C["border_light"]))
        cursor.setCharFormat(sep_fmt)
        if self._output.toPlainText():
            cursor.insertText("\n─────────────────────────\n")

        cursor.setCharFormat(fmt)
        cursor.insertText(prefix)

        body_fmt = QTextCharFormat()
        body_fmt.setForeground(QColor(C["text_secondary"]))
        cursor.setCharFormat(body_fmt)
        cursor.insertText(text + "\n")

        self._output.setTextCursor(cursor)
        self._output.ensureCursorVisible()

    def _set_busy(self, busy: bool):
        self._send_btn.setEnabled(not busy)
        self._input.setEnabled(not busy)
        self._status.setText("● THINKING…" if busy else "●")
        self._status.setStyleSheet(
            f"color:{C['accent_blue'] if busy else C['text_muted']}; font-size:10px;"
        )

    def _clear_chat(self):
        self._output.clear()
        self._history.clear()
        self._append_message("assistant", "Chat cleared. How can I help?")
