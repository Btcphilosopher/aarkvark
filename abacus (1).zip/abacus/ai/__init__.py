from ai.assistant import AIPanel
