"""
ui/main_window.py — Main application window.
Assembles grid, formula bar, graph view, charts and AI panel.
"""
from __future__ import annotations
import os
from typing import Optional

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTabWidget, QTabBar, QLabel, QLineEdit,
    QToolBar, QStatusBar, QFileDialog, QMessageBox,
    QInputDialog, QApplication, QFrame, QPushButton,
    QMenu, QMenuBar
)
from PySide6.QtCore    import Qt, QSize, QTimer, Signal
from PySide6.QtGui     import (
    QAction, QKeySequence, QFont, QColor, QIcon
)

from config          import COLORS as C, FONT_UI, FONT_SIZE, APP_NAME, APP_VERSION, FILE_EXT
from engine.workbook import Workbook
from engine.cells    import col_to_letter, CellType
from ui.grid         import GridWidget
from ui.graph_view   import GraphView
from ui.charts       import ChartPanel
from ai.assistant    import AIPanel


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.wb       = Workbook()
        self._file    = None
        self._dirty   = False
        self._active_sheet = self.wb.sheet_order[0]

        self.setWindowTitle(f"{APP_NAME}  {APP_VERSION}")
        self.resize(1400, 860)
        self.setMinimumSize(900, 600)

        self._build_menu()
        self._build_toolbar()
        self._build_central()
        self._build_status()

        # Connect workbook events
        self.wb.on_cell_changed(self._on_cell_changed)
        self.wb.on_sheet_changed(self._on_sheet_changed)

        self._populate_sheet_tabs()
        self._sync_formula_bar()

    # ── menu ─────────────────────────────────────────────────────────────────
    def _build_menu(self):
        mb = self.menuBar()

        # File
        file_menu = mb.addMenu("File")
        file_menu.addAction(self._act("New",        self._new,        "Ctrl+N"))
        file_menu.addAction(self._act("Open…",      self._open,       "Ctrl+O"))
        file_menu.addAction(self._act("Save",        self._save,       "Ctrl+S"))
        file_menu.addAction(self._act("Save As…",   self._save_as,    "Ctrl+Shift+S"))
        file_menu.addSeparator()
        file_menu.addAction(self._act("Quit",        self.close,       "Ctrl+Q"))

        # Edit
        edit_menu = mb.addMenu("Edit")
        edit_menu.addAction(self._act("Copy",  lambda: self._grid().keyPressEvent_proxy("copy"),  "Ctrl+C"))
        edit_menu.addAction(self._act("Paste", lambda: self._grid().keyPressEvent_proxy("paste"), "Ctrl+V"))
        edit_menu.addSeparator()
        edit_menu.addAction(self._act("Select All", self._select_all, "Ctrl+A"))

        # Sheet
        sheet_menu = mb.addMenu("Sheet")
        sheet_menu.addAction(self._act("New Sheet",    self._add_sheet))
        sheet_menu.addAction(self._act("Rename Sheet…", self._rename_sheet))
        sheet_menu.addAction(self._act("Delete Sheet", self._delete_sheet))

        # View
        view_menu = mb.addMenu("View")
        self._act_graph = self._act("Graph View",  self._toggle_graph, checkable=True)
        self._act_chart = self._act("Chart Panel", self._toggle_chart, checkable=True)
        self._act_ai    = self._act("AI Assistant",self._toggle_ai,    checkable=True)
        self._act_ai.setChecked(True)
        view_menu.addAction(self._act_graph)
        view_menu.addAction(self._act_chart)
        view_menu.addAction(self._act_ai)

        # Insert
        ins_menu = mb.addMenu("Insert")
        ins_menu.addAction(self._act("Chart from Selection", self._chart_selection))
        ins_menu.addAction(self._act("Function…",            self._insert_function))

        # Help
        help_menu = mb.addMenu("Help")
        help_menu.addAction(self._act("About", self._about))
        help_menu.addAction(self._act("Keyboard Shortcuts", self._shortcuts))
        help_menu.addAction(self._act("Function Reference",  self._func_ref))

    def _act(self, label, slot=None, shortcut=None, checkable=False):
        a = QAction(label, self)
        if slot:
            a.triggered.connect(slot)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
        if checkable:
            a.setCheckable(True)
        return a

    # ── toolbar ───────────────────────────────────────────────────────────────
    def _build_toolbar(self):
        tb = QToolBar("Main", self)
        tb.setMovable(False)
        tb.setIconSize(QSize(16, 16))
        self.addToolBar(tb)

        def tbtn(label, slot, tip=""):
            a = QAction(label, self)
            a.setToolTip(tip)
            a.triggered.connect(slot)
            tb.addAction(a)
            return a

        tbtn("◻ New",    self._new,   "New workbook")
        tbtn("📂 Open",  self._open,  "Open file")
        tbtn("💾 Save",  self._save,  "Save file")
        tb.addSeparator()

        # Cell reference box
        self._ref_box = QLineEdit()
        self._ref_box.setObjectName("cell_ref")
        self._ref_box.setFixedWidth(72)
        self._ref_box.returnPressed.connect(self._navigate_to_ref)
        tb.addWidget(self._ref_box)

        # Formula bar
        fx_label = QLabel("ƒx")
        fx_label.setStyleSheet(f"color:{C['text_gold']}; font-size:13px; padding:0 6px;")
        tb.addWidget(fx_label)

        self._formula_bar = QLineEdit()
        self._formula_bar.setObjectName("formula_bar")
        self._formula_bar.setMinimumWidth(300)
        self._formula_bar.returnPressed.connect(self._formula_committed)
        tb.addWidget(self._formula_bar)

        tb.addSeparator()
        self._btn_grid  = tbtn("⊞ Grid",  self._show_grid,  "Grid view")
        self._btn_graph = tbtn("⬡ Graph", self._show_graph, "Dependency graph")
        self._btn_chart = tbtn("📊 Chart", self._show_chart, "Chart panel")
        tb.addSeparator()
        tbtn("⬡ AI",     self._toggle_ai,  "Toggle AI panel")

    # ── central widget ────────────────────────────────────────────────────────
    def _build_central(self):
        central = QWidget()
        self.setCentralWidget(central)

        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Left: main content (grid + sheets)
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(0)

        # View stack
        self._view_stack = QTabWidget()
        self._view_stack.setTabPosition(QTabWidget.TabPosition.South)
        self._view_stack.tabBar().hide()
        left_layout.addWidget(self._view_stack, 1)

        # Spreadsheet grid
        self._grid_widget = GridWidget(self.wb, self._active_sheet)
        self._grid_widget.cell_selected.connect(self._on_cell_selected)
        self._grid_widget.cell_edited.connect(self._on_cell_edited)
        self._view_stack.addTab(self._grid_widget, "Grid")

        # Graph view
        self._graph_widget = GraphView(self.wb, self._active_sheet)
        self._graph_widget.node_selected.connect(self._on_graph_node_selected)
        self._view_stack.addTab(self._graph_widget, "Graph")

        # Chart
        self._chart_widget = ChartPanel(self.wb)
        self._view_stack.addTab(self._chart_widget, "Chart")

        # Sheet tab bar
        self._sheet_tabs = _SheetTabBar(self)
        self._sheet_tabs.sheet_selected.connect(self._switch_sheet)
        self._sheet_tabs.sheet_add.connect(self._add_sheet)
        self._sheet_tabs.sheet_rename.connect(self._rename_sheet_by_name)
        self._sheet_tabs.sheet_delete.connect(self._delete_sheet_by_name)
        left_layout.addWidget(self._sheet_tabs)

        # Right: AI panel
        self._ai_panel = AIPanel(self.wb)
        self._ai_panel.apply_formula.connect(self._apply_ai_formula)

        # Splitter
        self._splitter = QSplitter(Qt.Orientation.Horizontal)
        self._splitter.addWidget(left)
        self._splitter.addWidget(self._ai_panel)
        self._splitter.setStretchFactor(0, 4)
        self._splitter.setStretchFactor(1, 1)
        self._splitter.setSizes([1060, 340])

        root.addWidget(self._splitter)

    # ── status bar ────────────────────────────────────────────────────────────
    def _build_status(self):
        sb = QStatusBar()
        self.setStatusBar(sb)
        self._stat_cell  = QLabel("A1")
        self._stat_sum   = QLabel("")
        self._stat_count = QLabel("")
        self._stat_avg   = QLabel("")
        self._stat_mode  = QLabel("READY")
        for w in (self._stat_cell, self._stat_sum,
                  self._stat_count, self._stat_avg, self._stat_mode):
            sb.addWidget(w)
        sb.addPermanentWidget(QLabel(f"{APP_NAME} {APP_VERSION}"))

    # ── sheet tabs ────────────────────────────────────────────────────────────
    def _populate_sheet_tabs(self):
        self._sheet_tabs.set_sheets(self.wb.sheet_order, self._active_sheet)

    def _switch_sheet(self, name: str):
        self._active_sheet = name
        self._grid_widget.set_sheet(name)
        self._graph_widget.set_sheet(name)
        self._chart_widget.set_sheet(name)
        self._ai_panel.set_context(name, 0, 0)
        self._sync_formula_bar()

    # ── grid events ───────────────────────────────────────────────────────────
    def _on_cell_selected(self, row: int, col: int):
        sheet = self._active_sheet
        addr  = f"{col_to_letter(col)}{row+1}"
        self._ref_box.setText(addr)
        cell = self.wb.get_cell(sheet, row, col)
        self._formula_bar.setText(cell.raw)
        self._formula_bar.blockSignals(False)
        self._ai_panel.set_context(sheet, row, col)
        self._update_status_stats(row, col)

    def _on_cell_edited(self, row: int, col: int, raw: str):
        self._dirty = True
        self._formula_bar.setText(raw)
        self._graph_widget.rebuild()
        self._chart_widget.set_data_from_sheet()
        self._update_title()

    def _on_cell_changed(self, sheet, row, col):
        if sheet == self._active_sheet:
            self._grid_widget.viewport().update()

    def _on_sheet_changed(self):
        self._populate_sheet_tabs()

    def _on_graph_node_selected(self, sheet, row, col):
        self._active_sheet = sheet
        self._grid_widget._sel_row = self._grid_widget._sel_row2 = row
        self._grid_widget._sel_col = self._grid_widget._sel_col2 = col
        self._grid_widget.viewport().update()
        self._on_cell_selected(row, col)

    # ── formula bar ──────────────────────────────────────────────────────────
    def _formula_committed(self):
        row, col = self._grid_widget.selected_cell()
        raw = self._formula_bar.text()
        self.wb.set_cell(self._active_sheet, row, col, raw)
        self._dirty = True
        self._graph_widget.rebuild()
        self._chart_widget.set_data_from_sheet()
        self._update_title()
        self._grid_widget.viewport().update()

    def _sync_formula_bar(self):
        row, col = self._grid_widget.selected_cell()
        addr = f"{col_to_letter(col)}{row+1}"
        self._ref_box.setText(addr)
        cell = self.wb.get_cell(self._active_sheet, row, col)
        self._formula_bar.setText(cell.raw)

    def _navigate_to_ref(self):
        ref = self._ref_box.text().strip().upper()
        import re
        m = re.fullmatch(r"([A-Z]+)(\d+)", ref)
        if m:
            from engine.cells import letter_to_col
            col = letter_to_col(m.group(1))
            row = int(m.group(2)) - 1
            self._grid_widget._sel_row = self._grid_widget._sel_row2 = row
            self._grid_widget._sel_col = self._grid_widget._sel_col2 = col
            self._grid_widget._ensure_visible(row, col)
            self._grid_widget.viewport().update()
            self._on_cell_selected(row, col)
            self._grid_widget.setFocus()

    # ── AI formula apply ──────────────────────────────────────────────────────
    def _apply_ai_formula(self, formula: str):
        row, col = self._grid_widget.selected_cell()
        self.wb.set_cell(self._active_sheet, row, col, formula)
        self._formula_bar.setText(formula)
        self._dirty = True
        self._grid_widget.viewport().update()
        self._graph_widget.rebuild()

    # ── view toggles ─────────────────────────────────────────────────────────
    def _show_grid(self):
        self._view_stack.setCurrentIndex(0)

    def _show_graph(self):
        self._view_stack.setCurrentIndex(1)
        self._graph_widget.rebuild()

    def _show_chart(self):
        self._view_stack.setCurrentIndex(2)
        self._chart_widget.set_data_from_sheet()

    def _toggle_graph(self):
        if self._view_stack.currentIndex() == 1:
            self._show_grid()
        else:
            self._show_graph()

    def _toggle_chart(self):
        if self._view_stack.currentIndex() == 2:
            self._show_grid()
        else:
            self._show_chart()

    def _toggle_ai(self):
        self._ai_panel.setVisible(not self._ai_panel.isVisible())

    # ── sheet operations ──────────────────────────────────────────────────────
    def _add_sheet(self):
        self.wb.add_sheet()
        name = self.wb.sheet_order[-1]
        self._switch_sheet(name)
        self._populate_sheet_tabs()

    def _rename_sheet(self):
        self._rename_sheet_by_name(self._active_sheet)

    def _rename_sheet_by_name(self, old: str):
        new, ok = QInputDialog.getText(self, "Rename Sheet", "New name:", text=old)
        if ok and new and new != old:
            try:
                self.wb.rename_sheet(old, new)
                if self._active_sheet == old:
                    self._active_sheet = new
                    self._grid_widget.set_sheet(new)
                    self._graph_widget.set_sheet(new)
                self._populate_sheet_tabs()
            except ValueError as e:
                QMessageBox.warning(self, "Error", str(e))

    def _delete_sheet(self):
        self._delete_sheet_by_name(self._active_sheet)

    def _delete_sheet_by_name(self, name: str):
        if len(self.wb.sheet_order) <= 1:
            QMessageBox.warning(self, "Error", "Cannot delete the only sheet.")
            return
        reply = QMessageBox.question(self, "Delete Sheet",
                                     f"Delete '{name}'?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.wb.delete_sheet(name)
            if self._active_sheet == name:
                self._active_sheet = self.wb.sheet_order[0]
                self._grid_widget.set_sheet(self._active_sheet)
                self._graph_widget.set_sheet(self._active_sheet)
            self._populate_sheet_tabs()

    # ── file operations ───────────────────────────────────────────────────────
    def _new(self):
        if self._dirty:
            r = QMessageBox.question(self, "Unsaved changes",
                                     "Discard changes and create new workbook?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if r != QMessageBox.StandardButton.Yes:
                return
        self.wb = Workbook()
        self.wb.on_cell_changed(self._on_cell_changed)
        self.wb.on_sheet_changed(self._on_sheet_changed)
        self._active_sheet = self.wb.sheet_order[0]
        self._grid_widget.wb = self.wb
        self._grid_widget.set_sheet(self._active_sheet)
        self._graph_widget.wb = self.wb
        self._graph_widget.set_sheet(self._active_sheet)
        self._chart_widget.wb = self.wb
        self._ai_panel.wb = self.wb
        self._file  = None
        self._dirty = False
        self._populate_sheet_tabs()
        self._update_title()

    def _open(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Workbook", "",
            f"Abacus files (*{FILE_EXT});;JSON files (*.json);;All files (*)"
        )
        if path:
            try:
                self.wb = Workbook.load_json(path)
                self.wb.on_cell_changed(self._on_cell_changed)
                self.wb.on_sheet_changed(self._on_sheet_changed)
                self._active_sheet = self.wb.sheet_order[0]
                self._grid_widget.wb = self.wb
                self._grid_widget.set_sheet(self._active_sheet)
                self._graph_widget.wb = self.wb
                self._graph_widget.set_sheet(self._active_sheet)
                self._chart_widget.wb = self.wb
                self._ai_panel.wb = self.wb
                self._file  = path
                self._dirty = False
                self._populate_sheet_tabs()
                self._update_title()
            except Exception as e:
                QMessageBox.critical(self, "Open Error", str(e))

    def _save(self):
        if not self._file:
            self._save_as()
        else:
            self._do_save(self._file)

    def _save_as(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Workbook", "",
            f"Abacus files (*{FILE_EXT});;JSON files (*.json)"
        )
        if path:
            if not path.endswith(FILE_EXT) and not path.endswith(".json"):
                path += FILE_EXT
            self._do_save(path)

    def _do_save(self, path: str):
        try:
            self.wb.save_json(path)
            self._file  = path
            self._dirty = False
            self._update_title()
            self.statusBar().showMessage(f"Saved: {path}", 3000)
        except Exception as e:
            QMessageBox.critical(self, "Save Error", str(e))

    # ── misc ──────────────────────────────────────────────────────────────────
    def _select_all(self):
        g = self._grid_widget
        g._sel_row = g._sel_col = 0
        g._sel_row2 = 999
        g._sel_col2 = 199
        g.viewport().update()

    def _chart_selection(self):
        r1, c1, r2, c2 = self._grid_widget.selected_range()
        self._chart_widget.set_selection_data(self.wb, self._active_sheet, r1, c1, r2, c2)
        self._show_chart()

    def _insert_function(self):
        funcs = [
            "SUM(range)", "AVERAGE(range)", "MIN(range)", "MAX(range)",
            "COUNT(range)", "IF(condition,true,false)", "ROUND(value,digits)",
            "CONCAT(a,b)", "GROWTH(start,end,periods)", "CAGR(start,end,years)",
        ]
        fn, ok = QInputDialog.getItem(self, "Insert Function",
                                      "Select function:", funcs, editable=False)
        if ok:
            self._formula_bar.setText("=" + fn)
            self._formula_bar.setFocus()

    def _update_status_stats(self, row, col):
        r1, c1, r2, c2 = self._grid_widget.selected_range()
        vals = []
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                cell = self.wb.get_cell(self._active_sheet, r, c)
                if isinstance(cell.value, (int, float)):
                    vals.append(cell.value)
        addr = f"{col_to_letter(col)}{row+1}"
        self._stat_cell.setText(addr)
        if vals:
            self._stat_sum.setText(f"Sum: {sum(vals):.4g}")
            self._stat_count.setText(f"Count: {len(vals)}")
            self._stat_avg.setText(f"Avg: {sum(vals)/len(vals):.4g}")
        else:
            self._stat_sum.setText("")
            self._stat_count.setText("")
            self._stat_avg.setText("")

    def _update_title(self):
        dirty = " ●" if self._dirty else ""
        fname = os.path.basename(self._file) if self._file else "Untitled"
        self.setWindowTitle(f"{APP_NAME}  —  {fname}{dirty}")

    def _grid(self):
        return self._grid_widget

    def _about(self):
        QMessageBox.about(self, f"About {APP_NAME}",
            f"<b>Abacus {APP_VERSION}</b><br><br>"
            "Hypermodern spreadsheet with reactive computation graph<br>"
            "and AI-assisted insights.<br><br>"
            "<small>Built with Python, PySide6 & Anthropic Claude</small>")

    def _shortcuts(self):
        QMessageBox.information(self, "Keyboard Shortcuts",
            "Navigation: Arrow keys\n"
            "Edit cell: Enter or F2 or type\n"
            "Confirm: Enter / Tab\n"
            "Cancel: Escape\n"
            "Copy/Paste/Cut: Ctrl+C/V/X\n"
            "Clear: Delete\n"
            "New: Ctrl+N\n"
            "Open: Ctrl+O\n"
            "Save: Ctrl+S\n"
            "Graph View: toolbar ⬡ Graph\n"
            "Chart View: toolbar 📊 Chart\n"
            "Toggle AI: toolbar ⬡ AI")

    def _func_ref(self):
        from engine.evaluator import BUILTINS
        fns = "\n".join(sorted(BUILTINS.keys()))
        QMessageBox.information(self, "Function Reference",
            f"Available functions:\n\n{fns}\n\n"
            "Usage: =FUNCTION(args…)\n"
            "Ranges: =SUM(A1:A10)\n"
            "Cross-sheet: =Sheet2!B3")

    def closeEvent(self, event):
        if self._dirty:
            r = QMessageBox.question(self, "Unsaved Changes",
                                     "Save before quitting?",
                                     QMessageBox.StandardButton.Save |
                                     QMessageBox.StandardButton.Discard |
                                     QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Save:
                self._save()
            elif r == QMessageBox.StandardButton.Cancel:
                event.ignore()
                return
        event.accept()


# ── Sheet tab bar widget ──────────────────────────────────────────────────────
class _SheetTabBar(QWidget):
    sheet_selected = Signal(str)
    sheet_add      = Signal()
    sheet_rename   = Signal(str)
    sheet_delete   = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(32)
        self.setStyleSheet(f"background:{C['bg_surface']}; border-top:1px solid {C['border']};")
        self._layout = QHBoxLayout(self)
        self._layout.setContentsMargins(4, 0, 4, 0)
        self._layout.setSpacing(2)
        self._btns: dict[str, QPushButton] = {}
        self._active = ""

    def set_sheets(self, names: list[str], active: str):
        # clear
        for b in self._btns.values():
            b.setParent(None)
        self._btns.clear()
        while self._layout.count():
            self._layout.takeAt(0)

        self._active = active
        for name in names:
            self._add_tab(name)

        # + button
        add_btn = QPushButton("+")
        add_btn.setFixedSize(26, 22)
        add_btn.setStyleSheet(
            f"QPushButton{{background:transparent;color:{C['text_muted']};"
            f"border:1px solid {C['border']};border-radius:3px;font-size:14px;}}"
            f"QPushButton:hover{{color:{C['text_primary']};border-color:{C['border_light']};}}"
        )
        add_btn.clicked.connect(self.sheet_add.emit)
        self._layout.addWidget(add_btn)
        self._layout.addStretch()

        self._refresh_styles()

    def _add_tab(self, name: str):
        btn = QPushButton(name)
        btn.setFixedHeight(22)
        btn.setContentsMargins(0, 0, 0, 0)
        btn.clicked.connect(lambda _, n=name: self._on_click(n))
        btn.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        btn.customContextMenuRequested.connect(lambda pos, n=name: self._tab_menu(n, pos))
        self._btns[name] = btn
        self._layout.insertWidget(self._layout.count(), btn)

    def _on_click(self, name: str):
        self._active = name
        self._refresh_styles()
        self.sheet_selected.emit(name)

    def _tab_menu(self, name: str, pos):
        menu = QMenu(self)
        menu.addAction("Rename…", lambda: self.sheet_rename.emit(name))
        menu.addAction("Delete",  lambda: self.sheet_delete.emit(name))
        menu.exec(self._btns[name].mapToGlobal(pos))

    def _refresh_styles(self):
        for name, btn in self._btns.items():
            if name == self._active:
                btn.setStyleSheet(
                    f"QPushButton{{background:{C['bg_elevated']};color:{C['text_accent']};"
                    f"border:none;border-top:2px solid {C['accent_blue']};"
                    f"padding:0 14px;font-size:10px;letter-spacing:0.3px;}}"
                )
            else:
                btn.setStyleSheet(
                    f"QPushButton{{background:transparent;color:{C['text_muted']};"
                    f"border:none;border-top:2px solid transparent;"
                    f"padding:0 14px;font-size:10px;letter-spacing:0.3px;}}"
                    f"QPushButton:hover{{color:{C['text_secondary']};background:{C['bg_hover']};}}"
                )
