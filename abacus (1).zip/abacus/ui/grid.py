"""
ui/grid.py — Spreadsheet grid widget.
Custom QWidget-based grid with virtual rendering for performance.
"""
from __future__ import annotations
import re
from typing import Optional

from PySide6.QtWidgets import (
    QWidget, QAbstractScrollArea, QScrollBar, QApplication,
    QMenu, QInputDialog, QMessageBox
)
from PySide6.QtCore import (
    Qt, QRect, QPoint, QSize, Signal, QTimer
)
from PySide6.QtGui import (
    QPainter, QColor, QFont, QFontMetrics, QPen, QBrush,
    QKeyEvent, QMouseEvent, QWheelEvent, QContextMenuEvent,
    QClipboard
)

from config import COLORS as C, FONT_MONO, FONT_UI, FONT_SIZE
from config import DEFAULT_COL_WIDTH, DEFAULT_ROW_HEIGHT, HEADER_HEIGHT, HEADER_WIDTH
from engine.cells import CellType, col_to_letter
from engine.workbook import Workbook


# ── colours pre-built ─────────────────────────────────────────────────────────
_COL = {k: QColor(v) for k, v in C.items()}

_FONT_GRID   = QFont(FONT_MONO.split(",")[0].strip(), FONT_SIZE - 1)
_FONT_HEADER = QFont(FONT_UI.split(",")[0].strip(), FONT_SIZE - 1)
_FONT_HEADER.setWeight(QFont.Weight.Medium)
_FONT_FORMULA = QFont(FONT_MONO.split(",")[0].strip(), FONT_SIZE - 1)
_FONT_FORMULA.setItalic(True)


class GridWidget(QAbstractScrollArea):
    """
    High-performance virtual spreadsheet grid.
    Only renders visible cells.
    """
    cell_selected   = Signal(int, int)       # row, col
    cell_edited     = Signal(int, int, str)  # row, col, new_raw

    def __init__(self, workbook: Workbook, sheet_name: str, parent=None):
        super().__init__(parent)
        self.wb         = workbook
        self.sheet_name = sheet_name

        # Selection state
        self._sel_row  = 0
        self._sel_col  = 0
        self._sel_row2 = 0   # for multi-cell selection
        self._sel_col2 = 0

        # Edit state
        self._editing     = False
        self._edit_text   = ""
        self._edit_cursor = 0

        # Column widths / row heights (overrides)
        self._col_widths: dict[int, int] = {}
        self._row_heights: dict[int, int] = {}

        # Resize dragging
        self._drag_col  = -1
        self._drag_row  = -1
        self._drag_start = 0

        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        self.viewport().setMouseTracking(True)

        # Clipboard
        self._clipboard_cells: list[list[str]] = []

        self._update_scrollbars()

    # ── public API ────────────────────────────────────────────────────────────
    def set_sheet(self, name: str):
        self.sheet_name = name
        self._sel_row = self._sel_col = 0
        self._sel_row2 = self._sel_col2 = 0
        self._editing = False
        self._update_scrollbars()
        self.viewport().update()

    def selected_cell(self):
        return self._sel_row, self._sel_col

    def selected_range(self):
        r1 = min(self._sel_row, self._sel_row2)
        r2 = max(self._sel_row, self._sel_row2)
        c1 = min(self._sel_col, self._sel_col2)
        c2 = max(self._sel_col, self._sel_col2)
        return r1, c1, r2, c2

    @property
    def _sheet(self):
        return self.wb.sheets.get(self.sheet_name)

    # ── geometry helpers ──────────────────────────────────────────────────────
    def _col_w(self, c: int) -> int:
        return self._col_widths.get(c, DEFAULT_COL_WIDTH)

    def _row_h(self, r: int) -> int:
        return self._row_heights.get(r, DEFAULT_ROW_HEIGHT)

    def _col_x(self, c: int) -> int:
        x = HEADER_WIDTH
        for i in range(c):
            x += self._col_w(i)
        return x - self.horizontalScrollBar().value()

    def _row_y(self, r: int) -> int:
        y = HEADER_HEIGHT
        for i in range(r):
            y += self._row_h(i)
        return y - self.verticalScrollBar().value()

    def _xy_to_cell(self, x: int, y: int):
        """Convert viewport (x,y) → (row, col) or None."""
        vp = self.viewport()
        if x < HEADER_WIDTH or y < HEADER_HEIGHT:
            return None
        cx = HEADER_WIDTH - self.horizontalScrollBar().value()
        col = 0
        while col < 100:
            cx += self._col_w(col)
            if x < cx:
                break
            col += 1
        cy = HEADER_HEIGHT - self.verticalScrollBar().value()
        row = 0
        while row < 1000:
            cy += self._row_h(row)
            if y < cy:
                break
            row += 1
        return row, col

    def _col_right_edge(self, c: int) -> int:
        return self._col_x(c) + self._col_w(c)

    def _row_bottom_edge(self, r: int) -> int:
        return self._row_y(r) + self._row_h(r)

    def _visible_range(self):
        vp    = self.viewport()
        w, h  = vp.width(), vp.height()
        scroll_x = self.horizontalScrollBar().value()
        scroll_y = self.verticalScrollBar().value()

        # first visible col
        cx  = 0
        col0 = 0
        while col0 < 200 and cx + self._col_w(col0) < scroll_x:
            cx += self._col_w(col0); col0 += 1
        # last visible col
        col1 = col0
        cx2  = HEADER_WIDTH
        while col1 < 200 and cx2 < w:
            cx2 += self._col_w(col1); col1 += 1
        col1 = min(col1 + 1, 200)

        # first visible row
        ry   = 0
        row0 = 0
        while row0 < 1000 and ry + self._row_h(row0) < scroll_y:
            ry += self._row_h(row0); row0 += 1
        # last visible row
        row1 = row0
        ry2  = HEADER_HEIGHT
        while row1 < 1000 and ry2 < h:
            ry2 += self._row_h(row1); row1 += 1
        row1 = min(row1 + 1, 1000)

        return row0, col0, row1, col1

    def _update_scrollbars(self):
        total_w = HEADER_WIDTH + sum(self._col_w(c) for c in range(100))
        total_h = HEADER_HEIGHT + sum(self._row_h(r) for r in range(200))
        vp = self.viewport()
        self.horizontalScrollBar().setRange(0, max(0, total_w - vp.width()))
        self.verticalScrollBar().setRange(0, max(0, total_h - vp.height()))
        self.horizontalScrollBar().setPageStep(vp.width())
        self.verticalScrollBar().setPageStep(vp.height())

    # ── painting ──────────────────────────────────────────────────────────────
    def paintEvent(self, event):
        painter = QPainter(self.viewport())
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        self._draw(painter)
        painter.end()

    def _draw(self, p: QPainter):
        vp   = self.viewport()
        w, h = vp.width(), vp.height()
        r0, c0, r1, c1 = self._visible_range()
        sr, sc, sr2, sc2 = self.selected_range()

        # ── background ──
        p.fillRect(0, 0, w, h, _COL["bg_deep"])

        # ── grid cells ──
        for row in range(r0, r1):
            ry = self._row_y(row)
            rh = self._row_h(row)
            for col in range(c0, c1):
                cx  = self._col_x(col)
                cw  = self._col_w(col)
                rect = QRect(cx, ry, cw, rh)

                in_sel = (sr <= row <= sr2 and sc <= col <= sc2)
                is_sel = (row == self._sel_row and col == self._sel_col)

                cell = None
                if self._sheet:
                    cell = self._sheet.cells.get((row, col))

                # background
                if is_sel and self._editing:
                    bg = _COL["bg_elevated"]
                elif in_sel:
                    bg = _COL["bg_selected"]
                elif cell and cell.cell_type == CellType.FORMULA:
                    bg = _COL["cell_formula"]
                elif cell and cell.cell_type == CellType.ERROR:
                    bg = _COL["cell_error"]
                else:
                    bg = _COL["bg_deep"]

                p.fillRect(rect, bg)

                # grid lines
                p.setPen(QPen(_COL["border"], 0.5))
                p.drawLine(cx + cw - 1, ry, cx + cw - 1, ry + rh)
                p.drawLine(cx, ry + rh - 1, cx + cw, ry + rh - 1)

                # text
                if is_sel and self._editing:
                    text = self._edit_text
                    tfont = _FONT_FORMULA if text.startswith("=") else _FONT_GRID
                    p.setFont(tfont)
                    p.setPen(_COL["text_primary"])
                    txt_rect = rect.adjusted(4, 1, -2, -1)
                    p.drawText(txt_rect, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, text)
                    # cursor
                    fm    = QFontMetrics(tfont)
                    cur_x = cx + 4 + fm.horizontalAdvance(text[:self._edit_cursor])
                    p.setPen(QPen(_COL["accent_blue"], 1))
                    p.drawLine(cur_x, ry + 3, cur_x, ry + rh - 4)
                elif cell and cell.cell_type != CellType.EMPTY:
                    display = cell.display_value()
                    if cell.cell_type == CellType.ERROR:
                        p.setFont(_FONT_GRID)
                        p.setPen(_COL["text_red"])
                        align = Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft
                    elif isinstance(cell.value, (int, float)):
                        p.setFont(_FONT_GRID)
                        p.setPen(_COL["text_primary"])
                        align = Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight
                    elif cell.is_formula():
                        p.setFont(_FONT_GRID)
                        p.setPen(_COL["text_cyan"])
                        align = Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft
                    else:
                        p.setFont(_FONT_GRID)
                        p.setPen(_COL["text_primary"])
                        align = Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft
                    txt_rect = rect.adjusted(4, 1, -4, -1)
                    p.drawText(txt_rect, align, display)

        # ── selection border ──
        if sr == sr2 and sc == sc2:
            sx = self._col_x(sc)
            sy = self._row_y(sr)
            sw = self._col_w(sc)
            sh = self._row_h(sr)
            p.setPen(QPen(_COL["accent_blue"], 2))
            p.drawRect(sx, sy, sw - 1, sh - 1)
        else:
            sx  = self._col_x(sc)
            sy  = self._row_y(sr)
            sx2 = self._col_x(sc2) + self._col_w(sc2)
            sy2 = self._row_y(sr2) + self._row_h(sr2)
            p.setPen(QPen(_COL["accent_blue"], 1.5))
            p.drawRect(sx, sy, sx2 - sx - 1, sy2 - sy - 1)

        # ── column headers ──
        p.fillRect(0, 0, w, HEADER_HEIGHT, _COL["bg_header"])
        p.setPen(QPen(_COL["border"], 0.5))
        p.drawLine(0, HEADER_HEIGHT - 1, w, HEADER_HEIGHT - 1)

        for col in range(c0, c1):
            cx = self._col_x(col)
            cw = self._col_w(col)
            in_sel = sc <= col <= sc2
            bg = _COL["bg_elevated"] if in_sel else _COL["bg_header"]
            p.fillRect(cx, 0, cw, HEADER_HEIGHT, bg)
            p.setPen(QPen(_COL["border"], 0.5))
            p.drawLine(cx + cw - 1, 0, cx + cw - 1, HEADER_HEIGHT)
            p.setFont(_FONT_HEADER)
            p.setPen(_COL["text_accent"] if in_sel else _COL["text_muted"])
            p.drawText(QRect(cx, 0, cw, HEADER_HEIGHT),
                       Qt.AlignmentFlag.AlignCenter, col_to_letter(col))

        # ── row headers ──
        p.fillRect(0, 0, HEADER_WIDTH, h, _COL["bg_header"])
        p.setPen(QPen(_COL["border"], 0.5))
        p.drawLine(HEADER_WIDTH - 1, 0, HEADER_WIDTH - 1, h)

        for row in range(r0, r1):
            ry = self._row_y(row)
            rh = self._row_h(row)
            in_sel = sr <= row <= sr2
            bg = _COL["bg_elevated"] if in_sel else _COL["bg_header"]
            p.fillRect(0, ry, HEADER_WIDTH, rh, bg)
            p.setPen(QPen(_COL["border"], 0.5))
            p.drawLine(0, ry + rh - 1, HEADER_WIDTH, ry + rh - 1)
            p.setFont(_FONT_HEADER)
            p.setPen(_COL["text_accent"] if in_sel else _COL["text_muted"])
            p.drawText(QRect(0, ry, HEADER_WIDTH, rh),
                       Qt.AlignmentFlag.AlignCenter, str(row + 1))

        # ── corner ──
        p.fillRect(0, 0, HEADER_WIDTH, HEADER_HEIGHT, _COL["bg_header"])
        p.setPen(QPen(_COL["border"], 0.5))
        p.drawLine(HEADER_WIDTH - 1, 0, HEADER_WIDTH - 1, HEADER_HEIGHT)
        p.drawLine(0, HEADER_HEIGHT - 1, HEADER_WIDTH, HEADER_HEIGHT - 1)

    # ── mouse ─────────────────────────────────────────────────────────────────
    def mousePressEvent(self, event: QMouseEvent):
        vp = self.viewport()
        x  = event.position().x()
        y  = event.position().y()

        if self._editing:
            self._commit_edit()

        result = self._xy_to_cell(int(x), int(y))
        if result:
            row, col = result
            mods = event.modifiers()
            if mods & Qt.KeyboardModifier.ShiftModifier:
                self._sel_row2 = row
                self._sel_col2 = col
            else:
                self._sel_row = self._sel_row2 = row
                self._sel_col = self._sel_col2 = col
            self.cell_selected.emit(row, col)
            vp.update()

        self.setFocus()

    def mouseDoubleClickEvent(self, event: QMouseEvent):
        result = self._xy_to_cell(int(event.position().x()), int(event.position().y()))
        if result:
            row, col = result
            self._sel_row = self._sel_row2 = row
            self._sel_col = self._sel_col2 = col
            self._start_edit()
        vp = self.viewport()
        vp.update()

    def mouseMoveEvent(self, event: QMouseEvent):
        if event.buttons() & Qt.MouseButton.LeftButton:
            result = self._xy_to_cell(int(event.position().x()), int(event.position().y()))
            if result:
                row, col = result
                self._sel_row2 = row
                self._sel_col2 = col
                self.viewport().update()

    def wheelEvent(self, event: QWheelEvent):
        delta = event.angleDelta().y()
        sb = self.verticalScrollBar()
        sb.setValue(sb.value() - delta // 3)

    def contextMenuEvent(self, event: QContextMenuEvent):
        menu = QMenu(self)
        menu.addAction("Copy",  self._copy).setShortcut("Ctrl+C")
        menu.addAction("Paste", self._paste).setShortcut("Ctrl+V")
        menu.addAction("Cut",   self._cut).setShortcut("Ctrl+X")
        menu.addSeparator()
        menu.addAction("Clear",        self._clear_selection)
        menu.addSeparator()
        menu.addAction("Insert Row",   self._insert_row_above)
        menu.addAction("Insert Column",self._insert_col_left)
        menu.addSeparator()
        menu.addAction("Column Width…", self._set_col_width)
        menu.exec(event.globalPos())

    # ── keyboard ──────────────────────────────────────────────────────────────
    def keyPressEvent(self, event: QKeyEvent):
        key  = event.key()
        mods = event.modifiers()
        ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)
        shft = bool(mods & Qt.KeyboardModifier.ShiftModifier)

        if self._editing:
            self._edit_key(event)
            return

        if ctrl:
            if key == Qt.Key.Key_C: self._copy(); return
            if key == Qt.Key.Key_V: self._paste(); return
            if key == Qt.Key.Key_X: self._cut(); return
            if key == Qt.Key.Key_Z: return  # undo stub
            if key == Qt.Key.Key_Home:
                self._sel_row = self._sel_col = 0
                self._sel_row2 = self._sel_col2 = 0
                self._ensure_visible(0, 0)
                self.viewport().update()
                self.cell_selected.emit(0, 0)
                return

        nav = {
            Qt.Key.Key_Up:    (-1,  0),
            Qt.Key.Key_Down:  ( 1,  0),
            Qt.Key.Key_Left:  ( 0, -1),
            Qt.Key.Key_Right: ( 0,  1),
            Qt.Key.Key_Tab:   ( 0,  1 if not shft else -1),
        }
        if key in nav:
            dr, dc = nav[key]
            if shft and key not in (Qt.Key.Key_Tab,):
                self._sel_row2 = max(0, min(999, self._sel_row2 + dr))
                self._sel_col2 = max(0, min(199, self._sel_col2 + dc))
            else:
                self._sel_row  = max(0, min(999, self._sel_row  + dr))
                self._sel_col  = max(0, min(199, self._sel_col  + dc))
                self._sel_row2 = self._sel_row
                self._sel_col2 = self._sel_col
            self._ensure_visible(self._sel_row, self._sel_col)
            self.viewport().update()
            self.cell_selected.emit(self._sel_row, self._sel_col)
            return

        if key == Qt.Key.Key_Return or key == Qt.Key.Key_F2:
            self._start_edit()
            return

        if key == Qt.Key.Key_Delete or key == Qt.Key.Key_Backspace:
            self._clear_selection()
            return

        if key == Qt.Key.Key_Escape:
            return

        text = event.text()
        if text and text.isprintable():
            self._start_edit(text)

    def _edit_key(self, event: QKeyEvent):
        key  = event.key()
        mods = event.modifiers()
        ctrl = bool(mods & Qt.KeyboardModifier.ControlModifier)

        if key == Qt.Key.Key_Escape:
            self._cancel_edit()
        elif key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self._commit_edit()
            self._sel_row  = min(999, self._sel_row + 1)
            self._sel_row2 = self._sel_row
            self._ensure_visible(self._sel_row, self._sel_col)
            self.cell_selected.emit(self._sel_row, self._sel_col)
        elif key == Qt.Key.Key_Tab:
            self._commit_edit()
            self._sel_col  = min(199, self._sel_col + 1)
            self._sel_col2 = self._sel_col
            self._ensure_visible(self._sel_row, self._sel_col)
            self.cell_selected.emit(self._sel_row, self._sel_col)
        elif key == Qt.Key.Key_Backspace:
            if self._edit_cursor > 0:
                self._edit_text   = self._edit_text[:self._edit_cursor - 1] + self._edit_text[self._edit_cursor:]
                self._edit_cursor -= 1
        elif key == Qt.Key.Key_Delete:
            self._edit_text = self._edit_text[:self._edit_cursor] + self._edit_text[self._edit_cursor + 1:]
        elif key == Qt.Key.Key_Left:
            self._edit_cursor = max(0, self._edit_cursor - 1)
        elif key == Qt.Key.Key_Right:
            self._edit_cursor = min(len(self._edit_text), self._edit_cursor + 1)
        elif key == Qt.Key.Key_Home:
            self._edit_cursor = 0
        elif key == Qt.Key.Key_End:
            self._edit_cursor = len(self._edit_text)
        else:
            text = event.text()
            if text and text.isprintable():
                self._edit_text = self._edit_text[:self._edit_cursor] + text + self._edit_text[self._edit_cursor:]
                self._edit_cursor += len(text)

        self.viewport().update()

    # ── edit helpers ──────────────────────────────────────────────────────────
    def _start_edit(self, initial: str = None):
        self._editing = True
        if initial is not None:
            self._edit_text   = initial
            self._edit_cursor = len(initial)
        else:
            cell = self._sheet.cells.get((self._sel_row, self._sel_col)) if self._sheet else None
            self._edit_text   = cell.raw if cell else ""
            self._edit_cursor = len(self._edit_text)
        self.viewport().update()

    def _commit_edit(self):
        if not self._editing:
            return
        text          = self._edit_text
        self._editing = False
        self.wb.set_cell(self.sheet_name, self._sel_row, self._sel_col, text)
        self.cell_edited.emit(self._sel_row, self._sel_col, text)
        self.viewport().update()

    def _cancel_edit(self):
        self._editing  = False
        self._edit_text = ""
        self.viewport().update()

    def _ensure_visible(self, row: int, col: int):
        vp = self.viewport()
        ry = self._row_y(row)
        rx = self._col_x(col)
        rh = self._row_h(row)
        rw = self._col_w(col)

        sb_v = self.verticalScrollBar()
        sb_h = self.horizontalScrollBar()

        if ry < HEADER_HEIGHT:
            sb_v.setValue(sb_v.value() + ry - HEADER_HEIGHT)
        elif ry + rh > vp.height():
            sb_v.setValue(sb_v.value() + ry + rh - vp.height())

        if rx < HEADER_WIDTH:
            sb_h.setValue(sb_h.value() + rx - HEADER_WIDTH)
        elif rx + rw > vp.width():
            sb_h.setValue(sb_h.value() + rx + rw - vp.width())

    # ── clipboard ─────────────────────────────────────────────────────────────
    def _copy(self):
        r1, c1, r2, c2 = self.selected_range()
        rows = []
        for r in range(r1, r2 + 1):
            cols = []
            for c in range(c1, c2 + 1):
                cell = self._sheet.cells.get((r, c)) if self._sheet else None
                cols.append(cell.raw if cell else "")
            rows.append("\t".join(cols))
        text = "\n".join(rows)
        QApplication.clipboard().setText(text)
        self._clipboard_cells = [row.split("\t") for row in rows]

    def _paste(self):
        text = QApplication.clipboard().text()
        if not text:
            return
        rows = text.split("\n")
        for dr, row_text in enumerate(rows):
            cols = row_text.split("\t")
            for dc, val in enumerate(cols):
                self.wb.set_cell(self.sheet_name,
                                 self._sel_row + dr,
                                 self._sel_col + dc,
                                 val)
        self.viewport().update()

    def _cut(self):
        self._copy()
        self._clear_selection()

    def _clear_selection(self):
        r1, c1, r2, c2 = self.selected_range()
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                self.wb.set_cell(self.sheet_name, r, c, "")
        self.cell_edited.emit(self._sel_row, self._sel_col, "")
        self.viewport().update()

    # ── row / col operations ──────────────────────────────────────────────────
    def _insert_row_above(self):
        r = self._sel_row
        sheet = self._sheet
        if not sheet:
            return
        # shift cells down
        to_move = sorted(
            [(r2, c2) for (r2, c2) in sheet.cells if r2 >= r],
            reverse=True
        )
        for (r2, c2) in to_move:
            cell = sheet.cells.pop((r2, c2))
            cell.row = r2 + 1
            sheet.cells[(r2 + 1, c2)] = cell
        self.wb.recalculate_all()
        self.viewport().update()

    def _insert_col_left(self):
        c = self._sel_col
        sheet = self._sheet
        if not sheet:
            return
        to_move = sorted(
            [(r2, c2) for (r2, c2) in sheet.cells if c2 >= c],
            reverse=True
        )
        for (r2, c2) in to_move:
            cell = sheet.cells.pop((r2, c2))
            cell.col = c2 + 1
            sheet.cells[(r2, c2 + 1)] = cell
        self.wb.recalculate_all()
        self.viewport().update()

    def _set_col_width(self):
        current = self._col_w(self._sel_col)
        val, ok = QInputDialog.getInt(self, "Column Width",
                                      "Width (px):", current, 20, 400)
        if ok:
            self._col_widths[self._sel_col] = val
            self.viewport().update()

    # ── resize event ──────────────────────────────────────────────────────────
    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_scrollbars()

    def scrollContentsBy(self, dx, dy):
        self.viewport().update()
