"""
ui/theme.py — Anglo-futurist dark theme for Abacus.
"""
from config import COLORS as C, FONT_UI, FONT_MONO, FONT_SIZE


def apply_theme(app):
    app.setStyleSheet(_STYLESHEET)


_STYLESHEET = f"""
/* ═══════════════════════════════════════════════════════════════════
   ABACUS — Anglo-Futurist Dark Theme
═══════════════════════════════════════════════════════════════════ */

QWidget {{
    background-color: {C['bg_deep']};
    color: {C['text_primary']};
    font-family: {FONT_UI};
    font-size: {FONT_SIZE}px;
    selection-background-color: {C['bg_selected']};
    selection-color: {C['text_primary']};
}}

/* ── Main window ─────────────────────────────────────────────────── */
QMainWindow {{
    background: {C['bg_deep']};
}}
QMainWindow::separator {{
    background: {C['border']};
    width: 1px;
    height: 1px;
}}

/* ── Menu bar ────────────────────────────────────────────────────── */
QMenuBar {{
    background: {C['bg_surface']};
    color: {C['text_secondary']};
    border-bottom: 1px solid {C['border']};
    padding: 2px 4px;
    spacing: 2px;
}}
QMenuBar::item {{
    padding: 4px 10px;
    border-radius: 3px;
}}
QMenuBar::item:selected {{
    background: {C['bg_hover']};
    color: {C['text_primary']};
}}
QMenu {{
    background: {C['bg_elevated']};
    border: 1px solid {C['border_light']};
    padding: 4px 0;
}}
QMenu::item {{
    padding: 6px 24px 6px 14px;
    color: {C['text_secondary']};
}}
QMenu::item:selected {{
    background: {C['bg_hover']};
    color: {C['text_primary']};
}}
QMenu::separator {{
    height: 1px;
    background: {C['border']};
    margin: 4px 8px;
}}

/* ── Toolbar ─────────────────────────────────────────────────────── */
QToolBar {{
    background: {C['bg_surface']};
    border-bottom: 1px solid {C['border']};
    padding: 4px 8px;
    spacing: 4px;
}}
QToolButton {{
    background: transparent;
    color: {C['text_secondary']};
    border: 1px solid transparent;
    border-radius: 4px;
    padding: 4px 8px;
    font-size: {FONT_SIZE}px;
}}
QToolButton:hover {{
    background: {C['bg_hover']};
    border-color: {C['border_light']};
    color: {C['text_primary']};
}}
QToolButton:pressed {{
    background: {C['bg_selected']};
}}
QToolButton:checked {{
    background: {C['bg_selected']};
    border-color: {C['accent_blue']};
    color: {C['text_accent']};
}}

/* ── Tab bar (sheets) ────────────────────────────────────────────── */
QTabBar {{
    background: {C['bg_surface']};
}}
QTabBar::tab {{
    background: {C['bg_surface']};
    color: {C['text_muted']};
    border: none;
    border-top: 2px solid transparent;
    padding: 6px 20px;
    font-size: 10px;
    letter-spacing: 0.5px;
    text-transform: uppercase;
}}
QTabBar::tab:selected {{
    color: {C['text_accent']};
    border-top-color: {C['accent_blue']};
    background: {C['bg_elevated']};
}}
QTabBar::tab:hover:!selected {{
    color: {C['text_secondary']};
    background: {C['bg_hover']};
}}
QTabWidget::pane {{
    border: none;
    border-top: 1px solid {C['border']};
    background: {C['bg_deep']};
}}

/* ── Formula bar ─────────────────────────────────────────────────── */
QLineEdit#formula_bar {{
    background: {C['bg_panel']};
    border: 1px solid {C['border']};
    border-radius: 3px;
    padding: 4px 10px;
    color: {C['text_primary']};
    font-family: {FONT_MONO};
    font-size: {FONT_SIZE}px;
    selection-background-color: {C['accent_blue_dim']};
}}
QLineEdit#formula_bar:focus {{
    border-color: {C['accent_blue']};
}}
QLineEdit#cell_ref {{
    background: {C['bg_panel']};
    border: 1px solid {C['border']};
    border-radius: 3px;
    padding: 4px 8px;
    color: {C['text_gold']};
    font-family: {FONT_MONO};
    font-size: {FONT_SIZE}px;
    max-width: 80px;
}}

/* ── Status bar ──────────────────────────────────────────────────── */
QStatusBar {{
    background: {C['bg_surface']};
    border-top: 1px solid {C['border']};
    color: {C['text_muted']};
    font-size: 10px;
    padding: 0 8px;
}}
QStatusBar QLabel {{
    color: {C['text_muted']};
    padding: 2px 8px;
    border-right: 1px solid {C['border']};
}}

/* ── Splitter ────────────────────────────────────────────────────── */
QSplitter::handle {{
    background: {C['border']};
    width: 1px;
    height: 1px;
}}
QSplitter::handle:hover {{
    background: {C['accent_blue']};
}}

/* ── Scrollbars ──────────────────────────────────────────────────── */
QScrollBar:vertical {{
    background: {C['bg_surface']};
    width: 10px;
    margin: 0;
}}
QScrollBar::handle:vertical {{
    background: {C['border_light']};
    min-height: 30px;
    border-radius: 5px;
    margin: 1px;
}}
QScrollBar::handle:vertical:hover {{
    background: {C['text_muted']};
}}
QScrollBar:horizontal {{
    background: {C['bg_surface']};
    height: 10px;
    margin: 0;
}}
QScrollBar::handle:horizontal {{
    background: {C['border_light']};
    min-width: 30px;
    border-radius: 5px;
    margin: 1px;
}}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}

/* ── AI Panel ────────────────────────────────────────────────────── */
QWidget#ai_panel {{
    background: {C['bg_panel']};
    border-left: 1px solid {C['border']};
}}
QTextEdit#ai_output {{
    background: {C['bg_panel']};
    border: none;
    color: {C['text_secondary']};
    font-family: {FONT_UI};
    font-size: {FONT_SIZE}px;
    padding: 8px;
}}
QLineEdit#ai_input {{
    background: {C['bg_elevated']};
    border: 1px solid {C['border_light']};
    border-radius: 4px;
    padding: 6px 12px;
    color: {C['text_primary']};
    font-size: {FONT_SIZE}px;
}}
QLineEdit#ai_input:focus {{
    border-color: {C['accent_blue']};
}}

/* ── Buttons ─────────────────────────────────────────────────────── */
QPushButton {{
    background: {C['bg_elevated']};
    color: {C['text_secondary']};
    border: 1px solid {C['border_light']};
    border-radius: 4px;
    padding: 5px 14px;
    font-size: {FONT_SIZE}px;
}}
QPushButton:hover {{
    background: {C['bg_hover']};
    color: {C['text_primary']};
    border-color: {C['border_accent']};
}}
QPushButton:pressed {{
    background: {C['bg_selected']};
}}
QPushButton#primary_btn {{
    background: {C['accent_blue_dim']};
    color: {C['text_accent']};
    border-color: {C['accent_blue']};
}}
QPushButton#primary_btn:hover {{
    background: {C['accent_blue']};
    color: white;
}}

/* ── Labels ──────────────────────────────────────────────────────── */
QLabel#title_label {{
    color: {C['text_gold']};
    font-size: 11px;
    font-weight: bold;
    letter-spacing: 1px;
    padding: 4px 8px;
}}
QLabel#section_label {{
    color: {C['text_muted']};
    font-size: 9px;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    padding: 2px 4px;
}}

/* ── Context menu ────────────────────────────────────────────────── */
QMenu#context_menu {{
    background: {C['bg_elevated']};
    border: 1px solid {C['border_light']};
}}

/* ── Graph view canvas ───────────────────────────────────────────── */
QWidget#graph_view {{
    background: {C['bg_deep']};
    border: none;
}}
"""
